// Copyright (c) 2025 Huawei Technologies Co., Ltd.

#include "register/op_def_registry.h"

namespace ops {
class KvcacheScatterLocalAiv : public OpDef {
public:
    explicit KvcacheScatterLocalAiv(const char* name) : OpDef(name)
    {
        this->Input("hbm_kpe").ParamType(REQUIRED).DataType({ge::DT_FLOAT16})
            .Format({ge::FORMAT_ND});
        this->Input("hbm_ckv").ParamType(REQUIRED).DataType({ge::DT_FLOAT16})
            .Format({ge::FORMAT_ND});
        this->Input("hbm_staging").ParamType(REQUIRED).DataType({ge::DT_UINT8})
            .Format({ge::FORMAT_ND});
        this->Input("hbm_block_table").ParamType(REQUIRED).DataType({ge::DT_INT32})
            .Format({ge::FORMAT_ND});
        this->Input("src_token_ids").ParamType(REQUIRED).DataType({ge::DT_INT32})
            .Format({ge::FORMAT_ND});
        this->Input("dst_slots").ParamType(REQUIRED).DataType({ge::DT_INT32})
            .Format({ge::FORMAT_ND});
        this->Input("copy_counts").ParamType(REQUIRED).DataType({ge::DT_INT32})
            .Format({ge::FORMAT_ND});
        this->Output("hbm_kpe").ParamType(REQUIRED).DataType({ge::DT_FLOAT16})
            .Format({ge::FORMAT_ND});
        this->Output("hbm_ckv").ParamType(REQUIRED).DataType({ge::DT_FLOAT16})
            .Format({ge::FORMAT_ND});
        this->AICore().AddConfig("ascend910_93").AddConfig("ascend950");
    }
};
OP_ADD(KvcacheScatterLocalAiv);
}  // namespace ops
