// Copyright (c) 2025 Huawei Technologies Co., Ltd.
#pragma once

#include "register/tilingdata_base.h"

namespace optiling {
BEGIN_TILING_DATA_DEF(KvcacheScatterLocalAivTilingData)
TILING_DATA_FIELD_DEF(int64_t, usedCoreNum);
TILING_DATA_FIELD_DEF(int64_t, totalPairSlots);
TILING_DATA_FIELD_DEF(int64_t, batchSize);
TILING_DATA_FIELD_DEF(int64_t, copyCap);
TILING_DATA_FIELD_DEF(int64_t, hbmMaxBlocks);
TILING_DATA_FIELD_DEF(int64_t, dramMaxBlocks);
TILING_DATA_FIELD_DEF(int64_t, tokenLayout);
TILING_DATA_FIELD_DEF(int64_t, tokenBytes);
END_TILING_DATA_DEF;

REGISTER_TILING_DATA_CLASS(KvcacheScatterLocalAiv, KvcacheScatterLocalAivTilingData)
}  // namespace optiling
