// Copyright (c) 2025 Huawei Technologies Co., Ltd.

#include "kvcache_scatter_local_aiv_tiling.h"

#include "exe_graph/runtime/tiling_context.h"
#include "platform/platform_info.h"
#include "register/op_impl_registry.h"
#include "tiling/platform/platform_ascendc.h"

namespace optiling {
namespace {
constexpr int64_t kBlockBytes = 128 * (1024 + 128);
constexpr int64_t kTokenBytes = 1024 + 128;
constexpr int64_t kFlatFp8TokenBytes = 576;
constexpr int64_t kFlatC8TokenBytes = 656;
constexpr int64_t kCopyCap = 16384;

ge::graphStatus Tiling(gert::TilingContext* context)
{
    const auto* counts = context->GetInputShape(6);
    const auto* table = context->GetInputShape(3);
    const auto* staging = context->GetInputShape(2);
    if (counts == nullptr || table == nullptr || staging == nullptr) return ge::GRAPH_FAILED;
    const auto countShape = counts->GetStorageShape();
    const auto tableShape = table->GetStorageShape();
    const auto stagingShape = staging->GetStorageShape();
    if (countShape.GetDimNum() != 1 || tableShape.GetDimNum() != 2 ||
        countShape.GetDim(0) <= 0) {
        return ge::GRAPH_FAILED;
    }
    const int64_t batch = countShape.GetDim(0);
    const int64_t tokenLayout = stagingShape.GetDimNum() == 2 ? 1 : 0;
    const int64_t tokenBytes = tokenLayout != 0 ? stagingShape.GetDim(1) : kTokenBytes;
    if ((tokenLayout == 0 && stagingShape.GetDimNum() != 1) ||
        (tokenLayout != 0 &&
         (stagingShape.GetDim(0) <= 0 ||
          (tokenBytes != kTokenBytes && tokenBytes != kFlatFp8TokenBytes &&
           tokenBytes != kFlatC8TokenBytes)))) {
        return ge::GRAPH_FAILED;
    }
    const int64_t stagingBytes = tokenLayout != 0 ?
        stagingShape.GetDim(0) * stagingShape.GetDim(1) :
        stagingShape.GetDim(0);
    if (tokenLayout == 0 && stagingBytes % (batch * kBlockBytes) != 0) {
        return ge::GRAPH_FAILED;
    }
    const int64_t dramMaxBlocks = tokenLayout != 0 ?
        tableShape.GetDim(1) : stagingBytes / (batch * kBlockBytes);
    const auto platform =
        platform_ascendc::PlatformAscendC(context->GetPlatformInfo());
    const int64_t cores = platform.GetCoreNumAiv();
    const int64_t pairSlots = batch * kCopyCap;
    KvcacheScatterLocalAivTilingData data;
    data.set_usedCoreNum(pairSlots < cores ? pairSlots : cores);
    data.set_totalPairSlots(pairSlots);
    data.set_batchSize(batch);
    data.set_copyCap(kCopyCap);
    data.set_hbmMaxBlocks(tableShape.GetDim(1));
    data.set_dramMaxBlocks(dramMaxBlocks);
    data.set_tokenLayout(tokenLayout);
    data.set_tokenBytes(tokenBytes);
    context->SetBlockDim(data.get_usedCoreNum());
    context->SetTilingKey(1);
    auto* raw = context->GetRawTilingData();
    data.SaveToBuffer(raw->GetData(), raw->GetCapacity());
    raw->SetDataSize(data.GetDataSize());
    context->GetWorkspaceSizes(1)[0] = 32;
    return ge::GRAPH_SUCCESS;
}

// This operator has no platform-specific compile-info payload. Register an
// explicit parser so CANN does not fall back to the auto parser, which expects
// a generated `_pattern` field that is absent from this operator's package.
struct KvcacheScatterLocalAivCompileInfo {};

ge::graphStatus ParseKvcacheScatterLocalAivCompileInfo(
    gert::TilingParseContext* context)
{
    (void)context;
    return ge::GRAPH_SUCCESS;
}
}  // namespace

IMPL_OP_OPTILING(KvcacheScatterLocalAiv)
    .Tiling(Tiling)
    .TilingParse<KvcacheScatterLocalAivCompileInfo>(
        ParseKvcacheScatterLocalAivCompileInfo);
}  // namespace optiling
