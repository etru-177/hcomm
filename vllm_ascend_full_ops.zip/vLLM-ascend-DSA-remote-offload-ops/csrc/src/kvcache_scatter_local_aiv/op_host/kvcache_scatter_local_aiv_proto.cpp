// Copyright (c) 2025 Huawei Technologies Co., Ltd.

#include <register/op_impl_registry.h>

namespace ops {
static ge::graphStatus InferShape(gert::InferShapeContext* context)
{
    *context->GetOutputShape(0) = *context->GetInputShape(0);
    *context->GetOutputShape(1) = *context->GetInputShape(1);
    return ge::GRAPH_SUCCESS;
}

static ge::graphStatus InferDtype(gert::InferDataTypeContext* context)
{
    context->SetOutputDataType(0, context->GetInputDataType(0));
    context->SetOutputDataType(1, context->GetInputDataType(1));
    return ge::GRAPH_SUCCESS;
}

IMPL_OP_INFERSHAPE(KvcacheScatterLocalAiv)
    .InferShape(InferShape)
    .InferDataType(InferDtype);
}  // namespace ops
