// Copyright (c) 2025 Huawei Technologies Co., Ltd.

#include "kernel_operator.h"
#include "kvcache_scatter_local_aiv_kernel.h"

using namespace AscendC;

extern "C" __global__ __aicore__ void kvcache_scatter_local_aiv(
    GM_ADDR hbmKpe, GM_ADDR hbmCkv, GM_ADDR staging, GM_ADDR hbmBlockTable,
    GM_ADDR srcTokenIds, GM_ADDR dstSlots, GM_ADDR copyCounts,
    GM_ADDR hbmKpeOut, GM_ADDR hbmCkvOut, GM_ADDR workspace, GM_ADDR tiling)
{
    if (g_coreType == AIC) return;
    TPipe pipe;
    GET_TILING_DATA(data, tiling);
    if (TILING_KEY_IS(1)) {
        KvcacheScatterLocalAivKernel<uint16_t> kernel(&pipe, &data);
        kernel.Init(hbmKpeOut, hbmCkvOut, staging, hbmBlockTable,
            srcTokenIds, dstSlots, copyCounts);
        kernel.Process();
    }
}
