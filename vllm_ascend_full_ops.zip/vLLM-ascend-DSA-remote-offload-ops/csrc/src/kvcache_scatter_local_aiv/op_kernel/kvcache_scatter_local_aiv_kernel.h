// Copyright (c) 2025 Huawei Technologies Co., Ltd.
#pragma once

#include "kernel_operator.h"

using namespace AscendC;

constexpr int64_t kLocalBlockSize = 128;
constexpr int64_t kLocalBlockShift = 7;
constexpr int64_t kLocalBlockMask = 127;
constexpr int64_t kLocalCkvBytes = 1024;
constexpr int64_t kLocalKpeBytes = 128;
constexpr int64_t kLocalTokenBytes = kLocalCkvBytes + kLocalKpeBytes;
constexpr int64_t kLocalBlockBytes =
    kLocalBlockSize * kLocalTokenBytes;

template <typename T>
class KvcacheScatterLocalAivKernel {
public:
    __aicore__ inline KvcacheScatterLocalAivKernel(
        TPipe* pipe, const KvcacheScatterLocalAivTilingData* tiling)
        : pipe_(pipe), tiling_(tiling)
    {}

    __aicore__ inline void Init(GM_ADDR hbmKpe, GM_ADDR hbmCkv, GM_ADDR staging,
        GM_ADDR hbmBlockTable, GM_ADDR srcTokenIds, GM_ADDR dstSlots,
        GM_ADDR copyCounts)
    {
        blockIdx_ = GetBlockIdx();
        pipe_->InitBuffer(queue_, 1, kLocalTokenBytes);
        hbmKpe_.SetGlobalBuffer(reinterpret_cast<__gm__ T*>(hbmKpe));
        hbmCkv_.SetGlobalBuffer(reinterpret_cast<__gm__ T*>(hbmCkv));
        staging_.SetGlobalBuffer(reinterpret_cast<__gm__ T*>(staging));
        hbmTable_.SetGlobalBuffer(reinterpret_cast<__gm__ int32_t*>(hbmBlockTable));
        srcIds_.SetGlobalBuffer(reinterpret_cast<__gm__ int32_t*>(srcTokenIds));
        dstSlots_.SetGlobalBuffer(reinterpret_cast<__gm__ int32_t*>(dstSlots));
        counts_.SetGlobalBuffer(reinterpret_cast<__gm__ int32_t*>(copyCounts));
    }

    __aicore__ inline void Process()
    {
        if (blockIdx_ >= tiling_->usedCoreNum) return;
        if (tiling_->tokenLayout != 0) {
            int64_t sourceBase = 0;
            for (int64_t batch = 0; batch < tiling_->batchSize; ++batch) {
                const int64_t count = counts_.GetValue(batch);
                for (int64_t copy = blockIdx_; copy < count;
                     copy += tiling_->usedCoreNum) {
                    CopyOne(batch, copy, sourceBase + copy);
                }
                sourceBase += count;
            }
            return;
        }
        for (int64_t flat = blockIdx_; flat < tiling_->totalPairSlots;
             flat += tiling_->usedCoreNum) {
            const int64_t batch = flat / tiling_->copyCap;
            const int64_t copy = flat - batch * tiling_->copyCap;
            if (copy < counts_.GetValue(batch)) CopyOne(batch, copy, -1);
        }
    }

private:
    __aicore__ inline void CopyOne(
        int64_t batch, int64_t copy, int64_t sourceOrdinal)
    {
        const int64_t item = batch * tiling_->copyCap + copy;
        const int32_t srcToken = srcIds_.GetValue(item);
        const int32_t dstToken = dstSlots_.GetValue(item);
        if (srcToken < 0 || dstToken < 0) return;
        const int64_t srcBlock = static_cast<int64_t>(srcToken) >> kLocalBlockShift;
        const int64_t dstBlock = static_cast<int64_t>(dstToken) >> kLocalBlockShift;
        if ((sourceOrdinal < 0 && srcBlock >= tiling_->dramMaxBlocks) ||
            dstBlock >= tiling_->hbmMaxBlocks) return;
        const int32_t physicalBlock =
            hbmTable_.GetValue(batch * tiling_->hbmMaxBlocks + dstBlock);
        if (physicalBlock < 0) return;
        const int64_t srcOffset = static_cast<int64_t>(srcToken) & kLocalBlockMask;
        const int64_t dstOffset = static_cast<int64_t>(dstToken) & kLocalBlockMask;
        if (sourceOrdinal >= 0 && tiling_->tokenBytes != kLocalTokenBytes) {
            const int64_t source =
                sourceOrdinal * tiling_->tokenBytes / sizeof(T);
            const int64_t destinationBytes =
                static_cast<int64_t>(physicalBlock) *
                    kLocalBlockSize * tiling_->tokenBytes +
                dstOffset * tiling_->tokenBytes;
            const int64_t destination = destinationBytes / sizeof(T);
            LocalTensor<T> local = queue_.AllocTensor<T>();
            DataCopyPadExtParams<T> pad{false, 0, 0, 0};
            DataCopyExtParams copyBytes{
                1, static_cast<uint32_t>(tiling_->tokenBytes), 0, 0, 0};
            DataCopyPad(local, staging_[source], copyBytes, pad);
            queue_.EnQue(local);
            local = queue_.DeQue<T>();
            DataCopyPad(hbmCkv_[destination], local, copyBytes);
            queue_.FreeTensor(local);
            return;
        }
        int64_t sourceCkv = 0;
        int64_t sourceKpe = 0;
        if (sourceOrdinal >= 0) {
            const int64_t sourceBytes =
                sourceOrdinal * kLocalTokenBytes;
            sourceCkv = sourceBytes / sizeof(T);
            sourceKpe = (sourceBytes + kLocalCkvBytes) / sizeof(T);
        } else {
            const int64_t sourceBytes =
                (batch * tiling_->dramMaxBlocks + srcBlock) * kLocalBlockBytes;
            sourceCkv =
                (sourceBytes + srcOffset * kLocalCkvBytes) / sizeof(T);
            sourceKpe =
                (sourceBytes + kLocalBlockSize * kLocalCkvBytes +
                 srcOffset * kLocalKpeBytes) / sizeof(T);
        }
        const int64_t destinationToken =
            static_cast<int64_t>(physicalBlock) * kLocalBlockSize + dstOffset;
        const int64_t destinationCkv =
            destinationToken * kLocalCkvBytes / sizeof(T);
        const int64_t destinationKpe =
            destinationToken * kLocalKpeBytes / sizeof(T);

        LocalTensor<T> local = queue_.AllocTensor<T>();
        DataCopyPadExtParams<T> pad{false, 0, 0, 0};
        DataCopyExtParams ckv{1, kLocalCkvBytes, 0, 0, 0};
        DataCopyExtParams kpe{1, kLocalKpeBytes, 0, 0, 0};
        DataCopyPad(local, staging_[sourceCkv], ckv, pad);
        DataCopyPad(local[kLocalCkvBytes / sizeof(T)], staging_[sourceKpe], kpe, pad);
        queue_.EnQue(local);
        local = queue_.DeQue<T>();
        DataCopyPad(hbmCkv_[destinationCkv], local, ckv);
        DataCopyPad(hbmKpe_[destinationKpe],
            local[kLocalCkvBytes / sizeof(T)], kpe);
        queue_.FreeTensor(local);
    }

    TPipe* pipe_;
    const KvcacheScatterLocalAivTilingData* tiling_;
    int64_t blockIdx_ = 0;
    GlobalTensor<T> hbmKpe_;
    GlobalTensor<T> hbmCkv_;
    GlobalTensor<T> staging_;
    GlobalTensor<int32_t> hbmTable_;
    GlobalTensor<int32_t> srcIds_;
    GlobalTensor<int32_t> dstSlots_;
    GlobalTensor<int32_t> counts_;
    TQueBind<QuePosition::VECIN, QuePosition::VECOUT, 1> queue_;
};
