/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2026. All rights reserved.
 */

#ifndef KVCACHE_SCATTER_COPY_HCOMM_BATCH_COPY_H_
#define KVCACHE_SCATTER_COPY_HCOMM_BATCH_COPY_H_

#include <cstddef>
#include <cstdint>

#if defined(__GNUC__)
#define HCOMM_BATCH_COPY_API __attribute__((visibility("default")))
#else
#define HCOMM_BATCH_COPY_API
#endif

// ABI supplied by Hcomm. Source entries hold opaque 64-bit GVAs cast to
// pointers; Hcomm resolves them through its memory pool.
struct HybmBatchCopyParam {
    const void* const* srcDdrPtrList;
    void* const* dstHbmPtrList;
    const uint64_t* lengthList;
    uint64_t size;
};

extern "C" HCOMM_BATCH_COPY_API uint32_t HybmBatchCopy(void* args);

#undef HCOMM_BATCH_COPY_API

namespace hcomm {

constexpr uint32_t HCOMM_SUCCESS = 0;
constexpr uint32_t HCOMM_INVALID_ARGUMENT = 1;

} // namespace hcomm

#endif // KVCACHE_SCATTER_COPY_HCOMM_BATCH_COPY_H_
