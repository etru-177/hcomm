/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2026. All rights reserved.
 */

#ifndef KVCACHE_SCATTER_COPY_AICPU_IMPL_H_
#define KVCACHE_SCATTER_COPY_AICPU_IMPL_H_

#include <array>
#include <cstdint>

#include "hcomm_batch_copy.h"

namespace kvcache_scatter_copy_aicpu {

constexpr int64_t BLOCK_SIZE = 128;
constexpr int64_t BLOCK_SHIFT = 7;
constexpr int64_t BLOCK_MASK = BLOCK_SIZE - 1;
constexpr int64_t K_ROPE_DIM = 64;
constexpr int64_t KV_CACHE_DIM = 512;
constexpr int64_t COPY_CAP = 16384;
constexpr size_t ELEMENT_BYTES = sizeof(uint16_t);
constexpr size_t K_ROPE_TOKEN_BYTES = K_ROPE_DIM * ELEMENT_BYTES;
constexpr size_t KV_CACHE_TOKEN_BYTES = KV_CACHE_DIM * ELEMENT_BYTES;
constexpr size_t HCOMM_BATCH_REQUEST_CAPACITY = 128;
static_assert(HCOMM_BATCH_REQUEST_CAPACITY % 2 == 0, "a token emits CKV and KPE requests");

enum Status : uint32_t {
    STATUS_SUCCESS = 0,
    STATUS_PARAM_INVALID = 1,
    STATUS_INNER_ERROR = 2,
};

struct CopyParams {
    uint8_t* hbmKRoPE = nullptr;
    uint8_t* hbmKvCache = nullptr;
    const uint8_t* dramKRoPE = nullptr;
    const uint8_t* dramKvCache = nullptr;
    const int32_t* hbmBlockTable = nullptr;
    const uint64_t* dramBlockTable = nullptr;
    const int32_t* srcTokenIds = nullptr;
    const int32_t* dstSlots = nullptr;
    const int32_t* copyCounts = nullptr;
    int64_t hbmBlockCount = 0;
    int64_t dramBlockCount = 0;
    int64_t hbmMaxBlockNum = 0;
    int64_t dramMaxBlockNum = 0;
    int64_t batchSize = 0;
};

using BatchCopyFunction = uint32_t (*)(void*);

inline void StoreReadyFlag(int32_t* readyFlag, int32_t value)
{
    if (readyFlag != nullptr) {
#if defined(__GNUC__)
        __atomic_store_n(readyFlag, value, __ATOMIC_RELEASE);
#else
        *readyFlag = value;
#endif
    }
}

inline uint32_t BuildCopyRequestPair(const CopyParams& params, int64_t batchIdx,
    int64_t copyIdx, void*& ckvDst, uint64_t& ckvGva, void*& kpeDst, uint64_t& kpeGva)
{
    const int64_t pairOffset = batchIdx * COPY_CAP + copyIdx;
    const int32_t srcTokenId = params.srcTokenIds[pairOffset];
    const int32_t dstSlot = params.dstSlots[pairOffset];
    if (srcTokenId < 0 || dstSlot < 0) {
        return STATUS_PARAM_INVALID;
    }

    const int64_t srcBlockCol = static_cast<int64_t>(srcTokenId) >> BLOCK_SHIFT;
    const int64_t srcBlockOffset = static_cast<int64_t>(srcTokenId) & BLOCK_MASK;
    const int64_t dstBlockCol = static_cast<int64_t>(dstSlot) >> BLOCK_SHIFT;
    const int64_t dstBlockOffset = static_cast<int64_t>(dstSlot) & BLOCK_MASK;
    if (srcBlockCol >= params.dramMaxBlockNum || dstBlockCol >= params.hbmMaxBlockNum) {
        return STATUS_PARAM_INVALID;
    }

    const uint64_t srcBlockGva =
        params.dramBlockTable[batchIdx * params.dramMaxBlockNum + srcBlockCol];
    const int32_t dstPhysicalBlock =
        params.hbmBlockTable[batchIdx * params.hbmMaxBlockNum + dstBlockCol];
    if (srcBlockGva == 0 || dstPhysicalBlock < 0 ||
        static_cast<int64_t>(dstPhysicalBlock) >= params.hbmBlockCount) {
        return STATUS_PARAM_INVALID;
    }

    const int64_t dstTokenOffset =
        static_cast<int64_t>(dstPhysicalBlock) * BLOCK_SIZE + dstBlockOffset;

    // Mock remote-block layout: [128 CKV tokens][128 KPE tokens].
    ckvGva = srcBlockGva + static_cast<uint64_t>(srcBlockOffset) * KV_CACHE_TOKEN_BYTES;
    kpeGva = srcBlockGva + BLOCK_SIZE * KV_CACHE_TOKEN_BYTES +
        static_cast<uint64_t>(srcBlockOffset) * K_ROPE_TOKEN_BYTES;
    ckvDst = params.hbmKvCache + dstTokenOffset * KV_CACHE_TOKEN_BYTES;
    kpeDst = params.hbmKRoPE + dstTokenOffset * K_ROPE_TOKEN_BYTES;
    return STATUS_SUCCESS;
}

inline uint32_t DispatchBatchCopyRequests(const CopyParams& params,
    BatchCopyFunction batchCopy, uint32_t& hcommStatus)
{
    hcommStatus = hcomm::HCOMM_SUCCESS;
    if (batchCopy == nullptr || params.copyCounts == nullptr) {
        return STATUS_PARAM_INVALID;
    }

    // Fixed-size stack storage avoids both request-vector allocation and a full
    // O(total_copy_count) prebuild before the first Hcomm submission.
    std::array<void*, HCOMM_BATCH_REQUEST_CAPACITY> dstHbm;
    std::array<uint64_t, HCOMM_BATCH_REQUEST_CAPACITY> srcGva;
    std::array<const void*, HCOMM_BATCH_REQUEST_CAPACITY> srcDdrPtr;
    std::array<uint64_t, HCOMM_BATCH_REQUEST_CAPACITY> copyBytes;
    size_t requestCount = 0;
    for (int64_t batchIdx = 0; batchIdx < params.batchSize; ++batchIdx) {
        const int32_t copyCount = params.copyCounts[batchIdx];
        for (int64_t copyIdx = 0; copyIdx < copyCount; ++copyIdx) {
            const uint32_t status = BuildCopyRequestPair(params, batchIdx, copyIdx,
                dstHbm[requestCount], srcGva[requestCount], dstHbm[requestCount + 1],
                srcGva[requestCount + 1]);
            if (status != STATUS_SUCCESS) {
                return status;
            }
            copyBytes[requestCount] = KV_CACHE_TOKEN_BYTES;
            copyBytes[requestCount + 1] = K_ROPE_TOKEN_BYTES;
            srcDdrPtr[requestCount] = reinterpret_cast<const void*>(static_cast<uintptr_t>(srcGva[requestCount]));
            srcDdrPtr[requestCount + 1] = reinterpret_cast<const void*>(static_cast<uintptr_t>(srcGva[requestCount + 1]));
            requestCount += 2;
            if (requestCount == dstHbm.size()) {
                HybmBatchCopyParam batchParam = {srcDdrPtr.data(), dstHbm.data(),
                    copyBytes.data(), static_cast<uint64_t>(requestCount)};
                hcommStatus = batchCopy(&batchParam);
                if (hcommStatus != hcomm::HCOMM_SUCCESS) {
                    return STATUS_INNER_ERROR;
                }
                requestCount = 0;
            }
        }
    }

    if (requestCount != 0) {
        HybmBatchCopyParam batchParam = {srcDdrPtr.data(), dstHbm.data(),
            copyBytes.data(), static_cast<uint64_t>(requestCount)};
        hcommStatus = batchCopy(&batchParam);
        if (hcommStatus != hcomm::HCOMM_SUCCESS) {
            return STATUS_INNER_ERROR;
        }
    }
    return STATUS_SUCCESS;
}

} // namespace kvcache_scatter_copy_aicpu

#endif // KVCACHE_SCATTER_COPY_AICPU_IMPL_H_
