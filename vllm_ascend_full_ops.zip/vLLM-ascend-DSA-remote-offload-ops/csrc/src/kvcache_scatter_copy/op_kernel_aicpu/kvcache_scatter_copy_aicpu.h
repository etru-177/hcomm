/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2026. All rights reserved.
 */

#ifndef KVCACHE_SCATTER_COPY_AICPU_H_
#define KVCACHE_SCATTER_COPY_AICPU_H_

#include "cpu_kernel.h"

namespace aicpu {

class KvcacheScatterCopyAicpuKernel : public CpuKernel {
public:
    ~KvcacheScatterCopyAicpuKernel() = default;
    uint32_t Compute(CpuKernelContext& ctx) override;
};

} // namespace aicpu

#endif // KVCACHE_SCATTER_COPY_AICPU_H_
