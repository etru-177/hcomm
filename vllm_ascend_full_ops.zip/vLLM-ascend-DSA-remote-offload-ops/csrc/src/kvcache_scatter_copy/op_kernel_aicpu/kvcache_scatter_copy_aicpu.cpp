/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2026. All rights reserved.
 */

#include "kvcache_scatter_copy_aicpu.h"

#include <cstdint>

#include "cust_cpu_utils.h"
#include "hcomm_batch_copy.h"
#include "kvcache_scatter_copy_aicpu_impl.h"

// Use the CANN AICPU dump-log interface. Unlike libc stdout, these records are
// attached to the AICPU dump data and can be decoded with dump_parser.py.

namespace {

// cust_cpu_utils.h defines its logging macros with an unqualified
// CustCpuKernelUtils reference. The validation helpers live outside the
// aicpu namespace, so make the official AICPU utility visible here as well.
using aicpu::CustCpuKernelUtils;
using kvcache_scatter_copy_aicpu::BLOCK_SIZE;
using kvcache_scatter_copy_aicpu::COPY_CAP;
using kvcache_scatter_copy_aicpu::CopyParams;
using kvcache_scatter_copy_aicpu::DispatchBatchCopyRequests;
using kvcache_scatter_copy_aicpu::K_ROPE_DIM;
using kvcache_scatter_copy_aicpu::KV_CACHE_DIM;
using kvcache_scatter_copy_aicpu::STATUS_INNER_ERROR;
using kvcache_scatter_copy_aicpu::STATUS_PARAM_INVALID;
using kvcache_scatter_copy_aicpu::STATUS_SUCCESS;
using kvcache_scatter_copy_aicpu::StoreReadyFlag;

constexpr char OP_TYPE[] = "KvcacheScatterCopy";
constexpr uint32_t HBM_K_ROPE_IDX = 0;
constexpr uint32_t HBM_KV_CACHE_IDX = 1;
constexpr uint32_t DRAM_K_ROPE_IDX = 2;
constexpr uint32_t DRAM_KV_CACHE_IDX = 3;
constexpr uint32_t HBM_BLOCK_TABLE_IDX = 4;
constexpr uint32_t DRAM_BLOCK_TABLE_IDX = 5;
constexpr uint32_t SRC_TOKEN_IDS_IDX = 6;
constexpr uint32_t DST_SLOTS_IDX = 7;
constexpr uint32_t COPY_COUNTS_IDX = 8;
constexpr uint32_t READY_FLAG_IDX = 9;
constexpr char HCOMM_CHANNEL_ATTR[] = "hcomm_channel";
constexpr char HCOMM_THREAD_ATTR[] = "hcomm_thread";

template <typename TensorShapeHandle>
bool HasShape(const TensorShapeHandle& shape, int32_t rank, int64_t dim1 = -1, int64_t dim2 = -1)
{
    if (!shape || shape->GetDims() != rank) {
        return false;
    }
    if (rank > 1 && dim1 >= 0 && shape->GetDimSize(1) != dim1) {
        return false;
    }
    if (rank > 2 && dim2 >= 0 && shape->GetDimSize(2) != dim2) {
        return false;
    }
    return true;
}

bool HasDataWhenNonEmpty(aicpu::Tensor* tensor, const void* data)
{
    return tensor != nullptr && (tensor->GetDataSize() == 0 || data != nullptr);
}

uint32_t ValidateAndInit(aicpu::CpuKernelContext& ctx, CopyParams& params,
    int32_t*& readyFlag, int64_t& totalCopyCount)
{
    aicpu::Tensor* hbmKRoPE = ctx.Input(HBM_K_ROPE_IDX);
    aicpu::Tensor* hbmKvCache = ctx.Input(HBM_KV_CACHE_IDX);
    aicpu::Tensor* dramKRoPE = ctx.Input(DRAM_K_ROPE_IDX);
    aicpu::Tensor* dramKvCache = ctx.Input(DRAM_KV_CACHE_IDX);
    aicpu::Tensor* hbmBlockTable = ctx.Input(HBM_BLOCK_TABLE_IDX);
    aicpu::Tensor* dramBlockTable = ctx.Input(DRAM_BLOCK_TABLE_IDX);
    aicpu::Tensor* srcTokenIds = ctx.Input(SRC_TOKEN_IDS_IDX);
    aicpu::Tensor* dstSlots = ctx.Input(DST_SLOTS_IDX);
    aicpu::Tensor* copyCounts = ctx.Input(COPY_COUNTS_IDX);
    aicpu::Tensor* readyFlagTensor = ctx.Input(READY_FLAG_IDX);

    readyFlag = nullptr;
    if (readyFlagTensor != nullptr) {
        const auto readyFlagShape = readyFlagTensor->GetTensorShape();
        void* readyFlagData = readyFlagTensor->GetData();
        if (!HasShape(readyFlagShape, 1) || readyFlagShape->GetDimSize(0) != 1 ||
            readyFlagTensor->GetDataType() != aicpu::DT_INT32 ||
            !HasDataWhenNonEmpty(readyFlagTensor, readyFlagData) || readyFlagData == nullptr) {
            CUST_KERNEL_LOG_ERROR(ctx, "KvcacheScatterCopy: ready_flag must be a non-null int32 tensor with shape [1].");
            return STATUS_PARAM_INVALID;
        }
        readyFlag = static_cast<int32_t*>(readyFlagData);
        StoreReadyFlag(readyFlag, 0);
    }

    if (hbmKRoPE == nullptr || hbmKvCache == nullptr || dramKRoPE == nullptr ||
        dramKvCache == nullptr || hbmBlockTable == nullptr || dramBlockTable == nullptr ||
        srcTokenIds == nullptr || dstSlots == nullptr || copyCounts == nullptr) {
        CUST_KERNEL_LOG_ERROR(ctx, "KvcacheScatterCopy: a required input is missing.");
        return STATUS_PARAM_INVALID;
    }

    const auto hbmKRoPEShape = hbmKRoPE->GetTensorShape();
    const auto hbmKvCacheShape = hbmKvCache->GetTensorShape();
    const auto dramKRoPEShape = dramKRoPE->GetTensorShape();
    const auto dramKvCacheShape = dramKvCache->GetTensorShape();
    const auto hbmBlockTableShape = hbmBlockTable->GetTensorShape();
    const auto dramBlockTableShape = dramBlockTable->GetTensorShape();
    const auto srcTokenIdsShape = srcTokenIds->GetTensorShape();
    const auto dstSlotsShape = dstSlots->GetTensorShape();
    const auto copyCountsShape = copyCounts->GetTensorShape();

    if (!HasShape(hbmKRoPEShape, 3, BLOCK_SIZE, K_ROPE_DIM) ||
        !HasShape(hbmKvCacheShape, 3, BLOCK_SIZE, KV_CACHE_DIM) ||
        !HasShape(dramKRoPEShape, 3, BLOCK_SIZE, K_ROPE_DIM) ||
        !HasShape(dramKvCacheShape, 3, BLOCK_SIZE, KV_CACHE_DIM) ||
        !HasShape(hbmBlockTableShape, 2) || !HasShape(dramBlockTableShape, 2) ||
        !HasShape(srcTokenIdsShape, 3, 1, COPY_CAP) ||
        !HasShape(dstSlotsShape, 3, 1, COPY_CAP) || !HasShape(copyCountsShape, 1)) {
        CUST_KERNEL_LOG_ERROR(ctx, "KvcacheScatterCopy: input rank or shape is invalid.");
        return STATUS_PARAM_INVALID;
    }

    const auto kvDtype = hbmKRoPE->GetDataType();
    if ((kvDtype != aicpu::DT_FLOAT16 && kvDtype != aicpu::DT_BFLOAT16) ||
        hbmKvCache->GetDataType() != kvDtype || dramKRoPE->GetDataType() != kvDtype ||
        dramKvCache->GetDataType() != kvDtype ||
        hbmBlockTable->GetDataType() != aicpu::DT_INT32 ||
        dramBlockTable->GetDataType() != aicpu::DT_UINT64 ||
        srcTokenIds->GetDataType() != aicpu::DT_INT32 ||
        dstSlots->GetDataType() != aicpu::DT_INT32 ||
        copyCounts->GetDataType() != aicpu::DT_INT32) {
        CUST_KERNEL_LOG_ERROR(ctx, "KvcacheScatterCopy: input dtype is invalid.");
        return STATUS_PARAM_INVALID;
    }

    const int64_t hbmBlockCount = hbmKRoPEShape->GetDimSize(0);
    const int64_t dramBlockCount = dramKRoPEShape->GetDimSize(0);
    if (hbmBlockCount != hbmKvCacheShape->GetDimSize(0) ||
        dramBlockCount != dramKvCacheShape->GetDimSize(0)) {
        CUST_KERNEL_LOG_ERROR(ctx, "KvcacheScatterCopy: K-RoPE and KV block counts do not match.");
        return STATUS_PARAM_INVALID;
    }

    const int64_t batchSize = copyCountsShape->GetDimSize(0);
    const int64_t hbmMaxBlockNum = hbmBlockTableShape->GetDimSize(1);
    const int64_t dramMaxBlockNum = dramBlockTableShape->GetDimSize(1);
    if (batchSize < 0 || hbmMaxBlockNum <= 0 || dramMaxBlockNum <= 0 ||
        hbmBlockTableShape->GetDimSize(0) != batchSize ||
        dramBlockTableShape->GetDimSize(0) != batchSize ||
        srcTokenIdsShape->GetDimSize(0) != batchSize ||
        dstSlotsShape->GetDimSize(0) != batchSize) {
        CUST_KERNEL_LOG_ERROR(ctx, "KvcacheScatterCopy: batch dimensions or block table width are invalid.");
        return STATUS_PARAM_INVALID;
    }

    void* hbmKRoPEData = hbmKRoPE->GetData();
    void* hbmKvCacheData = hbmKvCache->GetData();
    void* dramKRoPEData = dramKRoPE->GetData();
    void* dramKvCacheData = dramKvCache->GetData();
    void* hbmBlockTableData = hbmBlockTable->GetData();
    void* dramBlockTableData = dramBlockTable->GetData();
    void* srcTokenIdsData = srcTokenIds->GetData();
    void* dstSlotsData = dstSlots->GetData();
    void* copyCountsData = copyCounts->GetData();
    if (!HasDataWhenNonEmpty(hbmKRoPE, hbmKRoPEData) ||
        !HasDataWhenNonEmpty(hbmKvCache, hbmKvCacheData) ||
        !HasDataWhenNonEmpty(dramKRoPE, dramKRoPEData) ||
        !HasDataWhenNonEmpty(dramKvCache, dramKvCacheData) ||
        !HasDataWhenNonEmpty(hbmBlockTable, hbmBlockTableData) ||
        !HasDataWhenNonEmpty(dramBlockTable, dramBlockTableData) ||
        !HasDataWhenNonEmpty(srcTokenIds, srcTokenIdsData) ||
        !HasDataWhenNonEmpty(dstSlots, dstSlotsData) ||
        !HasDataWhenNonEmpty(copyCounts, copyCountsData)) {
        CUST_KERNEL_LOG_ERROR(ctx, "KvcacheScatterCopy: a non-empty tensor has a null data pointer.");
        return STATUS_PARAM_INVALID;
    }

    // The generated aclnn API is in-place: output0/output1 alias input0/input1.
    // Write the input addresses to preserve the original AscendC operator's
    // mutation semantics and its void PyTorch schema.
    params.hbmKRoPE = static_cast<uint8_t*>(hbmKRoPEData);
    params.hbmKvCache = static_cast<uint8_t*>(hbmKvCacheData);
    params.dramKRoPE = static_cast<const uint8_t*>(dramKRoPEData);
    params.dramKvCache = static_cast<const uint8_t*>(dramKvCacheData);
    params.hbmBlockTable = static_cast<const int32_t*>(hbmBlockTableData);
    params.dramBlockTable = static_cast<const uint64_t*>(dramBlockTableData);
    params.srcTokenIds = static_cast<const int32_t*>(srcTokenIdsData);
    params.dstSlots = static_cast<const int32_t*>(dstSlotsData);
    params.copyCounts = static_cast<const int32_t*>(copyCountsData);
    params.hbmBlockCount = hbmBlockCount;
    params.dramBlockCount = dramBlockCount;
    params.hbmMaxBlockNum = hbmMaxBlockNum;
    params.dramMaxBlockNum = dramMaxBlockNum;
    params.batchSize = batchSize;

    totalCopyCount = 0;
    for (int64_t batchIdx = 0; batchIdx < batchSize; ++batchIdx) {
        const int32_t count = params.copyCounts[batchIdx];
        if (count < 0 || count > COPY_CAP) {
            CUST_KERNEL_LOG_ERROR(ctx, "KvcacheScatterCopy: copy_counts[%ld]=%d is outside [0, %ld].", batchIdx, count, COPY_CAP);
            return STATUS_PARAM_INVALID;
        }
        totalCopyCount += count;
    }
    return STATUS_SUCCESS;
}

} // namespace

namespace aicpu {

uint32_t KvcacheScatterCopyAicpuKernel::Compute(CpuKernelContext& ctx)
{
    CUST_KERNEL_LOG_INFO(ctx, "KvcacheScatterCopy: Compute entered.");
    const aicpu::AttrValue* channelAttr = ctx.GetAttr(HCOMM_CHANNEL_ATTR);
    const aicpu::AttrValue* threadAttr = ctx.GetAttr(HCOMM_THREAD_ATTR);
    const uint64_t hcommChannel = channelAttr == nullptr ? 0 :
        static_cast<uint64_t>(channelAttr->GetInt());
    const uint64_t hcommThread = threadAttr == nullptr ? 0 :
        static_cast<uint64_t>(threadAttr->GetInt());
    if (hcommChannel != 0 || hcommThread != 0) {
        CUST_KERNEL_LOG_INFO(ctx, "KvcacheScatterCopy: raw Hcomm context channel=%llu thread=%llu.",
            static_cast<unsigned long long>(hcommChannel), static_cast<unsigned long long>(hcommThread));
    }
    CopyParams params;
    int32_t* readyFlag = nullptr;
    int64_t totalCopyCount = 0;
    uint32_t status = ValidateAndInit(ctx, params, readyFlag, totalCopyCount);
    if (status != STATUS_SUCCESS) {
        CUST_KERNEL_LOG_ERROR(ctx, "KvcacheScatterCopy: input validation failed, status=%u.", status);
        return status;
    }
    CUST_KERNEL_LOG_INFO(ctx, "KvcacheScatterCopy: validation passed, batch=%ld, copies=%ld.",
        params.batchSize, totalCopyCount);
    if (totalCopyCount == 0) {
        StoreReadyFlag(readyFlag, 1);
        CUST_KERNEL_LOG_INFO(ctx, "KvcacheScatterCopy: no copies requested; completed.");
        return STATUS_SUCCESS;
    }

    CUST_KERNEL_LOG_INFO(ctx, "KvcacheScatterCopy: issuing batch copy.");
    uint32_t hcommStatus = hcomm::HCOMM_SUCCESS;
    status = DispatchBatchCopyRequests(params, HybmBatchCopy, hcommStatus);
    if (hcommStatus != hcomm::HCOMM_SUCCESS) {
        CUST_KERNEL_LOG_ERROR(ctx, "KvcacheScatterCopy: batch copy failed with status %u.", hcommStatus);
    } else if (status != STATUS_SUCCESS) {
        CUST_KERNEL_LOG_ERROR(ctx, "KvcacheScatterCopy: an active CKV/KPE copy contains an invalid index or GVA.");
    }
    if (status != STATUS_SUCCESS) {
        return status;
    }

    StoreReadyFlag(readyFlag, 1);
    CUST_KERNEL_LOG_INFO(ctx, "KvcacheScatterCopy: completed successfully.");
    return STATUS_SUCCESS;
}

REGISTER_CPU_KERNEL(OP_TYPE, KvcacheScatterCopyAicpuKernel);

} // namespace aicpu
