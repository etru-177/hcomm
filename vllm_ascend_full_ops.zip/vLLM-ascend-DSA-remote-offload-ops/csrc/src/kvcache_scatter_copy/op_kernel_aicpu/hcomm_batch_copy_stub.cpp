/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2026. All rights reserved.
 */

#include "hcomm_batch_copy.h"

#include <cstring>

#if __has_include(<hcomm/hcomm_primitives.h>)
#include <hcomm/hcomm_primitives.h>
#else
#include <hcomm_primitives.h>
#endif

// Match HIXL's device-side proxy pattern: this remains an undefined weak
// reference unless the AICPU runtime has already loaded ccl_kernel. Do not
// link libccl_kernel.so into this custom AICPU library.
extern "C" __attribute__((weak)) int32_t HcommBatchTransferOnThread(
    ThreadHandle thread, ChannelHandle channel, const HcommBatchTransferDesc* descs, uint32_t count);

extern "C" uint32_t HybmBatchCopy(void* args)
{
    if (args == nullptr) {
        return hcomm::HCOMM_INVALID_ARGUMENT;
    }
    const auto* param = static_cast<const HybmBatchCopyParam*>(args);
    if (param->size == 0) {
        return hcomm::HCOMM_SUCCESS;
    }
    if (param->srcDdrPtrList == nullptr || param->dstHbmPtrList == nullptr ||
        param->lengthList == nullptr) {
        return hcomm::HCOMM_INVALID_ARGUMENT;
    }

    for (uint64_t requestIdx = 0; requestIdx < param->size; ++requestIdx) {
        if (param->srcDdrPtrList[requestIdx] == nullptr ||
            param->dstHbmPtrList[requestIdx] == nullptr || param->lengthList[requestIdx] == 0) {
            return hcomm::HCOMM_INVALID_ARGUMENT;
        }
        // Stage-2 baseline: retain local memcpy until channel/thread context
        // can be supplied without changing the public scatter-copy ABI. The
        // weak Hcomm symbol above deliberately has no call site yet.
        std::memcpy(param->dstHbmPtrList[requestIdx], param->srcDdrPtrList[requestIdx],
            static_cast<size_t>(param->lengthList[requestIdx]));
    }
    return hcomm::HCOMM_SUCCESS;
}
