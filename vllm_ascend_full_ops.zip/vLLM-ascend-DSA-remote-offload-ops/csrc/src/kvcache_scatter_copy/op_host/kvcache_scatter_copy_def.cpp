/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
 */

#include "register/op_def_registry.h"

namespace ops {
namespace {
constexpr char AICPU_KERNEL_SO[] = "libkvcache_scatter_copy_aicpu_kernels.so";
constexpr char AICPU_OP_KERNEL_LIB[] = "CUSTAICPUKernel";
constexpr char AICPU_ENGINE[] = "DNN_VM_AICPU";
constexpr char AICPU_FUNCTION_NAME[] = "RunCpuKernel";
constexpr char OP_INFO_WORKSPACE_SIZE[] = "opInfo.workspaceSize";
constexpr char DEFAULT_WORKSPACE_SIZE[] = "100";
constexpr char OP_INFO_FORMAT_AGNOSTIC[] = "opInfo.formatAgnostic";
constexpr char FALSE_VALUE[] = "False";
constexpr char OP_INFO_OPS_FLAG[] = "opInfo.opsFlag";
constexpr char CLOSE_OPS_FLAG[] = "OPS_FLAG_CLOSE";
constexpr char OP_INFO_SUB_TYPE_OF_INFER_SHAPE[] = "opInfo.subTypeOfInferShape";
constexpr char DEFAULT_INFER_SHAPE_TYPE[] = "1";
} // namespace

class KvcacheScatterCopy : public OpDef {
public:
    explicit KvcacheScatterCopy(const char* name) : OpDef(name)
    {
        this->Input("hbm_k_rope").ParamType(REQUIRED).DataType({ge::DT_BF16, ge::DT_FLOAT16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND}).UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("hbm_kv_cache").ParamType(REQUIRED).DataType({ge::DT_BF16, ge::DT_FLOAT16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND}).UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("dram_k_rope").ParamType(REQUIRED).DataType({ge::DT_BF16, ge::DT_FLOAT16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND}).UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("dram_kv_cache").ParamType(REQUIRED).DataType({ge::DT_BF16, ge::DT_FLOAT16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND}).UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("hbm_block_table").ParamType(REQUIRED).DataType({ge::DT_INT32, ge::DT_INT32})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND}).UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("dram_block_table").ParamType(REQUIRED).DataType({ge::DT_UINT64, ge::DT_UINT64})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND}).UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("src_token_ids").ParamType(REQUIRED).DataType({ge::DT_INT32, ge::DT_INT32})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND}).UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("dst_slots").ParamType(REQUIRED).DataType({ge::DT_INT32, ge::DT_INT32})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND}).UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("copy_counts").ParamType(REQUIRED).DataType({ge::DT_INT32, ge::DT_INT32})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND}).UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("ready_flag").ParamType(OPTIONAL).DataType({ge::DT_INT32, ge::DT_INT32})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND}).UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});

        // These are private launch attributes, not public tensor inputs.  A
        // raw-Hcomm connection is created on the host, then its AICPU channel
        // context is attached to this invocation by aclopSetAttrInt.
        // layer_id is public API state reserved for layer-aware remote table
        // selection; the current layer-local table view does not consume it.
        this->Attr("layer_id").AttrType(OPTIONAL).Int(0);
        this->Attr("hcomm_channel").AttrType(OPTIONAL).Int(0);
        this->Attr("hcomm_thread").AttrType(OPTIONAL).Int(0);

        this->Output("hbm_k_rope").ParamType(REQUIRED).DataType({ge::DT_BF16, ge::DT_FLOAT16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND}).UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Output("hbm_kv_cache").ParamType(REQUIRED).DataType({ge::DT_BF16, ge::DT_FLOAT16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND}).UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});

        this->AICPU()
            .Engine(AICPU_ENGINE)
            .OpKernelLib(AICPU_OP_KERNEL_LIB)
            .KernelSo(AICPU_KERNEL_SO)
            .FunctionName(AICPU_FUNCTION_NAME)
            .UserDefined(true)
            .ExtendCfgInfo(OP_INFO_WORKSPACE_SIZE, DEFAULT_WORKSPACE_SIZE)
            .ExtendCfgInfo(OP_INFO_FORMAT_AGNOSTIC, FALSE_VALUE)
            .ExtendCfgInfo(OP_INFO_OPS_FLAG, CLOSE_OPS_FLAG)
            .ExtendCfgInfo(OP_INFO_SUB_TYPE_OF_INFER_SHAPE, DEFAULT_INFER_SHAPE_TYPE);
    }
};
OP_ADD(KvcacheScatterCopy);
} // namespace ops
