/** Stage 4: complete one-kernel C8 MTP3 LI and cache management. */

#include "kernel_operator.h"
#include "a5_fused_li_manage_mtp_c8_tiling.h"
#include "a5_fused_li_manage_mtp_c8_qli.h"
#include "a5_fused_li_manage_mtp_c8_union.h"
#include "a5_fused_li_manage_mtp_c8_workspace.h"

extern "C" __global__ __aicore__ void
a5_fused_li_manage_mtp_c8(
    GM_ADDR query,
    GM_ADDR key,
    GM_ADDR weights,
    GM_ADDR queryDequantScale,
    GM_ADDR keyDequantScale,
    GM_ADDR actualSeqLengthsQuery,
    GM_ADDR reqPoolEntries,
    GM_ADDR cacheSlotsPool,
    GM_ADDR cacheTokens,
    GM_ADDR candidateLens,
    GM_ADDR blockTable,
    GM_ADDR topkSourceIds,
    GM_ADDR topkDestinationSlots,
    GM_ADDR topkMissCount,
    GM_ADDR missSourceIds,
    GM_ADDR missDestinationSlots,
    GM_ADDR missCounts,
    GM_ADDR cacheSlotsAlias,
    GM_ADDR workspace,
    GM_ADDR tiling)
{
    (void)cacheSlotsAlias;
    KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_2);
    REGISTER_TILING_DEFAULT(A5FusedLiManageMtpC8TilingData);
    GET_TILING_DATA(tilingData, tiling);
    AscendC::TPipe pipe;
    GM_ADDR userWorkspace = GetUserWorkspace(workspace);
    using namespace a5_fused_li_manage_mtp_c8_workspace;
    const uint64_t scoreStride = tilingData.scoreWorkspaceStride;
    const uint64_t batchSize = tilingData.batchSize;
    // The helpers in the shared workspace header are intentionally host-side
    // constexpr functions for tiling.  Expand the same arithmetic here so an
    // __aicore__ kernel never calls a host function.
    const uint64_t routePairOffset = scoreStride * batchSize;
    const uint64_t routePairBytes =
        batchSize * UNION_CAPACITY * 2U * sizeof(int32_t);
    const uint64_t routeThresholdOffset =
        routePairOffset + routePairBytes;
    GM_ADDR routePairRows =
        userWorkspace + routePairOffset;
    GM_ADDR routeThresholds =
        userWorkspace + routeThresholdOffset;
    // The public per-query output is also the Stage-1 -> Stage-2 hand-off.
    // This keeps one authoritative count and avoids a redundant GM copy.
    GM_ADDR routeMissCounts = topkMissCount;

    a5_fused_li_manage_mtp_c8_impl::QuantLiMtpPhase qli(
        &pipe, &tilingData);
    qli.Init(
        query, key, weights, queryDequantScale, keyDequantScale,
        actualSeqLengthsQuery, cacheTokens, candidateLens,
        reqPoolEntries, cacheSlotsPool, blockTable,
        routePairRows, topkSourceIds, topkDestinationSlots,
        routeThresholds, routeMissCounts,
        userWorkspace);
    qli.Process();

    if ASCEND_IS_AIV {
        // The (request, gS1) QLI task owners publish route pairs/counts with
        // MTE3. Every request owner consumes all four routes through MTE2 only
        // after this global barrier.
        AscendC::SyncAll();
        if ((GetBlockIdx() & 1U) == 0U) {
            pipe.Reset();
            a5_fused_li_manage_mtp_c8_impl::OrderedMissUnion unionOp;
            unionOp.Init(
                routePairRows, routeThresholds, routeMissCounts,
                userWorkspace, candidateLens, reqPoolEntries,
                cacheSlotsPool, missSourceIds, missDestinationSlots,
                missCounts, topkSourceIds, topkDestinationSlots,
                cacheTokens,
                tilingData.sourceCapacity, tilingData.batchSize, &pipe);
            unionOp.Process(GetBlockIdx() / 2U,
                            tilingData.usedCoreNum);
        }
    }
}
