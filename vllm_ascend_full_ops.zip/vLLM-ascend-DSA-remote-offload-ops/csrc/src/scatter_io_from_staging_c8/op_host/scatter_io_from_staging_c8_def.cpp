// Copyright (c) 2026 Huawei Technologies Co., Ltd.

#include "register/op_def_registry.h"

namespace ops {
class ScatterIoFromStagingC8 : public OpDef {
public:
    explicit ScatterIoFromStagingC8(const char* name) : OpDef(name)
    {
        const std::vector<ge::DataType> bytes = {ge::DT_UINT8};
        const std::vector<ge::DataType> ints = {ge::DT_INT32};
        const std::vector<ge::Format> formats = {ge::FORMAT_ND};
        this->Input("packed_hbm_kv").ParamType(REQUIRED)
            .DataType(bytes).Format(formats);
        this->Input("hbm_staging").ParamType(REQUIRED)
            .DataType(bytes).Format(formats);
        this->Input("completion").ParamType(REQUIRED)
            .DataType(bytes).Format(formats);
        this->Input("hbm_block_table").ParamType(REQUIRED)
            .DataType(ints).Format(formats);
        this->Input("dst_slots").ParamType(REQUIRED)
            .DataType(ints).Format(formats);
        this->Input("copy_counts").ParamType(REQUIRED)
            .DataType(ints).Format(formats);
        this->Output("packed_hbm_kv_out").ParamType(REQUIRED)
            .DataType(bytes).Format(formats);
        this->AICore().AddConfig("ascend950");
    }
};
OP_ADD(ScatterIoFromStagingC8);
}  // namespace ops
