// Copyright (c) 2026 Huawei Technologies Co., Ltd.
#pragma once

#include "register/tilingdata_base.h"

namespace optiling {
BEGIN_TILING_DATA_DEF(ScatterIoFromStagingC8TilingData)
TILING_DATA_FIELD_DEF(int64_t, usedCoreNum);
TILING_DATA_FIELD_DEF(int64_t, batchSize);
TILING_DATA_FIELD_DEF(int64_t, copyCap);
TILING_DATA_FIELD_DEF(int64_t, hbmMaxBlocks);
END_TILING_DATA_DEF;

REGISTER_TILING_DATA_CLASS(
    ScatterIoFromStagingC8, ScatterIoFromStagingC8TilingData)
}  // namespace optiling
