// Copyright (c) 2026 Huawei Technologies Co., Ltd.

#include <register/op_impl_registry.h>

namespace ops {
static ge::graphStatus InferShape(gert::InferShapeContext* context)
{
    *context->GetOutputShape(0) = *context->GetInputShape(0);
    return ge::GRAPH_SUCCESS;
}

static ge::graphStatus InferDtype(gert::InferDataTypeContext* context)
{
    context->SetOutputDataType(0, context->GetInputDataType(0));
    return ge::GRAPH_SUCCESS;
}

IMPL_OP_INFERSHAPE(ScatterIoFromStagingC8)
    .InferShape(InferShape)
    .InferDataType(InferDtype);
}  // namespace ops
