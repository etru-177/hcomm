// Copyright (c) 2026 Huawei Technologies Co., Ltd.

#include "scatter_io_from_staging_c8_tiling.h"

#include "exe_graph/runtime/tiling_context.h"
#include "platform/platform_info.h"
#include "register/op_impl_registry.h"
#include "tiling/platform/platform_ascendc.h"

namespace optiling {
namespace {
constexpr int64_t kBlockSize = 128;
constexpr int64_t kTokenBytes = 656;
constexpr int64_t kCopyCap = 16384;
constexpr int64_t kCompletionBytes = 64;

ge::graphStatus Tiling(gert::TilingContext* context)
{
    if (context == nullptr) return ge::GRAPH_FAILED;
    for (int index = 0; index < 6; ++index) {
        if (context->GetInputShape(index) == nullptr ||
            context->GetInputDesc(index) == nullptr) {
            return ge::GRAPH_FAILED;
        }
    }
    const auto packed = context->GetInputShape(0)->GetStorageShape();
    const auto staging = context->GetInputShape(1)->GetStorageShape();
    const auto completion = context->GetInputShape(2)->GetStorageShape();
    const auto table = context->GetInputShape(3)->GetStorageShape();
    const auto slots = context->GetInputShape(4)->GetStorageShape();
    const auto counts = context->GetInputShape(5)->GetStorageShape();
    if (packed.GetDimNum() != 3 || packed.GetDim(0) <= 0 ||
        packed.GetDim(1) != kBlockSize || packed.GetDim(2) != kTokenBytes ||
        staging.GetDimNum() != 2 || staging.GetDim(0) <= 0 ||
        staging.GetDim(1) != kTokenBytes ||
        completion.GetDimNum() != 1 ||
        completion.GetDim(0) < kCompletionBytes ||
        table.GetDimNum() != 2 || table.GetDim(0) <= 0 ||
        table.GetDim(1) <= 0 ||
        slots.GetDimNum() != 3 || slots.GetDim(0) != table.GetDim(0) ||
        slots.GetDim(1) != 1 || slots.GetDim(2) != kCopyCap ||
        counts.GetDimNum() != 1 || counts.GetDim(0) != table.GetDim(0)) {
        return ge::GRAPH_FAILED;
    }
    if (context->GetInputDesc(0)->GetDataType() != ge::DT_UINT8 ||
        context->GetInputDesc(1)->GetDataType() != ge::DT_UINT8 ||
        context->GetInputDesc(2)->GetDataType() != ge::DT_UINT8 ||
        context->GetInputDesc(3)->GetDataType() != ge::DT_INT32 ||
        context->GetInputDesc(4)->GetDataType() != ge::DT_INT32 ||
        context->GetInputDesc(5)->GetDataType() != ge::DT_INT32) {
        return ge::GRAPH_FAILED;
    }

    const auto platform =
        platform_ascendc::PlatformAscendC(context->GetPlatformInfo());
    const int64_t cores = platform.GetCoreNumAiv();
    if (cores <= 0) return ge::GRAPH_FAILED;
    ScatterIoFromStagingC8TilingData data;
    data.set_usedCoreNum(cores);
    data.set_batchSize(table.GetDim(0));
    data.set_copyCap(kCopyCap);
    data.set_hbmMaxBlocks(table.GetDim(1));
    context->SetBlockDim(cores);
    context->SetTilingKey(1);
    auto* raw = context->GetRawTilingData();
    data.SaveToBuffer(raw->GetData(), raw->GetCapacity());
    raw->SetDataSize(data.GetDataSize());
    context->GetWorkspaceSizes(1)[0] = 32;
    return ge::GRAPH_SUCCESS;
}

// 显式注册空 parser，避免 CANN 自动 parser 查找不存在的 `_pattern`。
struct ScatterIoFromStagingC8CompileInfo {};
ge::graphStatus ParseCompileInfo(gert::TilingParseContext* context)
{
    (void)context;
    return ge::GRAPH_SUCCESS;
}
}  // namespace

IMPL_OP_OPTILING(ScatterIoFromStagingC8)
    .Tiling(Tiling)
    .TilingParse<ScatterIoFromStagingC8CompileInfo>(ParseCompileInfo);
}  // namespace optiling
