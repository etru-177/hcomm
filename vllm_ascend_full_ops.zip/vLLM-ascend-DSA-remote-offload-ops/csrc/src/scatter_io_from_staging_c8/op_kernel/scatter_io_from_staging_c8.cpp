// Copyright (c) 2026 Huawei Technologies Co., Ltd.

#include "kernel_operator.h"

using namespace AscendC;

namespace {
constexpr int64_t kBlockSize = 128;
constexpr int64_t kBlockShift = 7;
constexpr int64_t kBlockMask = 127;
constexpr int64_t kTokenBytes = 656;
constexpr int64_t kAlignedTokenBytes = 672;

class ScatterIoFromStagingC8Kernel {
public:
    __aicore__ inline ScatterIoFromStagingC8Kernel(
        TPipe* pipe, const ScatterIoFromStagingC8TilingData* tiling)
        : pipe_(pipe), tiling_(tiling)
    {}

    __aicore__ inline void Init(
        GM_ADDR packed, GM_ADDR staging, GM_ADDR completion,
        GM_ADDR table, GM_ADDR slots, GM_ADDR counts)
    {
        core_ = GetBlockIdx();
        pipe_->InitBuffer(copyQueue_, 1, kAlignedTokenBytes);
        pipe_->InitBuffer(signalQueue_, 1, 32);
        packed_.SetGlobalBuffer(reinterpret_cast<__gm__ uint8_t*>(packed));
        staging_.SetGlobalBuffer(reinterpret_cast<__gm__ uint8_t*>(staging));
        completion_.SetGlobalBuffer(
            reinterpret_cast<__gm__ uint64_t*>(completion));
        table_.SetGlobalBuffer(reinterpret_cast<__gm__ int32_t*>(table));
        slots_.SetGlobalBuffer(reinterpret_cast<__gm__ int32_t*>(slots));
        counts_.SetGlobalBuffer(reinterpret_cast<__gm__ int32_t*>(counts));
    }

    __aicore__ inline void Process()
    {
        if (core_ >= tiling_->usedCoreNum) return;
        WaitReady();
        int64_t sourceBase = 0;
        for (int64_t batch = 0; batch < tiling_->batchSize; ++batch) {
            const int64_t count = counts_.GetValue(batch);
            for (int64_t copy = core_; copy < count;
                 copy += tiling_->usedCoreNum) {
                CopyOne(batch, copy, sourceBase + copy);
            }
            sourceBase += count;
        }
    }

private:
    __aicore__ inline void WaitReady()
    {
        LocalTensor<uint64_t> signal = signalQueue_.AllocTensor<uint64_t>();
        do {
            DataCopy(signal, completion_, 4);
            pipe_barrier(PIPE_ALL);
        } while (signal.GetValue(1) == 0 ||
                 signal.GetValue(0) != signal.GetValue(1));
        signalQueue_.FreeTensor(signal);
    }

    __aicore__ inline void CopyOne(
        int64_t batch, int64_t copy, int64_t sourceOrdinal)
    {
        const int64_t item = batch * tiling_->copyCap + copy;
        const int32_t logicalSlot = slots_.GetValue(item);
        if (logicalSlot < 0) return;
        const int64_t logicalBlock =
            static_cast<int64_t>(logicalSlot) >> kBlockShift;
        if (logicalBlock >= tiling_->hbmMaxBlocks) return;
        const int32_t physicalBlock = table_.GetValue(
            batch * tiling_->hbmMaxBlocks + logicalBlock);
        if (physicalBlock < 0) return;
        const int64_t tokenOffset =
            static_cast<int64_t>(logicalSlot) & kBlockMask;
        const int64_t destination =
            (static_cast<int64_t>(physicalBlock) * kBlockSize + tokenOffset) *
            kTokenBytes;
        const int64_t source = sourceOrdinal * kTokenBytes;

        LocalTensor<uint8_t> local = copyQueue_.AllocTensor<uint8_t>();
        DataCopyPadExtParams<uint8_t> pad{false, 0, 0, 0};
        DataCopyExtParams copyBytes{
            1, static_cast<uint32_t>(kTokenBytes), 0, 0, 0};
        DataCopyPad<uint8_t, PaddingMode::Normal>(
            local, staging_[source], copyBytes, pad);
        copyQueue_.EnQue<uint8_t>(local);
        local = copyQueue_.DeQue<uint8_t>();
        DataCopyPad<uint8_t, PaddingMode::Normal>(
            packed_[destination], local, copyBytes);
        copyQueue_.FreeTensor(local);
    }

    TPipe* pipe_;
    const ScatterIoFromStagingC8TilingData* tiling_;
    int64_t core_ = 0;
    GlobalTensor<uint8_t> packed_;
    GlobalTensor<uint8_t> staging_;
    GlobalTensor<uint64_t> completion_;
    GlobalTensor<int32_t> table_;
    GlobalTensor<int32_t> slots_;
    GlobalTensor<int32_t> counts_;
    TQue<QuePosition::VECIN, 1> signalQueue_;
    TQueBind<QuePosition::VECIN, QuePosition::VECOUT, 1> copyQueue_;
};
}  // namespace

extern "C" __global__ __aicore__ void scatter_io_from_staging_c8(
    GM_ADDR packedHbmKv, GM_ADDR staging, GM_ADDR completion,
    GM_ADDR hbmBlockTable, GM_ADDR dstSlots, GM_ADDR copyCounts,
    GM_ADDR packedHbmKvOut, GM_ADDR workspace, GM_ADDR tiling)
{
    (void)packedHbmKv;
    (void)workspace;
    if (g_coreType == AIC) return;
    TPipe pipe;
    GET_TILING_DATA(data, tiling);
    if (TILING_KEY_IS(1)) {
        ScatterIoFromStagingC8Kernel kernel(&pipe, &data);
        kernel.Init(packedHbmKvOut, staging, completion,
            hbmBlockTable, dstSlots, copyCounts);
        kernel.Process();
    }
}
