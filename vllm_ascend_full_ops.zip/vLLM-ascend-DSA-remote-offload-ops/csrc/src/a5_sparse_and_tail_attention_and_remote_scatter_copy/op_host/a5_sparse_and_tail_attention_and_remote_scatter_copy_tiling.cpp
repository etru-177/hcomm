/**
 * Ascend 950 remote sparse-attention tiling.
 */

#include <cstddef>
#include <cstdint>
#include <cstring>

#include "a5_sparse_and_tail_attention_and_remote_scatter_copy_common.h"
#include "a5_sparse_and_tail_attention_and_remote_scatter_copy_tiling.h"
#include "register/op_impl_registry.h"

namespace optiling {
namespace {
ge::graphStatus TilingA5SparseAndTailAttentionAndRemoteScatterCopy(
    gert::TilingContext *context)
{
    SFATilingInfo sfaInfo;
    SFAInfoParser parser(context);
    if (parser.Parse(sfaInfo) != ge::GRAPH_SUCCESS) {
        return ge::GRAPH_FAILED;
    }

    uint32_t copyCap = 0;
    uint32_t completionBytes = 0;
    if (a5_sfa_remote::CheckRemoteInputs(
            context, copyCap, completionBytes) != ge::GRAPH_SUCCESS) {
        return ge::GRAPH_FAILED;
    }
    auto *attrs = context->GetAttrs();
    if (attrs == nullptr) {
        return ge::GRAPH_FAILED;
    }
    const int64_t *expectedGeneration =
        attrs->GetAttrPointer<int64_t>(
            a5_sfa_remote::EXPECTED_GENERATION_ATTR);
    if (expectedGeneration == nullptr || *expectedGeneration <= 0) {
        return ge::GRAPH_FAILED;
    }

    SFATilingCheck checker(sfaInfo);
    if (checker.Process() != ge::GRAPH_SUCCESS) {
        return ge::GRAPH_FAILED;
    }
    SFAMlaTiling tiler(context);
    if (tiler.DoOpTiling(&sfaInfo) != ge::GRAPH_SUCCESS) {
        return ge::GRAPH_FAILED;
    }

    auto *raw = context->GetRawTilingData();
    if (raw == nullptr) {
        return ge::GRAPH_FAILED;
    }
    A5SparseAndTailAttentionAndRemoteScatterCopyTilingData fusedTiling;
    const size_t baseSize = raw->GetDataSize();
    const size_t fusedSize = fusedTiling.GetDataSize();
    constexpr size_t suffixSize =
        sizeof(uint32_t) * 2U + sizeof(uint64_t);
    if (fusedSize != baseSize + suffixSize ||
        raw->GetCapacity() < fusedSize) {
        return ge::GRAPH_FAILED;
    }
    auto *payload = static_cast<uint8_t *>(raw->GetData());
    std::memcpy(payload + baseSize, &copyCap, sizeof(copyCap));
    std::memcpy(
        payload + baseSize + sizeof(copyCap),
        &completionBytes,
        sizeof(completionBytes));
    const uint64_t generation =
        static_cast<uint64_t>(*expectedGeneration);
    std::memcpy(
        payload + baseSize + sizeof(copyCap) + sizeof(completionBytes),
        &generation,
        sizeof(generation));
    raw->SetDataSize(fusedSize);
    return ge::GRAPH_SUCCESS;
}

struct A5SparseAndTailAttentionAndRemoteScatterCopyCompileInfo {};

ge::graphStatus ParseA5SparseAndTailAttentionAndRemoteScatterCopyCompileInfo(
    gert::TilingParseContext *context)
{
    (void)context;
    return ge::GRAPH_SUCCESS;
}
}  // namespace

IMPL_OP_OPTILING(A5SparseAndTailAttentionAndRemoteScatterCopy)
    .Tiling(TilingA5SparseAndTailAttentionAndRemoteScatterCopy)
    .TilingParse<A5SparseAndTailAttentionAndRemoteScatterCopyCompileInfo>(
        ParseA5SparseAndTailAttentionAndRemoteScatterCopyCompileInfo);
}  // namespace optiling
