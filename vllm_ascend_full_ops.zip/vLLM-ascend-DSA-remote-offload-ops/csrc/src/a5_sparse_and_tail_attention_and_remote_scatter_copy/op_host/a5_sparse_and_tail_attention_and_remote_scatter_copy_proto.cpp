/**
 * Ascend 950 remote sparse-attention inference.
 */

#include "a5_sparse_and_tail_attention_and_remote_scatter_copy_common.h"
#include "register/op_impl_registry.h"

namespace ops {
namespace {
ge::graphStatus InferShape(
    gert::InferShapeContext *context)
{
    using namespace a5_sfa_remote;
    if (context == nullptr ||
        context->GetInputShape(QUERY) == nullptr ||
        context->GetInputShape(HBM_KEY_ROPE) == nullptr ||
        context->GetInputShape(KEY) == nullptr ||
        context->GetOutputShape(0) == nullptr ||
        context->GetOutputShape(1) == nullptr ||
        context->GetOutputShape(2) == nullptr ||
        context->GetOutputShape(3) == nullptr ||
        context->GetOutputShape(4) == nullptr) {
        return ge::GRAPH_FAILED;
    }
    *context->GetOutputShape(0) = *context->GetInputShape(QUERY);
    // torch_npu::OpCommand cannot pass a REQUIRED zero-storage output to GE.
    // These one-element placeholders are unused when return_softmax_lse=false.
    *context->GetOutputShape(1) = gert::Shape({1});
    *context->GetOutputShape(2) = gert::Shape({1});
    *context->GetOutputShape(3) =
        *context->GetInputShape(HBM_KEY_ROPE);
    *context->GetOutputShape(4) =
        *context->GetInputShape(KEY);
    return ge::GRAPH_SUCCESS;
}

ge::graphStatus InferDataType(
    gert::InferDataTypeContext *context)
{
    using namespace a5_sfa_remote;
    if (context == nullptr) {
        return ge::GRAPH_FAILED;
    }
    context->SetOutputDataType(
        0, context->GetInputDataType(QUERY));
    context->SetOutputDataType(1, ge::DT_FLOAT);
    context->SetOutputDataType(2, ge::DT_FLOAT);
    context->SetOutputDataType(
        3, context->GetInputDataType(HBM_KEY_ROPE));
    context->SetOutputDataType(
        4, context->GetInputDataType(KEY));
    return ge::GRAPH_SUCCESS;
}
}  // namespace

IMPL_OP_INFERSHAPE(A5SparseAndTailAttentionAndRemoteScatterCopy)
    .InferShape(InferShape)
    .InferDataType(InferDataType);
}  // namespace ops
