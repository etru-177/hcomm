/**
 * Ascend 950 source-aware sparse attention + DRAM-to-HBM scatter tiling.
 */

#include <cstddef>
#include <cstdint>
#include <cstring>

#include "a5_sparse_and_tail_attention_and_scatter_copy_common.h"
#include "a5_sparse_and_tail_attention_and_scatter_copy_tiling.h"
#include "register/op_impl_registry.h"

namespace optiling {
namespace {
ge::graphStatus TilingA5SparseAndTailAttentionAndScatterCopy(
    gert::TilingContext *context)
{
    SFATilingInfo sfaInfo;
    SFAInfoParser parser(context);
    if (parser.Parse(sfaInfo) != ge::GRAPH_SUCCESS) {
        return ge::GRAPH_FAILED;
    }

    uint32_t copyCap = 0;
    uint32_t dramMaxBlockNum = 0;
    if (a5_sfa_fused::CheckFusedInputs(
            context, copyCap, dramMaxBlockNum) != ge::GRAPH_SUCCESS) {
        return ge::GRAPH_FAILED;
    }

    SFATilingCheck checker(sfaInfo);
    if (checker.Process() != ge::GRAPH_SUCCESS) {
        return ge::GRAPH_FAILED;
    }
    SFAMlaTiling tiler(context);
    if (tiler.DoOpTiling(&sfaInfo) != ge::GRAPH_SUCCESS) {
        return ge::GRAPH_FAILED;
    }

    auto *raw = context->GetRawTilingData();
    if (raw == nullptr) {
        return ge::GRAPH_FAILED;
    }
    A5SparseAndTailAttentionAndScatterCopyTilingData fusedTiling;
    const size_t baseSize = raw->GetDataSize();
    const size_t fusedSize = fusedTiling.GetDataSize();
    constexpr size_t suffixSize = sizeof(uint32_t) * 2U;
    if (fusedSize != baseSize + suffixSize ||
        raw->GetCapacity() < fusedSize) {
        return ge::GRAPH_FAILED;
    }
    auto *payload = static_cast<uint8_t *>(raw->GetData());
    std::memcpy(payload + baseSize, &copyCap, sizeof(copyCap));
    std::memcpy(
        payload + baseSize + sizeof(copyCap),
        &dramMaxBlockNum,
        sizeof(dramMaxBlockNum));
    raw->SetDataSize(fusedSize);
    return ge::GRAPH_SUCCESS;
}

struct A5SparseAndTailAttentionAndScatterCopyCompileInfo {};

ge::graphStatus ParseA5SparseAndTailAttentionAndScatterCopyCompileInfo(
    gert::TilingParseContext *context)
{
    (void)context;
    return ge::GRAPH_SUCCESS;
}
}  // namespace

IMPL_OP_OPTILING(A5SparseAndTailAttentionAndScatterCopy)
    .Tiling(TilingA5SparseAndTailAttentionAndScatterCopy)
    .TilingParse<A5SparseAndTailAttentionAndScatterCopyCompileInfo>(
        ParseA5SparseAndTailAttentionAndScatterCopyCompileInfo);
}  // namespace optiling
