/**
 * Ascend 950 source-aware sparse attention + DRAM-to-HBM scatter OpDef.
 */

#include <cstdint>
#include <vector>

#include "register/op_def_registry.h"

namespace ops {
class A5SparseAndTailAttentionAndScatterCopy : public OpDef {
public:
    explicit A5SparseAndTailAttentionAndScatterCopy(
        const char *name) : OpDef(name)
    {
        const std::vector<ge::DataType> floatTypes = {
            ge::DT_BF16, ge::DT_FLOAT16};
        const std::vector<ge::DataType> intTypes = {
            ge::DT_INT32, ge::DT_INT32};
        const std::vector<ge::DataType> fp32Types = {
            ge::DT_FLOAT, ge::DT_FLOAT};
        const std::vector<ge::Format> formats = {
            ge::FORMAT_ND, ge::FORMAT_ND};

        this->Input("query").ParamType(REQUIRED).DataType(floatTypes).Format(formats);
        this->Input("key").ParamType(REQUIRED).DataType(floatTypes).Format(formats);
        this->Input("value").ParamType(REQUIRED).DataType(floatTypes).Format(formats);
        this->Input("sparse_indices").ParamType(REQUIRED).DataType(intTypes).Format(formats);
        this->Input("block_table").ParamType(OPTIONAL).DataType(intTypes).Format(formats);
        this->Input("actual_seq_lengths_query").ParamType(OPTIONAL).DataType(intTypes).Format(formats);
        this->Input("actual_seq_lengths_kv").ParamType(OPTIONAL).DataType(intTypes).Format(formats);
        this->Input("query_rope").ParamType(OPTIONAL).DataType(floatTypes).Format(formats);
        this->Input("key_rope").ParamType(OPTIONAL).DataType(floatTypes).Format(formats);
        this->Input("cache_tokens").ParamType(REQUIRED).DataType(intTypes).Format(formats);
        this->Input("dram_key_rope").ParamType(REQUIRED).DataType(floatTypes).Format(formats);
        this->Input("dram_kv_cache").ParamType(REQUIRED).DataType(floatTypes).Format(formats);
        this->Input("dram_block_table").ParamType(REQUIRED).DataType(intTypes).Format(formats);
        this->Input("source_token_ids").ParamType(REQUIRED).DataType(intTypes).Format(formats);
        this->Input("copy_counts").ParamType(REQUIRED).DataType(intTypes).Format(formats);

        this->Output("attention_out").ParamType(REQUIRED).DataType(floatTypes).Format(formats);
        this->Output("softmax_max").ParamType(REQUIRED).DataType(fp32Types).Format(formats);
        this->Output("softmax_sum").ParamType(REQUIRED).DataType(fp32Types).Format(formats);
        this->Output("hbm_key_rope_out").ParamType(REQUIRED).DataType(floatTypes).Format(formats);
        this->Output("hbm_kv_cache_out").ParamType(REQUIRED).DataType(floatTypes).Format(formats);

        this->Attr("scale_value").AttrType(REQUIRED).Float(1.0);
        this->Attr("sparse_block_size").AttrType(OPTIONAL).Int(1);
        this->Attr("layout_query").AttrType(OPTIONAL).String("TND");
        this->Attr("layout_kv").AttrType(OPTIONAL).String("PA_BSND");
        this->Attr("sparse_mode").AttrType(OPTIONAL).Int(3);
        this->Attr("pre_tokens").AttrType(OPTIONAL).Int(INT64_MAX);
        this->Attr("next_tokens").AttrType(OPTIONAL).Int(INT64_MAX);
        this->Attr("attention_mode").AttrType(OPTIONAL).Int(2);
        this->Attr("return_softmax_lse").AttrType(OPTIONAL).Bool(false);

        OpAICoreConfig config;
        config.DynamicCompileStaticFlag(true)
            .DynamicFormatFlag(true)
            .DynamicRankSupportFlag(true)
            .DynamicShapeSupportFlag(true)
            .NeedCheckSupportFlag(false)
            .PrecisionReduceFlag(true);
        this->AICore().AddConfig("ascend950", config);
    }
};
OP_ADD(A5SparseAndTailAttentionAndScatterCopy);
}  // namespace ops
