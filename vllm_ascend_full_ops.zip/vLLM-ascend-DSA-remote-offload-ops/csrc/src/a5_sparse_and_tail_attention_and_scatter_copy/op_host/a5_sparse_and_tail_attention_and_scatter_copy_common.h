/**
 * Ascend 950 source-aware sparse attention + DRAM-to-HBM scatter.
 *
 * This is the input contract from nano-vllm-ascend-DeepseekV32, split out
 * only because this repository builds OpDef, tiling and infer-shape in
 * separate targets.
 */
#pragma once

#include <cstddef>
#include <cstdint>
#include <initializer_list>

#include "register/op_impl_registry.h"

namespace a5_sfa_fused {
constexpr size_t QUERY = 0;
constexpr size_t KEY = 1;
constexpr size_t VALUE = 2;
constexpr size_t SPARSE_SLOTS = 3;
constexpr size_t HBM_BLOCK_TABLE = 4;
constexpr size_t ACTUAL_Q = 5;
constexpr size_t ACTUAL_KV = 6;
constexpr size_t QUERY_ROPE = 7;
constexpr size_t HBM_KEY_ROPE = 8;
constexpr size_t CACHE_TOKENS = 9;
constexpr size_t DRAM_KEY_ROPE = 10;
constexpr size_t DRAM_KV_CACHE = 11;
constexpr size_t DRAM_BLOCK_TABLE = 12;
constexpr size_t SOURCE_TOKEN_IDS = 13;
constexpr size_t COPY_COUNTS = 14;

constexpr int64_t BLOCK_SIZE = 128;
constexpr int64_t CKV_DIM = 512;
constexpr int64_t KPE_DIM = 64;
constexpr int64_t SPARSE_COUNT = 2048;
constexpr int64_t MAX_REGULAR_LOCAL_HEADS = 64;
constexpr int64_t SPLIT_G_LOCAL_HEADS = 128;

inline bool IsShape(
    const gert::Shape &shape,
    std::initializer_list<int64_t> dims)
{
    if (shape.GetDimNum() != dims.size()) {
        return false;
    }
    size_t index = 0;
    for (const int64_t dim : dims) {
        if (dim >= 0 && shape.GetDim(index) != dim) {
            return false;
        }
        ++index;
    }
    return true;
}

inline ge::graphStatus CheckFusedInputs(
    gert::TilingContext *context,
    uint32_t &copyCap,
    uint32_t &dramMaxBlockNum)
{
    if (context == nullptr) {
        return ge::GRAPH_FAILED;
    }
    for (size_t index = QUERY; index <= COPY_COUNTS; ++index) {
        if (context->GetInputShape(index) == nullptr ||
            context->GetInputDesc(index) == nullptr) {
            return ge::GRAPH_FAILED;
        }
    }

    const gert::Shape query =
        context->GetInputShape(QUERY)->GetStorageShape();
    const gert::Shape hbmKv =
        context->GetInputShape(KEY)->GetStorageShape();
    const gert::Shape value =
        context->GetInputShape(VALUE)->GetStorageShape();
    const gert::Shape slots =
        context->GetInputShape(SPARSE_SLOTS)->GetStorageShape();
    const gert::Shape hbmTable =
        context->GetInputShape(HBM_BLOCK_TABLE)->GetStorageShape();
    const gert::Shape actualQ =
        context->GetInputShape(ACTUAL_Q)->GetStorageShape();
    const gert::Shape actualKv =
        context->GetInputShape(ACTUAL_KV)->GetStorageShape();
    const gert::Shape queryRope =
        context->GetInputShape(QUERY_ROPE)->GetStorageShape();
    const gert::Shape hbmRope =
        context->GetInputShape(HBM_KEY_ROPE)->GetStorageShape();
    const gert::Shape cacheTokens =
        context->GetInputShape(CACHE_TOKENS)->GetStorageShape();
    const gert::Shape dramRope =
        context->GetInputShape(DRAM_KEY_ROPE)->GetStorageShape();
    const gert::Shape dramKv =
        context->GetInputShape(DRAM_KV_CACHE)->GetStorageShape();
    const gert::Shape dramTable =
        context->GetInputShape(DRAM_BLOCK_TABLE)->GetStorageShape();
    const gert::Shape sourceIds =
        context->GetInputShape(SOURCE_TOKEN_IDS)->GetStorageShape();
    const gert::Shape copyCounts =
        context->GetInputShape(COPY_COUNTS)->GetStorageShape();

    if (!IsShape(query, {-1, -1, CKV_DIM}) ||
        query.GetDim(0) <= 0 ||
        query.GetDim(1) <= 0 ||
        (query.GetDim(1) > MAX_REGULAR_LOCAL_HEADS &&
         query.GetDim(1) != SPLIT_G_LOCAL_HEADS)) {
        return ge::GRAPH_FAILED;
    }
    const int64_t totalQueryTokens = query.GetDim(0);
    const int64_t localHeads = query.GetDim(1);
    const int64_t batchSize = actualQ.GetDimNum() == 1
        ? actualQ.GetDim(0)
        : -1;
    if (batchSize <= 0 ||
        totalQueryTokens != batchSize ||
        !IsShape(hbmKv, {-1, BLOCK_SIZE, 1, CKV_DIM}) ||
        !IsShape(value, {hbmKv.GetDim(0), BLOCK_SIZE, 1, CKV_DIM}) ||
        !IsShape(hbmRope, {hbmKv.GetDim(0), BLOCK_SIZE, 1, KPE_DIM}) ||
        !IsShape(queryRope, {totalQueryTokens, localHeads, KPE_DIM}) ||
        !IsShape(slots, {totalQueryTokens, 1, SPARSE_COUNT}) ||
        !IsShape(hbmTable, {batchSize, -1}) ||
        !IsShape(actualKv, {batchSize}) ||
        !IsShape(cacheTokens, {batchSize}) ||
        !IsShape(dramKv, {-1, BLOCK_SIZE, CKV_DIM}) ||
        !IsShape(dramRope, {dramKv.GetDim(0), BLOCK_SIZE, KPE_DIM}) ||
        !IsShape(dramTable, {batchSize, -1}) ||
        !IsShape(sourceIds, {batchSize, SPARSE_COUNT}) ||
        !IsShape(copyCounts, {batchSize}) ||
        hbmTable.GetDim(1) <= 0 ||
        dramTable.GetDim(1) <= 0) {
        return ge::GRAPH_FAILED;
    }

    const ge::DataType floatingType =
        context->GetInputDesc(QUERY)->GetDataType();
    if (floatingType != ge::DT_BF16 &&
        floatingType != ge::DT_FLOAT16) {
        return ge::GRAPH_FAILED;
    }
    for (size_t index :
         {KEY, VALUE, QUERY_ROPE, HBM_KEY_ROPE,
          DRAM_KEY_ROPE, DRAM_KV_CACHE}) {
        if (context->GetInputDesc(index)->GetDataType() != floatingType) {
            return ge::GRAPH_FAILED;
        }
    }
    for (size_t index :
         {SPARSE_SLOTS, HBM_BLOCK_TABLE, ACTUAL_Q, ACTUAL_KV,
          CACHE_TOKENS, DRAM_BLOCK_TABLE, SOURCE_TOKEN_IDS, COPY_COUNTS}) {
        if (context->GetInputDesc(index)->GetDataType() != ge::DT_INT32) {
            return ge::GRAPH_FAILED;
        }
    }

    copyCap = static_cast<uint32_t>(sourceIds.GetDim(1));
    dramMaxBlockNum = static_cast<uint32_t>(dramTable.GetDim(1));
    return ge::GRAPH_SUCCESS;
}
}  // namespace a5_sfa_fused
