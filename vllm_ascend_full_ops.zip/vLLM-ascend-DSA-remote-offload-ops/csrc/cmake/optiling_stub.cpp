// Copyright (c) 2026.
//
// The project framework always packages an optiling shared library. This
// project contains only AICPU operators, so no AI Core tiling symbols are
// registered here.

extern "C" void KvcacheScatterCopyAicpuOnlyOptilingStub() {}
