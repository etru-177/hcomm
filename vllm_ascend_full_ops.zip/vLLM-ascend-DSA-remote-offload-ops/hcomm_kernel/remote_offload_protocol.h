// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <cstdint>

namespace remote_offload {

// Versioned extension protocol for CPU-DU and recoverable KV offload. It is
// intentionally separate from raw_ub_hybrid_protocol.h so existing GET
// benchmarks retain their byte-for-byte command ABI while the new endpoint is
// being brought up.
constexpr uint32_t kRemoteOffloadMagic = 0x52464f31;  // "RFO1"
constexpr uint16_t kRemoteOffloadVersion = 1;

enum class RemoteOffloadOpcode : uint16_t {
    kGet = 1,
    kPutFull = 2,
    kPutTail = 3,
    kMetadataCommit = 4,
    kSnapshot = 5,
    kPoolDuPush = 6,
};

enum class RemoteMetadataState : uint32_t {
    kAllocated = 1,
    kWriting = 2,
    kCommitted = 3,
    kFailed = 4,
};

struct RemoteOffloadCommandHeader {
    uint32_t magic;
    uint16_t version;
    uint16_t opcode;
    uint32_t flags;
    uint32_t entryCount;
    uint64_t requestId;
    uint64_t generation;
    uint64_t epoch;
    uint32_t layerId;
    uint32_t payloadBytes;
    uint64_t metadataVersion;
    uint64_t reserved;
};

// GET: sourceGva is Pool memory and destinationGva is NPU HBM.
// PUT: sourceGva is NPU HBM and destinationGva is Pool memory; the Pool pulls
// the payload with URMA READ before it publishes metadata.
struct RemoteOffloadIoEntry {
    uint64_t sourceGva;
    uint64_t destinationGva;
    uint32_t bytes;
    uint32_t lane;
};

struct RemoteOffloadMetadataHeader {
    uint32_t magic;
    uint16_t version;
    uint16_t type;
    uint64_t requestId;
    uint64_t epoch;
    uint64_t generation;
    uint64_t logicalLength;
    uint32_t tailValidLength;
    uint32_t layerCount;
    uint32_t blockTableCount;
    uint32_t tokenSlotDeltaCount;
    uint32_t checksum;
    uint32_t state;
};

static_assert(sizeof(RemoteOffloadCommandHeader) == 64);
static_assert(sizeof(RemoteOffloadIoEntry) == 24);
static_assert(sizeof(RemoteOffloadMetadataHeader) == 64);

}  // namespace remote_offload
