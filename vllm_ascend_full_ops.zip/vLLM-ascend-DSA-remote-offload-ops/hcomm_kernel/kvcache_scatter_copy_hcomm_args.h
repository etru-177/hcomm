#pragma once

#include <cstdint>

constexpr uint64_t kHcommScatterMaxLanes = 4;
constexpr uint64_t kHcommProfileSlots = 256;

enum class HcommKvcacheProfileKind : uint64_t {
    SCATTER_COPY = 1,
    BANDWIDTH_PROBE = 2,
};

struct alignas(64) HcommKvcacheProfileRecord {
    uint64_t committedGeneration;
    uint64_t kind;
    uint64_t mode;
    uint64_t logicalBytes;
    uint64_t transferBytes;
    uint64_t entries;
    uint64_t lanes;
    uint64_t readyWaitNs;
    uint64_t prepareNs;
    uint64_t submitNs;
    uint64_t synchronizeNs;
    uint64_t completionWaitNs;
    uint64_t localScatterNs;
    uint64_t totalNs;
    uint64_t pullEntries;
    uint64_t pushEntries;
};
static_assert(sizeof(HcommKvcacheProfileRecord) == 128);

// The ACL CCL-kernel loader invokes an AICPU entry with one contiguous
// argument block. Keep this layout shared by the host launcher and entry.
struct HcommKvcacheScatterCopyArgs {
    void* hbmKpe;
    void* hbmCkv;
    void* hbmStaging;
    const int32_t* hbmBlockTable;
    const uint64_t* dramBlockTable;
    const int32_t* srcTokenIds;
    const int32_t* dstSlots;
    const int32_t* copyCounts;
    int32_t* readyFlag;
    uint64_t thread;
    uint64_t channel;
    uint64_t hbmBlockCount;
    uint64_t hbmStagingBlocks;
    uint64_t hbmMaxBlocks;
    uint64_t dramMaxBlocks;
    uint64_t batchSize;
    uint64_t laneCount;
    uint64_t laneThreads[kHcommScatterMaxLanes];
    uint64_t laneChannels[kHcommScatterMaxLanes];
    uint64_t stagingGva;
    uint64_t commandGva;
    void* deviceControl;
    uint64_t generation;
    uint64_t hostPushPercent;
    uint64_t commandSlots;
    uint64_t localOnly;
    HcommKvcacheProfileRecord* profileRing;
    uint64_t profileSlots;
    // Experimental arguments are appended to preserve the existing ABI prefix.
    uint64_t hostTokenGather;
    uint64_t scatterAfterGather;
    uint64_t deferCompletionToAttention;
    uint64_t ioBytes;
};

struct HcommRawScatterRuntimeContext {
    void* hbmStaging;
    uint64_t hbmStagingBlocks;
    uint64_t stagingGva;
    uint64_t commandGva;
    void* deviceControl;
    uint64_t generation;
    uint64_t hostPushPercent;
    uint64_t commandSlots;
    uint64_t laneCount;
    uint64_t laneThreads[kHcommScatterMaxLanes];
    uint64_t laneChannels[kHcommScatterMaxLanes];
    HcommKvcacheProfileRecord* profileRing;
    uint64_t profileSlots;
    uint64_t hostTokenGather;
    uint64_t scatterAfterGather;
    uint64_t deferCompletionToAttention;
    uint64_t ioBytes;
};

enum class HcommKvcacheBandwidthMode : uint64_t {
    PULL_CONTIGUOUS = 0,
    PUSH_CONTIGUOUS = 1,
    PUSH_AGGREGATE = 2,
};

struct HcommKvcacheBandwidthArgs {
    void* hbmStaging;
    const uint64_t* remoteGvas;
    uint64_t remoteGvaCount;
    uint64_t transferBytes;
    uint64_t mode;
    uint64_t hbmStagingBytes;
    uint64_t laneCount;
    uint64_t laneThreads[kHcommScatterMaxLanes];
    uint64_t laneChannels[kHcommScatterMaxLanes];
    uint64_t stagingGva;
    uint64_t commandGva;
    void* deviceControl;
    uint64_t generation;
    uint64_t commandSlots;
    uint64_t segments;
    HcommKvcacheProfileRecord* profileRing;
    uint64_t profileSlots;
};
