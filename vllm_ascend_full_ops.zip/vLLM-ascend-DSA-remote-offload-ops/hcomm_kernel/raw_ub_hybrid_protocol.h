// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <cstddef>
#include <cstdint>

constexpr uint32_t kRawUbPeerMagic = 0x55425031;       // "UBP1"
constexpr uint32_t kRawUbPeerVersion = 1;
constexpr uint32_t kRawUbLocalPeerMagic = 0x55424c31;  // "UBL1"
constexpr uint32_t kRawUbLocalPeerVersion = 1;
constexpr uint32_t kRawUbControlMagic = 0x55424332;    // "UBC2"
constexpr uint32_t kRawUbControlVersion = 6;
constexpr uint32_t kRawUbMaxLanes = 4;
constexpr uint32_t kRawUbCommandSlots = 8;
constexpr uint32_t kRawUbMaxPushEntries = 256;
constexpr uint32_t kRawUbMaxTokenGatherEntries = 32768;
constexpr uint32_t kRawUbCompletionStride = 64;
constexpr uint64_t kRawUbBlockBytes = 128ULL * (1024ULL + 128ULL);
constexpr uint32_t kRawUbCkvTokenBytes = 1024;
constexpr uint32_t kRawUbKpeTokenBytes = 128;
constexpr uint32_t kRawUbTokenBytes =
    kRawUbCkvTokenBytes + kRawUbKpeTokenBytes;
constexpr uint32_t kRawUbFlatFp8TokenBytes = 576;
constexpr uint32_t kRawUbFlatC8TokenBytes = 656;
constexpr uint32_t kRawUbCommandModeDirect = 0;
constexpr uint32_t kRawUbCommandModeAggregate = 1;
constexpr uint32_t kRawUbCommandModeTokenGather = 2;
constexpr uint32_t kRawUbAggregationFieldMask = 0xffff;
constexpr uint32_t kRawUbFixedWqeUnitBytes = 64;

constexpr uint32_t PackRawUbAggregationConfig(
    uint32_t maxSubIosPerWqe, uint32_t fixedWqeBytes)
{
    return (maxSubIosPerWqe & kRawUbAggregationFieldMask) |
        ((fixedWqeBytes / kRawUbFixedWqeUnitBytes) << 16);
}

constexpr uint32_t RawUbMaxSubIosPerWqe(uint32_t config)
{
    return config & kRawUbAggregationFieldMask;
}

constexpr uint32_t RawUbFixedWqeBytes(uint32_t config)
{
    return (config >> 16) * kRawUbFixedWqeUnitBytes;
}

struct RawUbPeerDescriptor {
    uint32_t magic;
    uint32_t version;
    uint8_t eid[16];
    uint32_t uasid;
    uint32_t jettyId;
    uint32_t transportMode;
    uint32_t tokenValue;
    uint64_t gva;
    uint64_t bytes;
    uint32_t segmentBytes;
    uint32_t tokenId;
    uint8_t segment[64];
};

struct RawUbLocalPeerDescriptor {
    uint32_t magic;
    uint32_t version;
    uint8_t eid[16];
    uint32_t uasid;
    uint32_t jettyId;
    uint32_t transportMode;
    uint32_t tokenValue;
    uint32_t keyBytes;
    uint8_t key[64];
};

struct RawUbLocalMemDescriptor {
    uint64_t gva;
    uint64_t bytes;
    uint32_t tokenValue;
    uint32_t segmentBytes;
    uint8_t segment[64];
};

struct RawUbControlRequest {
    uint32_t magic;
    uint32_t version;
    uint32_t laneCount;
    // Packed max-sub-IO and fixed-WQE configuration. Zero preserves the
    // existing maximum-aggregation pool behavior and packed payload length.
    uint32_t reserved;
};

struct RawUbControlResponse {
    uint32_t magic;
    uint32_t version;
    uint32_t laneCount;
    uint32_t commandSlots;
    uint64_t dataGva;
    uint64_t dataBytes;
    uint64_t commandGva;
    uint32_t commandStride;
    uint32_t reserved;
};

struct RawUbClientResources {
    uint32_t magic;
    uint32_t version;
    uint32_t laneCount;
    uint32_t reserved;
    uint64_t stagingGva;
    uint64_t stagingBytes;
    uint64_t deviceControlGva;
    uint64_t deviceControlBytes;
    RawUbLocalMemDescriptor stagingSegment;
    RawUbLocalPeerDescriptor peers[kRawUbMaxLanes];
};

struct RawUbControlAck {
    uint32_t magic;
    uint32_t version;
    uint32_t status;
    uint32_t reserved;
};

struct RawUbHostPushEntry {
    uint64_t srcGva;
    uint64_t dstGva;
    uint32_t bytes;
    uint32_t lane;
};

struct RawUbTokenGatherEntry {
    uint64_t blockGva;
    uint32_t tokenOffset;
    // 1152 keeps the split CKV/KPE layout; 576/656 select a flat IO.
    uint32_t tokenBytes;
};

struct alignas(kRawUbCompletionStride) RawUbCompletionSlot {
    uint64_t observedGeneration;
    uint64_t expectedGeneration;
    uint8_t reserved[kRawUbCompletionStride - 2 * sizeof(uint64_t)];
};

constexpr uint32_t kRawUbCommandHeaderBytes = 24;
constexpr uint32_t kRawUbCommandPayloadBytes =
    kRawUbCommandHeaderBytes +
    kRawUbMaxTokenGatherEntries * sizeof(RawUbTokenGatherEntry);
constexpr uint32_t kRawUbCommandAlignment = 8192;
constexpr uint32_t kRawUbCommandSlotBytes =
    ((kRawUbCommandPayloadBytes + sizeof(uint64_t) +
      kRawUbCommandAlignment - 1) /
     kRawUbCommandAlignment) *
    kRawUbCommandAlignment;
constexpr uint32_t kRawUbCommandCommitOffset = kRawUbCommandSlotBytes - sizeof(uint64_t);
constexpr uint32_t kRawUbDeviceControlBytes =
    kRawUbCommandSlotBytes + kRawUbCommandSlots * kRawUbCompletionStride;

constexpr uint32_t RawUbCommandPayloadBytesFor(
    uint32_t mode, uint32_t entryCount)
{
    return kRawUbCommandHeaderBytes +
        entryCount * (mode == kRawUbCommandModeTokenGather ?
            sizeof(RawUbTokenGatherEntry) : sizeof(RawUbHostPushEntry));
}

struct alignas(64) RawUbHostCommandSlot {
    uint64_t generation;
    uint32_t entryCount;
    uint32_t reserved;
    uint64_t destinationGva;
    union {
        RawUbHostPushEntry entries[kRawUbMaxPushEntries];
        RawUbTokenGatherEntry tokenEntries[kRawUbMaxTokenGatherEntries];
    };
    uint8_t padding[kRawUbCommandCommitOffset - kRawUbCommandPayloadBytes];
    uint64_t commitGeneration;
};

static_assert(sizeof(RawUbPeerDescriptor) == 128);
static_assert(sizeof(RawUbLocalPeerDescriptor) == 108);
static_assert(sizeof(RawUbLocalMemDescriptor) == 88);
static_assert(sizeof(RawUbControlRequest) == 16);
static_assert(sizeof(RawUbHostPushEntry) == 24);
static_assert(sizeof(RawUbTokenGatherEntry) == 16);
static_assert(sizeof(RawUbCompletionSlot) == kRawUbCompletionStride);
static_assert(sizeof(RawUbHostCommandSlot) == kRawUbCommandSlotBytes);
