// Device-side KV cache scatter-copy entry compiled into Hcomm's libccl_kernel.
// Keep this file in vLLM-ascend-DSA; Hcomm only supplies the build target and
// the Hcomm primitives used for the final batch READ.

#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <time.h>

#include <hcomm_primitives.h>
#include "log.h"

#include "kvcache_scatter_copy_hcomm_args.h"
#include "raw_ub_hybrid_protocol.h"

// Hcomm's A5 implementation waits until the AICPU RTSQ consumes all tasks
// submitted on this thread.  This internal primitive is intentionally kept
// out of the public Hcomm header for now.
extern "C" int32_t HcommThreadSynchronize(ThreadHandle thread);

namespace {
constexpr uint64_t kBlockSize = 128;
constexpr uint64_t kBlockMask = kBlockSize - 1;
constexpr uint64_t kBlockShift = 7;
constexpr uint64_t kKpeTokenBytes = 128;
constexpr uint64_t kCkvTokenBytes = 1024;
constexpr uint64_t kBlockBytes = kBlockSize * (kCkvTokenBytes + kKpeTokenBytes);
constexpr uint64_t kCopyCap = 16384;
constexpr uint64_t kPrefetchCapacity = 256;
constexpr uint64_t kTransferCapacity = kPrefetchCapacity + 2;
constexpr uint64_t kProfileModeBlockScatter = 0;
constexpr uint64_t kProfileModeLocalScatter = 1;
constexpr uint64_t kProfileModeTokenGatherScatter = 2;
constexpr uint64_t kProfileModeTokenGatherWorkspace = 3;
static_assert(kHcommScatterMaxLanes == kRawUbMaxLanes);
static_assert(kCkvTokenBytes == kRawUbCkvTokenBytes);
static_assert(kKpeTokenBytes == kRawUbKpeTokenBytes);
static_assert(kBlockBytes == kRawUbBlockBytes);

inline uint64_t NowNs()
{
    timespec timestamp{};
    (void)clock_gettime(CLOCK_MONOTONIC, &timestamp);
    return static_cast<uint64_t>(timestamp.tv_sec) * 1000000000ULL +
        static_cast<uint64_t>(timestamp.tv_nsec);
}

template<std::size_t Capacity>
inline void Submit(ThreadHandle thread, ChannelHandle channel,
    std::array<HcommBatchTransferDesc, Capacity>& descs, uint32_t count)
{
    if (count != 0) {
        (void)HcommBatchTransferOnThread(thread, channel, descs.data(), count);
    }
}

inline void WaitReady(const int32_t* readyFlag)
{
    if (readyFlag != nullptr) {
        while (__atomic_load_n(readyFlag, __ATOMIC_ACQUIRE) != 1) {
        }
    }
}

inline void CommitProfile(HcommKvcacheProfileRecord* ring, uint64_t slots,
    uint64_t generation, const HcommKvcacheProfileRecord& value)
{
    if (ring == nullptr || slots == 0 || generation == 0) return;
    HcommKvcacheProfileRecord* record = &ring[(generation - 1) % slots];
    record->committedGeneration = 0;
    record->kind = value.kind;
    record->mode = value.mode;
    record->logicalBytes = value.logicalBytes;
    record->transferBytes = value.transferBytes;
    record->entries = value.entries;
    record->lanes = value.lanes;
    record->readyWaitNs = value.readyWaitNs;
    record->prepareNs = value.prepareNs;
    record->submitNs = value.submitNs;
    record->synchronizeNs = value.synchronizeNs;
    record->completionWaitNs = value.completionWaitNs;
    record->localScatterNs = value.localScatterNs;
    record->totalNs = value.totalNs;
    record->pullEntries = value.pullEntries;
    record->pushEntries = value.pushEntries;
    __atomic_store_n(&record->committedGeneration, generation, __ATOMIC_RELEASE);
}
} // namespace

namespace {
uint32_t HcommKvcacheScatterCopyImpl(
    void* hbmKpe, void* hbmCkv, void* hbmStaging,
    const int32_t* hbmBlockTable, const uint64_t* dramBlockTable,
    const int32_t* srcTokenIds, const int32_t* dstSlots, const int32_t* copyCounts,
    int32_t* readyFlag,
    uint64_t hbmBlockCount, uint64_t hbmStagingBlocks, uint64_t hbmMaxBlocks,
    uint64_t dramMaxBlocks, uint64_t batchSize, uint64_t laneCount,
    const uint64_t* laneThreads, const uint64_t* laneChannels,
    uint64_t stagingGva, uint64_t commandGva, void* deviceControl,
    uint64_t generation, uint64_t hostPushPercent, uint64_t commandSlots,
    uint64_t localOnly, HcommKvcacheProfileRecord* profileRing, uint64_t profileSlots,
    uint64_t hostTokenGather, uint64_t scatterAfterGather,
    uint64_t deferCompletionToAttention, uint64_t ioBytes)
{
    const uint64_t invocationStartNs = NowNs();
    WaitReady(readyFlag);
    const uint64_t kernelStartNs = NowNs();

    const uint64_t stagingEntries = batchSize * dramMaxBlocks;
    const bool tokenLayout = hostTokenGather != 0;
    const bool splitTokenLayout = ioBytes == kRawUbTokenBytes;
    const bool supportedIoBytes = splitTokenLayout ||
        ioBytes == kRawUbFlatFp8TokenBytes ||
        ioBytes == kRawUbFlatC8TokenBytes;
    if (hbmStaging == nullptr ||
        (!tokenLayout &&
         (stagingEntries > hbmStagingBlocks ||
          stagingEntries > kPrefetchCapacity)) ||
        deviceControl == nullptr ||
        commandSlots == 0 || commandSlots > kRawUbCommandSlots ||
        hostPushPercent > 100 || hostTokenGather > 1 || scatterAfterGather > 1 ||
        deferCompletionToAttention > 1 ||
        !supportedIoBytes || (!tokenLayout && !splitTokenLayout) ||
        (tokenLayout && hostPushPercent != 100)) {
        return 1;
    }

    std::array<uint8_t, kPrefetchCapacity> requestedBlocks{};
    auto* command = static_cast<RawUbHostCommandSlot*>(deviceControl);
    uint64_t totalCopies = 0;
    for (uint64_t batch = 0; batch < batchSize; ++batch) {
        const int32_t copyCount = copyCounts[batch];
        if (copyCount < 0 || static_cast<uint64_t>(copyCount) > kCopyCap) {
            return 1;
        }
        for (int32_t copy = 0; copy < copyCount; ++copy) {
            const uint64_t item = batch * kCopyCap + static_cast<uint64_t>(copy);
            const int32_t srcToken = srcTokenIds[item];
            if (srcToken < 0) {
                return 1;
            }
            const uint64_t srcBlock = static_cast<uint64_t>(srcToken) >> kBlockShift;
            if (srcBlock >= dramMaxBlocks) {
                return 1;
            }
            if (tokenLayout && localOnly == 0) {
                if (totalCopies >= kRawUbMaxTokenGatherEntries) {
                    return 1;
                }
                auto& entry = command->tokenEntries[totalCopies];
                entry.blockGva =
                    dramBlockTable[batch * dramMaxBlocks + srcBlock];
                entry.tokenOffset =
                    static_cast<uint32_t>(
                        static_cast<uint64_t>(srcToken) & kBlockMask);
                entry.tokenBytes = static_cast<uint32_t>(ioBytes);
            } else if (!tokenLayout) {
                requestedBlocks[batch * dramMaxBlocks + srcBlock] = 1;
            }
            ++totalCopies;
        }
    }
    if (tokenLayout &&
        (totalCopies > kRawUbMaxTokenGatherEntries ||
         totalCopies * ioBytes > hbmStagingBlocks * kBlockBytes)) {
        return 1;
    }

    if (laneCount == 0 || laneCount > kHcommScatterMaxLanes) return 1;
    std::array<uint32_t, kPrefetchCapacity> requestedIndices{};
    uint32_t requestedCount = 0;
    if (!tokenLayout) {
        for (uint32_t stagingBlock = 0;
             stagingBlock < stagingEntries; ++stagingBlock) {
            if (requestedBlocks[stagingBlock] != 0) {
                requestedIndices[requestedCount++] = stagingBlock;
            }
        }
    }
    const uint32_t hostBlockCount =
        localOnly != 0 || tokenLayout ? 0 : static_cast<uint32_t>(
            (static_cast<uint64_t>(requestedCount) * hostPushPercent + 99) / 100);
    const uint32_t commandEntryCount = localOnly != 0 ? 0 :
        (tokenLayout ? static_cast<uint32_t>(totalCopies) : hostBlockCount);
    const uint32_t commandSlot = static_cast<uint32_t>((generation - 1) % commandSlots);
    auto* completions = static_cast<uint8_t*>(deviceControl) + kRawUbCommandSlotBytes;
    auto* completion = reinterpret_cast<RawUbCompletionSlot*>(
        completions + static_cast<uint64_t>(commandSlot) * kRawUbCompletionStride);
    __atomic_store_n(
        &completion->observedGeneration, uint64_t{0}, __ATOMIC_RELEASE);
    __atomic_store_n(
        &completion->expectedGeneration, generation, __ATOMIC_RELEASE);
    auto* volatileObserved =
        reinterpret_cast<volatile uint64_t*>(&completion->observedGeneration);
    command->generation = generation;
    command->entryCount = commandEntryCount;
    command->reserved =
        tokenLayout ? kRawUbCommandModeTokenGather : kRawUbCommandModeDirect;
    command->destinationGva = tokenLayout ? stagingGva : 0;

    std::array<HcommBatchTransferDesc, 2> commandDescs{};
    uint32_t commandDescCount = 0;
    std::array<std::array<HcommBatchTransferDesc, kTransferCapacity>, kHcommScatterMaxLanes> laneDescs{};
    std::array<uint32_t, kHcommScatterMaxLanes> laneCounts{};
    if (commandEntryCount != 0) {
        auto& payload = commandDescs[commandDescCount++];
        payload.transType = HCOMM_TRANSFER_TYPE_WRITE;
        payload.transferInfo.write.dst = reinterpret_cast<void*>(
            commandGva + static_cast<uint64_t>(commandSlot) * kRawUbCommandSlotBytes);
        payload.transferInfo.write.src = command;
        payload.transferInfo.write.len =
            RawUbCommandPayloadBytesFor(command->reserved, commandEntryCount);
    }

    uint32_t pullBlockCount = 0;
    if (!tokenLayout) {
        for (uint32_t ordinal = 0; ordinal < requestedCount; ++ordinal) {
            const uint64_t stagingBlock = requestedIndices[ordinal];
            if (localOnly != 0) continue;
            const uint64_t remoteBlock = dramBlockTable[stagingBlock];
            const uint64_t lane = ordinal % laneCount;
            if (ordinal < hostBlockCount) {
                auto& entry = command->entries[ordinal];
                entry.srcGva = remoteBlock;
                entry.dstGva = stagingGva + stagingBlock * kBlockBytes;
                entry.bytes = static_cast<uint32_t>(kBlockBytes);
                entry.lane = static_cast<uint32_t>(lane);
                continue;
            }
            auto& desc = laneDescs[lane][laneCounts[lane]++];
            desc.transType = HCOMM_TRANSFER_TYPE_READ;
            desc.transferInfo.read.dst =
                static_cast<uint8_t*>(hbmStaging) + stagingBlock * kBlockBytes;
            desc.transferInfo.read.src = reinterpret_cast<void*>(remoteBlock);
            desc.transferInfo.read.len = kBlockBytes;
            ++pullBlockCount;
        }
    }
    if (commandEntryCount != 0) {
        __atomic_store_n(&command->commitGeneration, generation, __ATOMIC_RELEASE);
        auto& commit = commandDescs[commandDescCount++];
        commit.transType = HCOMM_TRANSFER_TYPE_WRITE;
        commit.transferInfo.write.dst = reinterpret_cast<void*>(
            commandGva + static_cast<uint64_t>(commandSlot) * kRawUbCommandSlotBytes +
            kRawUbCommandCommitOffset);
        commit.transferInfo.write.src = &command->commitGeneration;
        commit.transferInfo.write.len = sizeof(command->commitGeneration);
    }

    const uint64_t prepareEndNs = NowNs();
    const uint64_t prefetchStartNs = prepareEndNs;
    int32_t batchEndRet = 0;
    int32_t syncRet = 0;
    if ((commandDescCount != 0 || pullBlockCount != 0) && localOnly == 0) {
        (void)HcommBatchModeStart(nullptr);
        if (commandDescCount != 0) {
            Submit(laneThreads[0], laneChannels[0], commandDescs, commandDescCount);
        }
        for (uint64_t lane = 0; lane < laneCount; ++lane) {
            Submit(laneThreads[lane], laneChannels[lane], laneDescs[lane], laneCounts[lane]);
        }
        batchEndRet = HcommBatchModeEnd(nullptr);
    }
    const uint64_t submitEndNs = NowNs();
    if ((commandDescCount != 0 || pullBlockCount != 0) && localOnly == 0) {
        for (uint64_t lane = 0; lane < laneCount; ++lane) {
            if (laneCounts[lane] != 0 || (lane == 0 && commandDescCount != 0)) {
                syncRet |= HcommThreadSynchronize(laneThreads[lane]);
            }
        }
    }
    const uint64_t pullEndNs = NowNs();
    const bool deferCompletion =
        localOnly == 0 && tokenLayout && scatterAfterGather == 0 &&
        deferCompletionToAttention != 0;
    if (commandEntryCount != 0 && !deferCompletion) {
        if (generation == 1) {
            HCCL_INFO("[HcommKvcacheScatterCopy][HYBRID] command submitted. "
                "mode[%u] pushEntries[%u] batchEndRet[%d] syncRet[%d] "
                "completion[%p] expected[%llu].",
                command->reserved, commandEntryCount, batchEndRet, syncRet,
                completion, generation);
        }
        uint64_t observed = 0;
        do {
            observed = *volatileObserved;
        } while (observed != generation);
        if (generation == 1) {
            HCCL_INFO("[HcommKvcacheScatterCopy][HYBRID] completion observed. "
                "address[%p] observed[%llu] expected[%llu].",
                completion, observed, generation);
        }
    }
    const uint64_t prefetchEndNs = NowNs();

    const bool doScatter =
        localOnly != 0 || !tokenLayout || scatterAfterGather != 0;
    uint64_t tokenOrdinal = 0;
    if (doScatter) {
        for (uint64_t batch = 0; batch < batchSize; ++batch) {
            for (int32_t copy = 0; copy < copyCounts[batch]; ++copy) {
                const uint64_t item =
                    batch * kCopyCap + static_cast<uint64_t>(copy);
                const int32_t srcToken = srcTokenIds[item];
                const int32_t dstToken = dstSlots[item];
                if (srcToken < 0 || dstToken < 0) {
                    return 1;
                }
                const uint64_t srcBlock =
                    static_cast<uint64_t>(srcToken) >> kBlockShift;
                const uint64_t dstBlock =
                    static_cast<uint64_t>(dstToken) >> kBlockShift;
                if (srcBlock >= dramMaxBlocks || dstBlock >= hbmMaxBlocks) {
                    return 1;
                }
                const int32_t physicalBlock =
                    hbmBlockTable[batch * hbmMaxBlocks + dstBlock];
                if (physicalBlock < 0 ||
                    static_cast<uint64_t>(physicalBlock) >= hbmBlockCount) {
                    return 1;
                }
                const uint64_t srcOffset =
                    static_cast<uint64_t>(srcToken) & kBlockMask;
                const uint64_t dstOffset =
                    static_cast<uint64_t>(dstToken) & kBlockMask;
                const uint8_t* src = nullptr;
                const uint8_t* srcCkv = nullptr;
                const uint8_t* srcKpe = nullptr;
                if (tokenLayout) {
                    src = static_cast<uint8_t*>(hbmStaging) +
                        tokenOrdinal * ioBytes;
                    srcCkv = src;
                    srcKpe = splitTokenLayout ? src + kCkvTokenBytes : nullptr;
                } else {
                    src = static_cast<uint8_t*>(hbmStaging) +
                        (batch * dramMaxBlocks + srcBlock) * kBlockBytes;
                    srcCkv = src + srcOffset * kCkvTokenBytes;
                    srcKpe = src + kBlockSize * kCkvTokenBytes +
                        srcOffset * kKpeTokenBytes;
                }
                if (tokenLayout && !splitTokenLayout) {
                    const uint64_t destinationBytes =
                        static_cast<uint64_t>(physicalBlock) *
                            kBlockSize * ioBytes +
                        dstOffset * ioBytes;
                    std::memcpy(static_cast<uint8_t*>(hbmCkv) + destinationBytes,
                        srcCkv, ioBytes);
                } else {
                    const uint64_t dstOffsetTokens =
                        static_cast<uint64_t>(physicalBlock) * kBlockSize + dstOffset;
                    std::memcpy(
                        static_cast<uint8_t*>(hbmCkv) +
                            dstOffsetTokens * kCkvTokenBytes,
                        srcCkv, kCkvTokenBytes);
                    std::memcpy(
                        static_cast<uint8_t*>(hbmKpe) +
                            dstOffsetTokens * kKpeTokenBytes,
                        srcKpe, kKpeTokenBytes);
                }
                ++tokenOrdinal;
            }
        }
    }
    const uint64_t endNs = NowNs();
    const uint64_t logicalBytes = totalCopies * ioBytes;
    HcommKvcacheProfileRecord profile{};
    profile.kind = static_cast<uint64_t>(HcommKvcacheProfileKind::SCATTER_COPY);
    profile.mode = localOnly != 0 ? kProfileModeLocalScatter :
        (tokenLayout ?
            (scatterAfterGather != 0 ? kProfileModeTokenGatherScatter :
                kProfileModeTokenGatherWorkspace) :
            kProfileModeBlockScatter);
    profile.logicalBytes = logicalBytes;
    profile.transferBytes = localOnly != 0 ? 0 :
        (tokenLayout ? logicalBytes :
            static_cast<uint64_t>(requestedCount) * kBlockBytes);
    profile.entries = tokenLayout ? totalCopies : requestedCount;
    profile.lanes = laneCount;
    profile.readyWaitNs = kernelStartNs - invocationStartNs;
    profile.prepareNs = prepareEndNs - kernelStartNs;
    profile.submitNs = submitEndNs - prefetchStartNs;
    profile.synchronizeNs = pullEndNs - submitEndNs;
    profile.completionWaitNs = prefetchEndNs - pullEndNs;
    profile.localScatterNs = doScatter ? endNs - prefetchEndNs : 0;
    profile.totalNs = endNs - invocationStartNs;
    profile.pullEntries = pullBlockCount;
    profile.pushEntries = commandEntryCount;
    CommitProfile(profileRing, profileSlots, generation, profile);
    const uint64_t fetchedBytes = tokenLayout ? logicalBytes :
        static_cast<uint64_t>(requestedCount) * kBlockBytes;
    HCCL_DEBUG("[HcommKvcacheScatterCopy][PERF] copies[%llu] pullEntries[%u] pushEntries[%u] "
        "logicalBytes[%llu] fetchedBytes[%llu] pullWaitUs[%llu] hostWaitUs[%llu] "
        "scatterUs[%llu] totalUs[%llu] "
        "batchEndRet[%d] syncRet[%d].",
        totalCopies, pullBlockCount, commandEntryCount, logicalBytes, fetchedBytes,
        (pullEndNs - prefetchStartNs) / 1000, (prefetchEndNs - pullEndNs) / 1000,
        doScatter ? (endNs - prefetchEndNs) / 1000 : 0,
        (endNs - kernelStartNs) / 1000, batchEndRet, syncRet);
    (void)batchEndRet;
    (void)syncRet;
    (void)fetchedBytes;
    return 0;
}

uint32_t HcommKvcacheBandwidthProbeImpl(const HcommKvcacheBandwidthArgs* params)
{
    const uint64_t beginNs = NowNs();
    if (params == nullptr || params->hbmStaging == nullptr || params->remoteGvas == nullptr ||
        params->remoteGvaCount == 0 || params->transferBytes == 0 ||
        params->transferBytes > params->hbmStagingBytes ||
        params->laneCount == 0 || params->laneCount > kHcommScatterMaxLanes ||
        params->segments == 0 || params->segments > kRawUbMaxPushEntries ||
        params->transferBytes % params->segments != 0) {
        return 1;
    }

    const auto mode = static_cast<HcommKvcacheBandwidthMode>(params->mode);
    if (mode == HcommKvcacheBandwidthMode::PULL_CONTIGUOUS) {
        std::array<HcommBatchTransferDesc, kRawUbMaxPushEntries> descs{};
        std::array<uint32_t, kHcommScatterMaxLanes> laneCounts{};
        std::array<uint32_t, kHcommScatterMaxLanes> laneStarts{};
        std::array<uint32_t, kHcommScatterMaxLanes> laneOffsets{};
        for (uint32_t segment = 0; segment < params->segments; ++segment) {
            ++laneCounts[segment % params->laneCount];
        }
        for (uint32_t lane = 1; lane < params->laneCount; ++lane) {
            laneStarts[lane] = laneStarts[lane - 1] + laneCounts[lane - 1];
        }
        const uint64_t segmentBytes = params->transferBytes / params->segments;
        for (uint32_t segment = 0; segment < params->segments; ++segment) {
            const uint32_t lane = segment % params->laneCount;
            auto& desc = descs[laneStarts[lane] + laneOffsets[lane]++];
            const uint64_t offset = static_cast<uint64_t>(segment) * segmentBytes;
            desc.transType = HCOMM_TRANSFER_TYPE_READ;
            desc.transferInfo.read.dst = static_cast<uint8_t*>(params->hbmStaging) + offset;
            desc.transferInfo.read.src = reinterpret_cast<void*>(params->remoteGvas[0] + offset);
            desc.transferInfo.read.len = segmentBytes;
        }
        const uint64_t prepareEndNs = NowNs();
        (void)HcommBatchModeStart(nullptr);
        for (uint64_t lane = 0; lane < params->laneCount; ++lane) {
            if (laneCounts[lane] != 0) {
                (void)HcommBatchTransferOnThread(params->laneThreads[lane],
                    params->laneChannels[lane], descs.data() + laneStarts[lane],
                    laneCounts[lane]);
            }
        }
        (void)HcommBatchModeEnd(nullptr);
        const uint64_t submitEndNs = NowNs();
        for (uint64_t lane = 0; lane < params->laneCount; ++lane) {
            if (laneCounts[lane] != 0) {
                (void)HcommThreadSynchronize(params->laneThreads[lane]);
            }
        }
        const uint64_t endNs = NowNs();
        HcommKvcacheProfileRecord profile{};
        profile.kind = static_cast<uint64_t>(HcommKvcacheProfileKind::BANDWIDTH_PROBE);
        profile.mode = params->mode;
        profile.logicalBytes = params->transferBytes;
        profile.transferBytes = params->transferBytes;
        profile.entries = params->segments;
        profile.lanes = params->laneCount;
        profile.prepareNs = prepareEndNs - beginNs;
        profile.submitNs = submitEndNs - prepareEndNs;
        profile.synchronizeNs = endNs - submitEndNs;
        profile.totalNs = endNs - beginNs;
        profile.pullEntries = params->segments;
        CommitProfile(params->profileRing, params->profileSlots, params->generation, profile);
        return 0;
    }

    if (params->deviceControl == nullptr || params->commandSlots == 0 ||
        params->commandSlots > kRawUbCommandSlots) {
        return 1;
    }
    const bool aggregate = mode == HcommKvcacheBandwidthMode::PUSH_AGGREGATE;
    if (mode != HcommKvcacheBandwidthMode::PUSH_CONTIGUOUS && !aggregate) {
        return 1;
    }
    if (aggregate &&
        (params->remoteGvaCount > kRawUbMaxPushEntries ||
         params->transferBytes % params->remoteGvaCount != 0 ||
         params->transferBytes / params->remoteGvaCount > UINT32_MAX)) {
        return 1;
    }
    const uint64_t segmentCount = aggregate ? params->remoteGvaCount : params->segments;
    if (segmentCount > kRawUbMaxPushEntries ||
        params->transferBytes % segmentCount != 0) {
        return 1;
    }

    const uint32_t commandSlot =
        static_cast<uint32_t>((params->generation - 1) % params->commandSlots);
    auto* command = static_cast<RawUbHostCommandSlot*>(params->deviceControl);
    auto* completion = reinterpret_cast<volatile uint64_t*>(
        static_cast<uint8_t*>(params->deviceControl) + kRawUbCommandSlotBytes +
        static_cast<uint64_t>(commandSlot) * kRawUbCompletionStride);
    *completion = 0;
    command->generation = params->generation;
    command->reserved = aggregate ? kRawUbCommandModeAggregate : kRawUbCommandModeDirect;
    command->destinationGva = 0;

    if (aggregate) {
        command->entryCount = static_cast<uint32_t>(params->remoteGvaCount);
        const uint64_t chunkBytes = params->transferBytes / params->remoteGvaCount;
        for (uint32_t index = 0; index < command->entryCount; ++index) {
            auto& entry = command->entries[index];
            entry.srcGva = params->remoteGvas[index];
            entry.dstGva = params->stagingGva + static_cast<uint64_t>(index) * chunkBytes;
            entry.bytes = static_cast<uint32_t>(chunkBytes);
            entry.lane = 0;
        }
    } else {
        command->entryCount = static_cast<uint32_t>(segmentCount);
        const uint64_t bytes = params->transferBytes / segmentCount;
        if (bytes > UINT32_MAX) return 1;
        for (uint32_t segment = 0; segment < command->entryCount; ++segment) {
            const uint64_t offset = static_cast<uint64_t>(segment) * bytes;
            auto& entry = command->entries[segment];
            entry.srcGva = params->remoteGvas[0] + offset;
            entry.dstGva = params->stagingGva + offset;
            entry.bytes = static_cast<uint32_t>(bytes);
            entry.lane = segment % params->laneCount;
        }
    }

    std::array<HcommBatchTransferDesc, 2> commandDescs{};
    auto& payload = commandDescs[0];
    payload.transType = HCOMM_TRANSFER_TYPE_WRITE;
    payload.transferInfo.write.dst = reinterpret_cast<void*>(
        params->commandGva + static_cast<uint64_t>(commandSlot) * kRawUbCommandSlotBytes);
    payload.transferInfo.write.src = command;
    payload.transferInfo.write.len =
        RawUbCommandPayloadBytesFor(command->reserved, command->entryCount);
    __atomic_store_n(&command->commitGeneration, params->generation, __ATOMIC_RELEASE);
    auto& commit = commandDescs[1];
    commit.transType = HCOMM_TRANSFER_TYPE_WRITE;
    commit.transferInfo.write.dst = reinterpret_cast<void*>(
        params->commandGva + static_cast<uint64_t>(commandSlot) * kRawUbCommandSlotBytes +
        kRawUbCommandCommitOffset);
    commit.transferInfo.write.src = &command->commitGeneration;
    commit.transferInfo.write.len = sizeof(command->commitGeneration);

    const uint64_t prepareEndNs = NowNs();
    (void)HcommBatchModeStart(nullptr);
    Submit(params->laneThreads[0], params->laneChannels[0], commandDescs, 2);
    (void)HcommBatchModeEnd(nullptr);
    const uint64_t submitEndNs = NowNs();
    (void)HcommThreadSynchronize(params->laneThreads[0]);
    const uint64_t syncEndNs = NowNs();
    while (*completion != params->generation) {
    }
    const uint64_t endNs = NowNs();
    HcommKvcacheProfileRecord profile{};
    profile.kind = static_cast<uint64_t>(HcommKvcacheProfileKind::BANDWIDTH_PROBE);
    profile.mode = params->mode;
    profile.logicalBytes = params->transferBytes;
    profile.transferBytes = params->transferBytes;
    profile.entries = segmentCount;
    profile.lanes = params->laneCount;
    profile.prepareNs = prepareEndNs - beginNs;
    profile.submitNs = submitEndNs - prepareEndNs;
    profile.synchronizeNs = syncEndNs - submitEndNs;
    profile.completionWaitNs = endNs - syncEndNs;
    profile.totalNs = endNs - beginNs;
    profile.pushEntries = segmentCount;
    CommitProfile(params->profileRing, params->profileSlots, params->generation, profile);
    return 0;
}
} // namespace

extern "C" __attribute__((visibility("default"))) uint32_t HcommKvcacheScatterCopy(void* args)
{
    const auto* params = static_cast<const HcommKvcacheScatterCopyArgs*>(args);
    return HcommKvcacheScatterCopyImpl(
        params->hbmKpe, params->hbmCkv, params->hbmStaging,
        params->hbmBlockTable, params->dramBlockTable,
        params->srcTokenIds, params->dstSlots, params->copyCounts, params->readyFlag,
        params->hbmBlockCount, params->hbmStagingBlocks, params->hbmMaxBlocks,
        params->dramMaxBlocks, params->batchSize, params->laneCount, params->laneThreads, params->laneChannels,
        params->stagingGva, params->commandGva, params->deviceControl, params->generation,
        params->hostPushPercent, params->commandSlots,
        params->localOnly, params->profileRing, params->profileSlots,
        params->hostTokenGather, params->scatterAfterGather,
        params->deferCompletionToAttention, params->ioBytes);
}

extern "C" __attribute__((visibility("default"))) uint32_t HcommKvcacheBandwidthProbe(void* args)
{
    return HcommKvcacheBandwidthProbeImpl(
        static_cast<const HcommKvcacheBandwidthArgs*>(args));
}
