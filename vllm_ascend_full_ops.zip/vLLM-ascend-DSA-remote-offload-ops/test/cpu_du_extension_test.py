#!/usr/bin/env python3
"""验证 PyTorch 扩展导出的 CPU DU 接口。"""

from __future__ import annotations

import sys
from pathlib import Path

import torch


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "torch_extension"))

from kvcache_scatter_copy_custom_ops import (  # noqa: E402
    CpuDuBatchWorkerRuntime,
    CpuDuWorkerRuntime,
    cpu_lidu_du_update,
    cpu_lidu_du_update_union,
)


TOPK = 2048
OWNER_BIT = 1 << 30


def topk_with_misses(budget: int, misses: int) -> torch.Tensor:
    hits = torch.arange(TOPK - misses, dtype=torch.int32)
    remote = torch.arange(
        budget, budget + misses, dtype=torch.int32
    )
    return torch.cat((hits, remote))


def main() -> None:
    budget = 4096
    capacity = 10000
    initial_state = torch.full((capacity,), -1, dtype=torch.int32)
    initial_state[:budget] = torch.arange(budget, dtype=torch.int32)
    # cpu_lidu_du_update* 会原地提交 token->slot 状态。后面的批量 worker
    # 测试必须从同一份初始模板开始，不能复用已经收敛到零 miss 的 state。
    state = initial_state.clone()
    topk = torch.stack(
        [topk_with_misses(budget, misses) for misses in (0, 100, 200, 300)]
    )

    outputs = cpu_lidu_du_update_union(
        topk, state, budget, capacity, generation=7, hits_first=True
    )
    if len(outputs) != 15:
        raise AssertionError(f"CPU DU 输出数量错误：{len(outputs)}")
    source_ids, slots, refs, miss_counts = outputs[:4]
    unique_sources, unique_slots, victims, alias, generation = outputs[4:9]
    if source_ids.shape != (4, 1, TOPK) or slots.shape != source_ids.shape:
        raise AssertionError("CPU DU TopK 输出 shape 错误")
    if refs.shape != source_ids.shape:
        raise AssertionError("CPU DU source_refs shape 错误")
    if miss_counts.tolist() != [0, 100, 200, 300]:
        raise AssertionError(f"CPU DU miss_counts 错误：{miss_counts.tolist()}")
    if unique_sources.numel() != 300 or unique_slots.numel() != 300:
        raise AssertionError("CPU DU 唯一 miss 数错误")
    if victims.numel() != 300 or alias.data_ptr() != state.data_ptr():
        raise AssertionError("CPU DU 状态 alias 或 victim 数错误")
    if generation != 8:
        raise AssertionError(f"CPU DU generation 错误：{generation}")
    (
        union_ordinals,
        union_hit_ids,
        union_hit_slots,
        union_hit_refs,
        union_hit_masks,
        union_miss_masks,
    ) = outputs[9:]
    if union_hit_ids.numel() != TOPK or union_hit_slots.numel() != TOPK:
        raise AssertionError("CPU DU union hit 数量错误")
    if int(union_hit_refs[0]) != 4 or int(union_hit_refs[2000]) != 1:
        raise AssertionError("CPU DU shared/private hit 引用计数错误")
    if int(union_ordinals[1, 0, -1]) != TOPK + 99:
        raise AssertionError("CPU DU union miss ordinal 错误")
    if (
        int(union_hit_masks[0]) != 0xF
        or int(union_hit_masks[2000]) != 0x1
        or int(union_miss_masks[0]) != 0xE
        or int(union_miss_masks[-1]) != 0x8
    ):
        raise AssertionError("CPU DU union query mask 错误")
    first_miss_ref = int(refs[1, 0, TOPK - 100])
    if first_miss_ref & OWNER_BIT == 0:
        raise AssertionError("CPU DU 首次 miss 未设置 owner bit")

    second = cpu_lidu_du_update(
        topk, state, budget, capacity, generation=generation, hits_first=True
    )
    if len(second) != 9:
        raise AssertionError("CPU DU 兼容接口返回数量发生变化")
    if second[3].tolist() != [0, 0, 0, 0]:
        raise AssertionError("CPU DU 重复更新没有收敛到零 miss")

    worker_state = torch.full((capacity,), -1, dtype=torch.int32)
    worker_state[:budget] = torch.arange(budget, dtype=torch.int32)
    worker = CpuDuWorkerRuntime(slot_count=64)
    worker.register_state(11, 22, 3, worker_state, budget, generation=7)
    _, li_address, du_address = worker.acquire(
        1, 11, 22, 3, query_count=4, candidate_length=capacity
    )
    if li_address == 0 or du_address == 0 or li_address == du_address:
        raise AssertionError("CPU DU worker payload 地址无效")
    worker.write_li(1, topk)
    worker.publish_li(1)
    legacy_worker_outputs = worker.wait_du(1, timeout_ms=1000)
    if len(legacy_worker_outputs) != 8:
        raise AssertionError("CPU DU worker 兼容接口返回数量发生变化")
    worker_outputs = worker.wait_du_union(1, timeout_ms=1000)
    if worker_outputs[3].tolist() != [0, 100, 200, 300]:
        raise AssertionError("CPU DU worker miss_counts 错误")
    if worker_outputs[4].numel() != 300 or worker_outputs[7] != 8:
        raise AssertionError("CPU DU worker unique miss 或 generation 错误")
    if (
        worker_outputs[9].numel() != TOPK
        or int(worker_outputs[11][0]) != 4
        or int(worker_outputs[11][2000]) != 1
        or int(worker_outputs[12][0]) != 0xF
        or int(worker_outputs[13][0]) != 0xE
    ):
        raise AssertionError("CPU DU worker union hit 元数据错误")
    snapshot, snapshot_budget, snapshot_generation = worker.snapshot_state(
        11, 22, 3
    )
    if (
        snapshot.numel() != capacity
        or snapshot_budget != budget
        or snapshot_generation != 8
    ):
        raise AssertionError("CPU DU worker snapshot 错误")
    worker.mark_command_submitted(1)
    worker.mark_data_ready(1)
    worker.release(1)
    if not worker.remove_state(11, 22, 3):
        raise AssertionError("CPU DU worker state 删除失败")

    batch = 4
    batch_states = initial_state.repeat(batch, 1).contiguous()
    batch_topk = topk.repeat(batch, 1).contiguous()
    batch_worker = CpuDuBatchWorkerRuntime(thread_count=batch)
    batch_worker.register_states(
        batch_states,
        torch.full((batch,), budget, dtype=torch.int32),
        torch.full((batch,), capacity, dtype=torch.int32),
        torch.full((batch,), 4, dtype=torch.int32),
    )
    packed = batch_worker.run(batch_topk, generation=1, hits_first=True)
    topk_elements = batch * 4 * TOPK
    union_elements = batch * batch_worker.union_capacity
    packed_slots = packed[:topk_elements].view(batch * 4, 1, TOPK)
    packed_sources = packed[
        topk_elements : topk_elements + union_elements
    ].view(batch, batch_worker.union_capacity)
    packed_counts = packed[-batch:]
    if packed_slots.shape != (batch * 4, 1, TOPK):
        raise AssertionError("批量 CPU DU TopK shape 错误")
    if packed_counts.tolist() != [300] * batch:
        raise AssertionError(f"批量 CPU DU miss 数错误：{packed_counts.tolist()}")
    if not torch.equal(
        packed_sources[:, :300],
        torch.arange(budget, budget + 300, dtype=torch.int32).repeat(batch, 1),
    ):
        raise AssertionError("批量 CPU DU unique miss 错误")
    repeated = batch_worker.run(batch_topk, generation=2, hits_first=True)
    if repeated.data_ptr() != packed.data_ptr() or repeated[-batch:].tolist() != [300] * batch:
        raise AssertionError("批量 CPU DU 未复用输出 buffer 或状态模板")
    print("CPU_DU_EXTENSION_TEST passed=3 failed=0", flush=True)


if __name__ == "__main__":
    main()
