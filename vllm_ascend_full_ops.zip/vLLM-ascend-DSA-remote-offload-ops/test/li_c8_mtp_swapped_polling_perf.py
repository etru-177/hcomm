#!/usr/bin/env python3
"""探测 swapped TopK 的 CPU polling 是否拖慢官方 A5 C8 MTP LI。

LI 输入与 ``nanovllm-DSA-offload:ops_a5`` 提交 2802bdd 中的
``bench_official_c8_li_mtp3.py`` 对齐。扩展仅给同一个
``aclnnQuantLightningIndexer`` 增加 caller-owned output；没有自定义 LI kernel，
也没有额外 NPU copy。性能必须从 msprof 的 LightningIndexer task 读取。
"""

from __future__ import annotations

import argparse
import gc
from dataclasses import dataclass

import torch
import torch_npu  # type: ignore

import kvcache_scatter_copy_custom_ops as remote_ops

from _c8_lidu_case import official_c8_lightning_indexer, quantize_fp8
from _utils import require_a5


BLOCK_SIZE = 128
HEAD_DIM = 128
TOPK = 2048
MODES = ("hbm_no_poll", "swapped_no_poll", "swapped_poll")


@dataclass
class Case:
    query: torch.Tensor
    key: torch.Tensor
    weights: torch.Tensor
    query_scale: torch.Tensor
    key_scale: torch.Tensor
    actual_q: torch.Tensor
    candidate_lens: torch.Tensor
    block_table: torch.Tensor


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=MODES, required=True)
    parser.add_argument("--device", default="npu:0")
    parser.add_argument("--bs", type=int, default=32)
    parser.add_argument("--heads", type=int, default=32)
    parser.add_argument("--source-len", type=int, default=131072)
    parser.add_argument(
        "--queries-per-request", type=int, default=4,
        help="MTP0/1/2/3 分别传 1/2/3/4；默认 MTP3(query=4)。",
    )
    parser.add_argument("--query-noise", type=float, default=0.25)
    parser.add_argument("--calls-per-iteration", type=int, default=10)
    parser.add_argument(
        "--eager-warmup", type=int, default=3,
        help="录图前用于初始化官方 C8 LI runtime/tiling cache 的 eager 轮数。",
    )
    parser.add_argument("--warmup", type=int, default=5)
    parser.add_argument("--iterations", type=int, default=20)
    parser.add_argument(
        "--poll-threads", type=int, default=0,
        help="swapped_poll 常驻线程数；0 表示 min(bs,32)。",
    )
    parser.add_argument(
        "--poll-first-cpu", type=int, default=-1,
        help=">=0 时从该逻辑 CPU 开始依次绑核。",
    )
    parser.add_argument(
        "--poll-scan", choices=("partition", "replicated"),
        default="partition",
        help="partition 将一个 slice 分给多线程；replicated 每线程读完整 slice。",
    )
    parser.add_argument("--poll-timeout-ms", type=int, default=30000)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--allow-non-a5", action="store_true")
    return parser.parse_args()


def check_args(args: argparse.Namespace) -> None:
    if args.bs <= 0:
        raise ValueError("--bs must be positive")
    if args.heads not in (32, 64):
        raise ValueError("C8 LI heads must be 32 or 64")
    if args.source_len < TOPK or args.source_len % BLOCK_SIZE:
        raise ValueError("--source-len must be a multiple of 128 and >=2048")
    if args.queries_per_request not in (1, 2, 3, 4):
        raise ValueError("--queries-per-request must be in [1,4]")
    if args.query_noise <= 0:
        raise ValueError("--query-noise must be positive")
    if args.calls_per_iteration <= 0:
        raise ValueError("--calls-per-iteration must be positive")
    if args.eager_warmup < 0 or args.warmup < 0 or args.iterations <= 0:
        raise ValueError(
            "require --eager-warmup>=0, --warmup>=0 and --iterations>0"
        )
    if args.poll_threads < 0 or args.poll_threads > 256:
        raise ValueError("--poll-threads must be in [0,256]")
    if args.poll_first_cpu < -1:
        raise ValueError("--poll-first-cpu must be -1 or non-negative")
    if args.poll_timeout_ms <= 0:
        raise ValueError("--poll-timeout-ms must be positive")


def make_case(args: argparse.Namespace, device: torch.device) -> Case:
    """复现 ops_a5 官方 C8 MTP benchmark 的输入与物理 key 布局。"""

    torch.manual_seed(args.seed)
    torch.npu.manual_seed_all(args.seed)
    generator = torch.Generator().manual_seed(args.seed)
    packed_t = args.bs * args.queries_per_request
    blocks_per_request = args.source_len // BLOCK_SIZE
    total_blocks = args.bs * blocks_per_request

    base_query = torch.randn(
        (args.bs, 1, args.heads, HEAD_DIM),
        dtype=torch.bfloat16,
        device=device,
    )
    route_noise = torch.randn(
        (args.bs, args.queries_per_request, args.heads, HEAD_DIM),
        dtype=torch.bfloat16,
        device=device,
    )
    query_fp = (
        base_query + args.query_noise * route_noise
    ).reshape(packed_t, args.heads, HEAD_DIM)
    query, query_scale = quantize_fp8(query_fp)

    key_fp = torch.randn(
        (total_blocks, BLOCK_SIZE, 1, HEAD_DIM),
        dtype=torch.bfloat16,
        device=device,
    )
    key, key_scale = quantize_fp8(key_fp)
    base_weights = torch.empty(
        (args.bs, 1, args.heads), dtype=torch.bfloat16, device=device
    ).uniform_(0.01, 1.0)
    weights = (
        base_weights.expand(-1, args.queries_per_request, -1)
        .reshape(packed_t, args.heads)
        .contiguous()
    )
    actual_q = torch.arange(
        args.queries_per_request,
        packed_t + 1,
        args.queries_per_request,
        dtype=torch.int32,
        device=device,
    )
    candidate_lens = torch.full(
        (args.bs,), args.source_len, dtype=torch.int32, device=device
    )
    # 每请求使用不重叠的 key blocks，并随机化物理顺序，避免跨请求 L2 复用。
    block_table = (
        torch.randperm(total_blocks, generator=generator)
        .reshape(args.bs, blocks_per_request)
        .to(torch.int32)
        .to(device)
    )
    torch.npu.synchronize()
    del base_query, route_noise, query_fp, key_fp, base_weights
    gc.collect()
    torch.npu.empty_cache()
    return Case(
        query=query,
        key=key,
        weights=weights,
        query_scale=query_scale,
        key_scale=key_scale,
        actual_q=actual_q,
        candidate_lens=candidate_lens,
        block_table=block_table,
    )


def make_output_ring(
    args: argparse.Namespace, case: Case, device: torch.device
) -> torch.Tensor:
    shape = (
        args.calls_per_iteration,
        case.query.size(0),
        1,
        TOPK,
    )
    if args.mode == "hbm_no_poll":
        ring = torch.empty(shape, dtype=torch.int32, device=device)
    else:
        allocator = getattr(torch_npu, "empty_with_swapped_memory", None)
        if allocator is None:
            raise RuntimeError(
                "torch_npu.empty_with_swapped_memory is unavailable"
            )
        ring = allocator(shape, dtype=torch.int32, device=device)
    ring.fill_(-1)
    torch.npu.synchronize()
    return ring


def launch(case: Case, output: torch.Tensor) -> None:
    result = torch.ops.nanovllm_dsa.quant_lightning_indexer_c8_out.default(
        case.query,
        case.key,
        case.weights,
        case.query_scale,
        case.key_scale,
        case.actual_q,
        case.candidate_lens,
        case.block_table,
        output,
    )
    if result.data_ptr() != output.data_ptr():
        raise RuntimeError("C8 LI out adapter did not preserve output storage")


def cross_check_official(case: Case) -> None:
    """证明薄 out adapter 与 torch_npu 官方 C8 LI bitwise 一致。"""

    expected = official_c8_lightning_indexer(
        case.query,
        case.key,
        case.weights,
        case.query_scale,
        case.key_scale,
        case.actual_q,
        case.candidate_lens,
        case.block_table,
    )
    actual = torch.empty(
        (case.query.size(0), 1, TOPK),
        dtype=torch.int32,
        device=case.query.device,
    )
    launch(case, actual)
    torch.npu.synchronize()
    if not torch.equal(actual.reshape(case.query.size(0), TOPK), expected):
        mismatches = int(
            (
                actual.reshape(case.query.size(0), TOPK) != expected
            ).sum().item()
        )
        raise AssertionError(
            f"C8 LI out adapter differs from official torch_npu: "
            f"mismatches={mismatches}"
        )


def launch_group(args: argparse.Namespace, case: Case, ring: torch.Tensor) -> None:
    for call in range(args.calls_per_iteration):
        launch(case, ring[call])


def capture_graph(
    args: argparse.Namespace, case: Case, ring: torch.Tensor
) -> torch.npu.NPUGraph:
    # Capture is performed only after eager warmup.  The ten output addresses
    # are stable, distinct slices and are reused by every graph replay.
    graph = torch.npu.NPUGraph()
    pool = torch.npu.graph_pool_handle()
    with torch.npu.graph(graph, pool=pool):
        launch_group(args, case, ring)
    torch.npu.synchronize()
    return graph


def run(args: argparse.Namespace, case: Case, ring: torch.Tensor) -> None:
    for _ in range(args.eager_warmup):
        ring.fill_(-1)
        launch_group(args, case, ring)
        torch.npu.synchronize()

    graph = capture_graph(args, case, ring)
    poller = None
    poll_threads = args.poll_threads or min(args.bs, 32)
    slice_elements = case.query.size(0) * TOPK
    if args.mode == "swapped_poll":
        poller = remote_ops.SwappedSlicePollerRuntime(
            poll_threads, args.poll_first_cpu
        )
        poller.register_tensor(ring)

    groups = args.warmup + args.iterations
    for _ in range(groups):
        # Reset is outside the graph and completed before polling is armed;
        # otherwise a worker could mistake the preceding replay's values for
        # this replay's completion.  The reset task is excluded by the parser.
        ring.fill_(-1)
        torch.npu.synchronize()
        if poller is not None:
            poller.arm(
                0,
                args.calls_per_iteration,
                slice_elements,
                args.poll_scan == "replicated",
            )
        graph.replay()
        # 每个 replay 固定只有 10 个 LI；三种模式保持同一图和 queue depth。
        # polling worker 在 synchronize 等待期间持续并发读取 swapped slices。
        torch.npu.synchronize()
        if poller is not None:
            poller.wait(args.poll_timeout_ms)


def check_output(args: argparse.Namespace, ring: torch.Tensor) -> None:
    final_output = ring[-1]
    invalid = int((final_output < 0).sum().item())
    out_of_range = int((final_output >= args.source_len).sum().item())
    if invalid or out_of_range:
        raise AssertionError(
            f"invalid C8 LI output: negative={invalid} "
            f"out_of_range={out_of_range}"
        )


def main() -> None:
    args = parse_args()
    check_args(args)
    device = torch.device(args.device)
    if device.type != "npu":
        raise ValueError("--device must select an NPU")
    torch.npu.set_device(device)
    torch.npu.config.allow_internal_format = False
    device_name = require_a5(device, args.allow_non_a5)
    poll_threads = args.poll_threads or min(args.bs, 32)

    case = make_case(args, device)
    cross_check_official(case)
    ring = make_output_ring(args, case, device)
    output_mib = ring.numel() * ring.element_size() / (1024 * 1024)
    print(
        "LI_C8_MTP_POLLING_CONFIG "
        f"mode={args.mode} device={device} device_name={device_name!r} "
        f"bs={args.bs} queries_per_request={args.queries_per_request} "
        f"packed_t={case.query.size(0)} heads={args.heads} "
        f"source_len={args.source_len} topk={TOPK} "
        f"calls_per_iteration={args.calls_per_iteration} "
        f"eager_warmup={args.eager_warmup} "
        f"graph_warmup={args.warmup} iterations={args.iterations} "
        f"poll_threads={poll_threads if args.mode == 'swapped_poll' else 0} "
        f"poll_scan={args.poll_scan if args.mode == 'swapped_poll' else 'none'} "
        f"output_mib={output_mib:.3f} graph_replay=1 "
        "graph_contains_only_li=1 timer=msprof_task_time "
        "official_bitwise_crosscheck=1 "
        "li_impl=torch_npu_aclnnQuantLightningIndexer_caller_owned_out",
        flush=True,
    )
    run(args, case, ring)
    check_output(args, ring)
    print(
        "LI_C8_MTP_POLLING_OK "
        f"mode={args.mode} graph_replay_li_calls="
        f"{(args.warmup + args.iterations) * args.calls_per_iteration} "
        "output_valid=1",
        flush=True,
    )


if __name__ == "__main__":
    main()
