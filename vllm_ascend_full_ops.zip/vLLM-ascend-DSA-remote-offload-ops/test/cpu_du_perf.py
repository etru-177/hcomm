#!/usr/bin/env python3
"""CPU DU 同步 ABI、ring worker 与批量并行常驻 worker 性能测试。"""

from __future__ import annotations

import argparse
import csv
import os
import shlex
import statistics
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import torch


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "torch_extension"))

from kvcache_scatter_copy_custom_ops import (  # noqa: E402
    CpuDuBatchWorkerRuntime,
    CpuDuWorkerRuntime,
    cpu_lidu_du_update_union,
)


TOPK = 2048


@dataclass
class Result:
    mode: str
    batch_size: int
    query_count: int
    candidate_length: int
    cache_budget: int
    misses: int
    topk_pattern: str
    union_hits: int
    shared_hits: int
    private_hits: int
    union_misses: int
    baseline_kv_refs: int
    unique_kv_rows: int
    potential_kv_ref_reduction_pct: float
    warmup: int
    iterations: int
    avg_us: float
    p50_us: float
    p90_us: float
    p99_us: float
    request_iops: int
    selected_token_iops: int
    unique_miss_iops: int
    worker_threads: int = 0
    submit_avg_us: float = 0.0
    wait_avg_us: float = 0.0


def int_list(value: str) -> tuple[int, ...]:
    try:
        values = tuple(int(item) for item in value.split(",") if item)
    except ValueError as error:
        raise argparse.ArgumentTypeError("需要使用逗号分隔的整数") from error
    if not values or any(item <= 0 for item in values):
        raise argparse.ArgumentTypeError("列表中的值必须为正整数")
    return values


def nonnegative_int_list(value: str) -> tuple[int, ...]:
    try:
        values = tuple(int(item) for item in value.split(",") if item)
    except ValueError as error:
        raise argparse.ArgumentTypeError("需要使用逗号分隔的整数") from error
    if not values or any(item < 0 for item in values):
        raise argparse.ArgumentTypeError("列表中的值必须为非负整数")
    return values


def percentile(samples: list[float], fraction: float) -> float:
    ordered = sorted(samples)
    index = min(len(ordered) - 1, max(0, round((len(ordered) - 1) * fraction)))
    return ordered[index]


def initial_state(candidate_length: int, cache_budget: int) -> torch.Tensor:
    state = torch.full((candidate_length,), -1, dtype=torch.int32)
    state[:cache_budget] = torch.arange(cache_budget, dtype=torch.int32)
    return state


def make_topk(
    query_count: int,
    cache_budget: int,
    candidate_length: int,
    misses: int,
    pattern: str,
) -> torch.Tensor:
    if misses > TOPK:
        raise ValueError(f"misses={misses} 超过单路 TopK={TOPK}")
    if cache_budget + misses > candidate_length:
        raise ValueError(
            f"candidate_length={candidate_length} 无法容纳 cache_budget="
            f"{cache_budget} 和 misses={misses}"
        )
    remote = torch.arange(cache_budget, cache_budget + misses, dtype=torch.int32)
    hits_per_query = TOPK - misses
    if pattern == "shared":
        hits = torch.arange(hits_per_query, dtype=torch.int32)
        return torch.cat((hits, remote)).repeat(query_count, 1).contiguous()
    if query_count * hits_per_query > cache_budget:
        raise ValueError(
            "low_overlap TopK 的常驻 hit union 超过 cache_budget："
            f"queries={query_count} hits_per_query={hits_per_query} "
            f"cache_budget={cache_budget}"
        )
    rows = []
    for query in range(query_count):
        begin = query * hits_per_query
        hits = torch.arange(
            begin, begin + hits_per_query, dtype=torch.int32
        )
        rows.append(torch.cat((hits, remote)))
    return torch.stack(rows).contiguous()


def validate_outputs(outputs: tuple, query_count: int, misses: int) -> None:
    miss_counts = outputs[3]
    unique_sources = outputs[4]
    expected = torch.full((query_count,), misses, dtype=torch.int32)
    if not torch.equal(miss_counts, expected):
        raise RuntimeError(
            f"CPU DU miss_counts 错误：actual={miss_counts.tolist()} "
            f"expected={expected.tolist()}"
        )
    if unique_sources.numel() != misses:
        raise RuntimeError(
            f"CPU DU unique miss 数错误：actual={unique_sources.numel()} "
            f"expected={misses}"
        )


def summarize(
    mode: str,
    args: argparse.Namespace,
    batch_size: int,
    candidate_length: int,
    misses: int,
    samples_us: list[float],
    union_hit_ref_counts: torch.Tensor,
    union_miss_count: int,
    submit_us: list[float] | None = None,
    wait_us: list[float] | None = None,
) -> Result:
    avg_us = statistics.fmean(samples_us)
    request_iops = round(batch_size * 1_000_000.0 / avg_us)
    selected_token_iops = round(
        batch_size * args.query_count * TOPK * 1_000_000.0 / avg_us
    )
    unique_miss_iops = round(batch_size * misses * 1_000_000.0 / avg_us)
    union_hits = union_hit_ref_counts.numel()
    shared_hits = int((union_hit_ref_counts > 1).sum())
    private_hits = union_hits - shared_hits
    baseline_kv_refs = args.query_count * TOPK
    unique_kv_rows = union_hits + union_miss_count
    return Result(
        mode=mode,
        batch_size=batch_size,
        query_count=args.query_count,
        candidate_length=candidate_length,
        cache_budget=args.cache_budget,
        misses=misses,
        topk_pattern=args.topk_pattern,
        union_hits=union_hits,
        shared_hits=shared_hits,
        private_hits=private_hits,
        union_misses=union_miss_count,
        baseline_kv_refs=baseline_kv_refs,
        unique_kv_rows=unique_kv_rows,
        potential_kv_ref_reduction_pct=(
            100.0 * (baseline_kv_refs - unique_kv_rows) / baseline_kv_refs
        ),
        warmup=args.warmup,
        iterations=args.iterations,
        avg_us=avg_us,
        p50_us=percentile(samples_us, 0.50),
        p90_us=percentile(samples_us, 0.90),
        p99_us=percentile(samples_us, 0.99),
        request_iops=request_iops,
        selected_token_iops=selected_token_iops,
        unique_miss_iops=unique_miss_iops,
        submit_avg_us=statistics.fmean(submit_us) if submit_us else 0.0,
        wait_avg_us=statistics.fmean(wait_us) if wait_us else 0.0,
    )


def run_sync_case(
    args: argparse.Namespace,
    batch_size: int,
    candidate_length: int,
    misses: int,
) -> Result:
    baseline = initial_state(candidate_length, args.cache_budget)
    states = [baseline.clone() for _ in range(batch_size)]
    topk = make_topk(
        args.query_count, args.cache_budget, candidate_length, misses,
        args.topk_pattern,
    )

    def iteration(generation: int) -> tuple:
        # 状态恢复不计时，使每个样本具有相同 miss 数。计时区域仍包含当前同步
        # ABI 的 state import/validation、DU、state commit 和输出 tensor 构造。
        for state in states:
            state.copy_(baseline)
        begin = time.perf_counter_ns()
        output = None
        for state in states:
            output = cpu_lidu_du_update_union(
                topk,
                state,
                args.cache_budget,
                candidate_length,
                generation=generation,
                hits_first=True,
            )
        elapsed_us = (time.perf_counter_ns() - begin) / 1000.0
        assert output is not None
        return output, elapsed_us

    for index in range(args.warmup):
        iteration(index + 1)
    samples = []
    for index in range(args.iterations):
        output, elapsed_us = iteration(args.warmup + index + 1)
        samples.append(elapsed_us)
    validate_outputs(output, args.query_count, misses)
    return summarize(
        "sync_union_abi",
        args,
        batch_size,
        candidate_length,
        misses,
        samples,
        output[12],
        output[4].numel(),
    )


def run_worker_case(
    args: argparse.Namespace,
    batch_size: int,
    candidate_length: int,
    misses: int,
) -> Result:
    baseline = initial_state(candidate_length, args.cache_budget)
    topk = make_topk(
        args.query_count, args.cache_budget, candidate_length, misses,
        args.topk_pattern,
    )
    slot_count = max(args.ring_slots, batch_size * 2)
    worker = CpuDuWorkerRuntime(slot_count=slot_count, cpu=args.worker_cpu)
    ring_generation = 1

    def iteration(epoch: int) -> tuple:
        nonlocal ring_generation
        # 每轮注册相同初始状态，避免状态收敛为全 hit。注册/删除属于控制面，
        # 不计入 worker 热路径；被测区域包含 ring 提交、CPU DU、等待和消费。
        for request in range(batch_size):
            worker.register_state(
                request + 1,
                epoch,
                0,
                baseline,
                args.cache_budget,
                generation=0,
            )

        generations: list[int] = []
        submit_begin = time.perf_counter_ns()
        for request in range(batch_size):
            generation = ring_generation
            ring_generation += 1
            worker.acquire(
                generation,
                request + 1,
                epoch,
                0,
                query_count=args.query_count,
                candidate_length=candidate_length,
            )
            worker.write_li(generation, topk)
            worker.publish_li(generation)
            generations.append(generation)
        submit_done = time.perf_counter_ns()

        output = None
        for generation in generations:
            output = worker.wait_du_union(
                generation, timeout_ms=args.timeout_ms
            )
        wait_done = time.perf_counter_ns()
        for generation in generations:
            worker.mark_command_submitted(generation)
            worker.mark_data_ready(generation)
            worker.release(generation)
        end = time.perf_counter_ns()

        for request in range(batch_size):
            if not worker.remove_state(request + 1, epoch, 0):
                raise RuntimeError("CPU DU worker 状态删除失败")
        assert output is not None
        return (
            output,
            (end - submit_begin) / 1000.0,
            (submit_done - submit_begin) / 1000.0,
            (wait_done - submit_done) / 1000.0,
        )

    for index in range(args.warmup):
        iteration(index + 1)
    samples = []
    submits = []
    waits = []
    for index in range(args.iterations):
        output, elapsed_us, submit_us, wait_us = iteration(args.warmup + index + 1)
        samples.append(elapsed_us)
        submits.append(submit_us)
        waits.append(wait_us)
    validate_outputs(output, args.query_count, misses)
    result = summarize(
        "worker_union_e2e",
        args,
        batch_size,
        candidate_length,
        misses,
        samples,
        output[11],
        output[4].numel(),
        submits,
        waits,
    )
    result.worker_threads = 1
    return result


def run_batch_case(
    args: argparse.Namespace,
    batch_size: int,
    candidate_length: int,
    misses: int,
) -> Result:
    baseline = initial_state(candidate_length, args.cache_budget)
    states = baseline.repeat(batch_size, 1).contiguous()
    topk = make_topk(
        args.query_count, args.cache_budget, candidate_length, misses,
        args.topk_pattern,
    ).repeat(batch_size, 1).contiguous()
    thread_count = args.batch_threads or min(batch_size, 32)
    worker = CpuDuBatchWorkerRuntime(
        thread_count=thread_count, first_cpu=args.batch_first_cpu
    )
    worker.register_states(
        states,
        torch.full((batch_size,), args.cache_budget, dtype=torch.int32),
        torch.full((batch_size,), candidate_length, dtype=torch.int32),
        torch.full((batch_size,), args.query_count, dtype=torch.int32),
    )

    def iteration(generation: int) -> tuple[torch.Tensor, float]:
        begin = time.perf_counter_ns()
        output = worker.run(topk, generation=generation, hits_first=True)
        return output, (time.perf_counter_ns() - begin) / 1000.0

    for index in range(args.warmup):
        iteration(index + 1)
    samples: list[float] = []
    output = torch.empty(0, dtype=torch.int32)
    for index in range(args.iterations):
        output, elapsed_us = iteration(args.warmup + index + 1)
        samples.append(elapsed_us)
    expected_counts = torch.full(
        (batch_size,), misses, dtype=torch.int32
    )
    if not torch.equal(output[-batch_size:], expected_counts):
        raise RuntimeError(
            f"批量 CPU DU union miss 错误：{output[-batch_size:].tolist()}"
        )
    request_topk = topk[: args.query_count]
    hit_values = request_topk[request_topk < args.cache_budget]
    _, hit_refs = torch.unique(hit_values, return_counts=True)
    result = summarize(
        "batch_union_parallel",
        args,
        batch_size,
        candidate_length,
        misses,
        samples,
        hit_refs,
        misses,
    )
    result.worker_threads = thread_count
    return result


def print_result(result: Result) -> None:
    stages = ""
    if result.mode.startswith("worker"):
        stages = (
            f" submit_avg_us={result.submit_avg_us:.3f}"
            f" wait_avg_us={result.wait_avg_us:.3f}"
        )
    print(
        "CPU_DU_PERF"
        f" mode={result.mode} bs={result.batch_size}"
        f" queries={result.query_count} seqlen={result.candidate_length}"
        f" cache_budget={result.cache_budget} misses={result.misses}"
        f" topk_pattern={result.topk_pattern}"
        f" avg_us={result.avg_us:.3f} p50_us={result.p50_us:.3f}"
        f" p90_us={result.p90_us:.3f}"
        f" p99_us={result.p99_us:.3f} request_IOPS={result.request_iops}"
        f" selected_token_IOPS={result.selected_token_iops}"
        f" unique_miss_IOPS={result.unique_miss_iops}"
        f" worker_threads={result.worker_threads}"
        f" union_hits={result.union_hits} shared_hits={result.shared_hits}"
        f" private_hits={result.private_hits} union_misses={result.union_misses}"
        f" potential_kv_ref_reduction_pct="
        f"{result.potential_kv_ref_reduction_pct:.2f}{stages}",
        flush=True,
    )


def print_case_command(
    args: argparse.Namespace,
    mode: str,
    batch_size: int,
    candidate_length: int,
    misses: int,
) -> None:
    command = [
        sys.executable,
        str(Path(__file__).resolve()),
        "--modes",
        mode,
        "--batch-sizes",
        str(batch_size),
        "--candidate-lengths",
        str(candidate_length),
        "--misses",
        str(misses),
        "--query-count",
        str(args.query_count),
        "--cache-budget",
        str(args.cache_budget),
        "--topk-pattern",
        args.topk_pattern,
        "--warmup",
        str(args.warmup),
        "--iterations",
        str(args.iterations),
        "--ring-slots",
        str(args.ring_slots),
        "--worker-cpu",
        str(args.worker_cpu),
        "--batch-threads",
        str(args.batch_threads),
        "--batch-first-cpu",
        str(args.batch_first_cpu),
        "--main-cpu",
        str(args.main_cpu),
        "--timeout-ms",
        str(args.timeout_ms),
    ]
    print(f"REPRODUCE_COMMAND {shlex.join(command)}", flush=True)


def write_csv(path: Path, results: list[Result]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(Result.__dataclass_fields__)
    with path.open("w", newline="", encoding="utf-8") as output:
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        for result in results:
            writer.writerow(vars(result))


def pin_main_thread(cpu: int) -> None:
    if cpu < 0:
        return
    if not hasattr(os, "sched_setaffinity"):
        raise RuntimeError("当前平台不支持 sched_setaffinity")
    os.sched_setaffinity(0, {cpu})


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--modes",
        default="sync,worker,batch",
        help="逗号分隔：sync,worker,batch（默认三者）",
    )
    parser.add_argument("--batch-sizes", type=int_list, default=(1,))
    parser.add_argument(
        "--candidate-lengths", type=int_list, default=(65536,)
    )
    parser.add_argument(
        "--misses", type=nonnegative_int_list, default=(0, 100, 200, 400)
    )
    parser.add_argument("--query-count", type=int, default=4)
    parser.add_argument("--cache-budget", type=int, default=4096)
    parser.add_argument(
        "--topk-pattern",
        choices=("shared", "low_overlap"),
        default="shared",
        help=(
            "shared 表示各 query 共享 TopK；low_overlap 表示 hit 尽量互不重叠，"
            "但共享同一组 unique miss。"
        ),
    )
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--iterations", type=int, default=50)
    parser.add_argument("--ring-slots", type=int, default=64)
    parser.add_argument("--worker-cpu", type=int, default=-1)
    parser.add_argument("--batch-threads", type=int, default=0)
    parser.add_argument("--batch-first-cpu", type=int, default=-1)
    parser.add_argument("--main-cpu", type=int, default=-1)
    parser.add_argument("--timeout-ms", type=int, default=5000)
    parser.add_argument("--csv", type=Path)
    args = parser.parse_args()
    modes = tuple(item for item in args.modes.split(",") if item)
    if not modes or any(
        item not in ("sync", "worker", "batch") for item in modes
    ):
        parser.error("--modes 只支持 sync,worker,batch")
    args.modes = modes
    if not 1 <= args.query_count <= 4:
        parser.error("--query-count 必须在 [1,4]")
    if args.cache_budget < TOPK:
        parser.error("--cache-budget 必须至少为 2048")
    if args.warmup < 0 or args.iterations <= 0:
        parser.error("--warmup 必须非负且 --iterations 必须为正")
    if args.ring_slots < 2 or args.ring_slots > 4096:
        parser.error("--ring-slots 必须在 [2,4096]")
    if max(args.batch_sizes) * 2 > 4096:
        parser.error("--batch-sizes 的最大值不能超过 2048")
    if args.batch_threads < 0 or args.batch_threads > 256:
        parser.error("--batch-threads 必须在 [0,256]")
    if args.batch_first_cpu < -1:
        parser.error("--batch-first-cpu 必须 >=-1")
    return args


def main() -> None:
    args = parse_args()
    pin_main_thread(args.main_cpu)
    runners: dict[str, Callable[..., Result]] = {
        "sync": run_sync_case,
        "worker": run_worker_case,
        "batch": run_batch_case,
    }
    results: list[Result] = []
    for candidate_length in args.candidate_lengths:
        if candidate_length < args.cache_budget:
            raise ValueError(
                f"candidate_length={candidate_length} 小于 cache_budget="
                f"{args.cache_budget}"
            )
        for batch_size in args.batch_sizes:
            for misses in args.misses:
                for mode in args.modes:
                    print_case_command(
                        args, mode, batch_size, candidate_length, misses
                    )
                    result = runners[mode](
                        args, batch_size, candidate_length, misses
                    )
                    results.append(result)
                    print_result(result)
    if args.csv:
        write_csv(args.csv, results)
        print(f"CPU_DU_CSV path={args.csv} rows={len(results)}", flush=True)
    print("CPU_DU_PERFORMANCE_SUMMARY", flush=True)
    for result in results:
        print_result(result)


if __name__ == "__main__":
    main()
