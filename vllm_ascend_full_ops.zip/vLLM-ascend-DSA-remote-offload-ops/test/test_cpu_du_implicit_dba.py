#!/usr/bin/env python3
"""验证 swapped-memory polling、32 路 CPU DU 和两组 ready 发布。"""

from __future__ import annotations

import sys
from pathlib import Path

import torch
import torch_npu


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "torch_extension"))

from kvcache_scatter_copy_custom_ops import (  # noqa: E402
    SwappedCpuDuImplicitDbaRuntime,
)


BATCH = 32
QUERIES = 4
TOPK = 2048
CACHE_BUDGET = 8192
SOURCE_CAPACITY = 10000
UNION_CAPACITY = 8192
HCOMM_CAPACITY = 16384


def swapped(shape: tuple[int, ...], device: torch.device) -> torch.Tensor:
    return torch_npu.empty_with_swapped_memory(
        shape, dtype=torch.int32, device=device
    )


def topk_with_misses(misses: int) -> torch.Tensor:
    return torch.cat((
        torch.arange(TOPK - misses, dtype=torch.int32),
        torch.arange(
            CACHE_BUDGET, CACHE_BUDGET + misses, dtype=torch.int32
        ),
    ))


def main() -> None:
    device = torch.device("npu:0")
    torch_npu.npu.set_device(device)
    routes = torch.stack([
        topk_with_misses(misses) for misses in (0, 100, 200, 300)
    ])
    all_routes = routes.repeat(BATCH, 1).view(BATCH * QUERIES, TOPK)

    topk_ring = swapped((1, BATCH * QUERIES, 1, TOPK), device)
    topk_ring.fill_(-1)
    ready = swapped((1, 2), device)
    ready.zero_()
    source_ids = swapped((BATCH * QUERIES, TOPK), device)
    attention_slots = swapped((BATCH * QUERIES, 1, 2308), device)
    source_refs = swapped(source_ids.shape, device)
    query_miss_counts = swapped((BATCH * QUERIES,), device)
    hcomm_sources = swapped((BATCH, 1, HCOMM_CAPACITY), device)
    hcomm_destinations = swapped(hcomm_sources.shape, device)
    hcomm_counts = swapped((BATCH,), device)
    evicted = swapped((BATCH, UNION_CAPACITY), device)
    union_miss_masks = swapped((BATCH, UNION_CAPACITY), device)
    union_hit_ids = swapped((BATCH, UNION_CAPACITY), device)
    union_hit_slots = swapped((BATCH, UNION_CAPACITY), device)
    union_hit_refs = swapped((BATCH, UNION_CAPACITY), device)
    union_hit_masks = swapped((BATCH, UNION_CAPACITY), device)
    union_hit_counts = swapped((BATCH,), device)
    union_ordinals = swapped((BATCH * QUERIES, TOPK), device)

    state = torch.full(
        (1, BATCH, SOURCE_CAPACITY), -1, dtype=torch.int32
    )
    state[:, :, :CACHE_BUDGET] = torch.arange(
        CACHE_BUDGET, dtype=torch.int32
    )
    runtime = SwappedCpuDuImplicitDbaRuntime(first_cpu=-1)
    runtime.register_pipeline(
        topk_ring=topk_ring,
        initial_states=state,
        cache_budgets=torch.full(
            (BATCH,), CACHE_BUDGET, dtype=torch.int32
        ),
        candidate_lengths=torch.full(
            (BATCH,), SOURCE_CAPACITY, dtype=torch.int32
        ),
        source_ids=source_ids,
        attention_slots=attention_slots,
        source_refs=source_refs,
        query_miss_counts=query_miss_counts,
        hcomm_sources=hcomm_sources,
        hcomm_destinations=hcomm_destinations,
        hcomm_counts=hcomm_counts,
        evicted_source_ids=evicted,
        union_miss_masks=union_miss_masks,
        union_hit_source_ids=union_hit_ids,
        union_hit_slots=union_hit_slots,
        union_hit_ref_counts=union_hit_refs,
        union_hit_masks=union_hit_masks,
        union_hit_counts=union_hit_counts,
        union_ordinals=union_ordinals,
        ready_flags=ready,
    )
    torch_npu.npu.synchronize()
    runtime.start()
    topk_ring[0, :, 0].copy_(all_routes.to(device))
    runtime.wait_all()
    torch_npu.npu.synchronize()

    if ready.cpu().tolist() != [[1, 1]]:
        raise AssertionError("两个 16-request IO group 未全部发布")
    if hcomm_counts.cpu().tolist() != [300] * BATCH:
        raise AssertionError("隐式 DBA union miss 数错误")
    if query_miss_counts.cpu().view(BATCH, QUERIES)[0].tolist() != [
        0, 100, 200, 300
    ]:
        raise AssertionError("隐式 DBA query miss 数错误")
    if union_hit_counts.cpu().tolist() != [TOPK] * BATCH:
        raise AssertionError("隐式 DBA union hit 数错误")
    if union_hit_refs.cpu()[0, :2].tolist() != [4, 4]:
        raise AssertionError("隐式 DBA common hit 引用计数错误")
    if union_hit_masks.cpu()[0, 0].item() != 0xF:
        raise AssertionError("隐式 DBA common hit query mask 错误")
    if union_miss_masks.cpu()[0, 0].item() != 0xE:
        raise AssertionError("隐式 DBA union miss query mask 错误")
    if bool((state[0, 0, CACHE_BUDGET : CACHE_BUDGET + 300] < 0).any()):
        raise AssertionError("隐式 DBA 没有把 union miss 提交到 request state")
    victim_ids = evicted.cpu()[0, :300]
    if bool((state[0, 0, victim_ids.long()] >= 0).any()):
        raise AssertionError("隐式 DBA 没有从 request state 移除 victim")
    request_profile, group_profile = runtime.profile_records()
    if request_profile.shape != (1, BATCH, 4) or group_profile.shape != (1, 2):
        raise AssertionError("隐式 DBA profiling shape 错误")
    print("CPU_DU_IMPLICIT_DBA_TEST passed=1 failed=0", flush=True)


if __name__ == "__main__":
    main()
