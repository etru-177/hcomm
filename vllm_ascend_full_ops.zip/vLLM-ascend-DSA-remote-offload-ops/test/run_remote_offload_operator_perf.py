#!/usr/bin/env python3
"""运行 CPU DU batch 与 A5 C8 MTP LIDU 单算子性能测试。"""

from __future__ import annotations

import argparse
import csv
import shlex
import subprocess
import sys
from datetime import datetime
from pathlib import Path

from analyze_remote_offload_msprof import invocations, percentile, read_tasks


ROOT = Path(__file__).resolve().parents[1]
C8_TOKENS = ("a5fusedlimanagemtpc8",)
CSV_FIELDS = (
    "component",
    "mode",
    "bs",
    "query_count",
    "candidate_length",
    "cache_budget",
    "misses",
    "topk_pattern",
    "warmup",
    "iterations",
    "avg_us",
    "p50_us",
    "p90_us",
    "p99_us",
    "request_iops",
    "unique_miss_iops",
    "worker_threads",
    "timing_source",
    "status",
)


def csv_ints(value: str) -> tuple[int, ...]:
    try:
        result = tuple(int(item) for item in value.split(",") if item)
    except ValueError as error:
        raise argparse.ArgumentTypeError("需要逗号分隔的整数") from error
    if not result or any(item < 0 for item in result):
        raise argparse.ArgumentTypeError("列表必须非空且不能包含负数")
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--components",
        default="cpu_du_extension,c8_mtp_lidu",
        help="逗号分隔：cpu_du_extension,c8_mtp_lidu。",
    )
    parser.add_argument("--device", default="npu:0")
    parser.add_argument("--bs", type=int, default=32)
    parser.add_argument("--heads", type=int, choices=(32, 64), default=32)
    parser.add_argument("--candidate-length", type=int, default=131072)
    parser.add_argument("--query-count", type=int, choices=(4,), default=4)
    parser.add_argument("--cache-budget", type=int, default=8192)
    parser.add_argument("--misses", type=csv_ints, default=(100, 200))
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--iterations", type=int, default=50)
    parser.add_argument("--cpu-du-threads", type=int, default=0)
    parser.add_argument("--cpu-du-first-cpu", type=int, default=-1)
    parser.add_argument("--python", default=sys.executable)
    parser.add_argument("--msprof-bin", default="msprof")
    parser.add_argument("--msprof-extra", default="")
    parser.add_argument(
        "--profile-root", type=Path, default=Path("operator_msprof")
    )
    parser.add_argument(
        "--csv", type=Path, default=Path("operator_perf_results.csv")
    )
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    components = tuple(
        item.strip() for item in args.components.split(",") if item.strip()
    )
    if not components or any(
        item not in ("cpu_du_extension", "c8_mtp_lidu")
        for item in components
    ):
        parser.error("--components 只支持 cpu_du_extension,c8_mtp_lidu")
    args.components = components
    if (
        args.bs <= 0
        or args.cpu_du_threads < 0
        or args.cpu_du_threads > min(args.bs, 256)
    ):
        parser.error("--cpu-du-threads 必须为 0 或不超过 min(bs,256)")
    if args.cpu_du_first_cpu < -1:
        parser.error("--cpu-du-first-cpu 必须 >= -1")
    if any(miss > 2048 for miss in args.misses):
        parser.error("--misses 不能超过 2048")
    if (
        args.cache_budget < args.query_count * 2048
        or args.cache_budget > 16256
        or args.cache_budget % 128
    ):
        parser.error("--cache-budget 必须覆盖 MTP TopK union、128 对齐且 <=16256")
    if args.candidate_length < args.cache_budget + max(args.misses):
        parser.error("--candidate-length 无法容纳 cache 与 miss token")
    return args


def base_row(
    args: argparse.Namespace, component: str, misses: int
) -> dict[str, object]:
    row: dict[str, object] = {field: "" for field in CSV_FIELDS}
    row.update({
        "component": component,
        "bs": args.bs,
        "query_count": args.query_count,
        "candidate_length": args.candidate_length,
        "cache_budget": args.cache_budget,
        "misses": misses,
        "warmup": args.warmup,
        "iterations": args.iterations,
    })
    return row


def cpu_command(args: argparse.Namespace) -> list[str]:
    threads = args.cpu_du_threads or min(args.bs, 32)
    return [
        args.python,
        str(ROOT / "test" / "cpu_du_perf.py"),
        "--modes", "batch",
        "--batch-sizes", str(args.bs),
        "--candidate-lengths", str(args.candidate_length),
        "--misses", ",".join(str(value) for value in args.misses),
        "--query-count", str(args.query_count),
        "--cache-budget", str(args.cache_budget),
        "--topk-pattern", "low_overlap",
        "--warmup", str(args.warmup),
        "--iterations", str(args.iterations),
        "--batch-threads", str(threads),
        "--batch-first-cpu", str(args.cpu_du_first_cpu),
    ]


def c8_application_command(args: argparse.Namespace, misses: int) -> list[str]:
    return [
        args.python,
        str(ROOT / "test" / "c8_mtp_lidu_perf_workload.py"),
        "--device", args.device,
        "--bs", str(args.bs),
        "--heads", str(args.heads),
        "--source-len", str(args.candidate_length),
        "--queries-per-request", str(args.query_count),
        "--cache-budget", str(args.cache_budget),
        "--misses", str(misses),
        "--warmup", str(args.warmup),
        "--iterations", str(args.iterations),
    ]


def c8_profiler_command(
    args: argparse.Namespace, misses: int, output: Path
) -> list[str]:
    return [
        args.msprof_bin,
        f"--application={shlex.join(c8_application_command(args, misses))}",
        f"--output={output}",
        "--task-time=on",
        "--export=on",
        *shlex.split(args.msprof_extra),
    ]


def key_values(line: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for item in line.split()[1:]:
        if "=" in item:
            key, value = item.split("=", 1)
            result[key] = value
    return result


def run_cpu(args: argparse.Namespace) -> list[dict[str, object]]:
    command = cpu_command(args)
    print(f"REPRODUCE_COMMAND {shlex.join(command)}", flush=True)
    if args.dry_run:
        return [
            {**base_row(args, "cpu_du_extension", miss), "status": "dry_run"}
            for miss in args.misses
        ]
    try:
        completed = subprocess.run(
            command,
            cwd=ROOT,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
        )
    except OSError as error:
        print(f"CPU DU 启动失败：{error}", file=sys.stderr)
        return [
            {
                **base_row(args, "cpu_du_extension", miss),
                "status": "failed_start",
            }
            for miss in args.misses
        ]
    print(completed.stdout, end="", flush=True)
    if completed.returncode != 0:
        return [
            {
                **base_row(args, "cpu_du_extension", miss),
                "status": "failed_cpu_du",
            }
            for miss in args.misses
        ]
    parsed: dict[int, dict[str, str]] = {}
    for line in completed.stdout.splitlines():
        if line.startswith("CPU_DU_PERF mode=batch_union_parallel"):
            values = key_values(line)
            parsed[int(values["misses"])] = values
    rows = []
    for miss in args.misses:
        row = base_row(args, "cpu_du_extension", miss)
        values = parsed.get(miss)
        if values is None:
            row["status"] = "failed_parse"
        else:
            row.update({
                "mode": "batch_union_parallel",
                "topk_pattern": values["topk_pattern"],
                "avg_us": values["avg_us"],
                "p50_us": values["p50_us"],
                "p90_us": values["p90_us"],
                "p99_us": values["p99_us"],
                "request_iops": values["request_IOPS"],
                "unique_miss_iops": values["unique_miss_IOPS"],
                "worker_threads": values["worker_threads"],
                "timing_source": "host_perf_counter",
                "status": "ok_profiled",
            })
        rows.append(row)
    return rows


def run_c8_case(
    args: argparse.Namespace, misses: int, output: Path
) -> dict[str, object]:
    row = base_row(args, "c8_mtp_lidu", misses)
    command = c8_profiler_command(args, misses, output)
    print(f"REPRODUCE_COMMAND {shlex.join(command)}", flush=True)
    if args.dry_run:
        row["status"] = "dry_run"
        return row
    output.mkdir(parents=True, exist_ok=False)
    try:
        completed = subprocess.run(
            command,
            cwd=ROOT,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
        )
    except OSError as error:
        (output / "msprof.log").write_text(
            f"failed to start msprof: {error}\n", encoding="utf-8"
        )
        row["status"] = "failed_start"
        return row
    (output / "msprof.log").write_text(completed.stdout, encoding="utf-8")
    if completed.returncode != 0:
        row["status"] = "failed_msprof"
        return row
    try:
        calls = invocations(read_tasks(output), C8_TOKENS)
    except Exception as error:
        with (output / "msprof.log").open("a", encoding="utf-8") as stream:
            stream.write(f"\nparse error: {error}\n")
        row["status"] = "failed_parse"
        return row
    required = args.warmup + args.iterations
    if len(calls) < required:
        row["status"] = "failed_parse"
        return row
    samples = [
        task.duration_us for task in calls[-required:][args.warmup :]
    ]
    average = sum(samples) / len(samples)
    row.update({
        "mode": "fused_li_du_out",
        "topk_pattern": "native_c8",
        "avg_us": round(average, 3),
        "p50_us": round(percentile(samples, 0.50), 3),
        "p90_us": round(percentile(samples, 0.90), 3),
        "p99_us": round(percentile(samples, 0.99), 3),
        "request_iops": round(args.bs * 1_000_000.0 / average),
        "unique_miss_iops": round(
            args.bs * misses * 1_000_000.0 / average
        ),
        "worker_threads": 0,
        "timing_source": "msprof_task_time",
        "status": "ok_profiled",
    })
    return row


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=CSV_FIELDS)
        writer.writeheader()
        writer.writerows(rows)


def format_result(row: dict[str, object]) -> str:
    if row.get("avg_us", "") == "":
        return (
            f"OPERATOR_PERF component={row['component']} misses={row['misses']} "
            f"status={row['status']}"
        )
    return (
        f"OPERATOR_PERF component={row['component']} mode={row['mode']} "
        f"bs={row['bs']} misses={row['misses']} avg_us={row['avg_us']} "
        f"p50_us={row['p50_us']} p90_us={row['p90_us']} "
        f"p99_us={row['p99_us']} request_IOPS={row['request_iops']} "
        f"unique_miss_IOPS={row['unique_miss_iops']} "
        f"timing_source={row['timing_source']} status={row['status']}"
    )


def main() -> int:
    args = parse_args()
    rows: list[dict[str, object]] = []
    if "cpu_du_extension" in args.components:
        rows.extend(run_cpu(args))
    if "c8_mtp_lidu" in args.components:
        run_id = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        root = args.profile_root.resolve()
        for misses in args.misses:
            rows.append(run_c8_case(
                args, misses, root / f"{run_id}_c8_miss{misses}"
            ))
    if not args.dry_run:
        write_csv(args.csv, rows)

    print("\nPERFORMANCE_ONLY_SUMMARY", flush=True)
    for row in rows:
        print(format_result(row), flush=True)
    if not args.dry_run:
        print(f"CSV path={args.csv.resolve()}", flush=True)
    return int(any(str(row["status"]).startswith("failed") for row in rows))


if __name__ == "__main__":
    raise SystemExit(main())
