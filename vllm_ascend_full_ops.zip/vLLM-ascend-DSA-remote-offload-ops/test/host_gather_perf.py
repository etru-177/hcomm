#!/usr/bin/env python3
"""Sweep the exact Host CKV(1024 B) + KPE(128 B) gather workload."""

import argparse
import csv
import itertools
import pathlib
import random
import subprocess


ROOT = pathlib.Path(__file__).resolve().parent
DEFAULT_BINARY = ROOT / "urma_mock_pool" / "gather_microbench"


def comma_list(text, convert):
    return tuple(convert(item) for item in text.split(",") if item)


def parse_probe(line):
    return dict(item.split("=", 1) for item in line.split() if "=" in item)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--binary", type=pathlib.Path, default=DEFAULT_BINARY)
    parser.add_argument("--tokens", default="100,200,400")
    parser.add_argument("--threads", default="1,2,4,8")
    parser.add_argument("--kernels", default="libc,neon,sve2")
    parser.add_argument("--patterns", default="random")
    parser.add_argument("--pool-tokens", type=int, default=262144)
    parser.add_argument("--warmup", type=int, default=20)
    parser.add_argument(
        "--iterations", "--measured-runs", dest="iterations", type=int, default=100
    )
    parser.add_argument("--cpus", default="")
    parser.add_argument("--top", type=int, default=15)
    parser.add_argument("--shuffle-seed", type=int)
    parser.add_argument("--output-csv", type=pathlib.Path)
    args = parser.parse_args()

    tokens = comma_list(args.tokens, int)
    threads = comma_list(args.threads, int)
    kernels = comma_list(args.kernels, str)
    patterns = comma_list(args.patterns, str)
    cpus = comma_list(args.cpus, int)
    if cpus and len(cpus) < max(threads):
        parser.error("--cpus must contain at least max(--threads) CPU IDs")
    for token_count in tokens:
        sampled_tokens = (args.warmup + args.iterations) * token_count
        if sampled_tokens > args.pool_tokens:
            print(
                f"HOST_GATHER_WARNING tokens={token_count} sampled_tokens="
                f"{sampled_tokens} pool_tokens={args.pool_tokens} "
                "source_sequence_wraps=1",
                flush=True,
            )

    cases = list(itertools.product(patterns, tokens, threads, kernels))
    if args.shuffle_seed is not None:
        random.Random(args.shuffle_seed).shuffle(cases)

    results = []
    for ordinal, (pattern, token_count, thread_count, kernel) in enumerate(
        cases, 1
    ):
        print(
            f"HOST_GATHER_SCAN case={ordinal}/{len(cases)} pattern={pattern} "
            f"tokens={token_count} threads={thread_count} kernel={kernel}",
            flush=True,
        )
        command = [
            str(args.binary),
            "--tokens",
            str(token_count),
            "--pool-tokens",
            str(args.pool_tokens),
            "--threads",
            str(thread_count),
            "--kernel",
            kernel,
            "--pattern",
            pattern,
            "--warmup",
            str(args.warmup),
            "--iterations",
            str(args.iterations),
        ]
        if cpus:
            command.extend(["--cpus", ",".join(map(str, cpus[:thread_count]))])
        completed = subprocess.run(
            command, check=True, text=True, capture_output=True
        )
        line = completed.stdout.strip()
        print(line, flush=True)
        fields = parse_probe(line)
        results.append(
            {
                "pattern": pattern,
                "tokens": token_count,
                "threads": thread_count,
                "kernel": kernel,
                "pool_tokens": args.pool_tokens,
                "warmup": args.warmup,
                "iterations": args.iterations,
                "avg_us": float(fields["avg_us"]),
                "p50_us": float(fields["p50_us"]),
                "p99_us": float(fields["p99_us"]),
                "tokens_per_s": float(fields["tokens_per_s"]),
                "payload_GBps": float(fields["payload_GBps"]),
            }
        )

    results.sort(key=lambda result: result["payload_GBps"], reverse=True)
    for rank, result in enumerate(results[: args.top], 1):
        print(
            f"HOST_GATHER_TOP rank={rank} pattern={result['pattern']} "
            f"tokens={result['tokens']} threads={result['threads']} "
            f"kernel={result['kernel']} "
            f"avg_us={result['avg_us']:.3f} p99_us={result['p99_us']:.3f} "
            f"payload_GBps={result['payload_GBps']:.3f}",
            flush=True,
        )

    if args.output_csv:
        with args.output_csv.open("w", newline="", encoding="utf-8") as output:
            writer = csv.DictWriter(output, fieldnames=results[0].keys())
            writer.writeheader()
            writer.writerows(results)


if __name__ == "__main__":
    main()
