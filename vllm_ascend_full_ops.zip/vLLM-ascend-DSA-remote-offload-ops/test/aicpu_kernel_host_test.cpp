/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2026. All rights reserved.
 */

#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <vector>

#include "../csrc/src/kvcache_scatter_copy/op_kernel_aicpu/hcomm_batch_copy.h"
#include "../csrc/src/kvcache_scatter_copy/op_kernel_aicpu/kvcache_scatter_copy_aicpu_impl.h"

namespace {

using namespace kvcache_scatter_copy_aicpu;

std::vector<void*> capturedDstHbm;
std::vector<uint64_t> capturedSrcGva;
std::vector<uint64_t> capturedCopyBytes;
std::vector<size_t> submittedBatchSizes;
uint32_t injectedHcommStatus = hcomm::HCOMM_SUCCESS;

void Check(bool condition, const char* message)
{
    if (!condition) {
        std::cerr << "FAILED: " << message << std::endl;
        std::exit(1);
    }
}

void ResetRecorder()
{
    capturedDstHbm.clear();
    capturedSrcGva.clear();
    capturedCopyBytes.clear();
    submittedBatchSizes.clear();
    injectedHcommStatus = hcomm::HCOMM_SUCCESS;
}

uint32_t RecordingBatchCopy(void* args)
{
    const auto* param = static_cast<const HybmBatchCopyParam*>(args);
    Check(param != nullptr, "HybmBatchCopyParam must be non-null");
    submittedBatchSizes.push_back(static_cast<size_t>(param->size));
    capturedDstHbm.insert(capturedDstHbm.end(), param->dstHbmPtrList,
        param->dstHbmPtrList + param->size);
    capturedCopyBytes.insert(capturedCopyBytes.end(), param->lengthList,
        param->lengthList + param->size);
    for (uint64_t idx = 0; idx < param->size; ++idx) {
        capturedSrcGva.push_back(reinterpret_cast<uint64_t>(param->srcDdrPtrList[idx]));
    }
    if (injectedHcommStatus != hcomm::HCOMM_SUCCESS) {
        return injectedHcommStatus;
    }
    return HybmBatchCopy(args);
}

void FillSource(std::vector<uint16_t>& data, uint16_t base)
{
    for (size_t token = 0; token < data.size() / KV_CACHE_DIM; ++token) {
        for (int64_t element = 0; element < KV_CACHE_DIM; ++element) {
            data[token * KV_CACHE_DIM + element] =
                static_cast<uint16_t>(base + token * 7 + element);
        }
    }
}

CopyParams MakeParams(std::vector<uint16_t>& hbmKv, const std::vector<uint16_t>& dramKv,
    const std::vector<int32_t>& hbmTable, const std::vector<uint64_t>& dramTable,
    const std::vector<int32_t>& srcIds, const std::vector<int32_t>& dstSlots,
    const std::vector<int32_t>& copyCounts, int64_t hbmBlocks, int64_t maxBlocks, int64_t batchSize)
{
    CopyParams params;
    params.hbmKvCache = reinterpret_cast<uint8_t*>(hbmKv.data());
    params.dramKvCache = reinterpret_cast<const uint8_t*>(dramKv.data());
    params.hbmBlockTable = hbmTable.data();
    params.dramBlockTable = dramTable.data();
    params.srcTokenIds = srcIds.data();
    params.dstSlots = dstSlots.data();
    params.copyCounts = copyCounts.data();
    params.hbmBlockCount = hbmBlocks;
    params.hbmMaxBlockNum = maxBlocks;
    params.dramMaxBlockNum = maxBlocks;
    params.batchSize = batchSize;
    return params;
}

void TestKvGvaAddressing()
{
    constexpr int64_t blockCount = 4;
    constexpr int64_t tokens = blockCount * BLOCK_SIZE;
    std::vector<uint16_t> hbmKv(tokens * KV_CACHE_DIM, 0x2222);
    std::vector<uint16_t> dramKv(tokens * KV_CACHE_DIM);
    FillSource(dramKv, 1000);
    std::vector<uint16_t> expectedKv = hbmKv;
    const std::vector<int32_t> hbmTable = {1, 0, 3, 2};
    const std::vector<uint64_t> dramTable = {
        reinterpret_cast<uint64_t>(dramKv.data() + 2 * BLOCK_SIZE * KV_CACHE_DIM),
        reinterpret_cast<uint64_t>(dramKv.data() + 3 * BLOCK_SIZE * KV_CACHE_DIM),
        reinterpret_cast<uint64_t>(dramKv.data()),
        reinterpret_cast<uint64_t>(dramKv.data() + BLOCK_SIZE * KV_CACHE_DIM)};
    std::vector<int32_t> srcIds(2 * COPY_CAP, -1);
    std::vector<int32_t> dstSlots(2 * COPY_CAP, -1);
    srcIds[0] = 0;
    dstSlots[0] = 129;
    srcIds[1] = 129;
    dstSlots[1] = 0;
    srcIds[COPY_CAP] = 1;
    dstSlots[COPY_CAP] = 130;
    const std::vector<int32_t> copyCounts = {2, 1};

    const auto addExpected = [&](int64_t batch, int64_t src, int64_t dst) {
        const uint64_t srcGva = dramTable[batch * 2 + src / BLOCK_SIZE] +
            static_cast<uint64_t>(src % BLOCK_SIZE) * KV_CACHE_TOKEN_BYTES;
        const int64_t dstPhysical =
            hbmTable[batch * 2 + dst / BLOCK_SIZE] * BLOCK_SIZE + dst % BLOCK_SIZE;
        const auto* source = reinterpret_cast<const uint16_t*>(static_cast<uintptr_t>(srcGva));
        std::copy_n(source, KV_CACHE_DIM,
            expectedKv.begin() + dstPhysical * KV_CACHE_DIM);
    };
    addExpected(0, 0, 129);
    addExpected(0, 129, 0);
    addExpected(1, 1, 130);

    CopyParams params = MakeParams(hbmKv, dramKv, hbmTable, dramTable, srcIds, dstSlots,
        copyCounts, blockCount, 2, 2);
    ResetRecorder();
    uint32_t hcommStatus = hcomm::HCOMM_SUCCESS;
    Check(DispatchBatchCopyRequests(params, RecordingBatchCopy, hcommStatus) == STATUS_SUCCESS,
        "KV GVA dispatch failed");
    Check(submittedBatchSizes == std::vector<size_t>({3}),
        "each miss token should generate exactly one KV request");
    Check(capturedSrcGva[0] == dramTable[0], "first source GVA is wrong");
    Check(capturedDstHbm[0] == hbmKv.data() + KV_CACHE_DIM,
        "first destination HBM address is wrong");
    Check(capturedCopyBytes[0] == KV_CACHE_TOKEN_BYTES, "KV copy size is wrong");
    Check(hbmKv == expectedKv, "KV mock result differs from reference");
}

void TestInvalidGvaAndStreaming()
{
    constexpr int64_t copyCount = HCOMM_BATCH_REQUEST_CAPACITY + 1;
    std::vector<uint16_t> hbmKv(2 * BLOCK_SIZE * KV_CACHE_DIM, 0);
    std::vector<uint16_t> dramKv(2 * BLOCK_SIZE * KV_CACHE_DIM);
    FillSource(dramKv, 17);
    const std::vector<int32_t> hbmTable = {0, 1};
    const std::vector<uint64_t> dramTable = {
        reinterpret_cast<uint64_t>(dramKv.data()),
        reinterpret_cast<uint64_t>(dramKv.data() + BLOCK_SIZE * KV_CACHE_DIM)};
    std::vector<int32_t> srcIds(COPY_CAP, -1);
    std::vector<int32_t> dstSlots(COPY_CAP, -1);
    for (int32_t token = 0; token < copyCount; ++token) {
        srcIds[token] = token;
        dstSlots[token] = token;
    }
    const std::vector<int32_t> copyCounts = {copyCount};
    CopyParams params = MakeParams(hbmKv, dramKv, hbmTable, dramTable, srcIds, dstSlots,
        copyCounts, 2, 2, 1);

    ResetRecorder();
    uint32_t hcommStatus = hcomm::HCOMM_SUCCESS;
    Check(DispatchBatchCopyRequests(params, RecordingBatchCopy, hcommStatus) == STATUS_SUCCESS,
        "KV streaming dispatch failed");
    Check(submittedBatchSizes == std::vector<size_t>({HCOMM_BATCH_REQUEST_CAPACITY, 1}),
        "KV request stream was not split at the fixed batch capacity");

    const std::vector<uint64_t> nullGva = {0, dramTable[1]};
    params.dramBlockTable = nullGva.data();
    ResetRecorder();
    Check(DispatchBatchCopyRequests(params, RecordingBatchCopy, hcommStatus) == STATUS_PARAM_INVALID,
        "zero GVA was not rejected");
    Check(capturedSrcGva.empty(), "invalid GVA submitted a batch");
}

void TestBatchCopyMockValidation()
{
    HybmBatchCopyParam emptyParam = {nullptr, nullptr, nullptr, 0};
    Check(HybmBatchCopy(&emptyParam) == hcomm::HCOMM_SUCCESS,
        "empty Hcomm batch should succeed");
    HybmBatchCopyParam invalidParam = {nullptr, nullptr, nullptr, 1};
    Check(HybmBatchCopy(&invalidParam) == hcomm::HCOMM_INVALID_ARGUMENT,
        "null Hcomm arrays were not rejected");
}

} // namespace

int main()
{
    TestKvGvaAddressing();
    TestInvalidGvaAndStreaming();
    TestBatchCopyMockValidation();
    std::cout << "KVCACHE_SCATTER_COPY_AICPU_HOST_TEST_OK" << std::endl;
    return 0;
}
