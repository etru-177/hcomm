#!/usr/bin/env python3
"""从 msprof task-time 中只提取 C8 LightningIndexer kernel 时间。"""

from __future__ import annotations

import argparse
import statistics
from pathlib import Path

from analyze_remote_offload_msprof import invocations, percentile, read_tasks


LI_TOKENS = ("quantlightningindexer", "lightningindexer")


def analyze(
    profile_path: Path,
    *,
    warmup: int,
    iterations: int,
    calls_per_iteration: int,
) -> dict[str, float | int]:
    required_groups = warmup + iterations
    required_calls = required_groups * calls_per_iteration
    calls = invocations(read_tasks(profile_path), LI_TOKENS)
    if len(calls) < required_calls:
        raise RuntimeError(
            f"msprof 中 LI 调用数不足：found={len(calls)} "
            f"required={required_calls}"
        )
    # 只取最后 required_calls，排除可能存在的输入校验或运行时首次探测。
    selected = calls[-required_calls:]
    measured = selected[warmup * calls_per_iteration :]
    samples = [task.duration_us for task in measured]
    group_sums = [
        sum(samples[begin : begin + calls_per_iteration])
        for begin in range(0, len(samples), calls_per_iteration)
    ]
    return {
        "li_task_count": len(samples),
        "li_call_avg_us": statistics.mean(samples),
        "li_call_p50_us": statistics.median(samples),
        "li_call_p90_us": percentile(samples, 0.90),
        "li_call_p99_us": percentile(samples, 0.99),
        "li_iteration_sum_avg_us": statistics.mean(group_sums),
        "li_iteration_sum_p50_us": statistics.median(group_sums),
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("profile", type=Path)
    parser.add_argument("--warmup", type=int, default=5)
    parser.add_argument("--iterations", type=int, default=20)
    parser.add_argument("--calls-per-iteration", type=int, default=10)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    result = analyze(
        args.profile,
        warmup=args.warmup,
        iterations=args.iterations,
        calls_per_iteration=args.calls_per_iteration,
    )
    print(
        "LI_C8_MTP_MSPROF_RESULT "
        + " ".join(f"{key}={value}" for key, value in result.items()),
        flush=True,
    )


if __name__ == "__main__":
    main()
