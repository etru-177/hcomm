#!/usr/bin/env python3
"""Minimal Event benchmark for raw-URMA KPE + CKV scatter copy."""

import math
import os
import statistics
import time

import numpy as np
import torch
import torch_npu

from _common import BLOCK_SIZE, BYTES_PER_TOKEN, COPY_CAP, K_ROPE_DIM, KV_CACHE_DIM, load_new_ops


# ---- machine-specific configuration ----
DEVICE = "npu:0"
DEVICE_EID = "00000000000000000000000000000000"
DEVICE_PHY_ID = 0
POOL_IP = "127.0.0.1"
CONTROL_PORT = 19090
RAW_LANES = 1
HOST_PUSH_PERCENT = 100
HOST_TOKEN_GATHER = True
AGGREGATION_ONLY = bool(int(os.getenv("URMA_AGGREGATION_ONLY", "0")))
SCATTER_AFTER_GATHER = (
    False if AGGREGATION_ONLY
    else bool(int(os.getenv("URMA_SCATTER_AFTER_GATHER", "1")))
)
RUN_AIV = False
IO_BYTES = int(os.getenv("URMA_IO_BYTES", str(BYTES_PER_TOKEN)))
MAX_SUBIOS_PER_WQE = int(os.getenv("URMA_MAX_SUBIOS_PER_WQE", "0"))
FIXED_WQE_BYTES = int(os.getenv("URMA_FIXED_WQE_BYTES", "0"))
LOCAL_AIV_WARMUP_MS = int(os.getenv("URMA_LOCAL_AIV_WARMUP_MS", "2000"))
LOCAL_AIV_WARMUP_BATCH = int(os.getenv("URMA_LOCAL_AIV_WARMUP_BATCH", "32"))
# ----------------------------------------

BATCH_SIZES = (1, 2, 4, 8, 16, 32, 64)
TOKENS_PER_BATCH = (100, 200, 300, 400)
WARMUP = 10
ITERS = 100
SEED = 2026
DTYPE = torch.bfloat16
POOL_BLOCK_BYTES = BLOCK_SIZE * BYTES_PER_TOKEN
MAX_HBM_BLOCKS = max(BATCH_SIZES) * math.ceil(max(TOKENS_PER_BATCH) / BLOCK_SIZE)


def make_case(device, pool_gva, pool_blocks, batch_size, tokens, seed):
    generator = torch.Generator().manual_seed(seed)
    blocks_per_batch = math.ceil(tokens / BLOCK_SIZE)
    blocks_per_call = batch_size * blocks_per_batch
    remote_banks = pool_blocks // blocks_per_call
    if remote_banks == 0:
        raise RuntimeError(
            f"remote pool has {pool_blocks} blocks; {batch_size}x{tokens} needs {blocks_per_call}"
        )

    hbm_block_table = torch.randperm(
        blocks_per_call, generator=generator, dtype=torch.int64
    ).reshape(batch_size, blocks_per_batch).to(torch.int32).to(device)

    remote_order = torch.randperm(pool_blocks, generator=generator, dtype=torch.int64)
    remote_order = remote_order[: remote_banks * blocks_per_call]
    dram_tables = pool_gva + remote_order.reshape(
        remote_banks, batch_size, blocks_per_batch
    ) * POOL_BLOCK_BYTES
    dram_tables = dram_tables.to(torch.uint64).to(device)

    padded_tokens = blocks_per_batch * BLOCK_SIZE
    src_token_ids = torch.full((batch_size, 1, COPY_CAP), -1, dtype=torch.int32)
    dst_slots = torch.full((batch_size, 1, COPY_CAP), -1, dtype=torch.int32)
    for batch in range(batch_size):
        src_token_ids[batch, 0, :tokens] = torch.randperm(
            padded_tokens, generator=generator, dtype=torch.int64
        )[:tokens].to(torch.int32)
        dst_slots[batch, 0, :tokens] = torch.randperm(
            padded_tokens, generator=generator, dtype=torch.int64
        )[:tokens].to(torch.int32)

    return (
        hbm_block_table,
        dram_tables,
        src_token_ids.to(device),
        dst_slots.to(device),
        torch.full((batch_size,), tokens, dtype=torch.int32, device=device),
        torch.ones((1,), dtype=torch.int32, device=device),
        remote_banks,
    )


PROFILE_STAGES = {
    "ready": 7,
    "prepare": 8,
    "submit": 9,
    "sync": 10,
    "host_wait": 11,
    "local_scatter": 12,
    "aicpu_total": 13,
}


def benchmark_case(
    operation,
    mode_name,
    profile_mode,
    profile_ring,
    device,
    hbm_kpe,
    hbm_ckv,
    pool_gva,
    pool_blocks,
    batch_size,
    tokens,
    seed,
):
    (
        hbm_block_table,
        dram_tables,
        src_token_ids,
        dst_slots,
        copy_counts,
        ready_flag,
        remote_banks,
    ) = make_case(device, pool_gva, pool_blocks, batch_size, tokens, seed)

    for iteration in range(WARMUP):
        operation(
            hbm_kpe,
            hbm_ckv,
            hbm_block_table,
            dram_tables[iteration % remote_banks],
            src_token_ids,
            dst_slots,
            copy_counts,
            ready_flag,
            7,
        )
    torch_npu.npu.synchronize()

    times_us = []
    for iteration in range(ITERS):
        dram_block_table = dram_tables[(WARMUP + iteration) % remote_banks]
        start = torch.npu.Event(enable_timing=True)
        end = torch.npu.Event(enable_timing=True)
        start.record()
        operation(
            hbm_kpe,
            hbm_ckv,
            hbm_block_table,
            dram_block_table,
            src_token_ids,
            dst_slots,
            copy_counts,
            ready_flag,
            7,
        )
        end.record()
        end.synchronize()
        times_us.append(float(start.elapsed_time(end)) * 1000.0)

    times_us.sort()
    avg_us = statistics.mean(times_us)
    p50_us = statistics.median(times_us)
    p99_us = times_us[math.ceil(0.99 * len(times_us)) - 1]
    payload_bytes = batch_size * tokens * IO_BYTES
    effective_gbps = payload_bytes / avg_us / 1000.0
    iops = round(batch_size * tokens * 1.0e6 / avg_us)
    subios_per_io = 2 if IO_BYTES == BYTES_PER_TOKEN else 1
    subio_iops = iops * subios_per_io
    records = profile_ring.cpu().numpy().view(np.uint64).reshape(-1, 16)
    records = records[
        (records[:, 0] != 0)
        & (records[:, 1] == 1)
        & (records[:, 2] == profile_mode)
    ]
    records = records[np.argsort(records[:, 0])][-ITERS:]
    stage_text = []
    for name, index in PROFILE_STAGES.items():
        values = np.sort(records[:, index].astype(np.float64) / 1000.0)
        stage_text.append(
            f"{name}_avg_us={np.mean(values):.3f} "
            f"{name}_p50_us={np.median(values):.3f} "
            f"{name}_p99_us={values[math.ceil(0.99 * len(values)) - 1]:.3f}"
        )
    launch_gap_us = avg_us - float(np.mean(records[:, 13])) / 1000.0
    aggregate_text = ""
    if mode_name == "end_to_end":
        aggregate_text = (
            f" max_subios_per_wqe={MAX_SUBIOS_PER_WQE} "
            f"fixed_wqe_bytes={FIXED_WQE_BYTES} subio_IOPS={subio_iops}"
        )
        if MAX_SUBIOS_PER_WQE:
            subios = batch_size * tokens * subios_per_io
            data_wqes = math.ceil(subios / MAX_SUBIOS_PER_WQE)
            physical_bytes = (
                data_wqes * FIXED_WQE_BYTES
                if FIXED_WQE_BYTES
                else payload_bytes
            )
            aggregate_text += (
                f" data_wqes_per_call={data_wqes} "
                f"physical_write_bytes={physical_bytes}"
            )
    print(
        f"mode={mode_name} io_bytes={IO_BYTES} bs={batch_size} tokens={tokens} "
        f"remote_blocks={pool_blocks} "
        f"remote_banks={remote_banks} payload={payload_bytes} "
        f"avg_us={avg_us:.3f} p50_us={p50_us:.3f} p99_us={p99_us:.3f} "
        f"effective_GBps={effective_gbps:.3f} IOPS={iops}"
        f"{aggregate_text} "
        f"launch_gap_us={launch_gap_us:.3f} "
        + " ".join(stage_text),
        flush=True,
    )


def benchmark_aiv_case(
    ops,
    staging,
    device,
    hbm_kpe,
    hbm_ckv,
    pool_gva,
    pool_blocks,
    batch_size,
    tokens,
    seed,
):
    (
        hbm_block_table,
        dram_tables,
        src_token_ids,
        dst_slots,
        copy_counts,
        ready_flag,
        remote_banks,
    ) = make_case(device, pool_gva, pool_blocks, batch_size, tokens, seed)
    ops.npu_hcomm_kvcache_scatter_copy(
        hbm_kpe,
        hbm_ckv,
        hbm_block_table,
        dram_tables[0],
        src_token_ids,
        dst_slots,
        copy_counts,
        ready_flag,
        7,
    )
    torch_npu.npu.synchronize()
    operation = torch.ops.custom.npu_kvcache_scatter_local_aiv
    hbm_kpe.zero_()
    hbm_ckv.zero_()
    ops.npu_hcomm_kvcache_local_scatter(
        hbm_kpe,
        hbm_ckv,
        hbm_block_table,
        dram_tables[0],
        src_token_ids,
        dst_slots,
        copy_counts,
        ready_flag,
        7,
    )
    torch_npu.npu.synchronize()
    reference_kpe = hbm_kpe.clone()
    reference_ckv = hbm_ckv.clone()
    hbm_kpe.zero_()
    hbm_ckv.zero_()
    staging_view = staging.narrow(
        0,
        0,
        (
            batch_size * tokens * IO_BYTES
            if HOST_TOKEN_GATHER
            else int(dram_tables[0].numel()) * POOL_BLOCK_BYTES
        ),
    )
    if HOST_TOKEN_GATHER:
        staging_view = staging_view.view(-1, IO_BYTES)
    aiv_kpe, aiv_ckv = operation(
        hbm_kpe,
        hbm_ckv,
        staging_view,
        hbm_block_table,
        src_token_ids,
        dst_slots,
        copy_counts,
    )
    torch_npu.npu.synchronize()
    if not torch.equal(aiv_kpe, reference_kpe) or not torch.equal(
        aiv_ckv, reference_ckv
    ):
        raise RuntimeError("AIV local scatter differs from the AICPU reference")
    warmup_begin = time.perf_counter_ns()
    warmup_calls = 0
    if LOCAL_AIV_WARMUP_MS == 0:
        warmup_target_calls = WARMUP
        while warmup_calls < warmup_target_calls:
            operation(
                hbm_kpe,
                hbm_ckv,
                staging_view,
                hbm_block_table,
                src_token_ids,
                dst_slots,
                copy_counts,
            )
            warmup_calls += 1
        torch_npu.npu.synchronize()
    else:
        warmup_deadline_ns = (
            warmup_begin + LOCAL_AIV_WARMUP_MS * 1_000_000
        )
        while time.perf_counter_ns() < warmup_deadline_ns:
            for _ in range(LOCAL_AIV_WARMUP_BATCH):
                operation(
                    hbm_kpe,
                    hbm_ckv,
                    staging_view,
                    hbm_block_table,
                    src_token_ids,
                    dst_slots,
                    copy_counts,
                )
                warmup_calls += 1
            # 控制队列深度，并确保预热时间对应设备实际执行时间，而不是 Host
            # 仅仅积压了尚未执行的 kernel。
            torch_npu.npu.synchronize()
    warmup_elapsed_ms = (
        time.perf_counter_ns() - warmup_begin
    ) / 1_000_000.0
    print(
        f"LOCAL_AIV_WARMUP io_bytes={IO_BYTES} bs={batch_size} "
        f"tokens={tokens} requested_ms={LOCAL_AIV_WARMUP_MS} "
        f"elapsed_ms={warmup_elapsed_ms:.3f} calls={warmup_calls} "
        f"batch={LOCAL_AIV_WARMUP_BATCH}",
        flush=True,
    )
    times_us = []
    for _ in range(ITERS):
        start = torch.npu.Event(enable_timing=True)
        end = torch.npu.Event(enable_timing=True)
        start.record()
        operation(
            hbm_kpe,
            hbm_ckv,
            staging_view,
            hbm_block_table,
            src_token_ids,
            dst_slots,
            copy_counts,
        )
        end.record()
        end.synchronize()
        times_us.append(float(start.elapsed_time(end)) * 1000.0)
    times_us.sort()
    avg_us = statistics.mean(times_us)
    payload_bytes = batch_size * tokens * IO_BYTES
    iops = round(batch_size * tokens * 1.0e6 / avg_us)
    print(
        f"mode=local_aiv_{'token' if HOST_TOKEN_GATHER else 'block'} "
        f"io_bytes={IO_BYTES} bs={batch_size} tokens={tokens} "
        f"avg_us={avg_us:.3f} p50_us={statistics.median(times_us):.3f} "
        f"p99_us={times_us[math.ceil(0.99 * len(times_us)) - 1]:.3f} "
        f"effective_GBps={payload_bytes / avg_us / 1000.0:.3f} IOPS={iops}",
        flush=True,
    )

    if SCATTER_AFTER_GATHER:
        return
    for iteration in range(WARMUP):
        ops.npu_hcomm_kvcache_scatter_copy(
            hbm_kpe,
            hbm_ckv,
            hbm_block_table,
            dram_tables[iteration % remote_banks],
            src_token_ids,
            dst_slots,
            copy_counts,
            ready_flag,
            7,
        )
        operation(
            hbm_kpe,
            hbm_ckv,
            staging_view,
            hbm_block_table,
            src_token_ids,
            dst_slots,
            copy_counts,
        )
    torch_npu.npu.synchronize()
    times_us = []
    for iteration in range(ITERS):
        start = torch.npu.Event(enable_timing=True)
        end = torch.npu.Event(enable_timing=True)
        start.record()
        ops.npu_hcomm_kvcache_scatter_copy(
            hbm_kpe,
            hbm_ckv,
            hbm_block_table,
            dram_tables[(WARMUP + iteration) % remote_banks],
            src_token_ids,
            dst_slots,
            copy_counts,
            ready_flag,
            7,
        )
        operation(
            hbm_kpe,
            hbm_ckv,
            staging_view,
            hbm_block_table,
            src_token_ids,
            dst_slots,
            copy_counts,
        )
        end.record()
        end.synchronize()
        times_us.append(float(start.elapsed_time(end)) * 1000.0)
    times_us.sort()
    avg_us = statistics.mean(times_us)
    iops = round(batch_size * tokens * 1.0e6 / avg_us)
    print(
        f"mode=end_to_end_aiv_{'token' if HOST_TOKEN_GATHER else 'block'} "
        f"io_bytes={IO_BYTES} bs={batch_size} tokens={tokens} "
        f"avg_us={avg_us:.3f} p50_us={statistics.median(times_us):.3f} "
        f"p99_us={times_us[math.ceil(0.99 * len(times_us)) - 1]:.3f} "
        f"effective_GBps={payload_bytes / avg_us / 1000.0:.3f} IOPS={iops}",
        flush=True,
    )


def run_connected_benchmarks(ops, channel, device, hbm_kpe, hbm_ckv):
    _, _, pool_gva, pool_bytes = ops.npu_hcomm_kvcache_pool_get_raw_context(channel)
    profile_ring = ops.npu_hcomm_kvcache_pool_get_profile(channel)
    staging = ops.npu_hcomm_kvcache_pool_get_staging(channel)
    if pool_bytes % POOL_BLOCK_BYTES != 0:
        raise RuntimeError(f"remote pool size {pool_bytes} is not block-aligned")
    pool_blocks = pool_bytes // POOL_BLOCK_BYTES
    if pool_blocks < MAX_HBM_BLOCKS:
        raise RuntimeError(
            f"remote pool has {pool_blocks} blocks; largest case needs {MAX_HBM_BLOCKS}"
        )
    print(
        f"RAW_HCOMM_CONNECTED channel=0x{channel:x} pool_gva=0x{pool_gva:x} "
        f"pool_bytes={pool_bytes} pool_blocks={pool_blocks} raw_lanes={RAW_LANES} "
        f"host_push_percent={HOST_PUSH_PERCENT} "
        f"host_token_gather={HOST_TOKEN_GATHER} "
        f"scatter_after_gather={SCATTER_AFTER_GATHER} io_bytes={IO_BYTES} "
        f"max_subios_per_wqe={MAX_SUBIOS_PER_WQE} "
        f"fixed_wqe_bytes={FIXED_WQE_BYTES}",
        flush=True,
    )

    end_to_end_profile_mode = (
        2 if SCATTER_AFTER_GATHER else 3
    ) if HOST_TOKEN_GATHER else 0
    case = 0
    for batch_size in BATCH_SIZES:
        for tokens in TOKENS_PER_BATCH:
            benchmarks = [(
                "end_to_end",
                end_to_end_profile_mode,
                ops.npu_hcomm_kvcache_scatter_copy,
            )]
            if not AGGREGATION_ONLY:
                benchmarks.append(
                    ("local_aicpu", 1, ops.npu_hcomm_kvcache_local_scatter))
            for mode_name, profile_mode, operation in benchmarks:
                benchmark_case(
                    operation,
                    mode_name,
                    profile_mode,
                    profile_ring,
                    device,
                    hbm_kpe,
                    hbm_ckv,
                    pool_gva,
                    pool_blocks,
                    batch_size,
                    tokens,
                    SEED + case,
                )
            if RUN_AIV and not AGGREGATION_ONLY:
                benchmark_aiv_case(
                    ops,
                    staging,
                    device,
                    hbm_kpe,
                    hbm_ckv,
                    pool_gva,
                    pool_blocks,
                    batch_size,
                    tokens,
                    SEED + case,
                )
            case += 1


def main():
    if IO_BYTES not in (576, 656, BYTES_PER_TOKEN):
        raise RuntimeError("URMA_IO_BYTES must be 576, 656, or 1152")
    if IO_BYTES != BYTES_PER_TOKEN and not HOST_TOKEN_GATHER:
        raise RuntimeError("576/656-byte IO requires HOST_TOKEN_GATHER=True")
    if not 0 <= MAX_SUBIOS_PER_WQE <= 65535:
        raise RuntimeError("URMA_MAX_SUBIOS_PER_WQE must be in [0, 65535]")
    if FIXED_WQE_BYTES < 0 or FIXED_WQE_BYTES % 64 != 0:
        raise RuntimeError("URMA_FIXED_WQE_BYTES must be zero or a multiple of 64")
    if FIXED_WQE_BYTES and not MAX_SUBIOS_PER_WQE:
        raise RuntimeError("URMA_FIXED_WQE_BYTES requires URMA_MAX_SUBIOS_PER_WQE > 0")
    if LOCAL_AIV_WARMUP_MS < 0:
        raise RuntimeError("URMA_LOCAL_AIV_WARMUP_MS must be non-negative")
    if LOCAL_AIV_WARMUP_BATCH <= 0:
        raise RuntimeError("URMA_LOCAL_AIV_WARMUP_BATCH must be positive")
    subio_bytes = (1024, 128) if IO_BYTES == BYTES_PER_TOKEN else (IO_BYTES,)
    max_wqe_payload = sum(
        subio_bytes[index % len(subio_bytes)]
        for index in range(MAX_SUBIOS_PER_WQE)
    )
    if FIXED_WQE_BYTES and max_wqe_payload > FIXED_WQE_BYTES:
        raise RuntimeError(
            "URMA_FIXED_WQE_BYTES is smaller than the largest capped WQE "
            f"payload ({max_wqe_payload} bytes)"
        )
    ops = load_new_ops()
    device = torch.device(DEVICE)
    torch_npu.npu.set_device(device)

    hbm_ckv = torch.empty(
        (MAX_HBM_BLOCKS, BLOCK_SIZE, KV_CACHE_DIM), dtype=DTYPE, device=device
    )
    hbm_kpe = torch.empty(
        (MAX_HBM_BLOCKS, BLOCK_SIZE, K_ROPE_DIM), dtype=DTYPE, device=device
    )
    channel = ops.npu_hcomm_kvcache_pool_connect_raw(
        DEVICE_EID,
        DEVICE_PHY_ID,
        POOL_IP,
        CONTROL_PORT,
        hbm_kpe,
        hbm_ckv,
        RAW_LANES,
        HOST_PUSH_PERCENT,
        HOST_TOKEN_GATHER,
        SCATTER_AFTER_GATHER,
        False,
        IO_BYTES,
        MAX_SUBIOS_PER_WQE,
        FIXED_WQE_BYTES,
    )
    try:
        run_connected_benchmarks(
            ops, channel, device, hbm_kpe, hbm_ckv
        )
    finally:
        try:
            torch_npu.npu.synchronize()
        finally:
            print(f"RAW_HCOMM_DISCONNECTING channel=0x{channel:x}", flush=True)
            disconnected = ops.npu_hcomm_kvcache_pool_disconnect_raw(channel)
            if not disconnected:
                raise RuntimeError(f"raw Hcomm channel 0x{channel:x} was not active")
            print(f"RAW_HCOMM_DISCONNECTED channel=0x{channel:x}", flush=True)

    print("URMA_REMOTE_SCATTER_PERF_OK", flush=True)


if __name__ == "__main__":
    main()
