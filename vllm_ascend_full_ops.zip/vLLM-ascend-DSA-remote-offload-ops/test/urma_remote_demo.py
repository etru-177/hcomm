#!/usr/bin/env python3
"""Minimal raw-URMA scatter-copy smoke test.

Edit only the constants below. Start urma_mock_pool with --blocks 2 and
--control-port CONTROL_PORT; pool GVA metadata is exchanged automatically.
"""

import torch
import torch_npu

from _common import BLOCK_SIZE, COPY_CAP, K_ROPE_DIM, KV_CACHE_DIM, load_new_ops


# ---- machine-specific configuration ----
DEVICE = "npu:0"
DEVICE_EID = "00000000000000000000000000000000"
DEVICE_PHY_ID = 0
POOL_IP = "127.0.0.1"
CONTROL_PORT = 19090
RAW_LANES = 1
HOST_PUSH_PERCENT = 100
HOST_TOKEN_GATHER = True
SCATTER_AFTER_GATHER = True
# ----------------------------------------


def byte_tensor(shape, dtype, value):
    byte_count = torch.empty(shape, dtype=dtype).numel() * torch.empty((), dtype=dtype).element_size()
    return torch.full((byte_count,), value, dtype=torch.uint8).view(dtype).reshape(shape)


def main():
    ops = load_new_ops()
    device = torch.device(DEVICE)
    torch_npu.npu.set_device(device)
    dtype = torch.bfloat16
    element_bytes = torch.empty((), dtype=dtype).element_size()
    ckv_token_bytes = KV_CACHE_DIM * element_bytes
    kpe_token_bytes = K_ROPE_DIM * element_bytes
    block_bytes = BLOCK_SIZE * (ckv_token_bytes + kpe_token_bytes)

    hbm_kv = byte_tensor((2, BLOCK_SIZE, KV_CACHE_DIM), dtype, 0xFF).to(device)
    hbm_kpe = byte_tensor((2, BLOCK_SIZE, K_ROPE_DIM), dtype, 0xFF).to(device)
    channel = ops.npu_hcomm_kvcache_pool_connect_raw(
        DEVICE_EID,
        DEVICE_PHY_ID,
        POOL_IP,
        CONTROL_PORT,
        hbm_kpe,
        hbm_kv,
        RAW_LANES,
        HOST_PUSH_PERCENT,
        HOST_TOKEN_GATHER,
        SCATTER_AFTER_GATHER,
    )
    _, _, pool_gva, pool_bytes = ops.npu_hcomm_kvcache_pool_get_raw_context(channel)
    if pool_bytes < 2 * block_bytes:
        raise RuntimeError(f"remote pool has {pool_bytes} bytes; need at least {2 * block_bytes}")
    print(
        f"RAW_HCOMM_CONNECTED channel=0x{channel:x} "
        f"pool_gva=0x{pool_gva:x} pool_bytes={pool_bytes} "
        f"raw_lanes={RAW_LANES} host_push_percent={HOST_PUSH_PERCENT} "
        f"host_token_gather={HOST_TOKEN_GATHER} "
        f"scatter_after_gather={SCATTER_AFTER_GATHER}"
    )

    hbm_block_table = torch.tensor([[1, 0]], dtype=torch.int32, device=device)
    dram_block_table = torch.tensor(
        [[pool_gva + block_bytes, pool_gva]], dtype=torch.uint64, device=device
    )
    src_token_ids = torch.full((1, 1, COPY_CAP), -1, dtype=torch.int32, device=device)
    dst_slots = torch.full((1, 1, COPY_CAP), -1, dtype=torch.int32, device=device)
    src_token_ids[0, 0, :2] = torch.tensor([1, 129], dtype=torch.int32, device=device)
    dst_slots[0, 0, :2] = torch.tensor([2, 130], dtype=torch.int32, device=device)
    copy_counts = torch.tensor([2], dtype=torch.int32, device=device)
    # The Hcomm kernel treats this as an input gate: loading starts at 1.
    ready_flag = torch.ones((1,), dtype=torch.int32, device=device)

    ops.npu_hcomm_kvcache_scatter_copy(
        hbm_kpe, hbm_kv, hbm_block_table, dram_block_table,
        src_token_ids, dst_slots, copy_counts, ready_flag, 7,
    )
    if HOST_TOKEN_GATHER and not SCATTER_AFTER_GATHER:
        ops.npu_hcomm_kvcache_local_scatter(
            hbm_kpe, hbm_kv, hbm_block_table, dram_block_table,
            src_token_ids, dst_slots, copy_counts, ready_flag, 7,
        )
    torch_npu.npu.synchronize()

    expected_kv = byte_tensor((2, BLOCK_SIZE, KV_CACHE_DIM), dtype, 0xFF).view(torch.uint8).reshape(-1)
    expected_kpe = byte_tensor((2, BLOCK_SIZE, K_ROPE_DIM), dtype, 0xFF).view(torch.uint8).reshape(-1)
    for src_token, dst_slot in ((1, 2), (129, 130)):
        src_block = (1, 0)[src_token // BLOCK_SIZE]
        dst_block = (1, 0)[dst_slot // BLOCK_SIZE]
        src_token_in_block = src_token % BLOCK_SIZE
        dst_token_in_block = dst_slot % BLOCK_SIZE
        remote_ckv = src_block * block_bytes + src_token_in_block * ckv_token_bytes
        remote_kpe = src_block * block_bytes + BLOCK_SIZE * ckv_token_bytes + src_token_in_block * kpe_token_bytes
        dst_ckv = (dst_block * BLOCK_SIZE + dst_token_in_block) * ckv_token_bytes
        dst_kpe = (dst_block * BLOCK_SIZE + dst_token_in_block) * kpe_token_bytes
        expected_kv[dst_ckv : dst_ckv + ckv_token_bytes] = torch.arange(
            remote_ckv, remote_ckv + ckv_token_bytes, dtype=torch.int64
        ).remainder(251).to(torch.uint8)
        expected_kpe[dst_kpe : dst_kpe + kpe_token_bytes] = torch.arange(
            remote_kpe, remote_kpe + kpe_token_bytes, dtype=torch.int64
        ).remainder(251).to(torch.uint8)

    assert torch.equal(hbm_kv.cpu().view(torch.uint8).reshape(-1), expected_kv)
    assert torch.equal(hbm_kpe.cpu().view(torch.uint8).reshape(-1), expected_kpe)
    assert ready_flag.item() == 1
    print("URMA_REMOTE_SCATTER_COPY_OK")


if __name__ == "__main__":
    main()
