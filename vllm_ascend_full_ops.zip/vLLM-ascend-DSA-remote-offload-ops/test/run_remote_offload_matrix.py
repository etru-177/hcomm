#!/usr/bin/env python3
"""运行固定 656B、标准 LI/LIDU、MTP3 Remote Offload 矩阵。"""

from __future__ import annotations

import argparse
import csv
import shlex
import subprocess
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from analyze_remote_offload_msprof import analyze

ROOT = Path(__file__).resolve().parents[1]
MODES = (
    "no_offload",
    "lidu_aicpu_poll_aiv",
    "lidu_aicpu_defer_aiv_poll",
    "li_cpu_du_implicit_dba",
)
MISSES = (100, 200)
CSV_FIELDS = (
    "mode", "bs", "li_candidate_seqlen", "mtp_draft_tokens",
    "query_count", "sparse_tokens", "dense_tail_tokens",
    "misses_per_request", "index_p50_us", "chain_p50_us", "chain_p90_us",
    "index_to_io_gap_p50_us", "bridge_device_task_p50_us",
    "bridge_non_device_gap_p50_us",
    "io_p50_us", "aiv_scatter_p50_us", "sfa_p50_us",
    "io_ubatch0_p50_us", "io_ubatch1_p50_us",
    "aiv_scatter_ubatch0_p50_us", "aiv_scatter_ubatch1_p50_us",
    "li_io_overlap_p50_us", "li_scatter_overlap_p50_us",
    "io_to_scatter_gap_p50_us", "ubatch_handoff_gap_p50_us",
    "ubatch1_io_to_scatter_gap_p50_us", "scatter_to_sfa_gap_p50_us",
    "index_to_sfa_gap_p50_us", "total_gap_p50_us",
    "cpu_topk_poll_wait_p50_us", "cpu_du_request_p50_us",
    "io_group1_minus_group0_ready_p50_us",
    "request_iops", "unique_iops", "effective_payload_GBps",
    "vs_no_offload_ratio", "cpu_du_threads", "cpu_du_persistent",
    "lidu_impl", "graph_safe", "explicit_npu_host_sync", "status",
)


@dataclass(frozen=True)
class Scenario:
    mode: str
    misses: int


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device-eid", required=True)
    parser.add_argument("--pool-ip", required=True)
    parser.add_argument("--control-port", type=int, default=19090)
    parser.add_argument("--device", default="npu:0")
    parser.add_argument("--device-phy-id", type=int, default=0)
    parser.add_argument("--lanes", type=int, default=1)
    parser.add_argument("--bs", type=int, default=32)
    parser.add_argument("--heads", type=int, default=32)
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--iterations", type=int, default=20)
    parser.add_argument(
        "--cpu-du-threads", type=int, default=0,
        help="隐式 DBA 固定 32 个 CPU DU 常驻线程；0 和 32 等价。",
    )
    parser.add_argument(
        "--cpu-du-first-cpu", type=int, default=-1,
        help=">=0 时把 CPU DU worker 依次绑到该 CPU 起始编号。",
    )
    parser.add_argument("--python", default=sys.executable)
    parser.add_argument(
        "--runner", type=Path,
        default=ROOT / "test" / "remote_offload_656_perf.py",
    )
    parser.add_argument("--csv", type=Path, default=Path("remote_offload_results.csv"))
    parser.add_argument(
        "--with-msprof", action="store_true",
        help="每个 case 通过 msprof 运行，并解析 task_time 输出到合并 CSV。",
    )
    parser.add_argument(
        "--msprof-bin", default="msprof",
        help="msprof 可执行文件路径（默认：msprof）。",
    )
    parser.add_argument(
        "--profile-root", type=Path, default=Path("remote_offload_msprof"),
        help="msprof case 输出根目录；每个 case 使用一个扁平子目录。",
    )
    parser.add_argument(
        "--msprof-extra", default="",
        help="追加给 msprof 的参数，例如 '--aic-metrics=PipeUtilization'。",
    )
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def scenarios() -> list[Scenario]:
    # 每个 miss 档固定先跑 no_offload，便于查看基础功能是否正常。
    return [Scenario(mode, misses) for misses in MISSES for mode in MODES]


def application_command(args: argparse.Namespace, scenario: Scenario) -> list[str]:
    return [
        args.python, str(args.runner),
        "--mode", scenario.mode,
        "--device", args.device,
        "--device-eid", args.device_eid,
        "--device-phy-id", str(args.device_phy_id),
        "--pool-ip", args.pool_ip,
        "--control-port", str(args.control_port),
        "--lanes", str(args.lanes),
        "--bs", str(args.bs),
        "--candidate-seqlen", "131072",
        "--misses-per-request", str(scenario.misses),
        "--heads", str(args.heads),
        "--warmup", str(args.warmup),
        "--iterations", str(args.iterations),
        "--cpu-du-threads", str(args.cpu_du_threads),
        "--cpu-du-first-cpu", str(args.cpu_du_first_cpu),
    ]


def profiler_command(
    args: argparse.Namespace, scenario: Scenario, profile_dir: Path,
) -> list[str]:
    """构造一个可复制的 msprof 命令，task-time 是矩阵唯一性能数据源。"""
    application = shlex.join(application_command(args, scenario))
    return [
        args.msprof_bin,
        f"--application={application}",
        f"--output={profile_dir}",
        "--task-time=on",
        "--export=on",
        *shlex.split(args.msprof_extra),
    ]


def format_case(row: dict[str, object]) -> str:
    if row.get("chain_p50_us", "") != "":
        return (
            "REMOTE_OFFLOAD_PERF "
            f"mode={row['mode']} misses_per_request={row['misses_per_request']} "
            f"chain_p50_us={row['chain_p50_us']} "
            f"chain_p90_us={row['chain_p90_us']} "
            f"index_p50_us={row['index_p50_us']} "
            f"index_to_io_gap_p50_us={row['index_to_io_gap_p50_us']} "
            f"bridge_device_task_p50_us={row['bridge_device_task_p50_us']} "
            f"bridge_non_device_gap_p50_us="
            f"{row['bridge_non_device_gap_p50_us']} "
            f"io_p50_us={row['io_p50_us']} "
            f"aiv_scatter_p50_us={row['aiv_scatter_p50_us']} "
            f"io_ubatch0_p50_us={row['io_ubatch0_p50_us']} "
            f"io_ubatch1_p50_us={row['io_ubatch1_p50_us']} "
            f"li_io_overlap_p50_us={row['li_io_overlap_p50_us']} "
            f"cpu_topk_poll_wait_p50_us="
            f"{row['cpu_topk_poll_wait_p50_us']} "
            f"cpu_du_request_p50_us={row['cpu_du_request_p50_us']} "
            f"io_group1_minus_group0_ready_p50_us="
            f"{row['io_group1_minus_group0_ready_p50_us']} "
            f"sfa_p50_us={row['sfa_p50_us']} "
            f"io_to_scatter_gap_p50_us={row['io_to_scatter_gap_p50_us']} "
            f"ubatch_handoff_gap_p50_us={row['ubatch_handoff_gap_p50_us']} "
            f"ubatch1_io_to_scatter_gap_p50_us="
            f"{row['ubatch1_io_to_scatter_gap_p50_us']} "
            f"scatter_to_sfa_gap_p50_us={row['scatter_to_sfa_gap_p50_us']} "
            f"total_gap_p50_us={row['total_gap_p50_us']} "
            f"request_iops={row['request_iops']} "
            f"unique_iops={row['unique_iops']} "
            f"effective_payload_GBps={row['effective_payload_GBps']} "
            f"vs_no_offload_ratio={row['vs_no_offload_ratio']} "
            f"status={row['status']}"
        )
    return (
        "REMOTE_OFFLOAD_CASE "
        f"mode={row['mode']} misses_per_request={row['misses_per_request']} "
        f"status={row['status']}"
    )


def successful_row(
    args: argparse.Namespace, scenario: Scenario
) -> dict[str, object]:
    cpu_mode = scenario.mode == "li_cpu_du_implicit_dba"
    return {
        "mode": scenario.mode,
        "bs": args.bs,
        "li_candidate_seqlen": 131072,
        "mtp_draft_tokens": 3,
        "query_count": 4,
        "sparse_tokens": 2048,
        "dense_tail_tokens": 256,
        "misses_per_request": scenario.misses,
        "cpu_du_threads": (
            (args.cpu_du_threads or min(args.bs, 32)) if cpu_mode else 0
        ),
        "cpu_du_persistent": int(cpu_mode),
        "lidu_impl": (
            "official_c8_li_implicit_dba_cpu_du"
            if cpu_mode else "ops_a5_2802bdd"
        ),
        "graph_safe": 0,
        "explicit_npu_host_sync": 0,
        "status": "ok_functional",
    }


def profiled_row(
    args: argparse.Namespace,
    scenario: Scenario,
    metrics: dict[str, object],
    baseline_p50_us: float | None,
) -> dict[str, object]:
    chain_p50_us = float(metrics["chain_p50_us"])
    ratio = (
        1.0 if scenario.mode == "no_offload"
        else (chain_p50_us / baseline_p50_us if baseline_p50_us else "")
    )
    cpu_mode = scenario.mode == "li_cpu_du_implicit_dba"
    return {
        "mode": scenario.mode,
        "bs": args.bs,
        "li_candidate_seqlen": 131072,
        "mtp_draft_tokens": 3,
        "query_count": 4,
        "sparse_tokens": 2048,
        "dense_tail_tokens": 256,
        "misses_per_request": scenario.misses,
        "index_p50_us": round(float(metrics["start_p50_us"]), 3),
        "chain_p50_us": round(chain_p50_us, 3),
        "chain_p90_us": round(float(metrics["chain_p90_us"]), 3),
        "index_to_io_gap_p50_us": round(
            float(metrics["index_to_io_gap_p50_us"]), 3,
        ),
        "bridge_device_task_p50_us": round(
            float(metrics["bridge_device_task_p50_us"]), 3,
        ),
        "bridge_non_device_gap_p50_us": round(
            float(metrics["bridge_non_device_gap_p50_us"]), 3,
        ),
        "io_p50_us": round(float(metrics["io_p50_us"]), 3),
        "aiv_scatter_p50_us": round(float(metrics["aiv_scatter_p50_us"]), 3),
        **{
            key: round(float(metrics.get(key, 0.0)), 3)
            for key in (
                "io_ubatch0_p50_us",
                "io_ubatch1_p50_us",
                "aiv_scatter_ubatch0_p50_us",
                "aiv_scatter_ubatch1_p50_us",
                "li_io_overlap_p50_us",
                "li_scatter_overlap_p50_us",
            )
        },
        "sfa_p50_us": round(float(metrics["sfa_p50_us"]), 3),
        "io_to_scatter_gap_p50_us": round(
            float(metrics["io_to_scatter_gap_p50_us"]), 3,
        ),
        "ubatch_handoff_gap_p50_us": round(
            float(metrics["ubatch_handoff_gap_p50_us"]), 3,
        ),
        "ubatch1_io_to_scatter_gap_p50_us": round(
            float(metrics["ubatch1_io_to_scatter_gap_p50_us"]), 3,
        ),
        "scatter_to_sfa_gap_p50_us": round(
            float(metrics["scatter_to_sfa_gap_p50_us"]), 3,
        ),
        "index_to_sfa_gap_p50_us": round(
            float(metrics["index_to_sfa_gap_p50_us"]), 3,
        ),
        "total_gap_p50_us": round(
            float(metrics["total_gap_p50_us"]), 3,
        ),
        **{
            key: round(float(metrics.get(key, 0.0)), 3)
            for key in (
                "cpu_topk_poll_wait_p50_us",
                "cpu_du_request_p50_us",
                "io_group1_minus_group0_ready_p50_us",
            )
        },
        "request_iops": metrics["request_iops"],
        "unique_iops": metrics["unique_iops"],
        "effective_payload_GBps": round(
            float(metrics["effective_payload_GBps"]), 6,
        ),
        "vs_no_offload_ratio": round(ratio, 4) if ratio != "" else "",
        "cpu_du_threads": (
            (args.cpu_du_threads or min(args.bs, 32)) if cpu_mode else 0
        ),
        "cpu_du_persistent": int(cpu_mode),
        "lidu_impl": (
            "official_c8_li_implicit_dba_cpu_du"
            if cpu_mode else "ops_a5_2802bdd"
        ),
        "graph_safe": 0,
        "explicit_npu_host_sync": 0,
        "status": "ok_profiled",
    }


def failed_row(
    args: argparse.Namespace, scenario: Scenario, status: str
) -> dict[str, object]:
    row: dict[str, object] = {field: "" for field in CSV_FIELDS}
    row.update({
        "mode": scenario.mode,
        "bs": args.bs,
        "li_candidate_seqlen": 131072,
        "mtp_draft_tokens": 3,
        "query_count": 4,
        "sparse_tokens": 2048,
        "dense_tail_tokens": 256,
        "misses_per_request": scenario.misses,
        "cpu_du_threads": (
            (args.cpu_du_threads or min(args.bs, 32))
            if scenario.mode == "li_cpu_du_implicit_dba"
            else 0
        ),
        "cpu_du_persistent": int(
            scenario.mode == "li_cpu_du_implicit_dba"
        ),
        "lidu_impl": (
            "official_c8_li_implicit_dba_cpu_du"
            if scenario.mode == "li_cpu_du_implicit_dba"
            else "ops_a5_2802bdd"
        ),
        "graph_safe": 0,
        "explicit_npu_host_sync": 0,
        "status": status,
    })
    return row


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=CSV_FIELDS)
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    args = parse_args()
    if args.lanes != 1:
        raise ValueError("当前硬件矩阵要求 lanes=1，且 Pool 使用 jetty-count=1")
    if args.bs != 32:
        raise ValueError("隐式 DBA 矩阵固定 bs=32")
    if (
        args.cpu_du_threads not in (0, 32)
        or args.cpu_du_first_cpu < -1
    ):
        raise ValueError("CPU DU 线程/绑核参数非法")
    # msprof 进程以仓库根目录为 cwd；转换为绝对路径以支持从任意目录调用本脚本。
    if args.with_msprof:
        args.profile_root = args.profile_root.resolve()
    rows: list[dict[str, object]] = []
    cases: list[str] = []
    baseline_p50_by_miss: dict[int, float] = {}
    profile_run = datetime.now().strftime("%Y%m%d_%H%M%S")

    print(
        "POOL_PRECONDITION pipeline_mib=2 lanes=1 jetty_count=1 "
        "max_aggregation=1 io_bytes=656 disk_model=0",
        flush=True,
    )
    for scenario in scenarios():
        profile_dir = (
            args.profile_root / f"{profile_run}_{scenario.mode}_miss{scenario.misses}"
        )
        command = (
            profiler_command(args, scenario, profile_dir)
            if args.with_msprof else application_command(args, scenario)
        )
        print(f"REPRODUCE_COMMAND: {shlex.join(command)}", flush=True)
        if args.dry_run:
            continue
        try:
            if args.with_msprof:
                profile_dir.mkdir(parents=True, exist_ok=False)
                try:
                    completed = subprocess.run(
                        command,
                        cwd=ROOT,
                        check=False,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        text=True,
                        errors="replace",
                    )
                    log = completed.stdout or ""
                except OSError as error:
                    # 即使 msprof 不在 PATH 中，也留下可直接排障的单 case 日志。
                    log = f"failed to start msprof: {error}\n"
                    (profile_dir / "msprof.log").write_text(log, encoding="utf-8")
                    raise
                (profile_dir / "msprof.log").write_text(log, encoding="utf-8")
            else:
                completed = subprocess.run(command, cwd=ROOT, check=False)
            if completed.returncode != 0:
                raise RuntimeError(f"workload_exit_{completed.returncode}")
            if args.with_msprof:
                metrics = analyze(
                    profile_dir, scenario.mode, args.warmup, args.iterations,
                    args.bs, scenario.misses,
                )
                row = profiled_row(
                    args, scenario, metrics,
                    baseline_p50_by_miss.get(scenario.misses),
                )
                if scenario.mode == "no_offload":
                    baseline_p50_by_miss[scenario.misses] = float(
                        metrics["chain_p50_us"],
                    )
            else:
                row = successful_row(args, scenario)
        except Exception as error:  # 保留其余场景和最终 CSV。
            status = "failed_" + "_".join(str(error).split())[:96]
            row = failed_row(args, scenario, status)
        rows.append(row)
        line = format_case(row)
        cases.append(line)
        print(line, flush=True)
        if args.with_msprof and not str(row["status"]).startswith("ok_"):
            print(f"MSPROF_LOG path={profile_dir / 'msprof.log'}", flush=True)

    if args.dry_run:
        print(
            f"DRY_RUN scenarios={len(scenarios())} "
            f"with_msprof={int(args.with_msprof)}",
            flush=True,
        )
        return 0
    write_csv(args.csv, rows)
    print(
        "\nPERFORMANCE_ONLY_SUMMARY" if args.with_msprof else "\nCASE_ONLY_SUMMARY",
        flush=True,
    )
    for line in cases:
        print(line, flush=True)
    print(f"CSV_RESULT path={args.csv} rows={len(rows)}", flush=True)
    return 1 if any(not str(row["status"]).startswith("ok_") for row in rows) else 0


if __name__ == "__main__":
    raise SystemExit(main())
