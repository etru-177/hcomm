// SPDX-License-Identifier: Apache-2.0

#include "../host_offload/offload_ring.h"
#include "../hcomm_kernel/remote_offload_protocol.h"

#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>

int main()
{
    using namespace remote_offload;
    std::vector<OffloadRingSlot> slots(4);
    OffloadRingView ring(slots.data(), static_cast<uint32_t>(slots.size()));
    ring.Initialize();

    OffloadSlotMetadata metadata;
    metadata.requestId = 17;
    metadata.layerId = 3;
    metadata.queryCount = 4;
    metadata.candidateLength = 262144;
    metadata.liPayloadOffset = 4096;
    metadata.duPayloadOffset = 4096 + 4 * 2048 * sizeof(int32_t);

    uint32_t index = 99;
    assert(ring.TryAcquire(1, metadata, &index));
    assert(index == 0);
    assert(!ring.TryAcquire(5, metadata, nullptr));
    assert(ring.TryTransition(1, OffloadSlotState::kNpuLiWriting,
        OffloadSlotState::kLiReady));
    assert(ring.TryTransition(1, OffloadSlotState::kLiReady,
        OffloadSlotState::kCpuDuRunning));
    assert(ring.TryTransition(1, OffloadSlotState::kCpuDuRunning,
        OffloadSlotState::kDuReady));
    assert(ring.TryTransition(1, OffloadSlotState::kDuReady,
        OffloadSlotState::kCommandSubmitted));
    assert(ring.TryTransition(1, OffloadSlotState::kCommandSubmitted,
        OffloadSlotState::kDataReady));
    assert(!ring.TryTransition(5, OffloadSlotState::kDataReady,
        OffloadSlotState::kFree));
    assert(ring.Release(1));

    assert(ring.TryAcquire(5, metadata, &index));
    assert(index == 0);
    assert(!ring.TryTransition(1, OffloadSlotState::kNpuLiWriting,
        OffloadSlotState::kLiReady));
    assert(ring.TryTransition(5, OffloadSlotState::kNpuLiWriting,
        OffloadSlotState::kError, OffloadStatus::kDuFailed));
    assert(ring.Find(5)->status ==
        static_cast<uint32_t>(OffloadStatus::kDuFailed));
    assert(ring.Release(5));

    RemoteOffloadCommandHeader command{};
    command.magic = kRemoteOffloadMagic;
    command.version = kRemoteOffloadVersion;
    command.opcode = static_cast<uint16_t>(RemoteOffloadOpcode::kPutTail);
    command.requestId = 17;
    command.generation = 5;
    command.epoch = 2;
    command.entryCount = 1;
    assert(command.magic == 0x52464f31);
    assert(command.opcode == 3);

    std::cout << "OFFLOAD_RING_HOST_TEST passed=3 failed=0\n";
    return 0;
}
