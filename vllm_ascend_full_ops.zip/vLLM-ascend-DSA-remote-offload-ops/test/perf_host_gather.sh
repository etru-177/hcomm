#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-stat}"
shift || true
if [[ "${1:-}" == "--" ]]; then
  shift
fi
if [[ "$#" == "0" ]]; then
  echo "usage: $0 stat|record -- <gather_microbench command...>" >&2
  exit 2
fi

if [[ "${MODE}" == "stat" ]]; then
  exec perf stat -r 5 \
    -e task-clock,cycles,instructions,stalled-cycles-frontend,stalled-cycles-backend,L1-dcache-loads,L1-dcache-load-misses,LLC-loads,LLC-load-misses,cache-references,cache-misses,branches,branch-misses,context-switches,cpu-migrations \
    "$@"
fi

if [[ "${MODE}" == "record" ]]; then
  perf record -g --call-graph dwarf -o perf-gather.data -- "$@"
  perf report -i perf-gather.data
  exit 0
fi

echo "mode must be stat or record" >&2
exit 2
