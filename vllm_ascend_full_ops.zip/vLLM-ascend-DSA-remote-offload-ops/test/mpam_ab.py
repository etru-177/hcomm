#!/usr/bin/env python3
"""Minimal MPAM/resctrl A/B runner for the Host gather pool."""

import argparse
import os
import pathlib
import subprocess
import sys


RESCTRL = pathlib.Path("/sys/fs/resctrl")
ACPI_MPAM = pathlib.Path("/sys/firmware/acpi/tables/MPAM")


def check():
    print(f"acpi_mpam={ACPI_MPAM.exists()}")
    print(f"resctrl_mounted={RESCTRL.is_mount()}")
    if RESCTRL.is_mount():
        for path in sorted((RESCTRL / "info").glob("*")):
            print(f"resource={path.name}")
        print("root_schemata:")
        print((RESCTRL / "schemata").read_text(), end="")


def limited_schemata(root):
    lines = []
    for line in root.splitlines():
        name, values = line.split(":", 1)
        fields = []
        for field in values.split(";"):
            resource, value = field.split("=", 1)
            if name == "MB":
                value = "25"
            elif name.startswith("L3"):
                mask = int(value, 16)
                low_bits = max(1, mask.bit_length() // 4)
                value = f"{mask & ((1 << low_bits) - 1):x}"
            fields.append(f"{resource}={value}")
        lines.append(f"{name}:{';'.join(fields)}")
    return "\n".join(lines) + "\n"


def assign_process(group, pid):
    for task in pathlib.Path(f"/proc/{pid}/task").iterdir():
        (group / "tasks").write_text(task.name)


def run(args):
    if os.geteuid() != 0 or not RESCTRL.is_mount():
        raise RuntimeError("run requires root and a mounted resctrl filesystem")
    pool_group = RESCTRL / "kvcache_pool"
    noise_group = RESCTRL / "kvcache_noise"
    pool_group.mkdir()
    noise_group.mkdir()
    try:
        root = (RESCTRL / "schemata").read_text()
        (pool_group / "schemata").write_text(root)
        (noise_group / "schemata").write_text(limited_schemata(root))
        assign_process(pool_group, args.pool_pid)
        noise = subprocess.Popen(
            ["stress-ng", "--stream", "0", "--timeout", f"{args.seconds}s"]
        )
        assign_process(noise_group, noise.pid)
        result = subprocess.run(args.command, check=False)
        noise.wait()
        return result.returncode
    finally:
        for group in (noise_group, pool_group):
            if group.exists():
                for task in list((group / "tasks").read_text().split()):
                    if pathlib.Path(f"/proc/{task}").exists():
                        (RESCTRL / "tasks").write_text(task)
                group.rmdir()


def main():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="action", required=True)
    subparsers.add_parser("check")
    runner = subparsers.add_parser("run")
    runner.add_argument("--pool-pid", type=int, required=True)
    runner.add_argument("--seconds", type=int, default=60)
    runner.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if args.action == "check":
        check()
        return
    if args.command and args.command[0] == "--":
        args.command.pop(0)
    if not args.command:
        parser.error("run requires a benchmark command after --")
    sys.exit(run(args))


if __name__ == "__main__":
    main()
