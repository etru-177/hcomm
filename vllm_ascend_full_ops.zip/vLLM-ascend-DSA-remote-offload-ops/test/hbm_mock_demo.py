#!/usr/bin/env python3

"""KV-only end-to-end smoke test using HBM as the temporary GVA backing store."""

import argparse

import torch
import torch_npu

from _common import BLOCK_SIZE, COPY_CAP, K_ROPE_DIM, KV_CACHE_DIM, call_new, load_new_ops


def parse_dtype(name):
    if name == "bf16":
        return torch.bfloat16
    if name == "fp16":
        return torch.float16
    raise ValueError(f"unsupported dtype: {name}")


def offset_pattern(byte_count):
    """A deterministic remote-pool byte pattern indexed by byte offset.

    This deliberately tests bytes, not floating-point values: the remote pool
    is opaque memory and the AICPU copy must preserve its CKV/KPE layout.
    """
    return torch.arange(byte_count, dtype=torch.int64).remainder(251).to(torch.uint8)


def byte_filled_tensor(shape, dtype, value):
    byte_count = torch.empty(shape, dtype=dtype).numel() * torch.empty((), dtype=dtype).element_size()
    return torch.full((byte_count,), value, dtype=torch.uint8).view(dtype).reshape(shape)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", default="npu:0")
    parser.add_argument("--dtype", choices=("bf16", "fp16"), default="bf16")
    # Optional control-plane-only raw Hcomm setup.  The copy below still uses
    # local HBM addresses until HybmBatchCopy switches to Hcomm READ.
    parser.add_argument("--device-eid")
    parser.add_argument("--device-phy-id", type=int)
    parser.add_argument("--pool-ip")
    parser.add_argument("--control-port", type=int)
    args = parser.parse_args()

    raw_options = (args.device_eid, args.device_phy_id, args.pool_ip, args.control_port)
    if any(value is not None for value in raw_options) and any(value is None for value in raw_options):
        parser.error("raw Hcomm setup requires --device-eid --device-phy-id --pool-ip --control-port")

    ops = load_new_ops()
    device = torch.device(args.device)
    torch.npu.set_device(device)
    if all(value is not None for value in raw_options):
        channel = ops.npu_hcomm_kvcache_pool_connect_raw(
            args.device_eid, args.device_phy_id, args.pool_ip, args.control_port
        )
        print(f"RAW_HCOMM_CONNECTED channel=0x{channel:x} pool={args.pool_ip}:{args.control_port}")
    dtype = parse_dtype(args.dtype)
    block_count = 2

    element_bytes = torch.empty((), dtype=dtype).element_size()
    kv_block_bytes = BLOCK_SIZE * KV_CACHE_DIM * element_bytes
    rope_block_bytes = BLOCK_SIZE * K_ROPE_DIM * element_bytes
    remote_block_bytes = kv_block_bytes + rope_block_bytes
    # Normal NPU tensors intentionally back the temporary "remote" GVA range.
    # Each byte is a function of its offset in [CKV block][KPE block] storage.
    remote_blocks_cpu = offset_pattern(block_count * remote_block_bytes)
    remote_blocks = remote_blocks_cpu.to(device)
    # Compatibility-only inputs; remote source addressing comes from the GVA table.
    dram_kv = torch.zeros((block_count, BLOCK_SIZE, KV_CACHE_DIM), dtype=dtype, device=device)
    dram_k_rope = torch.zeros((block_count, BLOCK_SIZE, K_ROPE_DIM), dtype=dtype, device=device)
    hbm_kv = byte_filled_tensor((block_count, BLOCK_SIZE, KV_CACHE_DIM), dtype, 0xFF).to(device)
    hbm_k_rope = byte_filled_tensor((block_count, BLOCK_SIZE, K_ROPE_DIM), dtype, 0xFF).to(device)
    expected_kv = hbm_kv.cpu().view(torch.uint8).reshape(-1)
    expected_k_rope = hbm_k_rope.cpu().view(torch.uint8).reshape(-1)

    hbm_block_table = torch.tensor([[1, 0]], dtype=torch.int32, device=device)
    dram_block_table = torch.tensor(
        [[remote_blocks.data_ptr() + remote_block_bytes, remote_blocks.data_ptr()]],
        dtype=torch.uint64,
        device=device,
    )
    src_token_ids = torch.full((1, 1, COPY_CAP), -1, dtype=torch.int32, device=device)
    dst_slots = torch.full((1, 1, COPY_CAP), -1, dtype=torch.int32, device=device)
    src_token_ids[0, 0, :2] = torch.tensor([1, 129], dtype=torch.int32, device=device)
    dst_slots[0, 0, :2] = torch.tensor([2, 130], dtype=torch.int32, device=device)
    copy_counts = torch.tensor([2], dtype=torch.int32, device=device)
    ready_flag = torch.full((1,), -1, dtype=torch.int32, device=device)

    # logical source 1 -> remote block 1 / token 1 -> HBM block 1 / token 2
    # logical source 129 -> remote block 0 / token 1 -> HBM block 0 / token 2
    # Copy expected raw bytes by their remote-pool offsets, then validate after
    # D2H.  This catches an incorrect CKV/KPE block stride as well as a wrong
    # token or block-table offset.
    dram_physical_blocks = (1, 0)
    hbm_physical_blocks = (1, 0)
    for src_token, dst_slot in zip((1, 129), (2, 130)):
        src_block = dram_physical_blocks[src_token // BLOCK_SIZE]
        dst_block = hbm_physical_blocks[dst_slot // BLOCK_SIZE]
        src_offset = src_token % BLOCK_SIZE
        dst_offset = dst_slot % BLOCK_SIZE
        remote_base = src_block * remote_block_bytes
        kv_src = remote_base + src_offset * (kv_block_bytes // BLOCK_SIZE)
        rope_src = remote_base + kv_block_bytes + src_offset * (rope_block_bytes // BLOCK_SIZE)
        kv_dst = (dst_block * BLOCK_SIZE + dst_offset) * (kv_block_bytes // BLOCK_SIZE)
        rope_dst = (dst_block * BLOCK_SIZE + dst_offset) * (rope_block_bytes // BLOCK_SIZE)
        expected_kv[kv_dst : kv_dst + kv_block_bytes // BLOCK_SIZE] = remote_blocks_cpu[
            kv_src : kv_src + kv_block_bytes // BLOCK_SIZE
        ]
        expected_k_rope[rope_dst : rope_dst + rope_block_bytes // BLOCK_SIZE] = remote_blocks_cpu[
            rope_src : rope_src + rope_block_bytes // BLOCK_SIZE
        ]

    call_new(
        {
            "hbm_k_rope": hbm_k_rope,
            "hbm_kv_cache": hbm_kv,
            "dram_k_rope": dram_k_rope,
            "dram_kv_cache": dram_kv,
            "hbm_block_table": hbm_block_table,
            "dram_block_table": dram_block_table,
            "src_token_ids": src_token_ids,
            "dst_slots": dst_slots,
            "copy_counts": copy_counts,
        },
        ready_flag,
        layer_id=7,
    )
    torch.npu.synchronize()

    if not torch.equal(hbm_kv.cpu().view(torch.uint8).reshape(-1), expected_kv):
        raise AssertionError("KV HBM mock bytes differ from the remote offset pattern")
    if not torch.equal(hbm_k_rope.cpu().view(torch.uint8).reshape(-1), expected_k_rope):
        raise AssertionError("K-RoPE HBM mock bytes differ from the remote offset pattern")
    if ready_flag.item() != 1:
        raise AssertionError(f"ready_flag={ready_flag.item()}, expected 1")
    print(f"KVCACHE_SCATTER_COPY_HBM_OFFSET_PATTERN_OK device={device} dtype={args.dtype}")


if __name__ == "__main__":
    main()
