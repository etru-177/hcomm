// SPDX-License-Identifier: Apache-2.0

#include "../host_offload/cpu_du_worker.h"

#include <cassert>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <thread>
#include <vector>

int main()
{
    using namespace remote_offload;
    std::vector<OffloadRingSlot> slots(2);
    const size_t perSlot = sizeof(OffloadLiPayload) + sizeof(OffloadDuPayload);
    std::vector<uint8_t> arena(perSlot * slots.size());
    OffloadRingView ring(slots.data(), static_cast<uint32_t>(slots.size()));
    ring.Initialize();
    CpuDuWorker worker(slots.data(), static_cast<uint32_t>(slots.size()),
        arena.data(), arena.size());

    CpuDuSnapshot snapshot;
    snapshot.cacheBudget = 4096;
    snapshot.tokenToSlot.assign(10000, -1);
    for (int32_t token = 0; token < snapshot.cacheBudget; ++token) {
        snapshot.tokenToSlot[static_cast<size_t>(token)] = token;
    }
    worker.RegisterState(11, 7, 3, snapshot);

    OffloadSlotMetadata metadata;
    metadata.requestId = 11;
    metadata.epoch = 7;
    metadata.layerId = 3;
    metadata.queryCount = 4;
    metadata.candidateLength = 10000;
    metadata.liPayloadOffset = 0;
    metadata.duPayloadOffset = sizeof(OffloadLiPayload);
    uint32_t index = 0;
    assert(ring.TryAcquire(1, metadata, &index));
    auto* input = reinterpret_cast<OffloadLiPayload*>(arena.data());
    for (int32_t row = 0; row < 4; ++row) {
        const int32_t misses = row * 100;
        for (int32_t item = 0; item < kSparseCount - misses; ++item) {
            input->topk[row][item] = item;
        }
        for (int32_t item = 0; item < misses; ++item) {
            input->topk[row][kSparseCount - misses + item] = 4096 + item;
        }
    }
    assert(ring.TryTransition(1, OffloadSlotState::kNpuLiWriting,
        OffloadSlotState::kLiReady));
    worker.Start();
    const auto deadline = std::chrono::steady_clock::now() +
        std::chrono::seconds(2);
    while (__atomic_load_n(&slots[0].state, __ATOMIC_ACQUIRE) !=
        static_cast<uint32_t>(OffloadSlotState::kDuReady)) {
        assert(std::chrono::steady_clock::now() < deadline);
        std::this_thread::yield();
    }
    worker.Stop();

    auto* output = reinterpret_cast<OffloadDuPayload*>(
        arena.data() + sizeof(OffloadLiPayload));
    assert(slots[0].uniqueMissCount == 300);
    assert(output->missCounts[0] == 0);
    assert(output->missCounts[3] == 300);
    assert(output->uniqueMissSourceIds[0] == 4096);
    assert(output->uniqueMissSourceIds[299] == 4395);
    assert(output->unionHitCount == kSparseCount);
    assert(output->unionHitSourceIds[0] == 0);
    assert(output->unionHitRefCounts[0] == 4);
    assert(output->unionHitRefCounts[2000] == 1);
    assert(output->unionHitQueryMasks[0] == 0xf);
    assert(output->unionHitQueryMasks[2000] == 0x1);
    assert(output->uniqueMissQueryMasks[0] == 0xe);
    assert(output->uniqueMissQueryMasks[299] == 0x8);
    assert(output->unionOrdinals[1][kSparseCount - 1] ==
        kSparseCount + 99);
    assert(worker.SnapshotState(11, 7, 3).generation == 1);
    assert(worker.RemoveState(11, 7, 3));
    assert(!worker.RemoveState(11, 7, 3));

    std::cout << "CPU_DU_WORKER_HOST_TEST passed=1 failed=0\n";
    return 0;
}
