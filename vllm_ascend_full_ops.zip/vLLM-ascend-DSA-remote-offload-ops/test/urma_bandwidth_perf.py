#!/usr/bin/env python3
"""Raw Host<->NPU URMA bandwidth baselines without KV scatter work."""

import math
import statistics

import numpy as np
import torch
import torch_npu

from _common import BLOCK_SIZE, BYTES_PER_TOKEN, K_ROPE_DIM, KV_CACHE_DIM, load_new_ops


# ---- machine-specific configuration ----
DEVICE = "npu:0"
DEVICE_EID = "00000000000000000000000000000000"
DEVICE_PHY_ID = 0
POOL_IP = "127.0.0.1"
CONTROL_PORT = 19090
RAW_LANES = 1
# ----------------------------------------

TRANSFER_MIB = (4, 16, 32, 64)
AGGREGATE_CHUNK_BYTES = 256 * 1024
WARMUP = 5
ITERS = 30
REMOTE_BANKS = 8
SEGMENTS = (1, 4, 16, 32, 64, 128, 256)
WQE_COUNTS = (1, 4, 16, 64, 128, 256)
SEED = 2026
DTYPE = torch.bfloat16
BLOCK_BYTES = BLOCK_SIZE * BYTES_PER_TOKEN
WQE_BYTES = (128, 1024, BLOCK_BYTES)
MAX_TRANSFER_BYTES = max(TRANSFER_MIB) * 1024 * 1024
STAGING_BLOCKS = math.ceil(MAX_TRANSFER_BYTES / BLOCK_BYTES)
MODES = (
    ("pull_contiguous", 0),
    ("push_contiguous", 1),
    ("push_aggregate", 2),
)


def make_remote_gvas(device, pool_gva, pool_bytes, transfer_bytes, mode, seed):
    if mode != 2:
        banks = min(REMOTE_BANKS, pool_bytes // transfer_bytes)
        if banks == 0:
            raise RuntimeError(f"pool_bytes={pool_bytes} is smaller than transfer_bytes={transfer_bytes}")
        return [
            torch.tensor(
                [pool_gva + bank * transfer_bytes], dtype=torch.uint64
            ).to(device)
            for bank in range(banks)
        ]

    chunks = transfer_bytes // AGGREGATE_CHUNK_BYTES
    if chunks == 0 or chunks > 256 or chunks * AGGREGATE_CHUNK_BYTES != transfer_bytes:
        raise RuntimeError("aggregate transfer must contain 1..256 exact 256-KiB chunks")
    pool_chunks = pool_bytes // AGGREGATE_CHUNK_BYTES
    if pool_chunks < chunks:
        raise RuntimeError(f"pool has {pool_chunks} aggregate chunks; transfer needs {chunks}")
    banks = min(REMOTE_BANKS, pool_chunks // chunks)
    generator = torch.Generator().manual_seed(seed)
    permutation = torch.randperm(pool_chunks, generator=generator, dtype=torch.int64)
    return [
        (
            pool_gva
            + permutation[bank * chunks : (bank + 1) * chunks]
            * AGGREGATE_CHUNK_BYTES
        ).to(torch.uint64).to(device)
        for bank in range(banks)
    ]


PROFILE_FIELDS = (
    "generation",
    "kind",
    "mode",
    "logical_bytes",
    "transfer_bytes",
    "entries",
    "lanes",
    "ready",
    "prepare",
    "submit",
    "sync",
    "completion",
    "scatter",
    "total",
    "pull_entries",
    "push_entries",
)


def benchmark(ops, profile_ring, remote_gvas, transfer_bytes, mode, segments):
    for iteration in range(WARMUP):
        ops.npu_hcomm_kvcache_bandwidth_probe(
            remote_gvas[iteration % len(remote_gvas)], transfer_bytes, mode, segments
        )
    torch_npu.npu.synchronize()

    times_us = []
    for iteration in range(ITERS):
        start = torch.npu.Event(enable_timing=True)
        end = torch.npu.Event(enable_timing=True)
        start.record()
        ops.npu_hcomm_kvcache_bandwidth_probe(
            remote_gvas[iteration % len(remote_gvas)], transfer_bytes, mode, segments
        )
        end.record()
        end.synchronize()
        times_us.append(float(start.elapsed_time(end)) * 1000.0)

    times_us.sort()
    avg_us = statistics.mean(times_us)
    p50_us = statistics.median(times_us)
    p99_us = times_us[math.ceil(0.99 * len(times_us)) - 1]
    gbps = transfer_bytes / avg_us / 1000.0
    records = (
        profile_ring.cpu()
        .numpy()
        .view(np.uint64)
        .reshape(-1, len(PROFILE_FIELDS))
    )
    records = records[(records[:, 0] != 0) & (records[:, 1] == 2)]
    records = records[np.argsort(records[:, 0])][-ITERS:]
    stage_stats = {}
    for index, name in enumerate(PROFILE_FIELDS[7:14], start=7):
        values_us = np.sort(records[:, index].astype(np.float64) / 1000.0)
        stage_stats[name] = (
            float(np.mean(values_us)),
            float(np.median(values_us)),
            float(values_us[math.ceil(0.99 * len(values_us)) - 1]),
        )
    return avg_us, p50_us, p99_us, gbps, stage_stats


def main():
    ops = load_new_ops()
    device = torch.device(DEVICE)
    torch_npu.npu.set_device(device)
    hbm_ckv = torch.empty(
        (STAGING_BLOCKS, BLOCK_SIZE, KV_CACHE_DIM), dtype=DTYPE, device=device
    )
    hbm_kpe = torch.empty(
        (STAGING_BLOCKS, BLOCK_SIZE, K_ROPE_DIM), dtype=DTYPE, device=device
    )
    channel = ops.npu_hcomm_kvcache_pool_connect_raw(
        DEVICE_EID,
        DEVICE_PHY_ID,
        POOL_IP,
        CONTROL_PORT,
        hbm_kpe,
        hbm_ckv,
        RAW_LANES,
        0,
    )
    _, _, pool_gva, pool_bytes = ops.npu_hcomm_kvcache_pool_get_raw_context(channel)
    profile_ring = ops.npu_hcomm_kvcache_pool_get_profile(channel)
    print(
        f"RAW_URMA_BANDWIDTH_CONNECTED channel=0x{channel:x} pool_gva=0x{pool_gva:x} "
        f"pool_bytes={pool_bytes} staging_bytes={STAGING_BLOCKS * BLOCK_BYTES} "
        f"raw_lanes={RAW_LANES}",
        flush=True,
    )

    case = 0
    for name, mode in MODES:
        for mib in TRANSFER_MIB:
            transfer_bytes = mib * 1024 * 1024
            segment_cases = (1,) if mode == 2 else SEGMENTS
            for segments in segment_cases:
                remote_gvas = make_remote_gvas(
                    device, pool_gva, pool_bytes, transfer_bytes, mode, SEED + case
                )
                avg_us, p50_us, p99_us, gbps, stages = benchmark(
                    ops, profile_ring, remote_gvas, transfer_bytes, mode, segments
                )
                stage_text = " ".join(
                    f"{stage}_avg_us={values[0]:.3f} "
                    f"{stage}_p50_us={values[1]:.3f} "
                    f"{stage}_p99_us={values[2]:.3f}"
                    for stage, values in stages.items()
                )
                print(
                    f"mode={name} size_MiB={mib} segments={segments} "
                    f"segment_KiB={transfer_bytes // segments / 1024:.3f} "
                    f"avg_us={avg_us:.3f} p50_us={p50_us:.3f} "
                    f"p99_us={p99_us:.3f} GBps={gbps:.3f} {stage_text}",
                    flush=True,
                )
                case += 1

    for wqe_bytes in WQE_BYTES:
        for segments in WQE_COUNTS:
            transfer_bytes = wqe_bytes * segments
            for name, mode in MODES[:2]:
                remote_gvas = make_remote_gvas(
                    device, pool_gva, pool_bytes, transfer_bytes, mode, SEED + case
                )
                avg_us, p50_us, p99_us, gbps, stages = benchmark(
                    ops, profile_ring, remote_gvas, transfer_bytes, mode, segments
                )
                print(
                    f"mode={name} probe=wqe_rate wqe_bytes={wqe_bytes} "
                    f"segments={segments} avg_us={avg_us:.3f} "
                    f"p50_us={p50_us:.3f} p99_us={p99_us:.3f} "
                    f"GBps={gbps:.3f} WQE_per_s={segments * 1.0e6 / avg_us:.3f} "
                    f"prepare_avg_us={stages['prepare'][0]:.3f} "
                    f"submit_avg_us={stages['submit'][0]:.3f} "
                    f"sync_avg_us={stages['sync'][0]:.3f} "
                    f"completion_avg_us={stages['completion'][0]:.3f}",
                    flush=True,
                )
                case += 1

    print("RAW_URMA_BANDWIDTH_PERF_OK", flush=True)


if __name__ == "__main__":
    main()
