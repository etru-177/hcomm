#!/usr/bin/env python3
"""ScatterIoFromStagingC8 的最小单算子功能测试。"""

from __future__ import annotations

import sys
from pathlib import Path

import torch
import torch_npu


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "torch_extension"))
import kvcache_scatter_copy_custom_ops  # noqa: E402,F401


def main() -> None:
    device = torch.device("npu:0")
    torch_npu.npu.set_device(device)
    blocks, count = 2, 4
    packed = torch.zeros((blocks, 128, 656), dtype=torch.uint8, device=device)
    staging_cpu = torch.stack(
        [torch.full((656,), index + 1, dtype=torch.uint8) for index in range(count)]
    )
    staging = staging_cpu.to(device)
    completion = torch.tensor(
        [7, 7, 0, 0, 0, 0, 0, 0], dtype=torch.uint64
    ).view(torch.uint8).to(device)
    table = torch.tensor([[1, 0]], dtype=torch.int32, device=device)
    destinations = torch.full((1, 1, 16384), -1, dtype=torch.int32, device=device)
    destinations[0, 0, :count] = torch.tensor(
        [0, 1, 128, 129], dtype=torch.int32, device=device
    )
    counts = torch.tensor([count], dtype=torch.int32, device=device)
    torch.ops.custom.npu_scatter_io_from_staging_c8.default(
        packed, staging, completion, table, destinations, counts
    )
    torch_npu.npu.synchronize()
    actual = packed.cpu()
    expected_rows = ((1, 0), (1, 1), (0, 0), (0, 1))
    for source, (block, offset) in enumerate(expected_rows):
        if not torch.equal(actual[block, offset], staging_cpu[source]):
            raise AssertionError(
                f"entry={source} 的 packed C8 scatter 结果不匹配"
            )
    print(
        "SCATTER_IO_FROM_STAGING_C8_TEST io_bytes=656 aiv=1 "
        "completion_poll=1 copied=4 passed=1",
        flush=True,
    )


if __name__ == "__main__":
    main()
