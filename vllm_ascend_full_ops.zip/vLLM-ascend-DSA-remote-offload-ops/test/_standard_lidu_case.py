"""标准 BF16 LightningIndexer/LIDU 共用输入。

算子来源与固定版本见 ``VENDORED.md``。本文件只在计时循环外构造可精确控制
union miss 数的状态，避免把测试数据准备计入 msprof 链路。
"""

from __future__ import annotations

from dataclasses import dataclass

import torch
import torch_npu


TOPK = 2048
BLOCK_SIZE = 128
HEAD_DIM = 128
INVALID_SLOT = -(1 << 31)


@dataclass
class StandardMtpCase:
    query: torch.Tensor
    key: torch.Tensor
    weights: torch.Tensor
    query_scale: torch.Tensor
    key_scale: torch.Tensor
    block_table: torch.Tensor
    actual_q: torch.Tensor
    actual_key: torch.Tensor
    offload_key: torch.Tensor
    cache_tokens: torch.Tensor
    request_state: torch.Tensor
    req_entries: torch.Tensor
    req_entries_cpu: torch.Tensor
    initial_pool: torch.Tensor
    native_topk: torch.Tensor
    target_misses: list[int]
    query_counts: list[int]
    source_capacity: int


def official_standard_lightning_indexer(
    query: torch.Tensor,
    key: torch.Tensor,
    weights: torch.Tensor,
    actual_q: torch.Tensor,
    candidate_lens: torch.Tensor,
    block_table: torch.Tensor,
) -> torch.Tensor:
    """调用与标准融合算子同精度、同 packed-Q 语义的官方 LI。"""

    op = getattr(torch_npu, "npu_lightning_indexer", None)
    if op is None:
        raise RuntimeError("torch_npu.npu_lightning_indexer 未注册")
    result = op(
        query=query,
        key=key,
        weights=weights,
        actual_seq_lengths_query=actual_q,
        actual_seq_lengths_key=candidate_lens,
        block_table=block_table,
        layout_query="TND",
        layout_key="PA_BSND",
        sparse_count=TOPK,
        sparse_mode=0,
    )
    output = result[0] if isinstance(result, (tuple, list)) else result
    if not isinstance(output, torch.Tensor) or output.dtype != torch.int32:
        raise RuntimeError("标准 LightningIndexer 未返回 int32 TopK")
    expected = query.size(0) * TOPK
    if output.numel() != expected:
        raise RuntimeError(
            f"标准 LightningIndexer shape 异常：{tuple(output.shape)}"
        )
    return output.reshape(query.size(0), TOPK).contiguous()


def _ordered_union(rows: torch.Tensor) -> list[int]:
    seen: set[int] = set()
    values: list[int] = []
    for value in rows.reshape(-1).tolist():
        token = int(value)
        if token >= 0 and token not in seen:
            seen.add(token)
            values.append(token)
    return values


def make_case(
    *,
    device: torch.device,
    batch: int,
    heads: int,
    candidate_len: int,
    query_count: int,
    cache_budget: int,
    misses: int,
    pool_extra: int,
    seed: int,
) -> StandardMtpCase:
    if batch <= 0 or heads not in (32, 64):
        raise ValueError("要求 batch>0 且 heads 为 32/64")
    if not 1 <= query_count <= 7:
        raise ValueError("query_count 必须在 [1,7]")
    if candidate_len < TOPK or candidate_len % BLOCK_SIZE:
        raise ValueError("candidate_len 必须是 >=2048 的 128 倍数")
    if not query_count * TOPK <= cache_budget <= 16256:
        raise ValueError("MTP cache_budget 必须在 [query_count*2048,16256]")
    if not 0 <= misses <= query_count * TOPK:
        raise ValueError("misses 超出 MTP union 上限")

    torch.manual_seed(seed)
    torch_npu.npu.manual_seed_all(seed)
    generator = torch.Generator().manual_seed(seed + 1)
    total_queries = batch * query_count
    # 多留一个 block，使 actual key 覆盖 MTP query token；offload LI 只读取
    # candidate_len 前缀，且所有下发到内存池的 source ID 都落在该前缀内。
    source_capacity = candidate_len + BLOCK_SIZE
    blocks = source_capacity // BLOCK_SIZE
    query = torch.empty(
        (total_queries, heads, HEAD_DIM), dtype=torch.bfloat16, device=device
    ).uniform_(-1, 1)
    key = torch.empty(
        (blocks, BLOCK_SIZE, 1, HEAD_DIM),
        dtype=torch.bfloat16,
        device=device,
    ).uniform_(-1, 1)
    weights = torch.empty(
        (total_queries, heads), dtype=torch.bfloat16, device=device
    ).uniform_(0.01, 1.0).contiguous()
    query_scale = torch.zeros(
        (total_queries, heads), dtype=torch.float32, device=device
    )
    key_scale = torch.zeros(
        (blocks, BLOCK_SIZE, 1), dtype=torch.float32, device=device
    )
    block_table = torch.arange(
        blocks, dtype=torch.int32, device=device
    ).repeat(batch, 1).contiguous()
    actual_q_cpu = [query_count * (request + 1) for request in range(batch)]
    actual_q = torch.tensor(actual_q_cpu, dtype=torch.int32, device=device)
    actual_key = torch.full(
        (batch,), source_capacity, dtype=torch.int32, device=device
    )
    offload_key = torch.full(
        (batch,), candidate_len, dtype=torch.int32, device=device
    )
    cache_tokens = torch.full(
        (batch,), cache_budget, dtype=torch.int32, device=device
    )
    request_state = torch.full(
        (batch,), -1, dtype=torch.int32, device=device
    )

    native_topk = official_standard_lightning_indexer(
        query, key, weights, actual_q, offload_key, block_table
    )
    torch_npu.npu.synchronize()
    native_cpu = native_topk.cpu()

    pool_size = batch + pool_extra
    req_entries_cpu = torch.randperm(
        pool_size, generator=generator
    )[:batch].to(torch.int32)
    pool = torch.full(
        (pool_size, source_capacity), INVALID_SLOT, dtype=torch.int32
    )
    target_misses: list[int] = []
    for request in range(batch):
        begin = request * query_count
        end = begin + query_count
        union = _ordered_union(native_cpu[begin:end])
        if misses > len(union) or len(union) > cache_budget:
            raise ValueError(
                f"request={request} union={len(union)} 无法构造 misses={misses}, "
                f"cache_budget={cache_budget}"
            )
        # 随机决定哪些 union token 常驻；剩余 cache slot 用非 TopK token
        # 填满，从而精确得到指定的 unique union miss 数。
        union_tensor = torch.tensor(union, dtype=torch.int64)
        order = torch.randperm(len(union), generator=generator)
        hit_tokens = union_tensor[order[: len(union) - misses]]
        occupied = torch.zeros(candidate_len, dtype=torch.bool)
        occupied[union_tensor] = True
        outside = torch.arange(candidate_len, dtype=torch.int64)[~occupied]
        fill_count = cache_budget - hit_tokens.numel()
        if fill_count > outside.numel():
            raise ValueError("候选区间不足以填满 cache budget")
        if fill_count:
            outside = outside[
                torch.randperm(outside.numel(), generator=generator)[:fill_count]
            ]
        residents = torch.cat((hit_tokens, outside))
        residents = residents[
            torch.randperm(residents.numel(), generator=generator)
        ]
        slots = torch.randperm(cache_budget, generator=generator).to(torch.int32)
        row = int(req_entries_cpu[request])
        pool[row, residents] = slots
        target_misses.append(misses)

    return StandardMtpCase(
        query=query,
        key=key,
        weights=weights,
        query_scale=query_scale,
        key_scale=key_scale,
        block_table=block_table,
        actual_q=actual_q,
        actual_key=actual_key,
        offload_key=offload_key,
        cache_tokens=cache_tokens,
        request_state=request_state,
        req_entries=req_entries_cpu.to(device),
        req_entries_cpu=req_entries_cpu,
        initial_pool=pool.to(device),
        native_topk=native_topk,
        target_misses=target_misses,
        query_counts=[query_count] * batch,
        source_capacity=source_capacity,
    )
