// SPDX-License-Identifier: Apache-2.0

#include "../host_offload/cpu_du.h"

#include <algorithm>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <vector>

namespace {

using remote_offload::CpuDuState;
using remote_offload::DuOutputOrder;
using remote_offload::kSourceRefOwnerBit;
using remote_offload::kSparseCount;

std::vector<int32_t> MakeState(int32_t capacity, int32_t budget)
{
    std::vector<int32_t> state(static_cast<size_t>(capacity), -1);
    for (int32_t token = 0; token < budget; ++token) {
        state[static_cast<size_t>(token)] = token;
    }
    return state;
}

std::vector<int32_t> MakeTopk(int32_t first, int32_t count = kSparseCount)
{
    std::vector<int32_t> result;
    result.reserve(kSparseCount);
    for (int32_t token = first; token < first + count; ++token) {
        result.push_back(token);
    }
    for (int32_t token = 0; result.size() < kSparseCount; ++token) {
        if (token < first || token >= first + count) {
            result.push_back(token);
        }
    }
    return result;
}

std::vector<int32_t> MakeTopkWithMisses(
    int32_t cacheBudget, int32_t missCount)
{
    std::vector<int32_t> result;
    result.reserve(kSparseCount);
    for (int32_t token = 0; token < kSparseCount - missCount; ++token) {
        result.push_back(token);
    }
    for (int32_t token = 0; token < missCount; ++token) {
        result.push_back(cacheBudget + token);
    }
    return result;
}

void TestZeroMiss()
{
    CpuDuState state(4096, MakeState(8192, 4096));
    const auto result = state.Update({MakeTopk(0)}, 8192);
    assert(result.generation == 1);
    assert(result.missCounts == std::vector<int32_t>({0}));
    assert(result.uniqueMissSourceIds.empty());
    assert(result.sourceIds[0] == MakeTopk(0));
    assert(result.destinationSlots[0].front() == 0);
}

void TestZeroBudgetNoOp()
{
    CpuDuState state(0, std::vector<int32_t>(4096, -1), 9);
    const auto result = state.Update({MakeTopk(0)}, 4096);
    assert(result.generation == 10);
    assert(result.missCounts == std::vector<int32_t>({0}));
    assert(result.uniqueMissSourceIds.empty());
    assert(std::all_of(result.sourceIds[0].begin(), result.sourceIds[0].end(),
        [](int32_t value) { return value == -1; }));
    assert(state.token_to_slot() == std::vector<int32_t>(4096, -1));
}

void TestUnionMetadataCanBeDisabled()
{
    CpuDuState state(4096, MakeState(8192, 4096));
    const auto result = state.Update({MakeTopk(0)}, 8192,
        DuOutputOrder::kHitsThenMisses, false);
    assert(result.sourceIds[0] == MakeTopk(0));
    assert(result.unionHitSourceIds.empty());
    assert(result.unionHitSlots.empty());
    assert(result.unionHitRefCounts.empty());
    assert(result.unionHitQueryMasks.empty());
    assert(result.unionOrdinals[0].empty());
}

void TestSingleQueryMissesAndCompatibilityOrder()
{
    CpuDuState state(4096, MakeState(8192, 4096));
    const auto topk = MakeTopk(4090);
    const auto snapshot = state.Snapshot();
    const auto result = state.Update(
        {topk}, 8192, DuOutputOrder::kMissesThenHits);
    assert(result.missCounts[0] == kSparseCount - 6);
    assert(result.sourceIds[0].front() == 4096);
    assert(result.uniqueMissDestinationSlots.front() == 0);
    assert(state.token_to_slot()[4096] == 0);

    state.Restore(snapshot);
    assert(state.generation() == 0);
    assert(state.token_to_slot()[4096] == -1);
    const auto replay = state.Update(
        {topk}, 8192, DuOutputOrder::kMissesThenHits);
    assert(replay.sourceIds == result.sourceIds);
    assert(replay.destinationSlots == result.destinationSlots);
}

void TestMtpUniqueMissOwner()
{
    CpuDuState state(4096, MakeState(10000, 4096));
    const auto row0 = MakeTopk(4000, 100);
    const auto row1 = MakeTopk(4050, 100);
    const auto result = state.Update({row0, row1}, 10000);
    assert(result.missCounts[0] == 4);
    assert(result.missCounts[1] == 54);
    assert(result.uniqueMissSourceIds.size() == 54);

    const auto firstMiss0 = result.sourceRefs[0].size() - 4;
    assert((result.sourceRefs[0][firstMiss0] & kSourceRefOwnerBit) != 0);
    const auto firstMiss1 = result.sourceRefs[1].size() - 54;
    // Tokens 4050..4099 first appear in row 0; their row-1 references must
    // reuse staging without taking persistent-copy ownership.
    assert((result.sourceRefs[1][firstMiss1] & kSourceRefOwnerBit) == 0);
    assert((result.sourceRefs[1].back() & kSourceRefOwnerBit) != 0);
}

void TestFourQueryMissMatrix()
{
    constexpr int32_t budget = 4096;
    CpuDuState state(budget, MakeState(10000, budget));
    const auto result = state.Update({
        MakeTopkWithMisses(budget, 0),
        MakeTopkWithMisses(budget, 100),
        MakeTopkWithMisses(budget, 200),
        MakeTopkWithMisses(budget, 300),
    }, 10000);
    assert(result.missCounts == std::vector<int32_t>({0, 100, 200, 300}));
    assert(result.uniqueMissSourceIds.size() == 300);
    assert(result.uniqueMissSourceIds.front() == budget);
    assert(result.uniqueMissSourceIds.back() == budget + 299);
    assert(result.unionHitSourceIds.size() == kSparseCount);
    assert(result.unionHitSlots.size() == kSparseCount);
    assert(result.unionHitRefCounts.size() == kSparseCount);
    assert(result.unionHitSourceIds.front() == 0);
    assert(result.unionHitSourceIds.back() == kSparseCount - 1);
    assert(result.unionHitRefCounts[0] == 4);
    assert(result.unionHitRefCounts[1800] == 3);
    assert(result.unionHitRefCounts[2000] == 1);
    assert(result.unionHitQueryMasks[0] == 0xf);
    assert(result.unionHitQueryMasks[1800] == 0x7);
    assert(result.unionHitQueryMasks[2000] == 0x1);
    assert(result.uniqueMissQueryMasks.front() == 0xe);
    assert(result.uniqueMissQueryMasks.back() == 0x8);
    assert(result.unionOrdinals[0].front() == 0);
    assert(result.unionOrdinals[1].back() == kSparseCount + 99);
    for (const int32_t token : result.uniqueMissSourceIds) {
        assert(state.token_to_slot()[static_cast<size_t>(token)] >= 0);
    }
}

void TestTransactionalFailure()
{
    // The first MTP query protects every cached slot. The second query asks
    // for uncached tokens, so no victim is available. The failed update must
    // not change state/generation.
    CpuDuState state(2048, MakeState(5000, 2048));
    const auto hits = MakeTopk(0);
    const auto misses = MakeTopk(2048);
    const auto before = state.Snapshot();
    bool failed = false;
    try {
        (void)state.Update({hits, misses}, 5000);
    } catch (const std::runtime_error&) {
        failed = true;
    }
    assert(failed);
    assert(state.generation() == before.generation);
    assert(state.token_to_slot() == before.tokenToSlot);
}

void TestFreeSlotsBeforeVictims()
{
    constexpr int32_t budget = 4096;
    auto initial = MakeState(8192, 2048);
    CpuDuState state(budget, std::move(initial));
    const auto result = state.Update(
        {MakeTopkWithMisses(2048, 100)}, 8192);
    assert(result.uniqueMissSourceIds.size() == 100);
    assert(result.uniqueMissDestinationSlots.front() == 2048);
    assert(result.uniqueMissDestinationSlots.back() == 2147);
    assert(std::all_of(result.evictedSourceIds.begin(),
        result.evictedSourceIds.end(),
        [](int32_t token) { return token == -1; }));
    assert(state.token_to_slot()[0] == 0);
    assert(state.token_to_slot()[2048] == 2048);
}

void TestValidation()
{
    auto invalid = MakeState(4096, 2048);
    invalid[2048] = 7;
    bool failed = false;
    try {
        CpuDuState state(2048, std::move(invalid));
        (void)state;
    } catch (const std::invalid_argument&) {
        failed = true;
    }
    assert(failed);
}

}  // namespace

int main()
{
    TestZeroMiss();
    TestZeroBudgetNoOp();
    TestUnionMetadataCanBeDisabled();
    TestSingleQueryMissesAndCompatibilityOrder();
    TestMtpUniqueMissOwner();
    TestFourQueryMissMatrix();
    TestTransactionalFailure();
    TestFreeSlotsBeforeVictims();
    TestValidation();
    std::cout << "CPU_DU_HOST_TEST passed=9 failed=0\n";
    return 0;
}
