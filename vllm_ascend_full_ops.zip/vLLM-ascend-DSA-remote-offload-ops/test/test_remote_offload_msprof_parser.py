#!/usr/bin/env python3
"""Remote Offload msprof CSV 解析器的纯 Python 测试。"""

from __future__ import annotations

import csv
import json
import tempfile
from pathlib import Path

from analyze_remote_offload_msprof import analyze


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "task_time_fixture.csv"
        rows = []
        for iteration in range(4):
            base = iteration * 100.0
            rows.extend([
                {
                    "Op Name": "A5FusedLiManageMtpC8",
                    "Task Start Time(us)": base,
                    "Task Duration(us)": 10,
                },
                {
                    "Op Name": "N/A MEMCPY_ASYNC",
                    "Task Start Time(us)": base + 10.5,
                    "Task Duration(us)": 1,
                },
                {
                    "Op Name": "HcommKvcacheScatterCopy",
                    "Task Start Time(us)": base + 12,
                    "Task Duration(us)": 20,
                },
                {
                    "Op Name": "ScatterIoFromStagingC8",
                    "Task Start Time(us)": base + 34,
                    "Task Duration(us)": 8,
                },
                {
                    "Op Name": "A5SparseTailAttentionMtpC8",
                    "Task Start Time(us)": base + 44,
                    "Task Duration(us)": 36,
                },
            ])
        with path.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        host_profile = {
            "li_d2h_sync_host_p50_us": 25.0,
            "cpu_du_host_p50_us": 125.0,
            "metadata_h2d_submit_host_p50_us": 15.0,
        }
        (Path(directory) / "msprof.log").write_text(
            "REMOTE_OFFLOAD_HOST_PROFILE_JSON "
            + json.dumps(host_profile)
            + "\n",
            encoding="utf-8",
        )
        result = analyze(
            Path(directory), "lidu_aicpu_poll_aiv",
            warmup=1, iterations=3, batch=32, misses=100,
        )
        assert result["chain_p50_us"] == 80.0
        assert result["io_p50_us"] == 20.0
        assert result["aiv_scatter_p50_us"] == 8.0
        assert result["sfa_p50_us"] == 36.0
        assert result["request_iops"] == 400000
        assert result["unique_iops"] == 40000000
        assert result["start_p50_us"] == 10.0
        assert result["index_to_io_gap_p50_us"] == 2.0
        assert result["io_to_scatter_gap_p50_us"] == 2.0
        assert result["scatter_to_sfa_gap_p50_us"] == 2.0
        assert result["total_gap_p50_us"] == 6.0
        assert result["bridge_device_task_p50_us"] == 1.0
        assert result["bridge_non_device_gap_p50_us"] == 1.0
        assert result["li_d2h_sync_host_p50_us"] == 25.0
        assert result["cpu_du_host_p50_us"] == 125.0
        assert result["metadata_h2d_submit_host_p50_us"] == 15.0

    # 隐式 DBA 保持一次完整 LI launch，但每轮固定提交两个 16-request
    # Hcomm/AIV scatter。解析器必须按轮两两配对，且不能把第二个 ubatch
    # 错配到下一轮。
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "task_time_implicit_dba.csv"
        rows = []
        for iteration in range(4):
            base = iteration * 100.0
            rows.extend([
                {
                    "Op Name": "LightningIndexer",
                    "Task Start Time(us)": base,
                    "Task Duration(us)": 30,
                },
                {
                    "Op Name": "HcommKvcacheScatterCopy",
                    "Task Start Time(us)": base + 5,
                    "Task Duration(us)": 10,
                },
                {
                    "Op Name": "ScatterIoFromStagingC8",
                    "Task Start Time(us)": base + 16,
                    "Task Duration(us)": 4,
                },
                {
                    "Op Name": "HcommKvcacheScatterCopy",
                    "Task Start Time(us)": base + 21,
                    "Task Duration(us)": 10,
                },
                {
                    "Op Name": "ScatterIoFromStagingC8",
                    "Task Start Time(us)": base + 32,
                    "Task Duration(us)": 4,
                },
                {
                    "Op Name": "A5SparseTailAttentionMtpC8",
                    "Task Start Time(us)": base + 38,
                    "Task Duration(us)": 20,
                },
            ])
        with path.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        (Path(directory) / "msprof.log").write_text(
            "REMOTE_OFFLOAD_HOST_PROFILE_JSON "
            + json.dumps({
                "cpu_topk_poll_wait_p50_us": 29.0,
                "cpu_du_request_p50_us": 7.0,
                "io_group1_minus_group0_ready_p50_us": 3.0,
            })
            + "\n",
            encoding="utf-8",
        )
        result = analyze(
            Path(directory), "li_cpu_du_implicit_dba",
            warmup=1, iterations=3, batch=32, misses=100,
        )
        assert result["chain_p50_us"] == 58.0
        assert result["io_p50_us"] == 20.0
        assert result["io_ubatch0_p50_us"] == 10.0
        assert result["io_ubatch1_p50_us"] == 10.0
        assert result["aiv_scatter_p50_us"] == 8.0
        assert result["aiv_scatter_ubatch0_p50_us"] == 4.0
        assert result["aiv_scatter_ubatch1_p50_us"] == 4.0
        assert result["li_io_overlap_p50_us"] == 19.0
        assert result["li_scatter_overlap_p50_us"] == 4.0
        assert result["ubatch_handoff_gap_p50_us"] == 1.0
        assert result["ubatch1_io_to_scatter_gap_p50_us"] == 1.0
        assert result["scatter_to_sfa_gap_p50_us"] == 2.0
        assert result["total_gap_p50_us"] == 5.0
        assert result["cpu_topk_poll_wait_p50_us"] == 29.0
        assert result["cpu_du_request_p50_us"] == 7.0
        assert result["io_group1_minus_group0_ready_p50_us"] == 3.0

    # 样例来自实际 msprof task-time 导出：下划线列名且直接以 CSV 路径作为输入。
    sample = ROOT / "task_time_20260831162142.csv"
    result = analyze(
        sample, "lidu_aicpu_poll_aiv",
        warmup=10, iterations=20, batch=32, misses=100,
    )
    assert result["samples"] == 20
    assert result["observed_start_calls"] == 30
    assert result["observed_sfa_calls"] == 30
    assert result["io_p50_us"] > 0.0
    assert result["aiv_scatter_p50_us"] > 0.0
    assert result["sfa_p50_us"] > 0.0
    print("REMOTE_OFFLOAD_MSPROF_PARSER_TEST passed=1", flush=True)


if __name__ == "__main__":
    main()
