#!/usr/bin/env python3
"""Remote Offload 阶段 1A 单算子功能测试入口。"""

from __future__ import annotations

import argparse
import json
import os
import shlex
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]

COMPONENTS: dict[str, list[str]] = {
    "host": ["bash", "test/run_cpu_du_host_test.sh"],
    "cpu_du_extension": [sys.executable, "test/cpu_du_extension_test.py"],
    "cpu_du_implicit_dba": [
        sys.executable, "test/test_cpu_du_implicit_dba.py",
    ],
    "aicpu": [
        sys.executable,
        "test/correctness.py",
        "--device",
        "npu:0",
        "--dtypes",
        "bf16,fp16",
    ],
    "pool_get": [sys.executable, "test/urma_remote_demo.py"],
    "copy_sfa": [sys.executable, "test/sfa_remote_perf.py"],
    "c8_aiv_scatter": [
        sys.executable,
        "test/scatter_io_from_staging_c8_test.py",
    ],
    "c8_lidu": [sys.executable, "test/test_fused_li_manage_c8.py"],
    "c8_mtp_lidu": [
        sys.executable,
        "test/test_fused_li_manage_mtp_c8.py",
    ],
    "standard_lidu": [
        sys.executable,
        "test/test_fused_li_manage_mtp_standard.py",
    ],
    "c8_scatter": [
        sys.executable,
        "test/test_kvcache_scatter_copy_c8.py",
    ],
    "c8_sfa": [
        sys.executable,
        "test/test_sparse_tail_attention_c8.py",
    ],
    "c8_mtp_sfa": [
        sys.executable,
        "test/test_sparse_tail_attention_mtp_c8.py",
    ],
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="依次执行 Remote Offload 阶段 1A 单算子功能测试。"
    )
    parser.add_argument(
        "--components",
        default="host",
        help=(
            "逗号分隔：host,cpu_du_extension,cpu_du_implicit_dba,"
            "aicpu,pool_get,copy_sfa,"
            "c8_aiv_scatter,c8_lidu,c8_mtp_lidu,c8_scatter,c8_sfa,"
            "c8_mtp_sfa,standard_lidu；"
            "默认只运行无 NPU 用例。"
        ),
    )
    parser.add_argument(
        "--json",
        type=Path,
        default=None,
        help="可选结果 JSON；仅保存状态和耗时，不保存命令。",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="只打印等效复现命令。",
    )
    return parser.parse_args()


def selected_components(value: str) -> list[str]:
    selected = [item.strip() for item in value.split(",") if item.strip()]
    unknown = [item for item in selected if item not in COMPONENTS]
    if unknown:
        raise ValueError(
            f"未知组件：{','.join(unknown)}；可选值：{','.join(COMPONENTS)}"
        )
    if not selected:
        raise ValueError("至少选择一个组件")
    return selected


def main() -> int:
    args = parse_args()
    try:
        selected = selected_components(args.components)
    except ValueError as error:
        print(f"参数错误：{error}", file=sys.stderr)
        return 2

    results: list[dict[str, object]] = []
    for component in selected:
        command = COMPONENTS[component]
        print(
            f"复现命令[{component}]："
            + shlex.join(command),
            flush=True,
        )
        if args.dry_run:
            results.append(
                {"component": component, "status": "dry_run", "elapsed_ms": 0}
            )
            continue

        begin = time.perf_counter_ns()
        env = os.environ.copy()
        python_path = str(ROOT / "torch_extension")
        if env.get("PYTHONPATH"):
            python_path += os.pathsep + env["PYTHONPATH"]
        env["PYTHONPATH"] = python_path
        completed = subprocess.run(command, cwd=ROOT, env=env, check=False)
        elapsed_ms = round((time.perf_counter_ns() - begin) / 1_000_000, 3)
        status = "passed" if completed.returncode == 0 else "failed"
        results.append(
            {
                "component": component,
                "status": status,
                "exit_code": completed.returncode,
                "elapsed_ms": elapsed_ms,
            }
        )
        if completed.returncode != 0:
            break

    print("\n单算子功能汇总", flush=True)
    for result in results:
        print(
            f"component={result['component']} status={result['status']} "
            f"elapsed_ms={result['elapsed_ms']}",
            flush=True,
        )

    if args.json is not None:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(
            json.dumps({"schema_version": 1, "results": results},
                       ensure_ascii=False, indent=2)
            + "\n",
            encoding="utf-8",
        )
        print(f"结果文件：{args.json}", flush=True)

    return 1 if any(result["status"] == "failed" for result in results) else 0


if __name__ == "__main__":
    raise SystemExit(main())
