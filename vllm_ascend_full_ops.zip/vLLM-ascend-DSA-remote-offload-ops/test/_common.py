import importlib
import sys
from pathlib import Path

import torch
import torch_npu


ROOT = Path(__file__).resolve().parents[1]
BLOCK_SIZE = 128
K_ROPE_DIM = 64
KV_CACHE_DIM = 512
COPY_CAP = 16384
BYTES_PER_TOKEN = (K_ROPE_DIM + KV_CACHE_DIM) * 2


def load_new_ops(root=ROOT):
    extension_dir = Path(root) / "torch_extension"
    sys.path.insert(0, str(extension_dir))
    return importlib.import_module("kvcache_scatter_copy_custom_ops")


def parse_dtype(name):
    if name == "bf16":
        return torch.bfloat16
    if name == "fp16":
        return torch.float16
    raise ValueError(f"unsupported dtype: {name}")


def swapped_tensor_from_cpu(cpu_tensor, device):
    swapped = torch_npu.empty_with_swapped_memory(
        cpu_tensor.shape,
        dtype=cpu_tensor.dtype,
        device=device,
    )
    swapped.fill_(0)
    swapped.add_(cpu_tensor.to(device))
    return swapped


def _rand_tensor(shape, dtype, generator):
    return torch.randn(shape, dtype=torch.float32, generator=generator).to(dtype).contiguous()


def make_case(counts, dtype, device, seed=0, logical_tokens=None, sequential_dest=False):
    if not counts:
        raise ValueError("counts must not be empty")
    if any(count < 0 or count > COPY_CAP for count in counts):
        raise ValueError("all copy counts must be in [0, 16384]")

    batch_size = len(counts)
    required_tokens = max(max(counts), 1)
    if logical_tokens is None:
        logical_tokens = max(required_tokens, 640)
    if logical_tokens < required_tokens:
        raise ValueError("logical_tokens must cover every copy count")
    blocks_per_row = (logical_tokens + BLOCK_SIZE - 1) // BLOCK_SIZE
    padded_tokens = blocks_per_row * BLOCK_SIZE
    total_blocks = batch_size * blocks_per_row
    generator = torch.Generator().manual_seed(seed)

    dram_table_cpu = torch.randperm(total_blocks, generator=generator).view(batch_size, blocks_per_row).to(torch.uint64)
    hbm_table_cpu = torch.randperm(total_blocks, generator=generator).view(batch_size, blocks_per_row).to(torch.int32)
    dram_rope_cpu = _rand_tensor((total_blocks, BLOCK_SIZE, K_ROPE_DIM), dtype, generator)
    dram_kv_cpu = _rand_tensor((total_blocks, BLOCK_SIZE, KV_CACHE_DIM), dtype, generator)
    hbm_rope_cpu = _rand_tensor((total_blocks, BLOCK_SIZE, K_ROPE_DIM), dtype, generator)
    hbm_kv_cpu = _rand_tensor((total_blocks, BLOCK_SIZE, KV_CACHE_DIM), dtype, generator)
    expected_rope_cpu = hbm_rope_cpu.clone()
    expected_kv_cpu = hbm_kv_cpu.clone()

    src_ids_cpu = torch.full((batch_size, 1, COPY_CAP), -1, dtype=torch.int32)
    dst_slots_cpu = torch.full((batch_size, 1, COPY_CAP), -1, dtype=torch.int32)
    for batch_idx, count in enumerate(counts):
        if count == 0:
            continue
        src = torch.randperm(padded_tokens, generator=generator)[:count].to(torch.int32)
        if sequential_dest:
            dst = torch.arange(count, dtype=torch.int32)
        else:
            dst = torch.randperm(padded_tokens, generator=generator)[:count].to(torch.int32)
        src_ids_cpu[batch_idx, 0, :count] = src
        dst_slots_cpu[batch_idx, 0, :count] = dst

        src64 = src.to(torch.int64)
        dst64 = dst.to(torch.int64)
        src_physical = dram_table_cpu[batch_idx, src64 // BLOCK_SIZE].to(torch.int64)
        dst_physical = hbm_table_cpu[batch_idx, dst64 // BLOCK_SIZE].to(torch.int64)
        expected_rope_cpu[dst_physical, dst64 % BLOCK_SIZE] = dram_rope_cpu[src_physical, src64 % BLOCK_SIZE]
        expected_kv_cpu[dst_physical, dst64 % BLOCK_SIZE] = dram_kv_cpu[src_physical, src64 % BLOCK_SIZE]

    return {
        "hbm_k_rope": hbm_rope_cpu.to(device),
        "hbm_kv_cache": hbm_kv_cpu.to(device),
        "dram_k_rope": swapped_tensor_from_cpu(dram_rope_cpu, device),
        "dram_kv_cache": swapped_tensor_from_cpu(dram_kv_cpu, device),
        "hbm_block_table": hbm_table_cpu.to(device),
        "dram_block_table": dram_table_cpu.to(device),
        "src_token_ids": src_ids_cpu.to(device),
        "dst_slots": dst_slots_cpu.to(device),
        "copy_counts": torch.tensor(counts, dtype=torch.int32, device=device),
        "expected_rope": expected_rope_cpu,
        "expected_kv": expected_kv_cpu,
    }


def call_new(case, ready_flag=None, layer_id=0):
    return torch.ops.custom.npu_kvcache_scatter_copy(
        case["hbm_k_rope"],
        case["hbm_kv_cache"],
        case["dram_k_rope"],
        case["dram_kv_cache"],
        case["hbm_block_table"],
        case["dram_block_table"],
        case["src_token_ids"],
        case["dst_slots"],
        case["copy_counts"],
        ready_flag,
        layer_id,
    )


def validate_case(case):
    actual_rope = case["hbm_k_rope"].cpu()
    actual_kv = case["hbm_kv_cache"].cpu()
    rope_ok = torch.equal(actual_rope, case["expected_rope"])
    kv_ok = torch.equal(actual_kv, case["expected_kv"])
    if not rope_ok:
        max_diff = float((actual_rope.float() - case["expected_rope"].float()).abs().max().item())
        raise AssertionError(f"K-RoPE mismatch, max_diff={max_diff:g}")
    if not kv_ok:
        max_diff = float((actual_kv.float() - case["expected_kv"].float()).abs().max().item())
        raise AssertionError(f"KV mismatch, max_diff={max_diff:g}")
