// SPDX-License-Identifier: Apache-2.0

#include "../host_offload/metadata_store.h"

#include <cassert>
#include <cstdint>
#include <iostream>

namespace {

remote_offload::LayerOffloadMetadata Layer(
    uint32_t layerId, remote_offload::PutPayloadKind kind,
    uint64_t logicalLength, uint32_t tailValid)
{
    remote_offload::LayerOffloadMetadata metadata;
    metadata.layerId = layerId;
    metadata.payloadKind = kind;
    metadata.logicalLength = logicalLength;
    metadata.tailValidLength = tailValid;
    metadata.remoteBlockTable = {0x1000 + layerId * 0x1000};
    metadata.tokenSlotDeltas = {{1, 1}, {2, 2}};
    metadata.duSnapshot.cacheBudget = 2048;
    metadata.duSnapshot.tokenToSlot.assign(4096, -1);
    for (int32_t token = 0; token < 2048; ++token) {
        metadata.duSnapshot.tokenToSlot[static_cast<size_t>(token)] = token;
    }
    metadata.payloadComplete = true;
    return metadata;
}

}  // namespace

int main()
{
    using namespace remote_offload;
    RemoteMetadataStore store;
    assert(store.Begin(9, 1, 1, 2));
    assert(store.RecordPayload(9, 1, 1,
        Layer(0, PutPayloadKind::kFullBlock, 128, 0)));
    assert(store.RecordPayload(9, 1, 1,
        Layer(0, PutPayloadKind::kFullBlock, 128, 0)));
    auto conflicting = Layer(0, PutPayloadKind::kFullBlock, 128, 0);
    conflicting.tokenSlotDeltas[0].slot = 99;
    assert(!store.RecordPayload(9, 1, 1, std::move(conflicting)));
    assert(!store.Commit(9, 1, 1));
    assert(!store.RecordPayload(9, 1, 1,
        Layer(1, PutPayloadKind::kFullBlock, 129, 0)));
    assert(store.RecordPayload(9, 1, 1,
        Layer(1, PutPayloadKind::kFullBlock, 128, 0)));
    assert(store.Commit(9, 1, 1));
    assert(store.Commit(9, 1, 1));
    assert(!store.Begin(9, 1, 1, 3));
    assert(!store.Begin(9, 1, 0, 2));

    const auto first = store.GetCommitted(9);
    assert(first.has_value());
    assert(first->generation == 1 && first->layers.size() == 2);

    assert(store.Begin(9, 1, 2, 2));
    assert(store.RecordPayload(9, 1, 2,
        Layer(0, PutPayloadKind::kTail, 129, 1)));
    assert(store.RecordPayload(9, 1, 2,
        Layer(1, PutPayloadKind::kTail, 129, 1)));
    assert(store.Commit(9, 1, 2));
    const auto second = store.GetCommitted(9);
    assert(second->generation == 2);
    assert(second->layers.at(0).tailValidLength == 1);

    assert(store.Begin(9, 1, 3, 2));
    assert(store.Abort(9, 1, 3));
    assert(!store.Commit(9, 1, 3));
    assert(store.GetCommitted(9)->generation == 2);

    auto badTail = Layer(0, PutPayloadKind::kTail, 256, 128);
    assert(store.Begin(10, 1, 1, 1));
    assert(!store.RecordPayload(10, 1, 1, std::move(badTail)));

    assert(store.Begin(11, 1, 1, 1));
    assert(!store.RecordPayload(11, 1, 1,
        Layer(0, PutPayloadKind::kTail, 128, 0)));
    assert(store.Begin(12, 1, 1, 1));
    assert(!store.RecordPayload(12, 1, 1,
        Layer(0, PutPayloadKind::kFullBlock, 129, 0)));
    assert(store.Begin(13, 1, 1, 1));
    assert(!store.RecordPayload(13, 1, 1,
        Layer(0, PutPayloadKind::kFullBlock, 128, 1)));

    auto invalidSnapshot = Layer(0, PutPayloadKind::kFullBlock, 128, 0);
    invalidSnapshot.duSnapshot.tokenToSlot[2048] = 7;
    assert(store.Begin(14, 1, 1, 1));
    assert(!store.RecordPayload(14, 1, 1, std::move(invalidSnapshot)));

    std::cout << "METADATA_STORE_HOST_TEST passed=4 failed=0\n";
    return 0;
}
