#!/usr/bin/env python3
"""固定 656B、A5 C8 LIDU/隐式 DBA CPU DU、MTP3 Remote Offload 工作负载。

脚本不使用 NPU Event 计时。它只做预热、执行固定次数的算子链并同步，性能数据
不由本脚本或功能矩阵统计。
"""

from __future__ import annotations

import argparse
import json
import math
import statistics
import sys
import time
from collections import defaultdict
from pathlib import Path

import torch
import torch_npu


ROOT = Path(__file__).resolve().parents[1]
TOPK = 2048
BLOCK_SIZE = 128
PACKED_BYTES = 656
UNION_CAP = 16384
C8_UNION_CAP = 8192
QUERY_COUNT = 4  # MTP3：root + 3 个 draft。
# 四路 Top-2048 union 最坏为 8192；缓存预算必须覆盖完整 union。
CACHE_TOKENS = 8192
DENSE_TAIL = 256
RAW_POOL_BLOCK_BYTES = 128 * (1024 + 128)
IO_UBATCH_REQUESTS = 16

MODES = (
    "no_offload",
    "lidu_aicpu_poll_aiv",
    "lidu_aicpu_defer_aiv_poll",
    "li_cpu_du_implicit_dba",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=MODES, required=True)
    parser.add_argument("--device", default="npu:0")
    parser.add_argument("--device-eid", required=True)
    parser.add_argument("--device-phy-id", type=int, default=0)
    parser.add_argument("--pool-ip", required=True)
    parser.add_argument("--control-port", type=int, default=19090)
    parser.add_argument("--lanes", type=int, default=1)
    parser.add_argument("--bs", type=int, default=32)
    parser.add_argument("--candidate-seqlen", type=int, default=131072)
    parser.add_argument("--misses-per-request", type=int, choices=(100, 200), required=True)
    parser.add_argument("--heads", type=int, default=32)
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--iterations", type=int, default=20)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument(
        "--cpu-du-threads", type=int, default=0,
        help="隐式 DBA 固定使用 32 线程；0 和 32 等价。",
    )
    parser.add_argument(
        "--cpu-du-first-cpu", type=int, default=-1,
        help=">=0 时把常驻线程依次绑定到该 CPU 起始编号。",
    )
    return parser.parse_args()


def load_dependencies():
    sys.path.insert(0, str(ROOT / "torch_extension"))
    try:
        import kvcache_scatter_copy_custom_ops as remote_ops
        from test_fused_li_manage_mtp_c8 import make_case
    except ImportError as error:
        raise RuntimeError(
            "无法加载 Remote Offload 依赖；请先使用 "
            "ENABLE_C8_MTP_OPS=1 编译当前仓库"
        ) from error
    return remote_ops, make_case


def make_attention_slots(
    device: torch.device, batch: int
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    rows = batch * QUERY_COUNT
    width = TOPK + DENSE_TAIL + QUERY_COUNT
    slots = torch.full((rows, 1, width), -1, dtype=torch.int32, device=device)
    for request in range(batch):
        for query in range(QUERY_COUNT):
            row = request * QUERY_COUNT + query
            slots[row, 0, TOPK : TOPK + DENSE_TAIL] = torch.arange(
                CACHE_TOKENS,
                CACHE_TOKENS + DENSE_TAIL,
                dtype=torch.int32,
                device=device,
            )
            slots[
                row,
                0,
                TOPK + DENSE_TAIL : TOPK + DENSE_TAIL + query + 1,
            ] = torch.arange(
                CACHE_TOKENS + DENSE_TAIL,
                CACHE_TOKENS + DENSE_TAIL + query + 1,
                dtype=torch.int32,
                device=device,
            )
    actual_q = torch.arange(
        QUERY_COUNT,
        rows + 1,
        QUERY_COUNT,
        dtype=torch.int32,
        device=device,
    )
    resident = torch.full(
        (batch,), CACHE_TOKENS + DENSE_TAIL + QUERY_COUNT,
        dtype=torch.int32, device=device,
    )
    return slots, actual_q, resident


def make_hbm_table(device: torch.device, batch: int) -> tuple[torch.Tensor, int]:
    blocks_per_request = math.ceil(
        (CACHE_TOKENS + DENSE_TAIL + QUERY_COUNT) / BLOCK_SIZE
    )
    table = torch.arange(
        batch * blocks_per_request, dtype=torch.int32
    ).reshape(batch, blocks_per_request).to(device)
    return table, batch * blocks_per_request


def make_remote_table(
    device: torch.device, pool_gva: int, pool_bytes: int,
    batch: int, candidate_seqlen: int,
) -> torch.Tensor:
    blocks = candidate_seqlen // BLOCK_SIZE
    available = pool_bytes // RAW_POOL_BLOCK_BYTES
    if available < blocks:
        raise RuntimeError(
            f"远端池只有 {available} blocks，128K 候选至少需要 {blocks} blocks"
        )
    addresses = pool_gva + torch.arange(blocks, dtype=torch.int64) * RAW_POOL_BLOCK_BYTES
    return addresses.to(torch.uint64).repeat(batch, 1).contiguous().to(device)


def initial_cpu_states(case, batch: int) -> torch.Tensor:
    pool = case.initial_pool.cpu()
    entries = case.req_entries_cpu.tolist()
    states = torch.stack(
        [pool[int(entries[row])].clone() for row in range(batch)]
    ).contiguous()
    # CPU DU 的空槽 ABI 固定使用 -1。
    states[states < 0] = -1
    return states


def empty_swapped_int32(shape, device: torch.device) -> torch.Tensor:
    allocator = getattr(torch_npu, "empty_with_swapped_memory", None)
    if allocator is None:
        raise RuntimeError(
            "li_cpu_du_implicit_dba 要求 torch_npu.empty_with_swapped_memory"
        )
    return allocator(shape, dtype=torch.int32, device=device)


def run() -> None:
    args = parse_args()
    if args.bs <= 0 or args.candidate_seqlen != 131072:
        raise ValueError("当前固定矩阵要求 bs>0 且 candidate-seqlen=131072")
    if args.lanes != 1:
        raise ValueError("当前硬件矩阵固定 lanes=1（对应 Pool jetty-count=1）")
    if args.candidate_seqlen % BLOCK_SIZE:
        raise ValueError("candidate-seqlen 必须是 128 的倍数")
    if args.heads not in (32, 64):
        raise ValueError("A5 C8 LI heads 只支持 32 或 64")
    if args.warmup < 0 or args.iterations <= 0:
        raise ValueError("要求 warmup>=0 且 iterations>0")
    use_cpu_du = args.mode == "li_cpu_du_implicit_dba"
    if args.cpu_du_first_cpu < -1:
        raise ValueError("cpu-du-first-cpu 必须 >=-1")
    if use_cpu_du and (args.bs != 32 or args.cpu_du_threads not in (0, 32)):
        raise ValueError(
            "li_cpu_du_implicit_dba 当前固定 bs=32、cpu-du-threads=32"
        )
    remote_ops, make_mtp_case = load_dependencies()
    device = torch.device(args.device)
    torch_npu.npu.set_device(device)

    controlled_misses = (
        0 if args.mode == "no_offload" else args.misses_per_request
    )
    # 四条路径共用完全相同的 C8 MTP3 输入和初始 residency。CPU DU 路径
    # 只拆开 LI/DU，不再混入 BF16 standard LI 精度和 kernel 的差异。
    case = make_mtp_case(
        device=device,
        batch=args.bs,
        heads=args.heads,
        source_len=args.candidate_seqlen,
        query_counts=[QUERY_COUNT] * args.bs,
        budgets=[CACHE_TOKENS] * args.bs,
        miss_range=(controlled_misses, controlled_misses),
        pool_extra=7,
        seed=args.seed,
    )
    run_count = args.warmup + args.iterations
    pools = (
        [] if use_cpu_du
        else [case.initial_pool.clone() for _ in range(run_count)]
    )
    attention_slots, actual_q, resident = make_attention_slots(device, args.bs)
    hbm_table, hbm_blocks = make_hbm_table(device, args.bs)
    packed_hbm = torch.zeros(
        (hbm_blocks, BLOCK_SIZE, 1, PACKED_BYTES),
        dtype=torch.int8, device=device,
    )
    attention_query = torch.empty(
        (args.bs * QUERY_COUNT, args.heads, 576),
        dtype=torch.bfloat16, device=device,
    ).uniform_(-0.5, 0.5)
    scale = 576 ** -0.5

    # Hcomm 使用固定 16384 容量 metadata；C8 LIDU 的 8192 union 在下方
    # 适配到该 ABI。
    miss_sources_out = torch.empty(
        (args.bs, UNION_CAP), dtype=torch.int32, device=device
    )
    miss_destinations_out = torch.empty_like(miss_sources_out)
    topk_out = torch.empty(
        (args.bs * QUERY_COUNT, 1, TOPK),
        dtype=torch.int32, device=device,
    )
    topk_source_out = torch.empty_like(topk_out)
    topk_miss_count_out = torch.empty(
        (args.bs * QUERY_COUNT,), dtype=torch.int32, device=device
    )
    counts_out = torch.empty((args.bs,), dtype=torch.int32, device=device)
    c8_miss_sources = None
    c8_miss_destinations = None
    if not use_cpu_du:
        c8_miss_sources = torch.empty(
            (args.bs, C8_UNION_CAP), dtype=torch.int32, device=device
        )
        c8_miss_destinations = torch.empty_like(c8_miss_sources)
    ready = torch.ones((1,), dtype=torch.int32, device=device)

    channel: int | None = None
    staging = None
    remote_table = None
    if args.mode != "no_offload":
        defer = args.mode == "lidu_aicpu_defer_aiv_poll"
        channel = remote_ops.npu_hcomm_kvcache_pool_connect_raw_packed(
            args.device_eid,
            args.device_phy_id,
            args.pool_ip,
            args.control_port,
            packed_hbm,
            args.lanes,
            100,
            defer,
            0,  # 内存池最大聚合率。
            0,  # 不启用盘模型的固定 WQE 粒度。
        )
        _, _, pool_gva, pool_bytes = remote_ops.npu_hcomm_kvcache_pool_get_raw_context(channel)
        remote_table = make_remote_table(
            device, int(pool_gva), int(pool_bytes), args.bs, args.candidate_seqlen
        )
        staging_bytes = remote_ops.npu_hcomm_kvcache_pool_get_staging(channel)
        staging = staging_bytes.narrow(
            0, 0, args.bs * args.misses_per_request * PACKED_BYTES
        ).view(-1, PACKED_BYTES)

    cpu_threads = 32 if use_cpu_du else 0
    cpu_runtime = None
    topk_ring = None
    ready_flags = None
    source_ids_out = None
    source_refs_out = None
    evicted_source_ids = None
    union_miss_masks = None
    union_hit_source_ids = None
    union_hit_slots = None
    union_hit_ref_counts = None
    union_hit_masks = None
    union_hit_counts = None
    union_ordinals = None
    if use_cpu_du:
        topk_ring = empty_swapped_int32(
            (run_count, args.bs * QUERY_COUNT, 1, TOPK), device
        )
        topk_ring.fill_(-1)
        swapped_attention = empty_swapped_int32(attention_slots.shape, device)
        swapped_attention.copy_(attention_slots)
        attention_slots = swapped_attention
        source_ids_out = empty_swapped_int32(
            (args.bs * QUERY_COUNT, TOPK), device
        )
        source_refs_out = empty_swapped_int32(source_ids_out.shape, device)
        topk_miss_count_out = empty_swapped_int32(
            (args.bs * QUERY_COUNT,), device
        )
        miss_sources_out = empty_swapped_int32(
            (args.bs, 1, UNION_CAP), device
        )
        miss_destinations_out = empty_swapped_int32(
            miss_sources_out.shape, device
        )
        counts_out = empty_swapped_int32((args.bs,), device)
        evicted_source_ids = empty_swapped_int32(
            (args.bs, C8_UNION_CAP), device
        )
        union_miss_masks = empty_swapped_int32(
            (args.bs, C8_UNION_CAP), device
        )
        union_hit_source_ids = empty_swapped_int32(
            (args.bs, C8_UNION_CAP), device
        )
        union_hit_slots = empty_swapped_int32(
            (args.bs, C8_UNION_CAP), device
        )
        union_hit_ref_counts = empty_swapped_int32(
            (args.bs, C8_UNION_CAP), device
        )
        union_hit_masks = empty_swapped_int32(
            (args.bs, C8_UNION_CAP), device
        )
        union_hit_counts = empty_swapped_int32((args.bs,), device)
        union_ordinals = empty_swapped_int32(
            (args.bs * QUERY_COUNT, TOPK), device
        )
        ready_flags = empty_swapped_int32((run_count, 2), device)
        ready_flags.zero_()
        torch_npu.npu.synchronize()

        base_states = initial_cpu_states(case, args.bs)
        generation_states = base_states.unsqueeze(0).repeat(
            run_count, 1, 1
        ).contiguous()
        cpu_runtime = remote_ops.SwappedCpuDuImplicitDbaRuntime(
            first_cpu=args.cpu_du_first_cpu
        )
        cpu_runtime.register_pipeline(
            topk_ring=topk_ring,
            initial_states=generation_states,
            cache_budgets=torch.full(
                (args.bs,), CACHE_TOKENS, dtype=torch.int32
            ),
            candidate_lengths=torch.full(
                (args.bs,), args.candidate_seqlen, dtype=torch.int32
            ),
            source_ids=source_ids_out,
            attention_slots=attention_slots,
            source_refs=source_refs_out,
            query_miss_counts=topk_miss_count_out,
            hcomm_sources=miss_sources_out,
            hcomm_destinations=miss_destinations_out,
            hcomm_counts=counts_out,
            evicted_source_ids=evicted_source_ids,
            union_miss_masks=union_miss_masks,
            union_hit_source_ids=union_hit_source_ids,
            union_hit_slots=union_hit_slots,
            union_hit_ref_counts=union_hit_ref_counts,
            union_hit_masks=union_hit_masks,
            union_hit_counts=union_hit_counts,
            union_ordinals=union_ordinals,
            ready_flags=ready_flags,
        )
        cpu_runtime.start()

    host_samples: dict[str, list[float]] = defaultdict(list)
    profile_host_iteration = False

    def measure_host(stage: str, function):
        begin = time.perf_counter_ns()
        result = function()
        if profile_host_iteration:
            host_samples[stage].append(
                (time.perf_counter_ns() - begin) / 1000.0
            )
        return result

    def run_sfa() -> torch.Tensor:
        return remote_ops.sparse_tail_attention_mtp_c8(
            attention_query,
            packed_hbm.view(torch.float8_e4m3fn),
            attention_slots,
            hbm_table,
            actual_q,
            resident,
            scale,
        )

    def npu_lidu(pool: torch.Tensor) -> None:
        assert c8_miss_sources is not None
        assert c8_miss_destinations is not None
        torch.ops.nanovllm_dsa.fused_li_manage_mtp_c8_out.default(
            case.query,
            case.key,
            case.weights,
            case.query_scale,
            case.key_scale,
            case.actual_q,
            case.req_entries,
            pool,
            case.cache_tokens,
            case.candidate_lens,
            case.block_table,
            topk_source_out,
            topk_out,
            topk_miss_count_out,
            c8_miss_sources,
            c8_miss_destinations,
            counts_out,
        )
        # Hcomm/AIV 的当前 metadata ABI 固定为 [B,1,16384]，C8 MTP
        # LIDU 的数学 union 上限为 8192。只复制有效前缀，后半段不会被
        # copy_counts 消费。
        miss_sources_out[:, :C8_UNION_CAP].copy_(c8_miss_sources)
        miss_destinations_out[:, :C8_UNION_CAP].copy_(
            c8_miss_destinations
        )
        attention_slots[:, :, :TOPK].copy_(topk_out)

    def npu_c8_li_cpu_du(iteration: int) -> None:
        assert cpu_runtime is not None
        assert topk_ring is not None
        # LI 保持一次完整 BS=32 launch；CPU 根据 swapped 输出的实际完成
        # 顺序隐式拆 DU，不修改 LI 算子或 tiling。
        measure_host(
            "c8_li_submit_host",
            lambda: remote_ops.quant_lightning_indexer_c8_out(
                case.query,
                case.key,
                case.weights,
                case.query_scale,
                case.key_scale,
                case.actual_q,
                case.candidate_lens,
                case.block_table,
                topk_ring[iteration],
            ),
        )

    def remote_io_and_scatter(
        sources: torch.Tensor | None = None,
        destinations: torch.Tensor | None = None,
        counts: torch.Tensor | None = None,
    ) -> None:
        assert channel is not None and remote_table is not None and staging is not None
        # Hcomm 使用 [B,1,16384]；CPU DU 已原生生成这个布局，C8 LIDU
        # 则在 npu_lidu() 中把 8192 项有效前缀复制进来。
        sources = (
            miss_sources_out.unsqueeze(1) if sources is None else sources
        )
        destinations = (
            miss_destinations_out.unsqueeze(1)
            if destinations is None else destinations
        )
        counts = counts_out if counts is None else counts
        completion = measure_host(
            "completion_get_host",
            lambda: remote_ops.npu_hcomm_kvcache_pool_get_next_completion(
                channel
            ),
        )
        measure_host(
            "aicpu_io_submit_host",
            lambda: remote_ops.npu_hcomm_kvcache_io(
                packed_hbm,
                hbm_table,
                remote_table,
                sources,
                destinations,
                counts,
                ready,
                0,
            ),
        )
        measure_host(
            "aiv_scatter_submit_host",
            lambda: torch.ops.custom.npu_scatter_io_from_staging_c8.default(
                packed_hbm.view(torch.uint8).reshape(
                    hbm_blocks, BLOCK_SIZE, PACKED_BYTES
                ),
                staging,
                completion,
                hbm_table,
                destinations,
                counts,
            ),
        )

    def implicit_dba_io(iteration: int) -> torch.npu.Event:
        assert channel is not None and remote_table is not None
        assert staging is not None and ready_flags is not None
        assert miss_sources_out.dim() == 3
        io_done = torch.npu.Event()
        for group in range(2):
            begin = group * IO_UBATCH_REQUESTS
            hbm_view = hbm_table.narrow(0, begin, IO_UBATCH_REQUESTS)
            remote_view = remote_table.narrow(
                0, begin, IO_UBATCH_REQUESTS
            )
            source_view = miss_sources_out.narrow(
                0, begin, IO_UBATCH_REQUESTS
            )
            destination_view = miss_destinations_out.narrow(
                0, begin, IO_UBATCH_REQUESTS
            )
            count_view = counts_out.narrow(
                0, begin, IO_UBATCH_REQUESTS
            )
            ready_view = ready_flags[iteration].narrow(0, group, 1)
            completion = measure_host(
                f"io{group}_completion_get_host",
                lambda: remote_ops.npu_hcomm_kvcache_pool_get_next_completion(
                    channel
                ),
            )
            measure_host(
                f"io{group}_aicpu_submit_host",
                lambda: remote_ops.npu_hcomm_kvcache_io(
                    packed_hbm,
                    hbm_view,
                    remote_view,
                    source_view,
                    destination_view,
                    count_view,
                    ready_view,
                    0,
                ),
            )
            measure_host(
                f"io{group}_aiv_scatter_submit_host",
                lambda: torch.ops.custom.npu_scatter_io_from_staging_c8.default(
                    packed_hbm.view(torch.uint8).reshape(
                        hbm_blocks, BLOCK_SIZE, PACKED_BYTES
                    ),
                    staging.narrow(
                        0, 0,
                        IO_UBATCH_REQUESTS * args.misses_per_request,
                    ),
                    completion,
                    hbm_view,
                    destination_view,
                    count_view,
                ),
            )
        io_done.record()
        return io_done

    try:
        retained = []
        retained_events = []
        compute_stream = torch.npu.current_stream(device)
        io_stream = torch.npu.Stream(device=device) if use_cpu_du else None
        for iteration in range(run_count):
            profile_host_iteration = iteration >= args.warmup
            if use_cpu_du:
                npu_c8_li_cpu_du(iteration)
                assert io_stream is not None
                with torch.npu.stream(io_stream):
                    io_done = implicit_dba_io(iteration)
                measure_host(
                    "io_event_wait_submit_host",
                    lambda: compute_stream.wait_event(io_done),
                )
                retained_events.append(io_done)
            else:
                measure_host(
                    "lidu_submit_host", lambda: npu_lidu(pools[iteration])
                )
            if args.mode != "no_offload" and cpu_runtime is None:
                remote_io_and_scatter()
            retained.append(measure_host("sfa_submit_host", run_sfa))
        torch_npu.npu.synchronize()
        if cpu_runtime is not None:
            cpu_runtime.wait_all()
        if not retained or retained[-1].shape != (
            args.bs * QUERY_COUNT, args.heads, 512
        ):
            raise RuntimeError("SFA 输出 shape 异常")
        if channel is not None:
            final_counts = counts_out.cpu()
            expected_counts = torch.full_like(
                final_counts, args.misses_per_request
            )
            if not torch.equal(final_counts, expected_counts):
                raise RuntimeError(
                    "C8 LIDU/C8 LI+CPU DU 的最终 union miss 数与矩阵参数不一致："
                    f"actual={final_counts.tolist()}"
                )
            profile = remote_ops.npu_hcomm_kvcache_pool_get_profile(channel)
            words = profile.cpu().view(torch.uint64).reshape(-1, 16)
            records = words[(words[:, 0] != 0) & (words[:, 1] == 1)]
            expected_records = run_count * (2 if use_cpu_du else 1)
            if records.size(0) < expected_records:
                raise RuntimeError(
                    f"AICPU profile 只有 {records.size(0)} 条，"
                    f"期望至少 {expected_records} 条"
                )
            if bool((records[-expected_records:, 12] != 0).any()):
                raise RuntimeError("检测到 AICPU local scatter，违反 IO-only 约束")
        lidu_impl = (
            "official_c8_li_implicit_dba_cpu_du" if use_cpu_du
            else "ops_a5_2802bdd"
        )
        host_profile = {}
        for stage, samples in sorted(host_samples.items()):
            if len(samples) != args.iterations:
                raise RuntimeError(
                    f"Host profiling 样本数错误：stage={stage} "
                    f"actual={len(samples)} expected={args.iterations}"
                )
            host_profile[f"{stage}_p50_us"] = statistics.median(samples)
            host_profile[f"{stage}_p90_us"] = sorted(samples)[
                math.ceil(0.9 * len(samples)) - 1
            ]
        if cpu_runtime is not None:
            request_profile, group_profile = cpu_runtime.profile_records()
            measured_requests = request_profile[args.warmup :]
            du_us = (
                measured_requests[:, :, 3] - measured_requests[:, :, 2]
            ).reshape(-1).to(torch.float64) / 1000.0
            poll_wait_us = (
                measured_requests[:, :, 1] - measured_requests[:, :, 0]
            ).reshape(-1).to(torch.float64) / 1000.0
            group_skew_us = (
                group_profile[args.warmup :, 1]
                - group_profile[args.warmup :, 0]
            ).to(torch.float64) / 1000.0
            host_profile["cpu_topk_poll_wait_p50_us"] = float(
                poll_wait_us.median().item()
            )
            host_profile["cpu_topk_poll_wait_p90_us"] = float(
                torch.quantile(poll_wait_us, 0.9).item()
            )
            host_profile["cpu_du_request_p50_us"] = float(
                du_us.median().item()
            )
            host_profile["cpu_du_request_p90_us"] = float(
                torch.quantile(du_us, 0.9).item()
            )
            host_profile["io_group1_minus_group0_ready_p50_us"] = float(
                group_skew_us.median().item()
            )
        print(
            "REMOTE_OFFLOAD_HOST_PROFILE_JSON "
            + json.dumps(host_profile, sort_keys=True),
            flush=True,
        )
        print(
            "REMOTE_OFFLOAD_656_WORKLOAD_OK "
            f"mode={args.mode} bs={args.bs} mtp_draft_tokens=3 "
            f"query_count=4 sparse_tokens=2048 dense_tail_tokens=256 "
            f"candidate_seqlen={args.candidate_seqlen} "
            f"misses_per_request={args.misses_per_request} "
            f"warmup={args.warmup} iterations={args.iterations} "
            f"event_timing=0 aicpu_scatter=0 "
            f"cpu_du_threads={cpu_threads if cpu_runtime is not None else 0} "
            f"cpu_du_persistent={int(cpu_runtime is not None)} "
            "graph_capture=0 graph_safe=0 "
            "explicit_npu_host_sync=0 "
            f"aicpu_profile_verified={int(channel is not None)} io_bytes=656 "
            "max_subios_per_wqe=0 fixed_wqe_bytes=0 "
            f"io_ubatch_requests={IO_UBATCH_REQUESTS if use_cpu_du else 0} "
            f"aicpu_io_calls_per_iteration={2 if use_cpu_du else int(channel is not None)} "
            f"lidu_impl={lidu_impl} li_dtype=fp8_e4m3fn li_mtp3=1",
            flush=True,
        )
    finally:
        if channel is not None:
            torch_npu.npu.synchronize()
            remote_ops.npu_hcomm_kvcache_pool_disconnect_raw(channel)


if __name__ == "__main__":
    run()
