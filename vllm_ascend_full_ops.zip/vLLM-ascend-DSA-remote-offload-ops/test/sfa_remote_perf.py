#!/usr/bin/env python3
"""Dual-stream event comparison of swapped-DRAM and raw-URMA SFA.

Start urma_mock_pool with ``--pool-pattern bf16``.  Its default ``bytes``
pattern remains reserved for the original raw-URMA smoke/performance tests.
The test checks gathered BF16 bytes, attention output, and scattered HBM rows
before reporting performance.
"""

import math
import statistics
import time

import torch
import torch_npu

from _common import BLOCK_SIZE, COPY_CAP, K_ROPE_DIM, KV_CACHE_DIM, load_new_ops


# ---- machine-specific configuration ----
DEVICE = "npu:0"
DEVICE_EID = "00000000000000000000000000000000"
DEVICE_PHY_ID = 0
POOL_IP = "127.0.0.1"
CONTROL_PORT = 19090
RAW_LANES = 1
# ----------------------------------------

BATCH_SIZES = (1, 8, 16, 32, 64)
MISS_TOKENS = (100, 200, 400)
WARMUP = 5
ITERS = 20
DTYPE = torch.bfloat16
HEADS = 8
SPARSE_TOKENS = 2048
TAIL_TOKENS = 256
REMOTE_BANKS = 4
SEED = 2026

TOKEN_BYTES = (KV_CACHE_DIM + K_ROPE_DIM) * 2
BLOCK_BYTES = BLOCK_SIZE * TOKEN_BYTES
CACHE_TOKENS = SPARSE_TOKENS
CACHE_BLOCKS = math.ceil(
    (CACHE_TOKENS + TAIL_TOKENS) / BLOCK_SIZE
)
SOURCE_BLOCKS = SPARSE_TOKENS // BLOCK_SIZE
MAX_HBM_BLOCKS = max(BATCH_SIZES) * CACHE_BLOCKS
MOCK_STAGING_BYTES = (
    max(BATCH_SIZES) * max(MISS_TOKENS) * TOKEN_BYTES
)


def swapped_zeros(shape, device):
    tensor = torch_npu.empty_with_swapped_memory(
        shape, dtype=DTYPE, device=device
    )
    tensor.zero_()
    return tensor


def make_case(device, pool_gva, pool_blocks, batch, misses):
    generator = torch.Generator().manual_seed(
        SEED + batch * 1000 + misses
    )
    hbm_table = torch.arange(
        batch * CACHE_BLOCKS, dtype=torch.int32
    ).reshape(batch, CACHE_BLOCKS)
    dram_table = torch.arange(
        batch * SOURCE_BLOCKS, dtype=torch.int32
    ).reshape(batch, SOURCE_BLOCKS)

    sparse = torch.empty(
        (batch, SPARSE_TOKENS), dtype=torch.int32
    )
    source = torch.full(
        (batch, SPARSE_TOKENS), -1, dtype=torch.int32
    )
    hcomm_source = torch.full(
        (batch, 1, COPY_CAP), -1, dtype=torch.int32
    )
    hcomm_destination = torch.full(
        (batch, 1, COPY_CAP), -1, dtype=torch.int32
    )
    for row in range(batch):
        sparse[row] = torch.randperm(
            CACHE_TOKENS, generator=generator
        )[:SPARSE_TOKENS].to(torch.int32)
        source[row, :misses] = torch.randperm(
            SPARSE_TOKENS, generator=generator
        )[:misses].to(torch.int32)
        hcomm_source[row, 0, :misses] = source[row, :misses]
        hcomm_destination[row, 0, :SPARSE_TOKENS] = sparse[row]

    blocks_per_bank = batch * SOURCE_BLOCKS
    banks = min(REMOTE_BANKS, pool_blocks // blocks_per_bank)
    if banks == 0:
        raise RuntimeError(
            f"remote pool has {pool_blocks} blocks; "
            f"case needs {blocks_per_bank}"
        )
    remote_tables = []
    for bank in range(banks):
        first = bank * blocks_per_bank
        addresses = pool_gva + (
            torch.arange(blocks_per_bank, dtype=torch.int64) +
            first
        ) * BLOCK_BYTES
        remote_tables.append(
            addresses.reshape(batch, SOURCE_BLOCKS)
            .to(torch.uint64)
            .to(device)
        )

    return {
        "query": torch.randn(
            (batch, HEADS, KV_CACHE_DIM),
            dtype=torch.float32,
        ).to(DTYPE).to(device),
        "query_rope": torch.randn(
            (batch, HEADS, K_ROPE_DIM),
            dtype=torch.float32,
        ).to(DTYPE).to(device),
        "sparse_cpu": sparse,
        "sparse": sparse[:, None, :].to(device),
        "cache_tokens": torch.full(
            (batch,), CACHE_TOKENS,
            dtype=torch.int32, device=device,
        ),
        "hbm_table": hbm_table.to(device),
        "dram_table": dram_table.to(device),
        "actual_q": torch.arange(
            1, batch + 1, dtype=torch.int32, device=device
        ),
        "actual_kv": torch.full(
            (batch,), CACHE_TOKENS + TAIL_TOKENS,
            dtype=torch.int32, device=device,
        ),
        "source_cpu": source,
        "source": source.to(device),
        "hcomm_source": hcomm_source.to(device),
        "hcomm_destination": hcomm_destination.to(device),
        "counts": torch.full(
            (batch,), misses, dtype=torch.int32, device=device
        ),
        "ready": torch.ones(
            (1,), dtype=torch.int32, device=device
        ),
        "remote_tables": remote_tables,
        "dram_kpe": swapped_zeros(
            (batch * SOURCE_BLOCKS, BLOCK_SIZE, K_ROPE_DIM),
            device,
        ),
        "dram_ckv": swapped_zeros(
            (batch * SOURCE_BLOCKS, BLOCK_SIZE, KV_CACHE_DIM),
            device,
        ),
    }


def measure(operation, prepare=None):
    for index in range(WARMUP):
        if prepare is not None:
            prepare(index)
        operation(index)
    torch_npu.npu.synchronize()
    samples = []
    for index in range(ITERS):
        if prepare is not None:
            prepare(WARMUP + index)
        begin = torch.npu.Event(enable_timing=True)
        end = torch.npu.Event(enable_timing=True)
        begin.record()
        operation(WARMUP + index)
        end.record()
        end.synchronize()
        samples.append(float(begin.elapsed_time(end)))
    return statistics.mean(samples)


def measure_remote(
    hcomm_operation,
    attention_operation,
    prepare,
    comm_stream,
    compute_stream,
):
    for index in range(WARMUP):
        prepare(index)
        with torch.npu.stream(comm_stream):
            hcomm_operation(index)
        with torch.npu.stream(compute_stream):
            attention_operation(index)
    torch_npu.npu.synchronize()

    total_samples = []
    hcomm_device_samples = []
    attention_device_samples = []
    hcomm_host_samples = []
    attention_host_samples = []
    for index in range(ITERS):
        prepare(WARMUP + index)
        begin = torch.npu.Event(enable_timing=True)
        hcomm_begin = torch.npu.Event(enable_timing=True)
        hcomm_end = torch.npu.Event(enable_timing=True)
        attention_begin = torch.npu.Event(enable_timing=True)
        end = torch.npu.Event(enable_timing=True)

        with torch.npu.stream(compute_stream):
            begin.record()
        with torch.npu.stream(comm_stream):
            hcomm_begin.record()
            host_begin = time.perf_counter_ns()
            hcomm_operation(WARMUP + index)
            host_hcomm_done = time.perf_counter_ns()
            hcomm_end.record()
        with torch.npu.stream(compute_stream):
            attention_begin.record()
            host_attention_begin = time.perf_counter_ns()
            attention_operation(WARMUP + index)
            host_attention_done = time.perf_counter_ns()
            end.record()
        end.synchronize()
        hcomm_end.synchronize()

        total_samples.append(float(begin.elapsed_time(end)))
        hcomm_device_samples.append(
            float(hcomm_begin.elapsed_time(hcomm_end))
        )
        attention_device_samples.append(
            float(attention_begin.elapsed_time(end))
        )
        hcomm_host_samples.append(
            (host_hcomm_done - host_begin) / 1.0e3
        )
        attention_host_samples.append(
            (host_attention_done - host_attention_begin) / 1.0e3
        )

    return {
        "total_ms": statistics.mean(total_samples),
        "hcomm_device_ms": statistics.mean(hcomm_device_samples),
        "attention_device_ms": statistics.mean(
            attention_device_samples
        ),
        "hcomm_host_us": statistics.mean(hcomm_host_samples),
        "attention_host_us": statistics.mean(
            attention_host_samples
        ),
    }


def validate_staging_pattern(
    staging, source_cpu, batch, misses, bank
):
    entry_count = batch * misses
    raw = staging.narrow(
        0, 0, entry_count * TOKEN_BYTES
    ).cpu().reshape(entry_count, KV_CACHE_DIM + K_ROPE_DIM, 2)
    sources = source_cpu[:, :misses].reshape(-1).to(torch.int64)
    rows = torch.arange(
        batch, dtype=torch.int64
    ).repeat_interleave(misses)
    blocks_per_bank = batch * SOURCE_BLOCKS
    blocks = (
        bank * blocks_per_bank
        + rows * SOURCE_BLOCKS
        + sources // BLOCK_SIZE
    )
    tokens = sources % BLOCK_SIZE
    dimensions = torch.arange(
        KV_CACHE_DIM + K_ROPE_DIM, dtype=torch.int64
    )
    planes = (dimensions >= KV_CACHE_DIM).to(torch.int64)
    plane_dimensions = dimensions - planes * KV_CACHE_DIM
    mask = 0xFFFFFFFF
    checksum = 0

    for begin in range(0, entry_count, 1024):
        end = min(entry_count, begin + 1024)
        block = blocks[begin:end, None]
        token = tokens[begin:end, None]
        hash_value = (
            ((block * 0x9E3779B1) & mask)
            ^ ((token * 0x85EBCA6B) & mask)
            ^ ((plane_dimensions[None, :] * 0xC2B2AE35) & mask)
            ^ ((planes[None, :] * 0x27D4EB2F) & mask)
        )
        hash_value ^= hash_value >> 16
        expected = (
            ((hash_value >> 31) << 15)
            | (122 << 7)
            | ((hash_value >> 8) & 0x7F)
        )
        actual_bytes = raw[begin:end].to(torch.int64)
        actual = (
            actual_bytes[:, :, 0]
            | (actual_bytes[:, :, 1] << 8)
        )
        if not torch.equal(actual, expected):
            mismatch = (actual != expected).nonzero()[0]
            row = begin + int(mismatch[0])
            dim = int(mismatch[1])
            raise RuntimeError(
                "remote staging mismatch at "
                f"entry={row} dim={dim}: "
                f"actual=0x{int(actual[mismatch[0], dim]):04x} "
                f"expected=0x{int(expected[mismatch[0], dim]):04x}"
            )
        checksum += int(actual.sum())
    return checksum


def main():
    ops = load_new_ops()
    device = torch.device(DEVICE)
    torch_npu.npu.set_device(device)
    compute_stream = torch.npu.current_stream(device)
    comm_stream = torch.npu.Stream(device=device)
    scale = 1.0 / math.sqrt(KV_CACHE_DIM + K_ROPE_DIM)

    remote_kpe = torch.zeros(
        (MAX_HBM_BLOCKS, BLOCK_SIZE, 1, K_ROPE_DIM),
        dtype=DTYPE, device=device,
    )
    remote_ckv = torch.zeros(
        (MAX_HBM_BLOCKS, BLOCK_SIZE, 1, KV_CACHE_DIM),
        dtype=DTYPE, device=device,
    )
    swap_kpe = remote_kpe.clone()
    swap_ckv = remote_ckv.clone()
    mock_staging = torch.zeros(
        (MOCK_STAGING_BYTES,), dtype=torch.uint8, device=device,
    )
    mock_ready_words = torch.tensor(
        [1, 1, 0, 0, 0, 0, 0, 0], dtype=torch.int64,
    ).view(torch.uint8).to(device)
    mock_completion = mock_ready_words.clone()
    channel = ops.npu_hcomm_kvcache_pool_connect_raw(
        DEVICE_EID,
        DEVICE_PHY_ID,
        POOL_IP,
        CONTROL_PORT,
        remote_kpe,
        remote_ckv,
        RAW_LANES,
        100,
        True,
        False,
        True,
    )
    _, _, pool_gva, pool_bytes = (
        ops.npu_hcomm_kvcache_pool_get_raw_context(channel)
    )
    torch_npu.npu.synchronize()
    pool_blocks = pool_bytes // BLOCK_BYTES
    print(
        f"SFA_REMOTE_CONNECTED channel=0x{channel:x} "
        f"pool_gva=0x{pool_gva:x} pool_blocks={pool_blocks} "
        "schedule=dual_stream_memory_handshake",
        flush=True,
    )

    for batch in BATCH_SIZES:
        for misses in MISS_TOKENS:
            case = make_case(
                device, pool_gva, pool_blocks, batch, misses
            )

            def swap_step(_):
                torch_npu.npu_sparse_and_tail_attention_and_scatter_copy(
                    case["query"],
                    swap_ckv,
                    case["sparse"],
                    case["cache_tokens"],
                    case["hbm_table"],
                    case["actual_q"],
                    case["actual_kv"],
                    case["query_rope"],
                    swap_kpe,
                    case["dram_kpe"],
                    case["dram_ckv"],
                    case["dram_table"],
                    case["source"],
                    case["counts"],
                    scale,
                )

            def remote_hcomm_step(iteration):
                table = case["remote_tables"][
                    iteration % len(case["remote_tables"])
                ]
                ops.npu_hcomm_kvcache_scatter_copy(
                    remote_kpe,
                    remote_ckv,
                    case["hbm_table"],
                    table,
                    case["hcomm_source"],
                    case["hcomm_destination"],
                    case["counts"],
                    case["ready"],
                    0,
                )

            def remote_attention_step(_):
                return torch_npu.npu_sparse_and_tail_attention_and_remote_scatter_copy(
                    case["query"],
                    remote_ckv,
                    case["sparse"],
                    case["cache_tokens"],
                    case["hbm_table"],
                    case["actual_q"],
                    case["actual_kv"],
                    case["query_rope"],
                    remote_kpe,
                    case["counts"],
                    scale,
                )

            def prepare_remote(_):
                completion = (
                    ops.npu_hcomm_kvcache_pool_get_next_completion(
                        channel
                    )
                )
                with torch.npu.stream(compute_stream):
                    completion.zero_()
                # Request-to-request cleanup stays outside the timed region.
                # No event orders the following Hcomm and SFA kernels.
                torch_npu.npu.synchronize()

            def prepare_ready_mock(_):
                mock_completion.copy_(mock_ready_words)

            def ready_mock_step(_):
                return torch_npu.npu_sparse_and_tail_attention_and_remote_scatter_copy_ready(
                    case["query"],
                    remote_ckv,
                    case["sparse"],
                    case["cache_tokens"],
                    case["hbm_table"],
                    case["actual_q"],
                    case["actual_kv"],
                    case["query_rope"],
                    remote_kpe,
                    mock_staging,
                    mock_completion,
                    case["counts"],
                    scale,
                )

            remote_kpe.zero_()
            remote_ckv.zero_()
            swap_kpe.zero_()
            swap_ckv.zero_()
            torch_npu.npu.synchronize()
            prepare_remote(0)
            with torch.npu.stream(comm_stream):
                remote_hcomm_step(0)
            with torch.npu.stream(compute_stream):
                remote_result = remote_attention_step(0)
            torch_npu.npu.synchronize()

            staging = ops.npu_hcomm_kvcache_pool_get_staging(
                channel
            )
            staging_checksum = validate_staging_pattern(
                staging, case["source_cpu"], batch, misses, 0
            )
            prepare_ready_mock(0)
            with torch.npu.stream(compute_stream):
                reference_result = (
                    torch_npu.npu_sparse_and_tail_attention_and_remote_scatter_copy_ready(
                        case["query"],
                        swap_ckv,
                        case["sparse"],
                        case["cache_tokens"],
                        case["hbm_table"],
                        case["actual_q"],
                        case["actual_kv"],
                        case["query_rope"],
                        swap_kpe,
                        staging,
                        mock_completion,
                        case["counts"],
                        scale,
                    )
                )
            torch_npu.npu.synchronize()
            if not torch.equal(
                remote_result[0].cpu(), reference_result[0].cpu()
            ):
                raise RuntimeError(
                    "remote SFA output differs from ready-staging replay"
                )
            destination_slots = (
                case["sparse_cpu"][:, :misses]
                .reshape(-1)
                .to(torch.int64)
            )
            destination_rows = torch.arange(
                batch, dtype=torch.int64
            ).repeat_interleave(misses)
            destination_blocks = (
                destination_rows * CACHE_BLOCKS
                + destination_slots // BLOCK_SIZE
            )
            destination_linear = (
                destination_blocks * BLOCK_SIZE
                + destination_slots % BLOCK_SIZE
            ).to(device)
            remote_ckv_rows = remote_ckv.reshape(
                -1, KV_CACHE_DIM
            ).index_select(0, destination_linear).cpu()
            reference_ckv_rows = swap_ckv.reshape(
                -1, KV_CACHE_DIM
            ).index_select(0, destination_linear).cpu()
            remote_kpe_rows = remote_kpe.reshape(
                -1, K_ROPE_DIM
            ).index_select(0, destination_linear).cpu()
            reference_kpe_rows = swap_kpe.reshape(
                -1, K_ROPE_DIM
            ).index_select(0, destination_linear).cpu()
            if (
                not torch.equal(remote_ckv_rows, reference_ckv_rows)
                or not torch.equal(remote_kpe_rows, reference_kpe_rows)
            ):
                raise RuntimeError(
                    "remote SFA HBM scatter differs from "
                    "ready-staging replay"
                )
            print(
                f"SFA_REMOTE_CHECK bs={batch} misses={misses} "
                f"staging_checksum={staging_checksum} "
                f"output=exact cache=exact",
                flush=True,
            )

            remote_kpe.zero_()
            remote_ckv.zero_()
            swap_kpe.zero_()
            swap_ckv.zero_()
            torch_npu.npu.synchronize()
            swap_ms = measure(swap_step)
            ready_mock_ms = measure(
                ready_mock_step, prepare_ready_mock
            )
            remote_stats = measure_remote(
                remote_hcomm_step,
                remote_attention_step,
                prepare_remote,
                comm_stream,
                compute_stream,
            )
            remote_ms = remote_stats["total_ms"]
            payload = batch * misses * TOKEN_BYTES
            swap_gbps = payload / swap_ms / 1.0e6
            ready_mock_gbps = payload / ready_mock_ms / 1.0e6
            remote_gbps = payload / remote_ms / 1.0e6
            print(
                f"SFA_REMOTE_PERF bs={batch} misses={misses} "
                f"bytes={payload} swap_ms={swap_ms:.4f} "
                f"swap_GBs={swap_gbps:.3f} "
                f"ready_mock_ms={ready_mock_ms:.4f} "
                f"ready_mock_GBs={ready_mock_gbps:.3f} "
                f"urma_ms={remote_ms:.4f} "
                f"urma_GBs={remote_gbps:.3f} "
                f"urma_hcomm_ms="
                f"{remote_stats['hcomm_device_ms']:.4f} "
                f"urma_sfa_wait_ms="
                f"{remote_stats['attention_device_ms']:.4f} "
                f"host_hcomm_call_us="
                f"{remote_stats['hcomm_host_us']:.1f} "
                f"host_sfa_call_us="
                f"{remote_stats['attention_host_us']:.1f} "
                f"speedup={swap_ms / remote_ms:.3f}",
                flush=True,
            )


if __name__ == "__main__":
    main()
