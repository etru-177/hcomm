#!/usr/bin/env python3
"""供 msprof 驱动的 A5 C8 MTP LIDU 单算子工作负载。"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "torch_extension"))

import torch
import torch_npu  # noqa: F401

import kvcache_scatter_copy_custom_ops  # noqa: F401

from _lidu_utils import MAX_CACHE_TOKENS
from _utils import require_a5
from test_fused_li_manage_mtp_c8 import (
    TOPK,
    UNION_CAPACITY,
    launch_out,
    make_case,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", default="npu:0")
    parser.add_argument("--bs", type=int, default=32)
    parser.add_argument("--heads", type=int, choices=(32, 64), default=32)
    parser.add_argument("--source-len", type=int, default=131072)
    parser.add_argument(
        "--queries-per-request", type=int, choices=(4,), default=4
    )
    parser.add_argument("--cache-budget", type=int, default=8192)
    parser.add_argument("--misses", type=int, required=True)
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--iterations", type=int, default=50)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--allow-non-a5", action="store_true")
    args = parser.parse_args()
    if args.bs <= 0:
        parser.error("--bs 必须为正")
    if args.source_len <= 0 or args.source_len % 128:
        parser.error("--source-len 必须是正的 128 倍数")
    if not (
        args.queries_per_request * TOPK
        <= args.cache_budget
        <= MAX_CACHE_TOKENS
    ):
        parser.error("--cache-budget 必须覆盖全部 MTP TopK union 且不超过 16256")
    if args.cache_budget % 128:
        parser.error("--cache-budget 必须是 128 的倍数")
    if not 0 <= args.misses <= min(
        UNION_CAPACITY, args.source_len - args.cache_budget
    ):
        parser.error("--misses 超出当前 source/cache 可构造范围")
    if args.warmup < 0 or args.iterations <= 0:
        parser.error("--warmup 必须非负且 --iterations 必须为正")
    return args


def main() -> None:
    args = parse_args()
    device = torch.device(args.device)
    if device.type != "npu":
        raise ValueError("--device 必须选择 NPU")
    torch.npu.set_device(device)
    torch.npu.config.allow_internal_format = False
    require_a5(device, args.allow_non_a5)

    case = make_case(
        device=device,
        batch=args.bs,
        heads=args.heads,
        source_len=args.source_len,
        query_counts=[args.queries_per_request] * args.bs,
        budgets=[args.cache_budget] * args.bs,
        miss_range=(args.misses, args.misses),
        pool_extra=7,
        seed=args.seed,
    )
    packed_t = args.bs * args.queries_per_request
    pool = case.initial_pool.clone()
    topk_slots = torch.empty(
        (packed_t, 1, TOPK), dtype=torch.int32, device=device
    )
    topk_sources = torch.empty_like(topk_slots)
    topk_miss_counts = torch.empty(
        (packed_t,), dtype=torch.int32, device=device
    )
    miss_sources = torch.empty(
        (args.bs, UNION_CAPACITY), dtype=torch.int32, device=device
    )
    miss_slots = torch.empty_like(miss_sources)
    miss_counts = torch.empty((args.bs,), dtype=torch.int32, device=device)

    # pool restore 在算子计时区之外；msprof parser 只选择
    # A5FusedLiManageMtpC8 task，因此无需引入 Event。
    for _ in range(args.warmup + args.iterations):
        pool.copy_(case.initial_pool)
        launch_out(
            case,
            pool,
            topk_slots,
            miss_sources,
            miss_slots,
            miss_counts,
            topk_sources,
            topk_miss_counts,
        )
    torch.npu.synchronize()
    expected = torch.full_like(miss_counts, args.misses)
    if not torch.equal(miss_counts.cpu(), expected.cpu()):
        raise RuntimeError(
            "C8 MTP LIDU union miss 数错误："
            f"actual={miss_counts.cpu().tolist()} expected={args.misses}"
        )
    print(
        "C8_MTP_LIDU_PERF_WORKLOAD_OK "
        f"bs={args.bs} queries={args.queries_per_request} "
        f"source_len={args.source_len} cache_budget={args.cache_budget} "
        f"misses={args.misses} warmup={args.warmup} "
        f"iterations={args.iterations} timer=msprof_task_time "
        "lidu_impl=ops_a5_2802bdd optimization_stage=4",
        flush=True,
    )


if __name__ == "__main__":
    main()
