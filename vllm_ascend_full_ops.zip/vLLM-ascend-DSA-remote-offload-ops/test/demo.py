#!/usr/bin/env python3

"""Minimal end-to-end demo for the AI CPU KvcacheScatterCopy operator."""

import argparse

import torch
import torch_npu

from _common import BLOCK_SIZE, COPY_CAP, K_ROPE_DIM, KV_CACHE_DIM, call_new, load_new_ops


def make_token_tensor(block_count, token_dim, value_offset, dtype):
    """Give every physical token a distinct, constant payload."""
    token_count = block_count * BLOCK_SIZE
    values = torch.arange(token_count, dtype=torch.float32).add_(value_offset)
    return (
        values.view(block_count, BLOCK_SIZE, 1)
        .expand(block_count, BLOCK_SIZE, token_dim)
        .to(dtype)
        .contiguous()
    )


def to_swapped_memory(cpu_tensor, device):
    swapped = torch_npu.empty_with_swapped_memory(
        cpu_tensor.shape,
        dtype=cpu_tensor.dtype,
        device=device,
    )
    swapped.fill_(0)
    swapped.add_(cpu_tensor.to(device))
    return swapped


def parse_dtype(name):
    if name == "bf16":
        return torch.bfloat16
    if name == "fp16":
        return torch.float16
    raise ValueError(f"unsupported dtype: {name}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", default="npu:0")
    parser.add_argument("--dtype", choices=("bf16", "fp16"), default="bf16")
    parser.add_argument(
        "--without-ready-flag",
        action="store_true",
        help="call the operator without its optional completion flag",
    )
    parser.add_argument(
        "--zero-copy",
        action="store_true",
        help="submit copy_counts=[0] to validate AICPU dispatch without touching swapped memory",
    )
    args = parser.parse_args()

    load_new_ops()
    device = torch.device(args.device)
    torch.npu.set_device(device)
    dtype = parse_dtype(args.dtype)

    # Logical blocks are deliberately mapped to the opposite physical blocks.
    # This makes the demo exercise both source and destination block tables.
    block_count = 2
    dram_block_table_cpu = torch.tensor([[1, 0]], dtype=torch.uint64)
    hbm_block_table_cpu = torch.tensor([[1, 0]], dtype=torch.int32)

    dram_k_rope_cpu = make_token_tensor(block_count, K_ROPE_DIM, 10, dtype)
    dram_kv_cache_cpu = make_token_tensor(block_count, KV_CACHE_DIM, 1000, dtype)
    hbm_k_rope_cpu = torch.full(
        (block_count, BLOCK_SIZE, K_ROPE_DIM), -1, dtype=dtype
    )
    hbm_kv_cache_cpu = torch.full(
        (block_count, BLOCK_SIZE, KV_CACHE_DIM), -1, dtype=dtype
    )
    expected_k_rope = hbm_k_rope_cpu.clone()
    expected_kv_cache = hbm_kv_cache_cpu.clone()

    # logical src 1   -> DRAM physical token 129
    # logical src 129 -> DRAM physical token 1
    # logical dst 2   -> HBM physical token 130
    # logical dst 130 -> HBM physical token 2
    src_tokens = () if args.zero_copy else (1, 129)
    dst_slots_active = () if args.zero_copy else (2, 130)
    for src_token, dst_slot in zip(src_tokens, dst_slots_active):
        src_block = int(dram_block_table_cpu[0, src_token // BLOCK_SIZE])
        dst_block = int(hbm_block_table_cpu[0, dst_slot // BLOCK_SIZE])
        src_offset = src_token % BLOCK_SIZE
        dst_offset = dst_slot % BLOCK_SIZE
        expected_k_rope[dst_block, dst_offset].copy_(
            dram_k_rope_cpu[src_block, src_offset]
        )
        expected_kv_cache[dst_block, dst_offset].copy_(
            dram_kv_cache_cpu[src_block, src_offset]
        )

    src_token_ids = torch.full((1, 1, COPY_CAP), -1, dtype=torch.int32)
    dst_slots = torch.full((1, 1, COPY_CAP), -1, dtype=torch.int32)
    src_token_ids[0, 0, : len(src_tokens)] = torch.tensor(
        src_tokens, dtype=torch.int32
    )
    dst_slots[0, 0, : len(dst_slots_active)] = torch.tensor(
        dst_slots_active, dtype=torch.int32
    )

    case = {
        "hbm_k_rope": hbm_k_rope_cpu.to(device),
        "hbm_kv_cache": hbm_kv_cache_cpu.to(device),
        "dram_k_rope": to_swapped_memory(dram_k_rope_cpu, device),
        "dram_kv_cache": to_swapped_memory(dram_kv_cache_cpu, device),
        "hbm_block_table": hbm_block_table_cpu.to(device),
        "dram_block_table": dram_block_table_cpu.to(device),
        "src_token_ids": src_token_ids.to(device),
        "dst_slots": dst_slots.to(device),
        "copy_counts": torch.tensor(
            [len(src_tokens)], dtype=torch.int32, device=device
        ),
    }
    ready_flag = None
    if not args.without_ready_flag:
        ready_flag = torch.full((1,), -1, dtype=torch.int32, device=device)

    call_new(case, ready_flag, layer_id=7)
    torch.npu.synchronize()

    actual_k_rope = case["hbm_k_rope"].cpu()
    actual_kv_cache = case["hbm_kv_cache"].cpu()
    if not torch.equal(actual_k_rope, expected_k_rope):
        raise AssertionError("K-RoPE cache differs from the reference result")
    if not torch.equal(actual_kv_cache, expected_kv_cache):
        raise AssertionError("KV cache differs from the reference result")
    if ready_flag is not None and ready_flag.item() != 1:
        raise AssertionError(f"ready_flag={ready_flag.item()}, expected 1")

    print(f"device={device} dtype={args.dtype}")
    if args.zero_copy:
        print("zero-copy smoke test: AICPU dispatched without an Hcomm request")
    else:
        print("copied logical tokens: 1 -> 2, 129 -> 130")
        print("source physical tokens: 129, 1")
        print("destination physical tokens: 130, 2")
    if ready_flag is not None:
        print(f"ready_flag={ready_flag.item()}")
    print("KVCACHE_SCATTER_COPY_DEMO_OK")


if __name__ == "__main__":
    main()
