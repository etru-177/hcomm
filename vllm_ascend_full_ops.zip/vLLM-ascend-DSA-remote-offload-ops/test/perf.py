#!/usr/bin/env python3

import argparse
import gc
import statistics

import torch

from _common import BYTES_PER_TOKEN, call_new, load_new_ops, make_case, parse_dtype


DEFAULT_CASES = "24x205,24x499,1x6144,1x10240,1x12288"


def parse_cases(value):
    cases = []
    for item in value.split(","):
        item = item.strip().lower()
        if not item:
            continue
        parts = item.split("x")
        if len(parts) != 2:
            raise ValueError(f"invalid case {item!r}; expected BxCOPY_COUNT")
        batch_size, copy_count = (int(part) for part in parts)
        if batch_size <= 0:
            raise ValueError("batch size must be positive")
        if copy_count < 0 or copy_count > 16384:
            raise ValueError("copy count must be in [0, 16384]")
        cases.append((batch_size, copy_count))
    if not cases:
        raise ValueError("at least one performance case is required")
    return cases


def benchmark_case(args, device, batch_size, copy_count, seed):
    dtype = parse_dtype(args.dtype)
    counts = [copy_count] * batch_size
    case = make_case(
        counts,
        dtype,
        device,
        seed=seed,
        logical_tokens=max(copy_count, 640),
        sequential_dest=True,
    )

    for _ in range(args.warmup):
        call_new(case)
    torch.npu.synchronize()

    iters = args.first_fill_iters if copy_count > 499 else args.iters
    times_ms = []
    for _ in range(iters):
        start = torch.npu.Event(enable_timing=True)
        end = torch.npu.Event(enable_timing=True)
        start.record()
        call_new(case)
        end.record()
        end.synchronize()
        times_ms.append(float(start.elapsed_time(end)))

    avg_ms = statistics.mean(times_ms)
    total_tokens = sum(counts)
    payload_bytes = total_tokens * BYTES_PER_TOKEN
    bandwidth_gbps = 0.0 if avg_ms == 0.0 else payload_bytes / (avg_ms / 1000.0) / 1.0e9
    result = {
        "batch_size": batch_size,
        "copy_count": copy_count,
        "total_tokens": total_tokens,
        "payload_bytes": payload_bytes,
        "avg_ms": avg_ms,
        "bandwidth_gbps": bandwidth_gbps,
        "iters": iters,
    }

    del case
    gc.collect()
    torch.npu.empty_cache()
    return result


def main():
    parser = argparse.ArgumentParser(description="Benchmark KvcacheScatterCopy host-DRAM to HBM bandwidth.")
    parser.add_argument("--device", default="npu:0")
    parser.add_argument("--dtype", choices=("bf16", "fp16"), default="bf16")
    parser.add_argument("--cases", default=DEFAULT_CASES, help="comma-separated BxCOPY_COUNT cases")
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--iters", type=int, default=100)
    parser.add_argument("--first-fill-iters", type=int, default=20)
    parser.add_argument("--min-bandwidth-gbps", type=float, default=40.0)
    parser.add_argument("--no-bandwidth-gate", action="store_true")
    parser.add_argument("--seed", type=int, default=2026)
    args = parser.parse_args()

    if args.warmup < 0 or args.iters <= 0 or args.first_fill_iters <= 0:
        raise ValueError("warmup must be non-negative and iteration counts must be positive")
    if args.min_bandwidth_gbps < 0.0:
        raise ValueError("min-bandwidth-gbps must be non-negative")

    load_new_ops()
    device = torch.device(args.device)
    torch.npu.set_device(device)
    cases = parse_cases(args.cases)
    failures = []

    print(
        f"PERF_CONFIG dtype={args.dtype} bytes_per_token={BYTES_PER_TOKEN} "
        "source=swapped_host_dram destination=hbm",
        flush=True,
    )
    for case_idx, (batch_size, copy_count) in enumerate(cases):
        result = benchmark_case(args, device, batch_size, copy_count, args.seed + case_idx)
        is_gated = 0 < copy_count < 500
        print(
            "PERF_RESULT "
            f"bsz={result['batch_size']} copy_count={result['copy_count']} "
            f"total_tokens={result['total_tokens']} payload_bytes={result['payload_bytes']} "
            f"avg_ms={result['avg_ms']:.6f} avg_bandwidth_GBps={result['bandwidth_gbps']:.2f} "
            f"iters={result['iters']} gated={int(is_gated)}",
            flush=True,
        )
        if is_gated and result["bandwidth_gbps"] < args.min_bandwidth_gbps:
            failures.append(result)

    if failures and not args.no_bandwidth_gate:
        detail = ", ".join(
            f"B={result['batch_size']},count={result['copy_count']}:"
            f"{result['bandwidth_gbps']:.2f}GB/s"
            for result in failures
        )
        raise SystemExit(
            f"KVCACHE_SCATTER_COPY_PERF_FAIL minimum={args.min_bandwidth_gbps:.2f}GB/s {detail}"
        )

    gate = "disabled" if args.no_bandwidth_gate else f">={args.min_bandwidth_gbps:.2f}GB/s"
    print(f"KVCACHE_SCATTER_COPY_PERF_OK gate={gate}", flush=True)


if __name__ == "__main__":
    main()
