#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="$(mktemp -d "${TMPDIR:-/tmp}/remote-offload-cpu-du.XXXXXX")"
trap 'rm -rf "${BUILD_DIR}"' EXIT

CXX_BIN="${CXX:-c++}"
COMMAND=(
  "${CXX_BIN}" -std=c++17 -O2 -Wall -Wextra -Werror
  -I"${ROOT}/host_offload"
  "${ROOT}/host_offload/cpu_du.cpp"
  "${ROOT}/test/cpu_du_host_test.cpp"
  -o "${BUILD_DIR}/cpu_du_host_test"
)

RING_COMMAND=(
  "${CXX_BIN}" -std=c++17 -O2 -Wall -Wextra -Werror
  -I"${ROOT}/host_offload"
  "${ROOT}/host_offload/offload_ring.cpp"
  "${ROOT}/test/offload_ring_host_test.cpp"
  -o "${BUILD_DIR}/offload_ring_host_test"
)

WORKER_COMMAND=(
  "${CXX_BIN}" -std=c++17 -O2 -Wall -Wextra -Werror -pthread
  -I"${ROOT}/host_offload"
  "${ROOT}/host_offload/cpu_du.cpp"
  "${ROOT}/host_offload/offload_ring.cpp"
  "${ROOT}/host_offload/cpu_du_worker.cpp"
  "${ROOT}/test/cpu_du_worker_host_test.cpp"
  -o "${BUILD_DIR}/cpu_du_worker_host_test"
)

METADATA_COMMAND=(
  "${CXX_BIN}" -std=c++17 -O2 -Wall -Wextra -Werror -pthread
  -I"${ROOT}/host_offload"
  "${ROOT}/host_offload/cpu_du.cpp"
  "${ROOT}/host_offload/metadata_store.cpp"
  "${ROOT}/test/metadata_store_host_test.cpp"
  -o "${BUILD_DIR}/metadata_store_host_test"
)

printf '复现命令:'
printf ' %q' "${COMMAND[@]}"
printf '\n'
"${COMMAND[@]}"
"${BUILD_DIR}/cpu_du_host_test"

printf '复现命令:'
printf ' %q' "${RING_COMMAND[@]}"
printf '\n'
"${RING_COMMAND[@]}"
"${BUILD_DIR}/offload_ring_host_test"

printf '复现命令:'
printf ' %q' "${WORKER_COMMAND[@]}"
printf '\n'
"${WORKER_COMMAND[@]}"
"${BUILD_DIR}/cpu_du_worker_host_test"

printf '复现命令:'
printf ' %q' "${METADATA_COMMAND[@]}"
printf '\n'
"${METADATA_COMMAND[@]}"
"${BUILD_DIR}/metadata_store_host_test"
