# 原生 Hcomm KV 内存池冒烟测试

这是散拷流程使用的集成内存池。程序创建 Host endpoint，注册包含两个 block 的
`[CKV][KPE]` 内存池，并作为 RaSocket 服务端阻塞在 `HcommChannelCreate`。Python
客户端建立对应的 AICPU channel 后，服务端只负责保持内存池和 Hcomm Jetty 资源
存活，不再运行额外的请求循环。

测试程序只显式链接 `libhccl.so`，应用代码不会直接调用 UMDK。不过在
`COMM_PROTOCOL_UBC_TP` 下，原生 Hcomm 会在运行时加载 `liburma.so.0`，并通过
所选 Host 网络地址使用 URMA provider/driver。因此必须安装匹配的 A5 UMDK
运行时和驱动，并保证动态链接器可以找到它们。

```bash
cd test/hcomm_pool_server
./build.sh
./hcomm_pool_server <host-eid> <device-eid> 60001 300 <host-device-id> <remote-device-phy-id>
```

在已经加载自定义扩展的 Python 进程中执行：

```python
torch_npu.npu_hcomm_kvcache_pool_connect(
    device_eid="<device-eid>", host_eid="<host-eid>",
    device_phy_id=<device-phy-id>, port=60001,
)
```

EID 格式为 `0123456789abcdef0123456789abcdef`，也可以在前 16 位后添加冒号。
两端都使用 `COMM_PROTOCOL_UBC_TP`、端口 `60001` 和 channel 名
`kvcache_pool`。`host-device-id` 是 `aclrtSetDevice` 使用的本地逻辑 NPU ID，
Hcomm 会据此得到 Host endpoint 的本地物理 ID；`remote-device-phy-id` 是运行
Python AICPU 客户端的 NPU 物理 ID。

连接句柄有意保持为进程生命周期状态。AICPU `HybmBatchCopy` ABI 没有 channel
参数，因此原生 Hcomm 实现根据 GVA 查找已经建立的内存池和 channel 状态。
