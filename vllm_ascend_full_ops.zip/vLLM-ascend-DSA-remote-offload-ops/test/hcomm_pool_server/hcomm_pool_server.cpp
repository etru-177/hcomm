// Minimal host pool for the native Hcomm RaSocket control path.
// The matching Python-side client creates an AICPU channel with the same
// endpoint pair, port and channel name. Hcomm exchanges the registered memory
// and Jetty resources during HcommChannelCreate; this process then only holds
// those resources alive for remote one-sided reads.

#include <acl/acl.h>
#include <hcomm/hcomm_res.h>

#include <charconv>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <thread>

namespace {
constexpr uint64_t kBlocks = 2;
constexpr uint64_t kBlockBytes = 128 * (1024 + 128);

bool SetEid(CommAddr* address, const char* eid)
{
    const size_t eidLength = std::strlen(eid);
    const bool compact = eidLength == 32;
    if (!compact && (eidLength != 33 || eid[16] != ':')) return false;
    for (size_t index = 0; index < 16; ++index) {
        const char* begin = eid + index * 2 + (!compact && index >= 8 ? 1 : 0);
        unsigned int byte = 0;
        const auto parsed = std::from_chars(begin, begin + 2, byte, 16);
        if (parsed.ec != std::errc{} || parsed.ptr != begin + 2) return false;
        address->eid[index] = static_cast<uint8_t>(byte);
    }
    address->type = COMM_ADDR_TYPE_EID;
    return true;
}
} // namespace

int main(int argc, char** argv)
{
    if (argc < 3 || argc > 7) {
        std::fprintf(stderr,
            "usage: %s <host-eid> <device-eid> [port=60001] [hold-seconds=300] "
            "[host-device-id=0] [remote-device-phy-id=0]\n",
            argv[0]);
        return 2;
    }
    const uint16_t port = argc > 3 ? static_cast<uint16_t>(std::strtoul(argv[3], nullptr, 0)) : 60001;
    const uint32_t holdSeconds = argc > 4 ? static_cast<uint32_t>(std::strtoul(argv[4], nullptr, 0)) : 300;
    const int32_t hostDeviceId = argc > 5 ? static_cast<int32_t>(std::strtol(argv[5], nullptr, 0)) : 0;
    const uint32_t remoteDevicePhyId = argc > 6 ? static_cast<uint32_t>(std::strtoul(argv[6], nullptr, 0)) : 0;
    std::printf("HCOMM_KV_POOL_START host_eid=%s device_eid=%s port=%u host_device_id=%d remote_device_phy_id=%u\n",
        argv[1], argv[2], port, hostDeviceId, remoteDevicePhyId);
    aclError aclResult = aclInit(nullptr);
    std::printf("aclInit=%d\n", aclResult);
    if (aclResult != ACL_SUCCESS) return 1;
    aclResult = aclrtSetDevice(hostDeviceId);
    std::printf("aclrtSetDevice=%d\n", aclResult);
    if (aclResult != ACL_SUCCESS) return 1;

    void* pool = nullptr;
    if (posix_memalign(&pool, 4096, kBlocks * kBlockBytes) != 0) return 1;
    std::memset(pool, 0xC0, kBlocks * kBlockBytes);

    EndpointDesc local{};
    EndpointDesc remote{};
    EndpointDescInit(&local, 1);
    EndpointDescInit(&remote, 1);
    local.protocol = COMM_PROTOCOL_UBC_TP;
    local.loc.locType = ENDPOINT_LOC_TYPE_HOST;
    local.loc.host.id = 0;
    remote.protocol = COMM_PROTOCOL_UBC_TP;
    remote.loc.locType = ENDPOINT_LOC_TYPE_DEVICE;
    remote.loc.device.devPhyId = remoteDevicePhyId;
    if (!SetEid(&local.commAddr, argv[1]) || !SetEid(&remote.commAddr, argv[2])) return 2;

    EndpointHandle endpoint = nullptr;
    HcommMemHandle memory = nullptr;
    ChannelHandle channel = 0;
    CommMem commMemory{COMM_MEM_TYPE_HOST, pool, kBlocks * kBlockBytes};
    HcommChannelDesc channelDesc{};
    HcommChannelDescInit(&channelDesc, 1);
    channelDesc.remoteEndpoint = remote;
    channelDesc.exchangeAllMems = true;
    channelDesc.role = HCOMM_SOCKET_ROLE_SERVER;
    channelDesc.port = port;
    channelDesc.channelName = "kvcache_pool";
    channelDesc.ubAttr.sqDepth = 64;
    HcommResult hcommResult = HcommEndpointCreate(&local, &endpoint);
    std::printf("HcommEndpointCreate=%d\n", hcommResult);
    if (hcommResult != 0) return 1;
    hcommResult = HcommMemReg(endpoint, "kvcache_pool", &commMemory, &memory);
    std::printf("HcommMemReg=%d\n", hcommResult);
    if (hcommResult != 0) return 1;
    hcommResult = HcommChannelCreate(endpoint, COMM_ENGINE_CPU, &channelDesc, 1, &channel);
    std::printf("HcommChannelCreate=%d\n", hcommResult);
    if (hcommResult != 0) return 1;

    std::printf("HCOMM_KV_POOL_CONNECTED\n");
    std::printf("pool_host_va=0x%llx\n", static_cast<unsigned long long>(reinterpret_cast<uintptr_t>(pool)));
    std::printf("pool_bytes=%llu\n", static_cast<unsigned long long>(kBlocks * kBlockBytes));
    std::fflush(stdout);
    std::this_thread::sleep_for(std::chrono::seconds(holdSeconds));

    (void)HcommChannelDestroy(&channel, 1);
    (void)HcommMemUnreg(endpoint, memory);
    (void)HcommEndpointDestroy(endpoint);
    std::free(pool);
    (void)aclrtResetDevice(hostDeviceId);
    (void)aclFinalize();
    return 0;
}
