#!/usr/bin/env bash
set -euo pipefail

ASCEND_HOME_PATH=/usr/local/Ascend/cann-9.1.T560/aarch64-linux
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
g++ -std=c++17 -O2 -Wall -Wextra -Werror -pthread \
  -I"${ASCEND_HOME_PATH}/include" "${ROOT}/hcomm_pool_server.cpp" \
  -L"${ASCEND_HOME_PATH}/lib64" -lc_sec -lhcomm -lhccl -lascendcl \
  -o "${ROOT}/hcomm_pool_server"
