#!/usr/bin/env python3
"""标准 BF16 NanovllmFusedLiManageMtp 单算子功能测试。"""

from __future__ import annotations

import argparse

import torch
import torch_npu

import kvcache_scatter_copy_custom_ops  # noqa: F401

from _standard_lidu_case import TOPK, make_case


MISS_CAPACITY = 16384


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", default="npu:0")
    parser.add_argument("--batch-size", type=int, default=2)
    parser.add_argument("--heads", type=int, choices=(32, 64), default=32)
    parser.add_argument("--candidate-seqlen", type=int, default=16384)
    parser.add_argument("--misses", type=int, default=100)
    parser.add_argument("--seed", type=int, default=2026)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    device = torch.device(args.device)
    torch_npu.npu.set_device(device)
    index = (
        device.index
        if device.index is not None
        else torch_npu.npu.current_device()
    )
    device_name = torch_npu.npu.get_device_name(index)
    if "950" in device_name.lower():
        # 来源算子的 kernel 明确将 __CCE_AICORE__==310 / DAV_310R6
        # 编译为空；A5 只能跳过，不能把未写出的零值当成功能结果。
        print(
            "STANDARD_LIM_MTP_TEST skipped=1 reason=unsupported_ascend950 "
            f"device={device_name!r}",
            flush=True,
        )
        return
    case = make_case(
        device=device,
        batch=args.batch_size,
        heads=args.heads,
        candidate_len=args.candidate_seqlen,
        query_count=4,
        cache_budget=8192,
        misses=args.misses,
        pool_extra=3,
        seed=args.seed,
    )
    rows = args.batch_size * 4
    topk_src = torch.empty(
        (rows, 1, TOPK), dtype=torch.int32, device=device
    )
    topk_dst = torch.empty_like(topk_src)
    topk_miss = torch.empty((rows,), dtype=torch.int32, device=device)
    miss_src = torch.empty(
        (args.batch_size, MISS_CAPACITY), dtype=torch.int32, device=device
    )
    miss_dst = torch.empty_like(miss_src)
    miss_count = torch.empty(
        (args.batch_size,), dtype=torch.int32, device=device
    )
    cache = case.initial_pool.clone()
    torch.ops.nanovllm_dsa.fused_li_manage_mtp_standard_out.default(
        case.weights,
        case.query_scale,
        case.query,
        case.key_scale,
        case.key,
        case.block_table,
        case.actual_q,
        case.actual_key,
        case.offload_key,
        case.cache_tokens,
        case.request_state,
        case.req_entries,
        cache,
        topk_src,
        topk_dst,
        topk_miss,
        miss_src,
        miss_dst,
        miss_count,
    )
    torch_npu.npu.synchronize()
    actual_counts = miss_count.cpu().tolist()
    if actual_counts != case.target_misses:
        raise AssertionError(
            f"union miss 数错误：actual={actual_counts}, "
            f"expected={case.target_misses}"
        )
    actual_src = topk_src.cpu().reshape(rows, TOPK)
    reference = case.native_topk.cpu().reshape(rows, TOPK)
    for row in range(rows):
        if not torch.equal(
            torch.sort(actual_src[row]).values,
            torch.sort(reference[row]).values,
        ):
            raise AssertionError(f"TopK 集合不一致：row={row}")
    cache_cpu = cache.cpu()
    dst_cpu = topk_dst.cpu().reshape(rows, TOPK)
    for request in range(args.batch_size):
        pool_row = int(case.req_entries_cpu[request])
        begin = request * 4
        for row in range(begin, begin + 4):
            sources = actual_src[row].to(torch.int64)
            expected_slots = cache_cpu[pool_row, sources]
            if not torch.equal(dst_cpu[row], expected_slots):
                raise AssertionError(
                    f"TopK destination slot 不一致：request={request}, row={row}"
                )
    print(
        "STANDARD_LIM_MTP_TEST passed=1 failed=0 "
        f"bs={args.batch_size} q=4 misses={args.misses}",
        flush=True,
    )


if __name__ == "__main__":
    main()
