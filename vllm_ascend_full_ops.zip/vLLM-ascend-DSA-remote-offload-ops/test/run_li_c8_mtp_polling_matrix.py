#!/usr/bin/env python3
"""运行 HBM/swapped/swapped+poll 三组 C8 MTP3 LI 穿刺实验。"""

from __future__ import annotations

import argparse
import csv
import shlex
import subprocess
import sys
from datetime import datetime
from pathlib import Path

from analyze_li_c8_mtp_polling_msprof import analyze


ROOT = Path(__file__).resolve().parents[1]
MODES = ("hbm_no_poll", "swapped_no_poll", "swapped_poll")
CSV_FIELDS = (
    "mode",
    "bs",
    "queries_per_request",
    "packed_t",
    "source_len",
    "calls_per_iteration",
    "poll_threads",
    "poll_scan",
    "li_task_count",
    "li_call_avg_us",
    "li_call_p50_us",
    "li_call_p90_us",
    "li_call_p99_us",
    "li_iteration_sum_avg_us",
    "li_iteration_sum_p50_us",
    "vs_hbm_no_poll_pct",
    "vs_swapped_no_poll_pct",
    "status",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", default="npu:0")
    parser.add_argument("--bs", type=int, default=32)
    parser.add_argument("--heads", type=int, default=32)
    parser.add_argument("--source-len", type=int, default=131072)
    parser.add_argument("--queries-per-request", type=int, default=4)
    parser.add_argument("--query-noise", type=float, default=0.25)
    parser.add_argument("--calls-per-iteration", type=int, default=10)
    parser.add_argument("--eager-warmup", type=int, default=3)
    parser.add_argument("--warmup", type=int, default=5)
    parser.add_argument("--iterations", type=int, default=20)
    parser.add_argument("--poll-threads", type=int, default=0)
    parser.add_argument("--poll-first-cpu", type=int, default=-1)
    parser.add_argument(
        "--poll-scan", choices=("partition", "replicated"),
        default="partition",
    )
    parser.add_argument("--poll-timeout-ms", type=int, default=30000)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--allow-non-a5", action="store_true")
    parser.add_argument("--python", default=sys.executable)
    parser.add_argument("--msprof-bin", default="msprof")
    parser.add_argument("--msprof-extra", default="")
    parser.add_argument(
        "--profile-root", type=Path, default=Path("li_polling_msprof")
    )
    parser.add_argument(
        "--csv", type=Path, default=Path("li_polling_results.csv")
    )
    parser.add_argument(
        "--regression-threshold-pct", type=float, default=1.0,
        help="swapped_poll 相对 swapped_no_poll 的 LI 平均时延门槛。",
    )
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def application_command(args: argparse.Namespace, mode: str) -> list[str]:
    command = [
        args.python,
        str(ROOT / "test" / "li_c8_mtp_swapped_polling_perf.py"),
        "--mode", mode,
        "--device", args.device,
        "--bs", str(args.bs),
        "--heads", str(args.heads),
        "--source-len", str(args.source_len),
        "--queries-per-request", str(args.queries_per_request),
        "--query-noise", str(args.query_noise),
        "--calls-per-iteration", str(args.calls_per_iteration),
        "--eager-warmup", str(args.eager_warmup),
        "--warmup", str(args.warmup),
        "--iterations", str(args.iterations),
        "--poll-threads", str(args.poll_threads),
        "--poll-first-cpu", str(args.poll_first_cpu),
        "--poll-scan", args.poll_scan,
        "--poll-timeout-ms", str(args.poll_timeout_ms),
        "--seed", str(args.seed),
    ]
    if args.allow_non_a5:
        command.append("--allow-non-a5")
    return command


def profiler_command(
    args: argparse.Namespace, mode: str, profile_dir: Path
) -> list[str]:
    return [
        args.msprof_bin,
        f"--application={shlex.join(application_command(args, mode))}",
        f"--output={profile_dir}",
        "--task-time=on",
        "--export=on",
        *shlex.split(args.msprof_extra),
    ]


def empty_row(args: argparse.Namespace, mode: str, status: str) -> dict[str, object]:
    row: dict[str, object] = {field: "" for field in CSV_FIELDS}
    row.update({
        "mode": mode,
        "bs": args.bs,
        "queries_per_request": args.queries_per_request,
        "packed_t": args.bs * args.queries_per_request,
        "source_len": args.source_len,
        "calls_per_iteration": args.calls_per_iteration,
        "poll_threads": (
            (args.poll_threads or min(args.bs, 32))
            if mode == "swapped_poll" else 0
        ),
        "poll_scan": args.poll_scan if mode == "swapped_poll" else "none",
        "status": status,
    })
    return row


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=CSV_FIELDS)
        writer.writeheader()
        writer.writerows(rows)


def format_result(row: dict[str, object]) -> str:
    if row.get("li_call_avg_us", "") == "":
        return f"LI_POLLING_RESULT mode={row['mode']} status={row['status']}"
    return (
        f"LI_POLLING_RESULT mode={row['mode']} "
        f"li_call_avg_us={row['li_call_avg_us']} "
        f"li_call_p50_us={row['li_call_p50_us']} "
        f"li_call_p90_us={row['li_call_p90_us']} "
        f"li_call_p99_us={row['li_call_p99_us']} "
        f"li_iteration_sum_avg_us={row['li_iteration_sum_avg_us']} "
        f"vs_swapped_no_poll_pct={row['vs_swapped_no_poll_pct']} "
        f"status={row['status']}"
    )


def main() -> int:
    args = parse_args()
    profile_root = args.profile_root.resolve()
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    rows: list[dict[str, object]] = []

    for mode in MODES:
        profile_dir = profile_root / f"{run_id}_{mode}"
        command = profiler_command(args, mode, profile_dir)
        print(f"REPRODUCE_COMMAND {shlex.join(command)}", flush=True)
        if args.dry_run:
            rows.append(empty_row(args, mode, "dry_run"))
            continue

        profile_dir.mkdir(parents=True, exist_ok=False)
        try:
            process = subprocess.run(
                command,
                cwd=ROOT,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                check=False,
            )
            log = process.stdout
        except OSError as error:
            process = None
            log = f"failed to start msprof: {error}\n"
        (profile_dir / "msprof.log").write_text(log, encoding="utf-8")
        if process is None or process.returncode != 0:
            row = empty_row(args, mode, "failed_msprof")
        else:
            try:
                metrics = analyze(
                    profile_dir,
                    warmup=args.warmup,
                    iterations=args.iterations,
                    calls_per_iteration=args.calls_per_iteration,
                )
                row = empty_row(args, mode, "ok_profiled")
                row.update({
                    key: round(value, 3) if isinstance(value, float) else value
                    for key, value in metrics.items()
                })
            except Exception as error:  # keep all cases and their logs
                row = empty_row(
                    args, mode, f"failed_parse:{type(error).__name__}"
                )
                with (profile_dir / "msprof.log").open(
                    "a", encoding="utf-8"
                ) as stream:
                    stream.write(f"\nparse error: {error}\n")
        rows.append(row)
        write_csv(args.csv, rows)
        print(format_result(row), flush=True)

    successful = {
        str(row["mode"]): row
        for row in rows
        if row.get("li_call_avg_us", "") != ""
    }
    hbm = successful.get("hbm_no_poll")
    swapped = successful.get("swapped_no_poll")
    for row in rows:
        if row.get("li_call_avg_us", "") == "":
            continue
        average = float(row["li_call_avg_us"])
        if hbm is not None:
            row["vs_hbm_no_poll_pct"] = round(
                (average / float(hbm["li_call_avg_us"]) - 1.0) * 100.0, 3
            )
        if swapped is not None:
            regression = (
                average / float(swapped["li_call_avg_us"]) - 1.0
            ) * 100.0
            row["vs_swapped_no_poll_pct"] = round(regression, 3)
            if (
                row["mode"] == "swapped_poll"
                and regression > args.regression_threshold_pct
            ):
                row["status"] = "regressed"
    write_csv(args.csv, rows)

    print("\nPERFORMANCE_ONLY_SUMMARY", flush=True)
    for row in rows:
        print(format_result(row), flush=True)
    print(f"CSV path={args.csv.resolve()}", flush=True)
    return int(any(str(row["status"]).startswith("failed") for row in rows))


if __name__ == "__main__":
    raise SystemExit(main())
