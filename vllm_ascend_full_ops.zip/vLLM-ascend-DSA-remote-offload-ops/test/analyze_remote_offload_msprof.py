#!/usr/bin/env python3
"""从 msprof task-time CSV 提取 Remote Offload 算子链性能。"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
import statistics
from dataclasses import dataclass
from pathlib import Path


START_TOKENS = {
    # 第二个 token 只用于继续解析切换标准 LIM 前保存的历史 CSV。
    "no_offload": (
        "nanovllmfusedlimanagemtp", "a5fusedlimanagemtpc8",
    ),
    "lidu_aicpu_poll_aiv": (
        "nanovllmfusedlimanagemtp", "a5fusedlimanagemtpc8",
    ),
    "lidu_aicpu_defer_aiv_poll": (
        "nanovllmfusedlimanagemtp", "a5fusedlimanagemtpc8",
    ),
    "li_cpu_du_implicit_dba": ("lightningindexer",),
    "li_c8_cpu_du_aicpu_poll_aiv": ("lightningindexer",),
}
SFA_TOKENS = ("a5sparsetailattentionmtpc8",)
IO_TOKENS = ("hcommkvcachescattercopy",)
SCATTER_TOKENS = ("scatteriofromstagingc8",)
HOST_PROFILE_PREFIX = "REMOTE_OFFLOAD_HOST_PROFILE_JSON "


@dataclass(frozen=True)
class Task:
    name: str
    start_us: float
    duration_us: float

    @property
    def end_us(self) -> float:
        return self.start_us + self.duration_us


def normalize(value: str) -> str:
    return "".join(character.lower() for character in value if character.isalnum())


def numeric(value: object) -> float | None:
    try:
        result = float(str(value).strip().rstrip("%"))
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def unit_scale(header: str) -> float:
    lower = header.lower()
    if "(ns)" in lower or "[ns]" in lower or lower.endswith("ns"):
        return 0.001
    if "(ms)" in lower or "[ms]" in lower or lower.endswith("ms"):
        return 1000.0
    return 1.0


def find_column(fieldnames: list[str], alternatives: tuple[str, ...]) -> str | None:
    normalized = [(field, normalize(field)) for field in fieldnames]
    for alternative in alternatives:
        needle = normalize(alternative)
        for field, value in normalized:
            if value == needle:
                return field
    for alternative in alternatives:
        needle = normalize(alternative)
        for field, value in normalized:
            if needle in value:
                return field
    return None


def task_csvs(profile_path: Path) -> list[Path]:
    """返回单个 task-time CSV，或 profiling 目录中的所有候选 CSV。"""
    if profile_path.is_file():
        return [profile_path]
    if not profile_path.is_dir():
        return []
    files = sorted(profile_path.rglob("*.csv"))
    task_time = [path for path in files if "task_time" in path.name.lower()]
    if task_time:
        return task_time
    return [path for path in files if "op_summary" in path.name.lower()]


def read_tasks(profile_path: Path) -> list[Task]:
    tasks: list[Task] = []
    for path in task_csvs(profile_path):
        with path.open(newline="", encoding="utf-8-sig", errors="replace") as stream:
            reader = csv.DictReader(stream)
            fields = list(reader.fieldnames or [])
            # msprof task-time 导出既有空格命名，也有样例中的下划线命名：
            # task_time(us)、task_start(us)、kernel_name。
            start_key = find_column(fields, (
                "Task Start Time", "Start Time", "Task Start", "task_start",
            ))
            duration_key = find_column(fields, (
                "Task Duration", "Duration", "Task Time", "task_time",
            ))
            name_keys = [
                key for key in (
                    find_column(fields, ("Op Name",)),
                    find_column(fields, ("OP Type", "Op Type")),
                    find_column(fields, ("Task Name", "Kernel Name", "kernel_name")),
                    find_column(fields, ("Kernel Type", "kernel_type")),
                ) if key is not None
            ]
            if start_key is None or duration_key is None or not name_keys:
                continue
            for row in reader:
                start = numeric(row.get(start_key))
                duration = numeric(row.get(duration_key))
                if start is None or duration is None or duration < 0:
                    continue
                name = " ".join(str(row.get(key, "")) for key in name_keys)
                tasks.append(Task(
                    name=name,
                    start_us=start * unit_scale(start_key),
                    duration_us=duration * unit_scale(duration_key),
                ))
    if not tasks:
        raise RuntimeError(f"{profile_path} 中没有可解析的 task-time/op-summary 记录")
    return sorted(tasks, key=lambda task: (task.start_us, task.end_us))


def matches(task: Task, tokens: tuple[str, ...]) -> bool:
    name = normalize(task.name)
    return any(token in name for token in tokens)


def invocations(tasks: list[Task], tokens: tuple[str, ...]) -> list[Task]:
    selected = [task for task in tasks if matches(task, tokens)]
    result: list[Task] = []
    for task in selected:
        # 一个 MIX 算子的 AIC/AIV task 可能同名且几乎同时开始；合成一次调用。
        if result and abs(task.start_us - result[-1].start_us) <= 2.0:
            previous = result[-1]
            end = max(previous.end_us, task.end_us)
            result[-1] = Task(
                previous.name, min(previous.start_us, task.start_us),
                end - min(previous.start_us, task.start_us),
            )
        else:
            result.append(task)
    return result


def percentile(values: list[float], quantile: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * quantile
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return ordered[lower]
    fraction = position - lower
    return ordered[lower] * (1.0 - fraction) + ordered[upper] * fraction


def stage_samples(
    tasks: list[Task], tokens: tuple[str, ...], warmup: int, iterations: int,
) -> list[float]:
    calls = invocations(tasks, tokens)
    selected = calls[-(warmup + iterations) :]
    return [
        task.duration_us for task in selected[warmup : warmup + iterations]
    ]


def paired_stage_samples(
    tasks: list[Task], tokens: tuple[str, ...], warmup: int, iterations: int,
    member: int | None = None,
) -> list[float]:
    """隐式 DBA 每轮有两个同类 task；按 IO stream 提交顺序两两配对。"""

    required = warmup + iterations
    calls = invocations(tasks, tokens)[-(required * 2) :]
    if len(calls) != required * 2:
        raise RuntimeError(
            f"隐式 DBA stage 调用数不足：actual={len(calls)} "
            f"required={required * 2}"
        )
    pairs = [calls[index : index + 2] for index in range(0, len(calls), 2)]
    selected = pairs[warmup : warmup + iterations]
    if member is not None:
        return [pair[member].duration_us for pair in selected]
    return [sum(task.duration_us for task in pair) for pair in selected]


def stage_statistics(samples: list[float], prefix: str) -> dict[str, float]:
    if not samples:
        return {
            f"{prefix}_p50_us": 0.0,
            f"{prefix}_p90_us": 0.0,
            f"{prefix}_avg_us": 0.0,
        }
    return {
        f"{prefix}_p50_us": statistics.median(samples),
        f"{prefix}_p90_us": percentile(samples, 0.90),
        f"{prefix}_avg_us": statistics.mean(samples),
    }


def read_host_profile(profile_path: Path) -> dict[str, float]:
    """读取 workload 写入 msprof.log 的 Host 分阶段 p50/p90。"""

    if profile_path.is_file():
        candidates = [profile_path.parent / "msprof.log"]
    else:
        candidates = [profile_path / "msprof.log"]
        if profile_path.is_dir():
            candidates.extend(sorted(profile_path.rglob("msprof.log")))
    result: dict[str, float] = {}
    for path in dict.fromkeys(candidates):
        if not path.is_file():
            continue
        for line in path.read_text(
            encoding="utf-8", errors="replace"
        ).splitlines():
            marker = line.find(HOST_PROFILE_PREFIX)
            if marker < 0:
                continue
            payload = line[marker + len(HOST_PROFILE_PREFIX) :]
            values = json.loads(payload)
            if not isinstance(values, dict):
                raise RuntimeError(f"{path} 中 Host profiling 不是 JSON object")
            for key, value in values.items():
                parsed = numeric(value)
                if parsed is not None:
                    result[str(key)] = parsed
    return result


def timeline_statistics(
    tasks: list[Task], mode: str, warmup: int, iterations: int,
) -> dict[str, float]:
    """按同一次调用配对 task，量化各算子之间未被 stage duration 覆盖的空洞。"""

    required = warmup + iterations
    starts = invocations(tasks, START_TOKENS[mode])[-required:]
    sfas = invocations(tasks, SFA_TOKENS)[-required:]
    if len(starts) != required or len(sfas) != required:
        raise RuntimeError("无法构造完整的 LI/LIDU→SFA 时间线")

    remote = mode != "no_offload"
    implicit_dba = mode == "li_cpu_du_implicit_dba"
    calls_per_iteration = 2 if implicit_dba else 1
    io_required = required * calls_per_iteration
    ios = invocations(tasks, IO_TOKENS)[-io_required:] if remote else []
    scatters = (
        invocations(tasks, SCATTER_TOKENS)[-io_required:] if remote else []
    )
    if remote and (len(ios) != io_required or len(scatters) != io_required):
        raise RuntimeError(
            f"无法构造完整远端时间线：io={len(ios)} "
            f"scatter={len(scatters)} required={io_required}"
        )

    values: dict[str, list[float]] = {
        "index_to_io_gap": [],
        "io_to_scatter_gap": [],
        "ubatch_handoff_gap": [],
        "ubatch1_io_to_scatter_gap": [],
        "scatter_to_sfa_gap": [],
        "index_to_sfa_gap": [],
        "total_gap": [],
        "bridge_device_task": [],
        "bridge_non_device_gap": [],
        "li_io_overlap": [],
        "li_scatter_overlap": [],
    }
    for index, (start, sfa) in enumerate(zip(starts, sfas)):
        if remote:
            io_index = index * calls_per_iteration
            io = ios[io_index]
            scatter = scatters[io_index]
            last_io = ios[io_index + calls_per_iteration - 1]
            last_scatter = scatters[io_index + calls_per_iteration - 1]
            first_gap = io.start_us - start.end_us
            second_gap = scatter.start_us - io.end_us
            third_gap = sfa.start_us - last_scatter.end_us
            handoff_gap = (
                ios[io_index + 1].start_us - scatter.end_us
                if implicit_dba else 0.0
            )
            ubatch1_io_to_scatter_gap = (
                last_scatter.start_us - last_io.end_us
                if implicit_dba else 0.0
            )
            bridge_tasks = [
                task for task in tasks
                if task.start_us >= start.end_us
                and task.end_us <= io.start_us
            ]
            values["index_to_io_gap"].append(first_gap)
            values["io_to_scatter_gap"].append(second_gap)
            values["ubatch_handoff_gap"].append(handoff_gap)
            values["ubatch1_io_to_scatter_gap"].append(
                ubatch1_io_to_scatter_gap
            )
            values["scatter_to_sfa_gap"].append(third_gap)
            values["index_to_sfa_gap"].append(0.0)
            values["total_gap"].append(
                max(0.0, first_gap) + max(0.0, second_gap) +
                max(0.0, handoff_gap) +
                max(0.0, ubatch1_io_to_scatter_gap) +
                max(0.0, third_gap)
            )
            bridge_device = sum(task.duration_us for task in bridge_tasks)
            values["bridge_device_task"].append(bridge_device)
            values["bridge_non_device_gap"].append(
                first_gap - bridge_device
            )
            values["li_io_overlap"].append(sum(
                max(
                    0.0,
                    min(start.end_us, item.end_us) -
                    max(start.start_us, item.start_us),
                )
                for item in ios[io_index : io_index + calls_per_iteration]
            ))
            values["li_scatter_overlap"].append(sum(
                max(
                    0.0,
                    min(start.end_us, item.end_us) -
                    max(start.start_us, item.start_us),
                )
                for item in scatters[
                    io_index : io_index + calls_per_iteration
                ]
            ))
        else:
            gap = sfa.start_us - start.end_us
            values["index_to_io_gap"].append(0.0)
            values["io_to_scatter_gap"].append(0.0)
            values["ubatch_handoff_gap"].append(0.0)
            values["ubatch1_io_to_scatter_gap"].append(0.0)
            values["scatter_to_sfa_gap"].append(0.0)
            values["index_to_sfa_gap"].append(gap)
            values["total_gap"].append(gap)
            values["bridge_device_task"].append(0.0)
            values["bridge_non_device_gap"].append(0.0)
            values["li_io_overlap"].append(0.0)
            values["li_scatter_overlap"].append(0.0)

    result: dict[str, float] = {}
    for name, samples in values.items():
        measured = samples[warmup : warmup + iterations]
        result[f"{name}_p50_us"] = statistics.median(measured)
        result[f"{name}_p90_us"] = percentile(measured, 0.90)
    return result


def analyze(
    profile_dir: Path, mode: str, warmup: int, iterations: int,
    batch: int, misses: int,
) -> dict[str, object]:
    tasks = read_tasks(profile_dir)
    all_starts = invocations(tasks, START_TOKENS[mode])
    all_sfas = invocations(tasks, SFA_TOKENS)
    required = warmup + iterations
    if len(all_starts) < required or len(all_sfas) < required:
        raise RuntimeError(
            f"msprof 调用数不足：start={len(all_starts)} sfa={len(all_sfas)} "
            f"required={required}"
        )
    starts = all_starts[-required:]
    sfas = all_sfas[-required:]
    chain = []
    for start, sfa in zip(starts, sfas):
        if sfa.end_us < start.start_us:
            raise RuntimeError("msprof 中 SFA 结束时间早于链路开始时间")
        chain.append(sfa.end_us - start.start_us)
    samples = chain[warmup : warmup + iterations]
    p50 = statistics.median(samples)
    p90 = percentile(samples, 0.90)
    has_remote_io = mode != "no_offload"
    payload_bytes = batch * misses * 656 if has_remote_io else 0
    result: dict[str, object] = {
        "chain_p50_us": p50,
        "chain_p90_us": p90,
        "chain_avg_us": statistics.mean(samples),
        "request_iops": round(batch * 1_000_000.0 / p50),
        "unique_iops": (
            round(batch * misses * 1_000_000.0 / p50)
            if has_remote_io else 0
        ),
        "effective_payload_GBps": payload_bytes / p50 / 1000.0,
        "samples": len(samples),
        "observed_start_calls": len(all_starts),
        "observed_sfa_calls": len(all_sfas),
    }
    result.update(stage_statistics(
        stage_samples(tasks, START_TOKENS[mode], warmup, iterations), "start"
    ))
    if mode == "li_cpu_du_implicit_dba":
        result.update(stage_statistics(
            paired_stage_samples(
                tasks, IO_TOKENS, warmup, iterations
            ), "io"
        ))
        result.update(stage_statistics(
            paired_stage_samples(
                tasks, IO_TOKENS, warmup, iterations, 0
            ), "io_ubatch0"
        ))
        result.update(stage_statistics(
            paired_stage_samples(
                tasks, IO_TOKENS, warmup, iterations, 1
            ), "io_ubatch1"
        ))
        result.update(stage_statistics(
            paired_stage_samples(
                tasks, SCATTER_TOKENS, warmup, iterations
            ), "aiv_scatter"
        ))
        result.update(stage_statistics(
            paired_stage_samples(
                tasks, SCATTER_TOKENS, warmup, iterations, 0
            ), "aiv_scatter_ubatch0"
        ))
        result.update(stage_statistics(
            paired_stage_samples(
                tasks, SCATTER_TOKENS, warmup, iterations, 1
            ), "aiv_scatter_ubatch1"
        ))
    else:
        result.update(stage_statistics(
            stage_samples(tasks, IO_TOKENS, warmup, iterations), "io"
        ))
        result.update(stage_statistics(
            stage_samples(
                tasks, SCATTER_TOKENS, warmup, iterations
            ), "aiv_scatter"
        ))
    result.update(stage_statistics(
        stage_samples(tasks, SFA_TOKENS, warmup, iterations), "sfa"
    ))
    result.update(timeline_statistics(tasks, mode, warmup, iterations))
    result.update(read_host_profile(profile_dir))
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "profile_path", type=Path,
        help="msprof 输出目录，或直接指定 task_time_*.csv。",
    )
    parser.add_argument("--mode", choices=tuple(START_TOKENS), required=True)
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--iterations", type=int, default=20)
    parser.add_argument("--bs", type=int, default=32)
    parser.add_argument("--misses-per-request", type=int, required=True)
    parser.add_argument("--json", type=Path, help="可选：写入机器可读 JSON 报告。")
    args = parser.parse_args()
    result = analyze(
        args.profile_path, args.mode, args.warmup, args.iterations,
        args.bs, args.misses_per_request,
    )
    if args.json is not None:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(
            json.dumps(result, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
    print(
        "REMOTE_OFFLOAD_MSPROF_RESULT "
        f"profile={args.profile_path} "
        + " ".join(f"{key}={value}" for key, value in result.items()),
        flush=True,
    )


if __name__ == "__main__":
    main()
