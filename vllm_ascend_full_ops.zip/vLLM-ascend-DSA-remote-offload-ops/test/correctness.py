#!/usr/bin/env python3

import argparse
import gc

import torch

from _common import call_new, load_new_ops, make_case, parse_dtype, validate_case


def summarize_counts(counts):
    if len(set(counts)) == 1:
        return f"same:{counts[0]}"
    return "mixed:" + ",".join(str(count) for count in counts)


def run_copy_case(name, device, dtype_name, counts, seed, sequential_dest=False):
    dtype = parse_dtype(dtype_name)
    logical_tokens = max(max(counts), 640)
    case = make_case(
        counts,
        dtype,
        device,
        seed=seed,
        logical_tokens=logical_tokens,
        sequential_dest=sequential_dest,
    )
    ready_flag = torch.full((1,), -1, dtype=torch.int32, device=device)
    call_new(case, ready_flag)
    torch.npu.synchronize()
    validate_case(case)
    if ready_flag.item() != 1:
        raise AssertionError(f"ready_flag was not signalled for case {name}")
    print(
        f"CORRECTNESS case={name} dtype={dtype_name} bsz={len(counts)} "
        f"copy_counts={summarize_counts(counts)} ok=1",
        flush=True,
    )
    del case
    gc.collect()
    torch.npu.empty_cache()


def expect_runtime_error(name, case, ready_flag=None):
    try:
        call_new(case, ready_flag)
    except RuntimeError:
        print(f"VALIDATION case={name} ok=1", flush=True)
        return
    raise AssertionError(f"validation case {name} did not raise RuntimeError")


def run_host_validation(device):
    base = make_case([1, 1], torch.bfloat16, device, seed=9001)

    case = dict(base)
    case["src_token_ids"] = base["src_token_ids"].view(2, -1)
    expect_runtime_error("src_rank", case)

    case = dict(base)
    case["dst_slots"] = base["dst_slots"][:, :, :100]
    expect_runtime_error("dst_capacity", case)

    case = dict(base)
    case["dst_slots"] = base["dst_slots"].to(torch.int64)
    expect_runtime_error("index_dtype", case)

    case = dict(base)
    case["dram_block_table"] = base["dram_block_table"].to(torch.int64)
    expect_runtime_error("dram_block_table_dtype", case)

    case = dict(base)
    case["copy_counts"] = base["copy_counts"][:1]
    expect_runtime_error("batch_mismatch", case)

    case = dict(base)
    case["hbm_k_rope"] = base["hbm_k_rope"][:, :, :63]
    expect_runtime_error("rope_dim", case)

    case = dict(base)
    case["hbm_kv_cache"] = base["hbm_kv_cache"].float()
    expect_runtime_error("kv_dtype", case)

    expect_runtime_error(
        "ready_flag_shape",
        base,
        ready_flag=torch.zeros(2, dtype=torch.int32, device=device),
    )
    expect_runtime_error(
        "ready_flag_dtype",
        base,
        ready_flag=torch.zeros(1, dtype=torch.int64, device=device),
    )

    case = dict(base)
    case["src_token_ids"] = torch.full(
        (2, 1, 32768), -1, dtype=torch.int32, device=device
    )[:, :, ::2]
    if case["src_token_ids"].is_contiguous():
        raise AssertionError("failed to construct a non-contiguous validation input")
    expect_runtime_error("non_contiguous", case)

    del base
    gc.collect()
    torch.npu.empty_cache()


def main():
    parser = argparse.ArgumentParser(description="Validate KvcacheScatterCopy.")
    parser.add_argument("--device", default="npu:0")
    parser.add_argument("--dtypes", default="bf16,fp16")
    args = parser.parse_args()

    load_new_ops()
    device = torch.device(args.device)
    torch.npu.set_device(device)
    dtype_names = [item.strip() for item in args.dtypes.split(",") if item.strip()]

    incremental_cases = (
        ("bs1_zero", [0]),
        ("bs1_one", [1]),
        ("bs1_499", [499]),
        ("bs4_same", [205] * 4),
        ("bs4_mixed", [0, 1, 205, 499]),
        ("bs8_same", [499] * 8),
        ("bs8_mixed", [1, 32, 64, 128, 205, 256, 384, 499]),
        ("bs24_same_205", [205] * 24),
        ("bs24_same_499", [499] * 24),
        ("bs24_mixed", [0, 1, 32, 64, 128, 205, 320, 499] * 3),
    )

    for dtype_idx, dtype_name in enumerate(dtype_names):
        for case_idx, (name, counts) in enumerate(incremental_cases):
            run_copy_case(
                name,
                device,
                dtype_name,
                counts,
                seed=100 + dtype_idx * 100 + case_idx,
            )
        for fill_idx, count in enumerate((6144, 10240, 12288)):
            run_copy_case(
                f"first_fill_{count}",
                device,
                dtype_name,
                [count],
                seed=1000 + dtype_idx * 10 + fill_idx,
                sequential_dest=True,
            )
        run_copy_case(
            "first_fill_mixed",
            device,
            dtype_name,
            [6144, 10240, 12288],
            seed=2000 + dtype_idx,
            sequential_dest=True,
        )

    run_host_validation(device)
    print("KVCACHE_SCATTER_COPY_CORRECTNESS_OK", flush=True)


if __name__ == "__main__":
    main()
