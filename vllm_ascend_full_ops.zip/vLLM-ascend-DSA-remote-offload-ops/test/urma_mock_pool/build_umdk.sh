#!/usr/bin/env bash
set -euo pipefail

# Build the public UMDK implementation for this smoke test. No staged-server
# source or headers are involved. UMDK's upstream CMake install destinations
# are system paths, so we consume the build tree directly rather than sudo
# installing anything.
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
UMDK_SOURCE_DIR="${UMDK_SOURCE_DIR:-${ROOT}/.deps/umdk}"
UMDK_REPOSITORY="${UMDK_REPOSITORY:-https://atomgit.com/openeuler/umdk.git}"
UMDK_BUILD_DIR="${UMDK_BUILD_DIR:-${UMDK_SOURCE_DIR}/build-kvcache-pool}"

if [[ ! -d "${UMDK_SOURCE_DIR}/.git" ]]; then
  mkdir -p "$(dirname "${UMDK_SOURCE_DIR}")"
  git clone --depth 1 "${UMDK_REPOSITORY}" "${UMDK_SOURCE_DIR}"
fi

cmake -S "${UMDK_SOURCE_DIR}/src/urma" -B "${UMDK_BUILD_DIR}" -DBUILD_DEBUG=off
cmake --build "${UMDK_BUILD_DIR}" --parallel "${BUILD_JOBS:-$(nproc)}"

URMA_INCLUDE_DIR="${UMDK_SOURCE_DIR}/src/urma/lib/urma/core/include" \
UMDK_BUILD_DIR="${UMDK_BUILD_DIR}" \
"${ROOT}/build.sh"
