#!/usr/bin/env bash
set -euo pipefail

# Build the standalone public-UMDK smoke test. This deliberately does not
# include workspace-a5 headers or link any staged-server implementation.
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT="${ROOT}/urma_mock_pool"
GATHER_OUT="${ROOT}/gather_microbench"
CXX="${CXX:-g++}"
UMDK_PREFIX="${UMDK_PREFIX:-${ROOT}/.umdk}"

if [[ -n "${URMA_INCLUDE_DIR:-}" ]]; then
  INCLUDE_DIR="${URMA_INCLUDE_DIR}"
elif [[ -f "${UMDK_PREFIX}/include/urma/urma_api.h" ]]; then
  INCLUDE_DIR="${UMDK_PREFIX}/include"
elif [[ -f "${UMDK_PREFIX}/include/ub/umdk/urma/urma_api.h" ]]; then
  INCLUDE_DIR="${UMDK_PREFIX}/include/ub/umdk/urma"
elif [[ -f "${UMDK_PREFIX}/include/urma_api.h" ]]; then
  INCLUDE_DIR="${UMDK_PREFIX}/include"
elif [[ -f /usr/include/urma/urma_api.h ]]; then
  INCLUDE_DIR=/usr/include
elif [[ -f /usr/local/include/urma/urma_api.h ]]; then
  INCLUDE_DIR=/usr/local/include
elif [[ -f /usr/include/ub/umdk/urma/urma_api.h ]]; then
  INCLUDE_DIR=/usr/include/ub/umdk/urma
elif [[ -f /usr/include/urma_api.h ]]; then
  INCLUDE_DIR=/usr/include
else
  echo "Cannot find public URMA headers; install umdk-urma-devel or set URMA_INCLUDE_DIR." >&2
  exit 1
fi

LIB_ARGS=(-lurma)
if [[ -n "${URMA_LIBRARY_DIR:-}" ]]; then
  LIB_ARGS=(-L"${URMA_LIBRARY_DIR}" -Wl,-rpath,"${URMA_LIBRARY_DIR}" -lurma)
elif [[ -f "${UMDK_PREFIX}/lib64/liburma.so" ]]; then
  LIB_ARGS=(-L"${UMDK_PREFIX}/lib64" -Wl,-rpath,"${UMDK_PREFIX}/lib64" -lurma)
elif [[ -f "${UMDK_PREFIX}/lib/liburma.so" ]]; then
  LIB_ARGS=(-L"${UMDK_PREFIX}/lib" -Wl,-rpath,"${UMDK_PREFIX}/lib" -lurma)
elif [[ -n "${UMDK_BUILD_DIR:-}" ]]; then
  UMDK_LIBRARY="$(find "${UMDK_BUILD_DIR}" -name liburma.so -type f -print -quit)"
  if [[ -z "${UMDK_LIBRARY}" ]]; then
    echo "Cannot find liburma.so below UMDK_BUILD_DIR=${UMDK_BUILD_DIR}." >&2
    exit 1
  fi
  LIBRARY_DIR="$(dirname "${UMDK_LIBRARY}")"
  LIB_ARGS=(-L"${LIBRARY_DIR}" -Wl,-rpath,"${LIBRARY_DIR}" -lurma)
fi

COMMON_FLAGS=(-std=c++17 -O3 -Wall -Wextra -Werror)
if [[ "${PROFILE:-0}" == "1" ]]; then
  COMMON_FLAGS+=(-g -fno-omit-frame-pointer)
fi
if [[ "${ENABLE_SVE2:-0}" == "1" ]]; then
  COMMON_FLAGS+=(-march=armv9-a+sve2)
fi

"${CXX}" "${COMMON_FLAGS[@]}" \
  -I"${INCLUDE_DIR}" "${ROOT}/urma_mock_pool.cpp" "${ROOT}/gather_kernels.cpp" \
  "${LIB_ARGS[@]}" -ldl -pthread -o "${OUT}"
"${CXX}" "${COMMON_FLAGS[@]}" \
  "${ROOT}/gather_microbench.cpp" "${ROOT}/gather_kernels.cpp" \
  -pthread -o "${GATHER_OUT}"

echo "built ${OUT}"
echo "built ${GATHER_OUT}"
