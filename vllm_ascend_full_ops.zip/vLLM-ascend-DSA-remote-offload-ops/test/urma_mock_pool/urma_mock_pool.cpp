// SPDX-License-Identifier: Apache-2.0
//
// Minimal host-side URMA memory-pool smoke test.
//
// This intentionally uses only the public UMDK URMA API.  It neither imports
// code from staged_server nor implements a request protocol.  Its purpose is
// to prove that a host can expose one contiguous CKV/KPE backing allocation as
// a real URMA segment and a READ/WRITE-capable jetty.  It deliberately does
// not post Send or Recv work requests.

#if __has_include(<urma_api.h>)
#include <urma_api.h>
#elif __has_include(<urma/urma_api.h>)
#include <urma/urma_api.h>
#else
#error "Cannot find public UMDK header urma_api.h"
#endif

#include "raw_ub_peer_descriptor.h"
#include "gather_kernels.h"

#include <algorithm>
#include <cerrno>
#include <chrono>
#include <atomic>
#include <array>
#include <cctype>
#include <csignal>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <memory>
#include <arpa/inet.h>
#include <ifaddrs.h>
#include <net/if.h>
#include <netinet/in.h>
#include <pthread.h>
#include <poll.h>
#include <sched.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <dlfcn.h>
#include <mutex>
#include <string>
#include <thread>
#include <unistd.h>
#include <vector>

namespace {

volatile std::sig_atomic_t gStop = 0;

void StopServer(int)
{
    gStop = 1;
}

constexpr uint64_t kTokensPerBlock = 128;
constexpr uint64_t kCkvBytesPerToken = 1024;
constexpr uint64_t kKpeBytesPerToken = 128;
constexpr uint32_t kTokenValue = 0x4b56434b;  // "KVCK"
constexpr uint32_t kUrmaTokenIdShift = 8;
constexpr uint64_t kAggregateBytes = 64ULL * 1024ULL * 1024ULL;
constexpr uint32_t kCappedWqesPerPost = 256;
constexpr std::array<uint64_t, 4> kProbeBytes{
    4ULL * 1024ULL * 1024ULL,
    16ULL * 1024ULL * 1024ULL,
    32ULL * 1024ULL * 1024ULL,
    64ULL * 1024ULL * 1024ULL,
};

enum class PoolPattern {
    BYTES,
    BF16,
};

struct Options {
    std::string deviceName;
    std::string hostNic;
    std::string peerEidHex;
    uint32_t blocks = 1024;
    uint32_t jettyCount = 1;
    uint32_t holdSeconds = 0;
    uint32_t eidIndex = 0;
    uint32_t peerUasid = 0;
    uint32_t peerJettyId = 0;
    uint32_t pollThreads = 1;
    uint32_t gatherThreads = 1;
    uint32_t pipelineMib = 0;
    uint16_t controlPort = 0;
    std::vector<uint32_t> pollCpus;
    std::vector<uint32_t> gatherCpus;
    GatherKernel gatherKernel = GatherKernel::LIBC;
    PoolPattern poolPattern = PoolPattern::BYTES;
    bool urmaPerf = false;
    bool peerUasidSet = false;
    bool peerJettyIdSet = false;
};

const char* PoolPatternName(PoolPattern pattern)
{
    return pattern == PoolPattern::BF16 ? "bf16" : "bytes";
}

bool ParsePoolPattern(const char* text, PoolPattern* pattern)
{
    if (std::strcmp(text, "bytes") == 0) {
        *pattern = PoolPattern::BYTES;
        return true;
    }
    if (std::strcmp(text, "bf16") == 0) {
        *pattern = PoolPattern::BF16;
        return true;
    }
    return false;
}

uint16_t Bf16Pattern(
    uint64_t block, uint64_t token, uint64_t dim,
    uint32_t plane)
{
    uint32_t hash =
        static_cast<uint32_t>(block) * 0x9e3779b1U ^
        static_cast<uint32_t>(token) * 0x85ebca6bU ^
        static_cast<uint32_t>(dim) * 0xc2b2ae35U ^
        plane * 0x27d4eb2fU;
    hash ^= hash >> 16;
    const uint16_t sign =
        static_cast<uint16_t>((hash >> 31) << 15);
    const uint16_t mantissa =
        static_cast<uint16_t>((hash >> 8) & 0x7fU);
    // Exponent 122 represents finite values in [2^-5, 2^-4).
    return static_cast<uint16_t>(
        sign | (122U << 7) | mantissa);
}

void FillBf16Pool(
    uint8_t* bytes, uint32_t blocks,
    uint64_t bytesPerBlock, uint64_t ckvBytesPerBlock)
{
    constexpr uint64_t ckvElements =
        kCkvBytesPerToken / sizeof(uint16_t);
    constexpr uint64_t kpeElements =
        kKpeBytesPerToken / sizeof(uint16_t);
    for (uint64_t block = 0; block < blocks; ++block) {
        auto* ckv = reinterpret_cast<uint16_t*>(
            bytes + block * bytesPerBlock);
        auto* kpe = reinterpret_cast<uint16_t*>(
            bytes + block * bytesPerBlock + ckvBytesPerBlock);
        for (uint64_t token = 0;
             token < kTokensPerBlock; ++token) {
            for (uint64_t dim = 0; dim < ckvElements; ++dim) {
                ckv[token * ckvElements + dim] =
                    Bf16Pattern(block, token, dim, 0);
            }
            for (uint64_t dim = 0; dim < kpeElements; ++dim) {
                kpe[token * kpeElements + dim] =
                    Bf16Pattern(block, token, dim, 1);
            }
        }
    }
}

bool ParseUint32(const char* text, uint32_t* out) {
    if (text == nullptr || out == nullptr || *text == '\0') return false;
    char* end = nullptr;
    errno = 0;
    const unsigned long value = std::strtoul(text, &end, 0);
    if (errno != 0 || end == text || *end != '\0' || value > UINT32_MAX) return false;
    *out = static_cast<uint32_t>(value);
    return true;
}

bool ParseOptions(int argc, char** argv, Options* options) {
    for (int i = 1; i < argc; ++i) {
        const std::string arg(argv[i]);
        const auto Invalid = [&arg](const char* expected) {
            std::fprintf(stderr, "invalid argument '%s': expected %s\n", arg.c_str(), expected);
            return false;
        };
        if ((arg == "--device" || arg == "--urma-device") && i + 1 < argc) {
            options->deviceName = argv[++i];
        } else if (arg == "--eid-index" && i + 1 < argc) {
            if (!ParseUint32(argv[++i], &options->eidIndex)) return Invalid("an unsigned integer");
        } else if (arg == "--host-nic" && i + 1 < argc) {
            options->hostNic = argv[++i];
        } else if (arg == "--blocks" && i + 1 < argc) {
            if (!ParseUint32(argv[++i], &options->blocks) || options->blocks == 0) {
                return Invalid("a positive integer");
            }
        } else if (arg == "--jetty-count" && i + 1 < argc) {
            if (!ParseUint32(argv[++i], &options->jettyCount) || options->jettyCount == 0 ||
                options->jettyCount > kRawUbMaxLanes) {
                return Invalid("an integer in [1, 4]");
            }
        } else if (arg == "--hold-seconds" && i + 1 < argc) {
            if (!ParseUint32(argv[++i], &options->holdSeconds)) return Invalid("an unsigned integer");
        } else if (arg == "--control-port" && i + 1 < argc) {
            uint32_t port = 0;
            if (!ParseUint32(argv[++i], &port) || port > UINT16_MAX) {
                return Invalid("an integer in [0, 65535]");
            }
            options->controlPort = static_cast<uint16_t>(port);
        } else if (arg == "--poll-threads" && i + 1 < argc) {
            if (!ParseUint32(argv[++i], &options->pollThreads) || options->pollThreads == 0 ||
                options->pollThreads > kRawUbCommandSlots) {
                return Invalid("an integer in [1, 8]");
            }
        } else if (arg == "--poll-cpus" && i + 1 < argc) {
            std::string cpus = argv[++i];
            size_t begin = 0;
            while (begin < cpus.size()) {
                const size_t end = cpus.find(',', begin);
                const std::string value = cpus.substr(begin, end - begin);
                uint32_t cpu = 0;
                if (!ParseUint32(value.c_str(), &cpu)) {
                    return Invalid("a comma-separated list of CPU IDs");
                }
                options->pollCpus.push_back(cpu);
                if (end == std::string::npos) break;
                begin = end + 1;
            }
        } else if (arg == "--gather-threads" && i + 1 < argc) {
            if (!ParseUint32(argv[++i], &options->gatherThreads) ||
                options->gatherThreads == 0 || options->gatherThreads > 64) {
                return Invalid("an integer in [1, 64]");
            }
        } else if (arg == "--gather-cpus" && i + 1 < argc) {
            std::string cpus = argv[++i];
            size_t begin = 0;
            while (begin < cpus.size()) {
                const size_t end = cpus.find(',', begin);
                const std::string value = cpus.substr(begin, end - begin);
                uint32_t cpu = 0;
                if (!ParseUint32(value.c_str(), &cpu)) {
                    return Invalid("a comma-separated list of CPU IDs");
                }
                options->gatherCpus.push_back(cpu);
                if (end == std::string::npos) break;
                begin = end + 1;
            }
        } else if (arg == "--gather-kernel" && i + 1 < argc) {
            if (!ParseGatherKernel(argv[++i], &options->gatherKernel)) {
                return Invalid("libc, neon, or sve2");
            }
        } else if (arg == "--pool-pattern" && i + 1 < argc) {
            if (!ParsePoolPattern(argv[++i], &options->poolPattern)) {
                return Invalid("bytes or bf16");
            }
        } else if (arg == "--pipeline-mib" && i + 1 < argc) {
            if (!ParseUint32(argv[++i], &options->pipelineMib) ||
                options->pipelineMib > 64) {
                return Invalid("an integer in [0, 64]");
            }
        } else if (arg == "--no-pipeline") {
            options->pipelineMib = 0;
        } else if (arg == "--urma-perf") {
            options->urmaPerf = true;
        } else if (arg == "--peer-eid" && i + 1 < argc) {
            options->peerEidHex = argv[++i];
        } else if (arg == "--peer-uasid" && i + 1 < argc) {
            options->peerUasidSet = ParseUint32(argv[++i], &options->peerUasid);
            if (!options->peerUasidSet) return Invalid("an unsigned integer");
        } else if (arg == "--peer-jetty-id" && i + 1 < argc) {
            options->peerJettyIdSet = ParseUint32(argv[++i], &options->peerJettyId);
            if (!options->peerJettyIdSet) return Invalid("an unsigned integer");
        } else if (arg == "--help") {
            std::printf("Usage: %s [--device NAME] [--eid-index N] [--host-nic IFACE] "
                        "[--blocks N] [--jetty-count 1..4] [--hold-seconds N] [--control-port N] "
                        "[--poll-threads N] [--poll-cpus C0,C1] "
                        "[--gather-threads N] [--gather-cpus C0,C1] "
                        "[--gather-kernel libc|neon|sve2] "
                        "[--pool-pattern bytes|bf16] "
                        "[--pipeline-mib 0..64 | --no-pipeline] "
                        "[--urma-perf]\n", argv[0]);
            std::printf("       %s --peer-eid HEX32 --peer-uasid N --peer-jetty-id N [...options]\n", argv[0]);
            std::printf("Registers one page-aligned [CKV][KPE] composite pool with liburma.so.\n");
            return false;
        } else {
            return Invalid("a supported option followed by its value");
        }
    }
    if (!options->pollCpus.empty() && options->pollCpus.size() != options->pollThreads) {
        std::fprintf(stderr,
            "invalid arguments: --poll-cpus contains %zu CPU IDs but --poll-threads is %u\n",
            options->pollCpus.size(), options->pollThreads);
        return false;
    }
    if (!options->gatherCpus.empty() &&
        options->gatherCpus.size() != options->gatherThreads) {
        std::fprintf(stderr,
            "invalid arguments: --gather-cpus contains %zu CPU IDs but --gather-threads is %u\n",
            options->gatherCpus.size(), options->gatherThreads);
        return false;
    }
    if (!GatherKernelAvailable(options->gatherKernel)) {
        std::fprintf(stderr,
            "gather kernel '%s' is not compiled in; use ENABLE_SVE2=1 for sve2\n",
            GatherKernelName(options->gatherKernel));
        return false;
    }
    return true;
}

void PrintHex(const uint8_t* data, size_t size) {
    for (size_t i = 0; i < size; ++i) std::printf("%02x", data[i]);
}

int CpuNumaNode(uint32_t cpu)
{
#if defined(__linux__)
    for (int node = 0; node < 256; ++node) {
        char path[128]{};
        (void)std::snprintf(path, sizeof(path),
            "/sys/devices/system/cpu/cpu%u/node%d", cpu, node);
        if (access(path, F_OK) == 0) return node;
    }
#else
    (void)cpu;
#endif
    return -1;
}

void PrintCpuPlacement(const char* name, const std::vector<uint32_t>& cpus)
{
    std::printf("%s=", name);
    if (cpus.empty()) {
        std::printf("unbound\n");
        return;
    }
    for (size_t index = 0; index < cpus.size(); ++index) {
        std::printf("%s%u:node%d", index == 0 ? "" : ",",
            cpus[index], CpuNumaNode(cpus[index]));
    }
    std::printf("\n");
}

bool ParseEid(const std::string& text, urma_eid_t* out) {
    if (out == nullptr) return false;
    std::array<char, 32> digits{};
    size_t count = 0;
    for (const unsigned char ch : text) {
        if (ch == ':' || ch == '-') continue;
        if (!std::isxdigit(ch) || count == digits.size()) return false;
        digits[count++] = static_cast<char>(ch);
    }
    if (count != digits.size()) return false;
    for (size_t i = 0; i < 16; ++i) {
        const auto hex = [](char value) -> uint8_t {
            if (value >= '0' && value <= '9') return static_cast<uint8_t>(value - '0');
            if (value >= 'a' && value <= 'f') return static_cast<uint8_t>(value - 'a' + 10);
            return static_cast<uint8_t>(value - 'A' + 10);
        };
        out->raw[i] = static_cast<uint8_t>((hex(digits[i * 2]) << 4) | hex(digits[i * 2 + 1]));
    }
    return true;
}

bool GetNicAddress(const std::string& nic, urma_net_addr_t* out, std::string* printable) {
    if (nic.empty() || out == nullptr || printable == nullptr || if_nametoindex(nic.c_str()) == 0) {
        return false;
    }
    ifaddrs* addresses = nullptr;
    if (getifaddrs(&addresses) != 0) return false;
    bool found = false;
    // Prefer IPv4 because it makes a simple two-host UBoE setup unambiguous;
    // fall back to IPv6 if the interface is IPv6-only.
    for (int wantedFamily : {AF_INET, AF_INET6}) {
        for (ifaddrs* item = addresses; item != nullptr; item = item->ifa_next) {
            if (item->ifa_addr == nullptr || nic != item->ifa_name ||
                item->ifa_addr->sa_family != wantedFamily) continue;
            std::memset(out, 0, sizeof(*out));
            out->sin_family = static_cast<sa_family_t>(wantedFamily);
            const void* raw = nullptr;
            if (wantedFamily == AF_INET) {
                out->in4 = reinterpret_cast<sockaddr_in*>(item->ifa_addr)->sin_addr;
                raw = &out->in4;
            } else {
                out->in6 = reinterpret_cast<sockaddr_in6*>(item->ifa_addr)->sin6_addr;
                raw = &out->in6;
            }
            char text[INET6_ADDRSTRLEN]{};
            if (inet_ntop(wantedFamily, raw, text, sizeof(text)) != nullptr) {
                *printable = text;
                found = true;
                break;
            }
        }
        if (found) break;
    }
    freeifaddrs(addresses);
    return found;
}

bool HasCompletePeer(const Options& options) {
    const bool any = !options.peerEidHex.empty() || options.peerUasidSet || options.peerJettyIdSet;
    return !any || (!options.peerEidHex.empty() && options.peerUasidSet && options.peerJettyIdSet);
}

bool SendAll(int fd, const void* data, size_t bytes) {
    const auto* cursor = static_cast<const uint8_t*>(data);
    while (bytes != 0) {
        const ssize_t sent = send(fd, cursor, bytes, MSG_NOSIGNAL);
        if (sent <= 0) return false;
        cursor += sent;
        bytes -= static_cast<size_t>(sent);
    }
    return true;
}

bool ReceiveAll(int fd, void* data, size_t bytes) {
    auto* cursor = static_cast<uint8_t*>(data);
    while (bytes != 0) {
        const ssize_t received = recv(fd, cursor, bytes, 0);
        if (received <= 0) return false;
        cursor += received;
        bytes -= static_cast<size_t>(received);
    }
    return true;
}

struct ReverseResources {
    uint32_t laneCount = 0;
    uint32_t maxSubIosPerWqe = 0;
    uint32_t fixedWqeBytes = 0;
    RawUbClientResources client{};
    urma_target_seg_t* stagingSegment = nullptr;
    std::array<urma_target_jetty_t*, kRawUbMaxLanes> targetJettys{};
};

struct PushSizeStats {
    uint64_t commands = 0;
    uint64_t bytes = 0;
    uint64_t gatherNs = 0;
    uint64_t prepareNs = 0;
    uint64_t postNs = 0;
    uint64_t pollNs = 0;
    uint64_t completionNs = 0;
    uint64_t wireNs = 0;
    uint64_t elapsedNs = 0;
};

struct PushSample {
    uint32_t mode;
    uint64_t bytes;
    uint64_t gatherNs;
    uint64_t prepareNs;
    uint64_t postNs;
    uint64_t pollNs;
    uint64_t completionNs;
    uint64_t wireNs;
    uint64_t elapsedNs;
};

struct PushStats {
    std::atomic<uint64_t> commands{0};
    std::atomic<uint64_t> blocks{0};
    std::atomic<uint64_t> bytes{0};
    std::atomic<uint64_t> elapsedNs{0};
    std::atomic<uint64_t> wireNs{0};
    std::atomic<uint64_t> directCommands{0};
    std::atomic<uint64_t> directBytes{0};
    std::atomic<uint64_t> directElapsedNs{0};
    std::atomic<uint64_t> directWireNs{0};
    std::atomic<uint64_t> aggregateCommands{0};
    std::atomic<uint64_t> aggregateBytes{0};
    std::atomic<uint64_t> aggregateElapsedNs{0};
    std::atomic<uint64_t> aggregateWireNs{0};
    std::atomic<uint64_t> gatherNs{0};
    std::atomic<uint64_t> tokenGatherCommands{0};
    std::atomic<uint64_t> tokenGatherBytes{0};
    std::atomic<uint64_t> tokenGatherElapsedNs{0};
    std::atomic<uint64_t> tokenGatherWireNs{0};
    std::atomic<uint64_t> tokenGatherNs{0};
    std::atomic<uint64_t> prepareNs{0};
    std::atomic<uint64_t> postNs{0};
    std::atomic<uint64_t> pollNs{0};
    std::atomic<uint64_t> completionNs{0};
    std::atomic<uint64_t> subIos{0};
    std::atomic<uint64_t> dataWqes{0};
    std::atomic<uint64_t> signaledDataWqes{0};
    std::atomic<uint64_t> wireBytes{0};
    std::array<PushSizeStats, kProbeBytes.size()> directSizes{};
    std::array<PushSizeStats, kProbeBytes.size()> aggregateSizes{};
    std::mutex samplesMutex;
    std::vector<PushSample> samples;
};

bool ImportReverseResources(urma_context_t* context,
    const std::array<urma_jetty_t*, kRawUbMaxLanes>& localJettys,
    const RawUbClientResources& client, ReverseResources* reverse) {
    urma_seg_t segment{};
    std::memcpy(&segment, client.stagingSegment.segment, sizeof(segment));
    urma_token_t segmentToken{};
    segmentToken.token = client.stagingSegment.tokenValue;
    urma_import_seg_flag_t segmentFlags{};
    segmentFlags.bs.cacheable = URMA_NON_CACHEABLE;
    segmentFlags.bs.access = URMA_ACCESS_READ | URMA_ACCESS_WRITE | URMA_ACCESS_ATOMIC;
    segmentFlags.bs.mapping = URMA_SEG_NOMAP;
    reverse->stagingSegment = urma_import_seg(context, &segment, &segmentToken, 0, segmentFlags);
    if (reverse->stagingSegment == nullptr) return false;
    std::printf("reverse_npu_memory staging_gva=0x%llx staging_bytes=%llu "
                "device_control_gva=0x%llx device_control_bytes=%llu "
                "segment_gva=0x%llx token_id=%u token_value=0x%x\n",
        static_cast<unsigned long long>(client.stagingGva),
        static_cast<unsigned long long>(client.stagingBytes),
        static_cast<unsigned long long>(client.deviceControlGva),
        static_cast<unsigned long long>(client.deviceControlBytes),
        static_cast<unsigned long long>(segment.ubva.va), segment.token_id,
        client.stagingSegment.tokenValue);

    reverse->laneCount = client.laneCount;
    reverse->client = client;
    for (uint32_t lane = 0; lane < client.laneCount; ++lane) {
        const auto& peer = client.peers[lane];
        urma_rjetty_t remote{};
        std::memcpy(remote.jetty_id.eid.raw, peer.eid, sizeof(remote.jetty_id.eid.raw));
        remote.jetty_id.uasid = peer.uasid;
        remote.jetty_id.id = peer.jettyId;
        remote.trans_mode = URMA_TM_RM;
        remote.tp_type = URMA_CTP;
        remote.type = URMA_JETTY;
        remote.policy = URMA_JETTY_GRP_POLICY_RR;

        urma_get_tp_cfg_t tpConfig{};
        tpConfig.flag.bs.ctp = 1;
        tpConfig.trans_mode = URMA_TM_RM;
        std::memcpy(tpConfig.local_eid.raw, context->eid.raw, sizeof(tpConfig.local_eid.raw));
        std::memcpy(tpConfig.peer_eid.raw, peer.eid, sizeof(tpConfig.peer_eid.raw));
        urma_tp_info_t tpInfo{};
        uint32_t tpCount = 1;
        if (urma_get_tp_list(context, &tpConfig, &tpCount, &tpInfo) != URMA_SUCCESS ||
            tpCount != 1 || tpInfo.tp_handle == 0) return false;

        urma_import_jetty_ex_cfg_t importConfig{};
        importConfig.tp_handle = tpInfo.tp_handle;
        importConfig.tag = 0;
        importConfig.tp_attr.tx_psn = static_cast<uint32_t>(::random());
        importConfig.tp_attr.rx_psn = 0;
        urma_token_t token{};
        token.token = peer.tokenValue;
        reverse->targetJettys[lane] =
            urma_import_jetty_ex(context, &remote, &token, &importConfig);
        if (reverse->targetJettys[lane] == nullptr) return false;
        const urma_status_t advise = urma_advise_jetty(localJettys[lane], reverse->targetJettys[lane]);
        if (advise != URMA_SUCCESS && advise != URMA_EEXIST) return false;
        std::printf("reverse_lane=%u npu_eid=", lane);
        PrintHex(peer.eid, sizeof(peer.eid));
        std::printf(" npu_jetty_id=%u npu_uasid=%u tp_handle=0x%llx\n",
            peer.jettyId, peer.uasid,
            static_cast<unsigned long long>(tpInfo.tp_handle));
    }
    std::fflush(stdout);
    return true;
}

void ReleaseReverseResources(
    const std::array<urma_jetty_t*, kRawUbMaxLanes>& localJettys,
    ReverseResources* reverse)
{
    if (reverse == nullptr) return;
    for (size_t lane = 0; lane < reverse->targetJettys.size(); ++lane) {
        auto* target = reverse->targetJettys[lane];
        if (target == nullptr) continue;
        if (localJettys[lane] != nullptr) {
            (void)urma_unadvise_jetty(localJettys[lane], target);
        }
        (void)urma_unimport_jetty(target);
    }
    if (reverse->stagingSegment != nullptr) {
        (void)urma_unimport_seg(reverse->stagingSegment);
    }
    *reverse = ReverseResources{};
}

int OpenControlListener(uint16_t port)
{
    const int listenFd = socket(AF_INET, SOCK_STREAM, 0);
    if (listenFd < 0) return -1;
    const int reuseAddress = 1;
    (void)setsockopt(listenFd, SOL_SOCKET, SO_REUSEADDR,
        &reuseAddress, sizeof(reuseAddress));
    sockaddr_in address{};
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    address.sin_port = htons(port);
    if (bind(listenFd, reinterpret_cast<const sockaddr*>(&address),
            sizeof(address)) != 0 ||
        listen(listenFd, 8) != 0) {
        close(listenFd);
        return -1;
    }
    std::printf("control_port=%u\n", port);
    std::fflush(stdout);
    return listenFd;
}

// -2 表示正常超时，-1 表示监听 socket 出错。
int AcceptControlClient(int listenFd, int timeoutMs)
{
    pollfd event{listenFd, POLLIN, 0};
    const int ready = poll(&event, 1, timeoutMs);
    if (ready == 0 || (ready < 0 && errno == EINTR)) return -2;
    if (ready < 0 ||
        (event.revents & (POLLERR | POLLHUP | POLLNVAL)) != 0) {
        return -1;
    }
    return accept(listenFd, nullptr, nullptr);
}

bool ExchangeResources(int clientFd, uint64_t pipelineBytes,
    const std::array<RawUbPeerDescriptor, kRawUbMaxLanes>& descriptors,
    uint32_t jettyCount, uint64_t dataGva, uint64_t dataBytes, uint64_t commandGva,
    urma_context_t* context, const std::array<urma_jetty_t*, kRawUbMaxLanes>& localJettys,
    ReverseResources* reverse) {
    if (clientFd < 0) return false;
    RawUbControlRequest request{};
    const bool receivedRequest =
        ReceiveAll(clientFd, &request, sizeof(request));
    const uint32_t lanes =
        receivedRequest && request.magic == kRawUbControlMagic &&
        request.version == kRawUbControlVersion &&
        request.laneCount <= jettyCount ? request.laneCount : 0;
    const RawUbControlResponse response{kRawUbControlMagic, kRawUbControlVersion, lanes,
        kRawUbCommandSlots, dataGva, dataBytes, commandGva, kRawUbCommandSlotBytes, 0};
    (void)SendAll(clientFd, &response, sizeof(response));
    if (lanes != 0) (void)SendAll(clientFd, descriptors.data(), lanes * sizeof(descriptors[0]));
    RawUbClientResources client{};
    const uint32_t maxSubIosPerWqe = RawUbMaxSubIosPerWqe(request.reserved);
    const uint32_t fixedWqeBytes = RawUbFixedWqeBytes(request.reserved);
    const bool aggregationConfigValid =
        (fixedWqeBytes == 0 || maxSubIosPerWqe != 0) &&
        (pipelineBytes == 0 ||
            (maxSubIosPerWqe == 0 && fixedWqeBytes == 0));
    if (!aggregationConfigValid) {
        std::fprintf(stderr,
            "invalid aggregation configuration: pipeline_mib=%llu "
            "max_subios_per_wqe=%u fixed_wqe_bytes=%u; capped aggregation "
            "requires --pipeline-mib=0\n",
            static_cast<unsigned long long>(pipelineBytes / (1024ULL * 1024ULL)),
            maxSubIosPerWqe, fixedWqeBytes);
    }
    const bool receivedClient = lanes != 0 &&
        ReceiveAll(clientFd, &client, sizeof(client));
    bool ready = receivedClient && aggregationConfigValid &&
        client.magic == kRawUbControlMagic && client.version == kRawUbControlVersion &&
        client.laneCount == lanes && client.deviceControlBytes >= kRawUbDeviceControlBytes;
    if (ready) {
        reverse->maxSubIosPerWqe = maxSubIosPerWqe;
        reverse->fixedWqeBytes = fixedWqeBytes;
        ready = ImportReverseResources(context, localJettys, client, reverse);
    }
    const RawUbControlAck ack{kRawUbControlMagic, kRawUbControlVersion, ready ? 0U : 1U, 0};
    (void)SendAll(clientFd, &ack, sizeof(ack));
    close(clientFd);
    return ready;
}

bool PollJfc(urma_jfc_t* jfc, uint32_t expected) {
    std::array<urma_cr_t, kRawUbMaxLanes> completions{};
    while (expected != 0) {
        const int count = urma_poll_jfc(jfc,
            static_cast<int>(std::min<uint32_t>(expected, completions.size())), completions.data());
        if (count > 0) expected -= static_cast<uint32_t>(count);
        if (count < 0) {
            std::fprintf(stderr, "urma_poll_jfc failed: %d\n", count);
            return false;
        }
    }
    return true;
}

class UrmaPerfSession {
public:
    void Start(bool enabled)
    {
        if (!enabled) return;
        start_ = reinterpret_cast<PerfControl>(dlsym(RTLD_DEFAULT, "urma_start_perf"));
        stop_ = reinterpret_cast<PerfControl>(dlsym(RTLD_DEFAULT, "urma_stop_perf"));
        get_ = reinterpret_cast<PerfGet>(dlsym(RTLD_DEFAULT, "urma_get_perf_info"));
        if (start_ == nullptr || stop_ == nullptr || get_ == nullptr) {
            std::fprintf(stderr, "--urma-perf requires a UMDK build exporting urma_*_perf\n");
            return;
        }
        active_ = start_() == 0;
    }

    void Print()
    {
        if (!active_) return;
        (void)stop_();
        std::vector<char> output(64 * 1024);
        uint32_t bytes = static_cast<uint32_t>(output.size());
        if (get_(output.data(), &bytes) == 0) {
            std::printf("URMA_API_PERF_BEGIN\n%.*sURMA_API_PERF_END\n",
                static_cast<int>(bytes), output.data());
        }
        active_ = false;
    }

private:
    using PerfControl = int (*)();
    using PerfGet = int (*)(char*, uint32_t*);
    PerfControl start_ = nullptr;
    PerfControl stop_ = nullptr;
    PerfGet get_ = nullptr;
    bool active_ = false;
};

struct PendingAggregateWrite {
    std::array<urma_sge_t, kRawUbMaxLanes> localSges{};
    std::array<urma_sge_t, kRawUbMaxLanes> remoteSges{};
    std::array<urma_jfs_wr_t, kRawUbMaxLanes> writes{};
    std::array<std::vector<urma_sge_t>, kRawUbMaxLanes> chainedLocalSges;
    std::array<std::vector<urma_sge_t>, kRawUbMaxLanes> chainedRemoteSges;
    std::array<std::vector<urma_jfs_wr_t>, kRawUbMaxLanes> chainedWrites;
    uint32_t completions = 0;
    uint64_t wqes = 0;
    uint64_t signaledWqes = 0;
    uint64_t wireBytes = 0;
    uint64_t internalPollNs = 0;
};

bool PostAggregateWrite(uint64_t sourceGva, uint64_t destinationGva, uint64_t bytes,
    uint64_t generation, urma_target_seg_t* hostSegment,
    const std::array<urma_jetty_t*, kRawUbMaxLanes>& localJettys,
    const ReverseResources& reverse, PendingAggregateWrite* pending)
{
    uint64_t offset = 0;
    uint64_t remaining = bytes;
    for (uint32_t lane = 0; lane < reverse.laneCount && remaining != 0; ++lane) {
        const uint64_t lanesLeft = reverse.laneCount - lane;
        uint64_t laneBytes = (remaining + lanesLeft - 1) / lanesLeft;
        if (lanesLeft != 1) laneBytes = (laneBytes + 63) & ~uint64_t{63};
        laneBytes = std::min(laneBytes, remaining);
        pending->localSges[lane].addr = sourceGva + offset;
        pending->localSges[lane].len = static_cast<uint32_t>(laneBytes);
        pending->localSges[lane].tseg = hostSegment;
        pending->remoteSges[lane].addr = destinationGva + offset;
        pending->remoteSges[lane].len = static_cast<uint32_t>(laneBytes);
        pending->remoteSges[lane].tseg = reverse.stagingSegment;
        pending->writes[lane].opcode = URMA_OPC_WRITE;
        pending->writes[lane].tjetty = reverse.targetJettys[lane];
        pending->writes[lane].user_ctx = (generation << 8) | lane;
        pending->writes[lane].flag.bs.complete_enable = 1;
        pending->writes[lane].rw.src.sge = &pending->localSges[lane];
        pending->writes[lane].rw.src.num_sge = 1;
        pending->writes[lane].rw.dst.sge = &pending->remoteSges[lane];
        pending->writes[lane].rw.dst.num_sge = 1;
        offset += laneBytes;
        remaining -= laneBytes;
        ++pending->completions;
        ++pending->signaledWqes;
        ++pending->wqes;
        pending->wireBytes += laneBytes;
    }
    for (uint32_t lane = 0; lane < pending->completions; ++lane) {
        urma_jfs_wr_t* bad = nullptr;
        if (urma_post_jetty_send_wr(
                localJettys[lane], &pending->writes[lane], &bad) != URMA_SUCCESS) {
            return false;
        }
    }
    return true;
}

bool PostCappedAggregateWrites(uint64_t sourceGva, uint64_t destinationGva,
    const std::vector<uint32_t>& subIoBytes, uint32_t maxSubIosPerWqe,
    uint32_t fixedWqeBytes, uint64_t generation, uint64_t aggregateBytes,
    urma_target_seg_t* hostSegment,
    const std::array<urma_jetty_t*, kRawUbMaxLanes>& localJettys,
    urma_jfc_t* jfc, const ReverseResources& reverse,
    PendingAggregateWrite* pending)
{
    if (subIoBytes.empty() || maxSubIosPerWqe == 0) return false;
    const uint32_t writeCount = static_cast<uint32_t>(
        (subIoBytes.size() + maxSubIosPerWqe - 1) / maxSubIosPerWqe);
    std::array<std::vector<uint64_t>, kRawUbMaxLanes> offsets;
    std::array<std::vector<uint32_t>, kRawUbMaxLanes> lengths;
    uint64_t packedOffset = 0;
    size_t subIo = 0;
    for (uint32_t writeIndex = 0; writeIndex < writeCount; ++writeIndex) {
        const uint32_t chunkSubIos = static_cast<uint32_t>(std::min<size_t>(
            maxSubIosPerWqe, subIoBytes.size() - subIo));
        uint64_t chunkBytes = 0;
        for (uint32_t index = 0; index < chunkSubIos; ++index, ++subIo) {
            chunkBytes += subIoBytes[subIo];
        }
        const uint64_t wireBytes = fixedWqeBytes == 0 ? chunkBytes : fixedWqeBytes;
        if (chunkBytes == 0 || chunkBytes > UINT32_MAX || wireBytes < chunkBytes ||
            wireBytes > UINT32_MAX || packedOffset + wireBytes > aggregateBytes) {
            std::fprintf(stderr,
                "invalid capped WQE: payload_bytes=%llu fixed_wqe_bytes=%u "
                "aggregate_bytes=%llu\n",
                static_cast<unsigned long long>(chunkBytes), fixedWqeBytes,
                static_cast<unsigned long long>(aggregateBytes));
            return false;
        }
        if (destinationGva < reverse.client.stagingGva) {
            std::fprintf(stderr, "capped WQE exceeds the NPU staging buffer\n");
            return false;
        }
        const uint64_t destinationOffset = destinationGva - reverse.client.stagingGva;
        if (destinationOffset > reverse.client.stagingBytes ||
            packedOffset + wireBytes >
                reverse.client.stagingBytes - destinationOffset) {
            std::fprintf(stderr, "capped WQE exceeds the NPU staging buffer\n");
            return false;
        }
        const uint32_t lane = writeIndex % reverse.laneCount;
        offsets[lane].push_back(packedOffset);
        lengths[lane].push_back(static_cast<uint32_t>(wireBytes));
        packedOffset += chunkBytes;
        ++pending->wqes;
        pending->wireBytes += wireBytes;
    }

    for (uint32_t lane = 0; lane < reverse.laneCount; ++lane) {
        const size_t count = offsets[lane].size();
        if (count == 0) continue;
        auto& localSges = pending->chainedLocalSges[lane];
        auto& remoteSges = pending->chainedRemoteSges[lane];
        auto& writes = pending->chainedWrites[lane];
        localSges.resize(count);
        remoteSges.resize(count);
        writes.resize(count);
        for (size_t index = 0; index < count; ++index) {
            localSges[index].addr = sourceGva + offsets[lane][index];
            localSges[index].len = lengths[lane][index];
            localSges[index].tseg = hostSegment;
            remoteSges[index].addr = destinationGva + offsets[lane][index];
            remoteSges[index].len = lengths[lane][index];
            remoteSges[index].tseg = reverse.stagingSegment;
            auto& write = writes[index];
            write.opcode = URMA_OPC_WRITE;
            write.tjetty = reverse.targetJettys[lane];
            write.user_ctx = (generation << 8) | lane;
            // Only the tail of each lane produces a CQE; all other data WQEs
            // are deliberately unsignaled.
            write.rw.src.sge = &localSges[index];
            write.rw.src.num_sge = 1;
            write.rw.dst.sge = &remoteSges[index];
            write.rw.dst.num_sge = 1;
        }
    }
    for (size_t begin = 0;; begin += kCappedWqesPerPost) {
        uint32_t roundCompletions = 0;
        bool hasMore = false;
        for (uint32_t lane = 0; lane < reverse.laneCount; ++lane) {
            auto& writes = pending->chainedWrites[lane];
            if (begin >= writes.size()) continue;
            const size_t end = std::min(
                begin + static_cast<size_t>(kCappedWqesPerPost), writes.size());
            for (size_t index = begin; index < end; ++index) {
                writes[index].flag.bs.complete_enable = index + 1 == end;
                writes[index].next = index + 1 == end ? nullptr : &writes[index + 1];
            }
            urma_jfs_wr_t* bad = nullptr;
            if (urma_post_jetty_send_wr(
                    localJettys[lane], &writes[begin], &bad) != URMA_SUCCESS) {
                return false;
            }
            ++roundCompletions;
            ++pending->signaledWqes;
            hasMore = hasMore || end != writes.size();
        }
        if (roundCompletions == 0) break;
        if (!hasMore) {
            pending->completions = roundCompletions;
            break;
        }
        const uint64_t pollStart = static_cast<uint64_t>(
            std::chrono::duration_cast<std::chrono::nanoseconds>(
                std::chrono::steady_clock::now().time_since_epoch()).count());
        if (!PollJfc(jfc, roundCompletions)) return false;
        const uint64_t pollEnd = static_cast<uint64_t>(
            std::chrono::duration_cast<std::chrono::nanoseconds>(
                std::chrono::steady_clock::now().time_since_epoch()).count());
        pending->internalPollNs += pollEnd - pollStart;
    }
    return true;
}

void ProcessCommand(uint32_t slotIndex, RawUbHostCommandSlot* command,
    uint8_t* poolHost, uint64_t poolGva, uint64_t poolBytes,
    const std::array<uint8_t*, 2>& aggregateHosts,
    const std::array<uint64_t, 2>& aggregateGvas,
    uint64_t aggregateBytes, uint64_t pipelineBytes,
    uint64_t hostCommandGva, urma_target_seg_t* hostSegment,
    const std::array<urma_jetty_t*, kRawUbMaxLanes>& localJettys,
    urma_jfc_t* jfc, const ReverseResources& reverse, GatherExecutor* gather,
    PushStats* stats, std::mutex* cqMutex) {
    const uint64_t generation = __atomic_load_n(&command->commitGeneration, __ATOMIC_ACQUIRE);
    if (generation == 0) return;
    static std::atomic<bool> firstCommandSeen{false};
    const bool firstCommand = !firstCommandSeen.exchange(true, std::memory_order_relaxed);
    if (firstCommand) {
        std::printf("HOST_PUSH_COMMAND_SEEN slot=%u commit=%llu generation=%llu entries=%u mode=%u\n",
            slotIndex, static_cast<unsigned long long>(generation),
            static_cast<unsigned long long>(command->generation), command->entryCount,
            command->reserved);
        std::fflush(stdout);
    }
    if (generation != command->generation) return;
    const uint64_t beginNs = static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count());

    const uint32_t mode = command->reserved;
    const bool aggregate = mode == kRawUbCommandModeAggregate;
    const bool tokenGather = mode == kRawUbCommandModeTokenGather;
    const bool gatherMode = aggregate || tokenGather;
    if ((!tokenGather && command->entryCount > kRawUbMaxPushEntries) ||
        (tokenGather && command->entryCount > kRawUbMaxTokenGatherEntries) ||
        (!gatherMode && mode != kRawUbCommandModeDirect)) {
        return;
    }
    uint64_t tokenBytes = kRawUbTokenBytes;
    if (tokenGather && command->entryCount != 0) {
        tokenBytes = command->tokenEntries[0].tokenBytes;
        if (tokenBytes != kRawUbTokenBytes &&
            tokenBytes != kRawUbFlatFp8TokenBytes &&
            tokenBytes != kRawUbFlatC8TokenBytes) {
            return;
        }
        for (uint32_t index = 1; index < command->entryCount; ++index) {
            if (command->tokenEntries[index].tokenBytes != tokenBytes) return;
        }
    }
    uint64_t totalBytes = tokenGather ?
        static_cast<uint64_t>(command->entryCount) * tokenBytes : 0;
    if (!tokenGather) {
        for (uint32_t index = 0; index < command->entryCount; ++index) {
            totalBytes += command->entries[index].bytes;
        }
    }

    std::lock_guard<std::mutex> lock(*cqMutex);
    uint32_t pendingCompletions = 0;
    uint64_t gatherNs = 0;
    uint64_t prepareNs = 0;
    uint64_t postNs = 0;
    uint64_t pollNs = 0;
    uint64_t networkNs = 0;
    uint64_t wireStartNs = 0;
    uint64_t postEndNs = 0;
    uint64_t lastPostStartNs = 0;
    uint64_t subIoCount = 0;
    uint64_t dataWqeCount = 0;
    uint64_t signaledDataWqeCount = 0;
    uint64_t physicalWireBytes = 0;
    if (gatherMode) {
        static thread_local std::vector<uint64_t> offsets;
        static thread_local std::vector<uint32_t> subIoBytes;
        static thread_local std::array<std::vector<GatherItem>, 2> gatherItems;
        if (!tokenGather) {
            offsets.resize(command->entryCount + 1);
            offsets[0] = 0;
            for (uint32_t index = 0; index < command->entryCount; ++index) {
                const auto& entry = command->entries[index];
                if (entry.srcGva < poolGva ||
                    entry.srcGva - poolGva + entry.bytes > poolBytes) {
                    return;
                }
                offsets[index + 1] = offsets[index] + entry.bytes;
            }
        }
        const uint64_t segmentLimit = pipelineBytes == 0 ? totalBytes : pipelineBytes;
        const uint32_t tokenEntriesPerSegment = static_cast<uint32_t>(
            std::max<uint64_t>(1, segmentLimit / tokenBytes));
        std::array<PendingAggregateWrite, 2> pendingWrites{};
        std::array<uint64_t, 2> pendingPostStarts{};
        uint32_t beginEntry = 0;
        uint32_t segment = 0;
        uint32_t previousCompletions = 0;
        while (beginEntry < command->entryCount) {
            uint32_t endEntry = beginEntry;
            if (tokenGather) {
                endEntry = std::min<uint32_t>(
                    command->entryCount, beginEntry + tokenEntriesPerSegment);
            } else {
                while (endEntry < command->entryCount &&
                       (endEntry == beginEntry ||
                        offsets[endEntry + 1] - offsets[beginEntry] <=
                            segmentLimit)) {
                    ++endEntry;
                }
            }
            const uint32_t buffer = segment & 1U;
            const uint64_t segmentBytes = tokenGather ?
                static_cast<uint64_t>(endEntry - beginEntry) *
                    tokenBytes :
                offsets[endEntry] - offsets[beginEntry];
            if (segmentBytes > aggregateBytes) return;
            const uint64_t prepareStartNs = static_cast<uint64_t>(
                std::chrono::duration_cast<std::chrono::nanoseconds>(
                    std::chrono::steady_clock::now().time_since_epoch()).count());
            if (!tokenGather) {
                auto& items = gatherItems[buffer];
                items.clear();
                items.reserve(endEntry - beginEntry);
                for (uint32_t index = beginEntry; index < endEntry; ++index) {
                    const auto& entry = command->entries[index];
                    items.push_back({
                        poolHost + (entry.srcGva - poolGva),
                        aggregateHosts[buffer] + offsets[index] -
                            offsets[beginEntry],
                        entry.bytes});
                }
            }
            const uint64_t prepareEndNs = static_cast<uint64_t>(
                std::chrono::duration_cast<std::chrono::nanoseconds>(
                    std::chrono::steady_clock::now().time_since_epoch()).count());
            prepareNs += prepareEndNs - prepareStartNs;
            if (tokenGather) {
                gather->StartTokenDescriptors(
                    command->tokenEntries + beginEntry,
                    endEntry - beginEntry, poolHost, poolGva,
                    aggregateHosts[buffer]);
            } else {
                const auto& items = gatherItems[buffer];
                gather->Start(items.data(), items.size());
            }
            if (previousCompletions != 0) {
                const uint64_t pollStart = static_cast<uint64_t>(
                    std::chrono::duration_cast<std::chrono::nanoseconds>(
                        std::chrono::steady_clock::now().time_since_epoch()).count());
                if (!PollJfc(jfc, previousCompletions)) return;
                const uint64_t pollEnd = static_cast<uint64_t>(
                    std::chrono::duration_cast<std::chrono::nanoseconds>(
                        std::chrono::steady_clock::now().time_since_epoch()).count());
                pollNs += pollEnd - pollStart;
                networkNs += pollEnd - pendingPostStarts[(segment - 1) & 1U];
            }
            gatherNs += gather->Wait();
            subIoBytes.clear();
            if (tokenGather) {
                const uint32_t entries = endEntry - beginEntry;
                subIoBytes.reserve(static_cast<size_t>(entries) *
                    (tokenBytes == kRawUbTokenBytes ? 2 : 1));
                for (uint32_t index = 0; index < entries; ++index) {
                    if (tokenBytes == kRawUbTokenBytes) {
                        subIoBytes.push_back(kRawUbCkvTokenBytes);
                        subIoBytes.push_back(kRawUbKpeTokenBytes);
                    } else {
                        subIoBytes.push_back(static_cast<uint32_t>(tokenBytes));
                    }
                }
            } else {
                subIoBytes.reserve(endEntry - beginEntry);
                for (uint32_t index = beginEntry; index < endEntry; ++index) {
                    subIoBytes.push_back(command->entries[index].bytes);
                }
            }
            subIoCount += subIoBytes.size();
            if (reverse.fixedWqeBytes != 0) {
                if (segmentBytes + reverse.fixedWqeBytes > aggregateBytes) {
                    std::fprintf(stderr, "fixed WQE padding exceeds aggregate buffer\n");
                    return;
                }
                std::memset(aggregateHosts[buffer] + segmentBytes, 0,
                    reverse.fixedWqeBytes);
            }
            pendingWrites[buffer] = {};
            const uint64_t postStart = static_cast<uint64_t>(
                std::chrono::duration_cast<std::chrono::nanoseconds>(
                    std::chrono::steady_clock::now().time_since_epoch()).count());
            if (wireStartNs == 0) wireStartNs = postStart;
            lastPostStartNs = postStart;
            pendingPostStarts[buffer] = postStart;
            const uint64_t destinationGva = tokenGather ?
                command->destinationGva +
                    static_cast<uint64_t>(beginEntry) * tokenBytes :
                command->entries[beginEntry].dstGva;
            const bool posted = reverse.maxSubIosPerWqe == 0 ?
                PostAggregateWrite(aggregateGvas[buffer], destinationGva,
                    segmentBytes, generation, hostSegment, localJettys,
                    reverse, &pendingWrites[buffer]) :
                PostCappedAggregateWrites(aggregateGvas[buffer], destinationGva,
                    subIoBytes, reverse.maxSubIosPerWqe,
                    reverse.fixedWqeBytes, generation, aggregateBytes,
                    hostSegment, localJettys, jfc, reverse,
                    &pendingWrites[buffer]);
            if (!posted) {
                std::fprintf(stderr, "host aggregate WRITE post failed\n");
                return;
            }
            dataWqeCount += pendingWrites[buffer].wqes;
            signaledDataWqeCount += pendingWrites[buffer].signaledWqes;
            physicalWireBytes += pendingWrites[buffer].wireBytes;
            postEndNs = static_cast<uint64_t>(
                std::chrono::duration_cast<std::chrono::nanoseconds>(
                    std::chrono::steady_clock::now().time_since_epoch()).count());
            postNs += postEndNs - postStart - pendingWrites[buffer].internalPollNs;
            pollNs += pendingWrites[buffer].internalPollNs;
            previousCompletions = pendingWrites[buffer].completions;
            beginEntry = endEntry;
            ++segment;
        }
        pendingCompletions = previousCompletions;
    } else {
        const uint64_t prepareStartNs = static_cast<uint64_t>(
            std::chrono::duration_cast<std::chrono::nanoseconds>(
                std::chrono::steady_clock::now().time_since_epoch()).count());
        std::array<std::vector<RawUbHostPushEntry>, kRawUbMaxLanes> laneEntries;
        std::array<std::vector<urma_sge_t>, kRawUbMaxLanes> localSges;
        std::array<std::vector<urma_sge_t>, kRawUbMaxLanes> remoteSges;
        std::array<std::vector<urma_jfs_wr_t>, kRawUbMaxLanes> writes;
        for (uint32_t index = 0; index < command->entryCount; ++index) {
            const auto entry = command->entries[index];
            laneEntries[entry.lane % reverse.laneCount].push_back(entry);
        }
        for (uint32_t lane = 0; lane < reverse.laneCount; ++lane) {
            const auto& entries = laneEntries[lane];
            if (entries.empty()) continue;
            localSges[lane].resize(entries.size());
            remoteSges[lane].resize(entries.size());
            writes[lane].resize(entries.size());
            for (size_t index = 0; index < entries.size(); ++index) {
                localSges[lane][index].addr = entries[index].srcGva;
                localSges[lane][index].len = entries[index].bytes;
                localSges[lane][index].tseg = hostSegment;
                remoteSges[lane][index].addr = entries[index].dstGva;
                remoteSges[lane][index].len = entries[index].bytes;
                remoteSges[lane][index].tseg = reverse.stagingSegment;
                writes[lane][index].opcode = URMA_OPC_WRITE;
                writes[lane][index].tjetty = reverse.targetJettys[lane];
                writes[lane][index].user_ctx = (generation << 8) | lane;
                writes[lane][index].rw.src.sge = &localSges[lane][index];
                writes[lane][index].rw.src.num_sge = 1;
                writes[lane][index].rw.dst.sge = &remoteSges[lane][index];
                writes[lane][index].rw.dst.num_sge = 1;
                writes[lane][index].flag.bs.complete_enable = index + 1 == entries.size();
                writes[lane][index].next =
                    index + 1 == entries.size() ? nullptr : &writes[lane][index + 1];
            }
        }
        const uint64_t prepareEndNs = static_cast<uint64_t>(
            std::chrono::duration_cast<std::chrono::nanoseconds>(
                std::chrono::steady_clock::now().time_since_epoch()).count());
        prepareNs = prepareEndNs - prepareStartNs;
        wireStartNs = static_cast<uint64_t>(
            std::chrono::duration_cast<std::chrono::nanoseconds>(
                std::chrono::steady_clock::now().time_since_epoch()).count());
        for (uint32_t lane = 0; lane < reverse.laneCount; ++lane) {
            if (writes[lane].empty()) continue;
            urma_jfs_wr_t* bad = nullptr;
            const urma_status_t status =
                urma_post_jetty_send_wr(localJettys[lane], writes[lane].data(), &bad);
            if (status != URMA_SUCCESS) {
                std::fprintf(stderr, "host data WRITE post failed: lane=%u status=%d\n", lane, status);
                return;
            }
            ++pendingCompletions;
        }
        subIoCount = command->entryCount;
        dataWqeCount = command->entryCount;
        signaledDataWqeCount = pendingCompletions;
        physicalWireBytes = totalBytes;
        postEndNs = static_cast<uint64_t>(
            std::chrono::duration_cast<std::chrono::nanoseconds>(
                std::chrono::steady_clock::now().time_since_epoch()).count());
    }
    if (firstCommand) {
        std::printf("HOST_PUSH_DATA_POSTED generation=%llu completions=%u\n",
            static_cast<unsigned long long>(generation), pendingCompletions);
        std::fflush(stdout);
    }
    if (!gatherMode) postNs = postEndNs - wireStartNs;
    const uint64_t pollStartNs = postEndNs;
    if (!PollJfc(jfc, pendingCompletions)) return;
    const uint64_t wireEndNs = static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count());
    pollNs += wireEndNs - pollStartNs;
    if (gatherMode) {
        networkNs += wireEndNs - lastPostStartNs;
    } else {
        networkNs = wireEndNs - wireStartNs;
    }
    if (firstCommand) {
        std::printf("HOST_PUSH_DATA_COMPLETED generation=%llu\n",
            static_cast<unsigned long long>(generation));
        std::fflush(stdout);
    }

    urma_sge_t completionSource{};
    completionSource.addr = hostCommandGva + static_cast<uint64_t>(slotIndex) * kRawUbCommandSlotBytes;
    completionSource.len = sizeof(generation);
    completionSource.tseg = hostSegment;
    urma_sge_t completionTarget{};
    completionTarget.addr = reverse.client.deviceControlGva + kRawUbCommandSlotBytes +
        static_cast<uint64_t>(slotIndex) * kRawUbCompletionStride;
    completionTarget.len = sizeof(generation);
    completionTarget.tseg = reverse.stagingSegment;
    if (firstCommand) {
        std::printf("HOST_PUSH_COMPLETION_TARGET generation=%llu gva=0x%llx\n",
            static_cast<unsigned long long>(generation),
            static_cast<unsigned long long>(completionTarget.addr));
        std::fflush(stdout);
    }
    urma_jfs_wr_t completionWrite{};
    completionWrite.opcode = URMA_OPC_WRITE;
    completionWrite.tjetty = reverse.targetJettys[0];
    completionWrite.user_ctx = generation;
    completionWrite.flag.bs.complete_enable = 1;
    completionWrite.rw.src.sge = &completionSource;
    completionWrite.rw.src.num_sge = 1;
    completionWrite.rw.dst.sge = &completionTarget;
    completionWrite.rw.dst.num_sge = 1;
    urma_jfs_wr_t* bad = nullptr;
    const urma_status_t completionStatus =
        urma_post_jetty_send_wr(localJettys[0], &completionWrite, &bad);
    if (completionStatus != URMA_SUCCESS) {
        std::fprintf(stderr, "host completion WRITE post failed: status=%d\n", completionStatus);
        return;
    }
    if (firstCommand) {
        std::printf("HOST_PUSH_COMPLETION_POSTED generation=%llu\n",
            static_cast<unsigned long long>(generation));
        std::fflush(stdout);
    }
    if (!PollJfc(jfc, 1)) return;
    if (firstCommand) {
        std::printf("HOST_PUSH_COMMAND_DONE generation=%llu\n",
            static_cast<unsigned long long>(generation));
        std::fflush(stdout);
    }
    __atomic_store_n(&command->commitGeneration, uint64_t{0}, __ATOMIC_RELEASE);

    const uint64_t endNs = static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count());
    const uint64_t completionNs = endNs - wireEndNs;
    stats->commands.fetch_add(1, std::memory_order_relaxed);
    stats->blocks.fetch_add(command->entryCount, std::memory_order_relaxed);
    stats->bytes.fetch_add(totalBytes, std::memory_order_relaxed);
    stats->elapsedNs.fetch_add(endNs - beginNs, std::memory_order_relaxed);
    stats->wireNs.fetch_add(networkNs, std::memory_order_relaxed);
    stats->prepareNs.fetch_add(prepareNs, std::memory_order_relaxed);
    stats->postNs.fetch_add(postNs, std::memory_order_relaxed);
    stats->pollNs.fetch_add(pollNs, std::memory_order_relaxed);
    stats->completionNs.fetch_add(completionNs, std::memory_order_relaxed);
    stats->subIos.fetch_add(subIoCount, std::memory_order_relaxed);
    stats->dataWqes.fetch_add(dataWqeCount, std::memory_order_relaxed);
    stats->signaledDataWqes.fetch_add(
        signaledDataWqeCount, std::memory_order_relaxed);
    stats->wireBytes.fetch_add(physicalWireBytes, std::memory_order_relaxed);
    if (aggregate) {
        stats->aggregateCommands.fetch_add(1, std::memory_order_relaxed);
        stats->aggregateBytes.fetch_add(totalBytes, std::memory_order_relaxed);
        stats->aggregateElapsedNs.fetch_add(endNs - beginNs, std::memory_order_relaxed);
        stats->aggregateWireNs.fetch_add(networkNs, std::memory_order_relaxed);
        stats->gatherNs.fetch_add(gatherNs, std::memory_order_relaxed);
    } else if (tokenGather) {
        stats->tokenGatherCommands.fetch_add(1, std::memory_order_relaxed);
        stats->tokenGatherBytes.fetch_add(totalBytes, std::memory_order_relaxed);
        stats->tokenGatherElapsedNs.fetch_add(
            endNs - beginNs, std::memory_order_relaxed);
        stats->tokenGatherWireNs.fetch_add(networkNs, std::memory_order_relaxed);
        stats->tokenGatherNs.fetch_add(gatherNs, std::memory_order_relaxed);
    } else {
        stats->directCommands.fetch_add(1, std::memory_order_relaxed);
        stats->directBytes.fetch_add(totalBytes, std::memory_order_relaxed);
        stats->directElapsedNs.fetch_add(endNs - beginNs, std::memory_order_relaxed);
        stats->directWireNs.fetch_add(networkNs, std::memory_order_relaxed);
    }
    if (!tokenGather) {
        for (size_t index = 0; index < kProbeBytes.size(); ++index) {
            if (totalBytes != kProbeBytes[index]) continue;
            auto& sizeStats =
                aggregate ? stats->aggregateSizes[index] : stats->directSizes[index];
            ++sizeStats.commands;
            sizeStats.bytes += totalBytes;
            sizeStats.gatherNs += gatherNs;
            sizeStats.prepareNs += prepareNs;
            sizeStats.postNs += postNs;
            sizeStats.pollNs += pollNs;
            sizeStats.completionNs += completionNs;
            sizeStats.wireNs += networkNs;
            sizeStats.elapsedNs += endNs - beginNs;
            break;
        }
    }
    {
        std::lock_guard<std::mutex> sampleLock(stats->samplesMutex);
        stats->samples.push_back({
            mode, totalBytes, gatherNs, prepareNs, postNs, pollNs,
            completionNs, networkNs, endNs - beginNs});
    }
}

void PollCommands(uint32_t threadIndex, uint32_t threadCount, int cpu,
    RawUbHostCommandSlot* commands,
    uint8_t* poolHost, uint64_t poolGva, uint64_t poolBytes,
    const std::array<uint8_t*, 2>& aggregateHosts,
    const std::array<uint64_t, 2>& aggregateGvas,
    uint64_t aggregateBytes, uint64_t pipelineBytes,
    uint64_t hostCommandGva, urma_target_seg_t* hostSegment,
    const std::array<urma_jetty_t*, kRawUbMaxLanes>& localJettys, urma_jfc_t* jfc,
    const ReverseResources& reverse, GatherExecutor* gather,
    std::atomic<bool>* running, PushStats* stats,
    std::mutex* cqMutex) {
#if defined(__linux__)
    if (cpu >= 0) {
        cpu_set_t set;
        CPU_ZERO(&set);
        CPU_SET(cpu, &set);
        const int result =
            pthread_setaffinity_np(pthread_self(), sizeof(set), &set);
        if (result != 0) {
            std::fprintf(stderr,
                "poll affinity failed: thread=%u cpu=%d error=%d\n",
                threadIndex, cpu, result);
        }
    }
#else
    (void)cpu;
#endif
    while (running->load(std::memory_order_acquire)) {
        for (uint32_t slot = threadIndex; slot < kRawUbCommandSlots; slot += threadCount) {
            if (__atomic_load_n(&commands[slot].commitGeneration, __ATOMIC_ACQUIRE) != 0) {
                ProcessCommand(slot, &commands[slot],
                    poolHost, poolGva, poolBytes,
                    aggregateHosts, aggregateGvas, aggregateBytes, pipelineBytes,
                    hostCommandGva, hostSegment,
                    localJettys, jfc, reverse, gather, stats, cqMutex);
            }
        }
    }
}

void PrintStagePercentiles(PushStats* stats, uint32_t wantedMode,
    const char* mode, uint32_t pipelineMib)
{
    std::array<std::vector<uint64_t>, 7> stages;
    {
        std::lock_guard<std::mutex> lock(stats->samplesMutex);
        for (const auto& sample : stats->samples) {
            if (sample.mode != wantedMode) continue;
            stages[0].push_back(sample.gatherNs);
            stages[1].push_back(sample.prepareNs);
            stages[2].push_back(sample.postNs);
            stages[3].push_back(sample.pollNs);
            stages[4].push_back(sample.wireNs);
            stages[5].push_back(sample.completionNs);
            stages[6].push_back(sample.elapsedNs);
        }
    }
    if (stages[0].empty()) return;
    constexpr std::array<const char*, 7> names{
        "gather", "prepare", "post", "poll", "wire", "completion", "total"};
    std::printf("HOST_STAGE_STATS mode=%s pipeline_mib=%u samples=%zu",
        mode, pipelineMib, stages[0].size());
    for (size_t stage = 0; stage < stages.size(); ++stage) {
        auto& values = stages[stage];
        std::sort(values.begin(), values.end());
        uint64_t sum = 0;
        for (uint64_t value : values) sum += value;
        const double avgUs =
            static_cast<double>(sum) / static_cast<double>(values.size()) / 1000.0;
        const double p50Us = static_cast<double>(values[values.size() / 2]) / 1000.0;
        const size_t p99Index = (values.size() * 99 + 99) / 100 - 1;
        const double p99Us = static_cast<double>(values[p99Index]) / 1000.0;
        std::printf(" %s_avg_us=%.3f %s_p50_us=%.3f %s_p99_us=%.3f",
            names[stage], avgUs, names[stage], p50Us, names[stage], p99Us);
    }
    std::printf("\n");
}

}  // namespace

int main(int argc, char** argv) {
    std::signal(SIGINT, StopServer);
    std::signal(SIGTERM, StopServer);
    Options options{};
    if (!ParseOptions(argc, argv, &options)) return 2;
    if (!HasCompletePeer(options)) {
        std::fprintf(stderr, "--peer-eid, --peer-uasid, and --peer-jetty-id must be supplied together\n");
        return 2;
    }

    const uint64_t ckvBytesPerBlock = kTokensPerBlock * kCkvBytesPerToken;
    const uint64_t kpeBytesPerBlock = kTokensPerBlock * kKpeBytesPerToken;
    const uint64_t bytesPerBlock = ckvBytesPerBlock + kpeBytesPerBlock;
    const uint64_t poolBytes = bytesPerBlock * options.blocks;
    const uint64_t commandBytes =
        static_cast<uint64_t>(kRawUbCommandSlots) * kRawUbCommandSlotBytes;
    const uint64_t aggregateBufferCount = options.pipelineMib == 0 ? 1 : 2;
    const uint64_t registeredBytes =
        poolBytes + commandBytes + aggregateBufferCount * kAggregateBytes;

    void* pool = nullptr;
    const long pageSize = sysconf(_SC_PAGESIZE);
    if (pageSize <= 0 || posix_memalign(&pool, static_cast<size_t>(pageSize), registeredBytes) != 0) {
        std::fprintf(stderr, "posix_memalign(%llu) failed\n",
                     static_cast<unsigned long long>(registeredBytes));
        return 1;
    }
#if defined(MADV_HUGEPAGE)
    (void)madvise(pool, registeredBytes, MADV_HUGEPAGE);
#endif
    auto* bytes = static_cast<uint8_t*>(pool);
    if (options.poolPattern == PoolPattern::BF16) {
        FillBf16Pool(
            bytes, options.blocks, bytesPerBlock,
            ckvBytesPerBlock);
    } else {
        // Preserve the original byte-address pattern for the raw transport
        // smoke tests.
        for (uint64_t offset = 0; offset < poolBytes; ++offset) {
            bytes[offset] =
                static_cast<uint8_t>(offset % 251U);
        }
    }
    std::memset(bytes + poolBytes, 0,
        commandBytes + aggregateBufferCount * kAggregateBytes);
    auto* commandSlots = reinterpret_cast<RawUbHostCommandSlot*>(bytes + poolBytes);
    auto* aggregateBuffer = bytes + poolBytes + commandBytes;
    std::array<uint8_t*, 2> aggregateBuffers{
        aggregateBuffer,
        options.pipelineMib == 0 ? nullptr : aggregateBuffer + kAggregateBytes};
    (void)mlock(commandSlots, commandBytes);

    urma_context_t* context = nullptr;
    urma_token_id_t* tokenId = nullptr;
    urma_target_seg_t* segment = nullptr;
    urma_device_t* device = nullptr;
    urma_jfce_t* jfce = nullptr;
    urma_jfc_t* jfc = nullptr;
    urma_jfr_t* jfr = nullptr;
    std::array<urma_jetty_t*, kRawUbMaxLanes> jettys{};
    urma_target_jetty_t* peerJetty = nullptr;
    urma_seg_cfg_t config{};
    urma_device_attr_t deviceAttr{};
    urma_jfc_cfg_t jfcConfig{};
    urma_jfr_cfg_t jfrConfig{};
    urma_jetty_cfg_t jettyConfig{};
    urma_net_addr_t hostNicAddress{};
    urma_eid_t hostNicEid{};
    urma_eid_t peerEid{};
    std::array<RawUbPeerDescriptor, kRawUbMaxLanes> descriptors{};
    std::string hostNicIp;
    bool jettyBound = false;
    int exitCode = 1;
    int controlListenFd = -1;
    uint64_t segmentGva = 0;
    std::array<uint64_t, 2> aggregateGvas{};
    ReverseResources reverse{};
    PushStats pushStats{};
    std::atomic<bool> pollRunning{false};
    std::mutex cqMutex;
    std::vector<std::thread> pollers;
    auto gatherExecutor = std::make_unique<GatherExecutor>(
        options.gatherThreads, options.gatherCpus,
        options.gatherKernel);
    UrmaPerfSession urmaPerf;
    const auto StopPollers = [&]() {
        pollRunning.store(false, std::memory_order_release);
        for (auto& poller : pollers) {
            if (poller.joinable()) poller.join();
        }
        pollers.clear();
    };
    const auto StartPollers = [&]() {
        pollRunning.store(true, std::memory_order_release);
        pollers.reserve(options.pollThreads);
        for (uint32_t thread = 0; thread < options.pollThreads; ++thread) {
            const int cpu = options.pollCpus.empty() ? -1 :
                static_cast<int>(options.pollCpus[thread]);
            pollers.emplace_back(PollCommands, thread,
                options.pollThreads, cpu, commandSlots,
                bytes, segmentGva, poolBytes,
                aggregateBuffers, aggregateGvas, kAggregateBytes,
                static_cast<uint64_t>(options.pipelineMib) *
                    1024ULL * 1024ULL,
                segmentGva + poolBytes, segment, std::cref(jettys),
                jfc, std::cref(reverse), gatherExecutor.get(),
                &pollRunning, &pushStats, &cqMutex);
        }
    };

    if (urma_init(nullptr) != URMA_SUCCESS) {
        std::fprintf(stderr, "urma_init failed (is liburma/provider/driver installed?)\n");
        goto cleanup;
    }

    if (options.deviceName.empty()) {
        int count = 0;
        urma_device_t** devices = urma_get_device_list(&count);
        if (devices == nullptr || count <= 0) {
            std::fprintf(stderr, "urma_get_device_list returned no devices\n");
            if (devices != nullptr) urma_free_device_list(devices);
            goto cleanup_uninit;
        }
        options.deviceName = devices[0]->name;
        urma_free_device_list(devices);
    }
    device = urma_get_device_by_name(const_cast<char*>(options.deviceName.c_str()));
    if (device == nullptr) {
        std::fprintf(stderr, "urma_get_device_by_name(%s) failed\n", options.deviceName.c_str());
        goto cleanup_uninit;
    }

    context = urma_create_context(device, options.eidIndex);
    if (context == nullptr) {
        std::fprintf(stderr, "urma_create_context(%s, %u) failed\n", options.deviceName.c_str(),
                     options.eidIndex);
        goto cleanup_uninit;
    }

    if (!options.hostNic.empty()) {
        if (!GetNicAddress(options.hostNic, &hostNicAddress, &hostNicIp)) {
            std::fprintf(stderr, "cannot resolve an IPv4/IPv6 address for --host-nic=%s\n",
                         options.hostNic.c_str());
            goto cleanup_context;
        }
        if (urma_get_eid_by_ip(context, &hostNicAddress, &hostNicEid) != URMA_SUCCESS) {
            std::fprintf(stderr, "host NIC %s (%s) is not configured for URMA device %s/eid-index %u\n",
                         options.hostNic.c_str(), hostNicIp.c_str(), options.deviceName.c_str(),
                         options.eidIndex);
            goto cleanup_context;
        }
    }

    // A Jetty consists of JFS and JFR in the public URMA API.  We create the
    // required JFR object but never post a receive WR to it: the only intended
    // data plane operations for this pool are one-sided READ/WRITE via JFS.
    if (urma_query_device(device, &deviceAttr) != URMA_SUCCESS ||
        (deviceAttr.dev_cap.trans_mode & URMA_TM_RM) == 0) {
        std::fprintf(stderr, "URMA device does not support RM READ/WRITE\n");
        goto cleanup_context;
    }

    jfce = urma_create_jfce(context);
    if (jfce == nullptr) {
        std::fprintf(stderr, "urma_create_jfce failed\n");
        goto cleanup_context;
    }
    jfcConfig.depth = 128;
    jfcConfig.jfce = jfce;
    jfc = urma_create_jfc(context, &jfcConfig);
    if (jfc == nullptr) {
        std::fprintf(stderr, "urma_create_jfc failed\n");
        goto cleanup_jfce;
    }
    jfrConfig.depth = 128;
    jfrConfig.flag.bs.tag_matching = URMA_NO_TAG_MATCHING;
    jfrConfig.trans_mode = URMA_TM_RM;
    jfrConfig.max_sge = 1;
    jfrConfig.min_rnr_timer = URMA_TYPICAL_MIN_RNR_TIMER;
    jfrConfig.jfc = jfc;
    jfrConfig.token_value.token = kTokenValue;
    jfr = urma_create_jfr(context, &jfrConfig);
    if (jfr == nullptr) {
        std::fprintf(stderr, "urma_create_jfr failed\n");
        goto cleanup_jfc;
    }
    jettyConfig.id = 1;
    jettyConfig.flag.bs.share_jfr = 1;
    jettyConfig.jfs_cfg.depth = 512;
    jettyConfig.jfs_cfg.trans_mode = URMA_TM_RM;
    jettyConfig.jfs_cfg.max_sge = 1;
    jettyConfig.jfs_cfg.max_rsge = 1;
    jettyConfig.jfs_cfg.rnr_retry = URMA_TYPICAL_RNR_RETRY;
    jettyConfig.jfs_cfg.err_timeout = URMA_TYPICAL_ERR_TIMEOUT;
    jettyConfig.jfs_cfg.jfc = jfc;
    jettyConfig.shared.jfr = jfr;
    for (uint32_t lane = 0; lane < options.jettyCount; ++lane) {
        jettyConfig.id = lane + 1;
        jettys[lane] = urma_create_jetty(context, &jettyConfig);
        if (jettys[lane] == nullptr) {
            std::fprintf(stderr, "urma_create_jetty failed\n");
            goto cleanup_jetty;
        }
    }

    if (!options.peerEidHex.empty()) {
        if (!ParseEid(options.peerEidHex, &peerEid)) {
            std::fprintf(stderr, "--peer-eid must contain exactly 16 bytes / 32 hex digits\n");
            goto cleanup_jetty;
        }
        urma_rjetty_t peer{};
        peer.jetty_id.eid = peerEid;
        peer.jetty_id.uasid = options.peerUasid;
        peer.jetty_id.id = options.peerJettyId;
        peer.trans_mode = URMA_TM_RM;
        peer.policy = URMA_JETTY_GRP_POLICY_RR;
        peer.type = URMA_JETTY;
        urma_token_t peerToken{};
        peerToken.token = kTokenValue;
        peerJetty = urma_import_jetty(context, &peer, &peerToken);
        if (peerJetty == nullptr) {
            std::fprintf(stderr, "urma_import_jetty(peer) failed\n");
            goto cleanup_jetty;
        }
    }

    tokenId = urma_alloc_token_id(context);
    if (tokenId == nullptr) {
        std::fprintf(stderr, "urma_alloc_token_id failed\n");
        goto cleanup_jetty;
    }

    config.va = reinterpret_cast<uint64_t>(pool);
    config.len = registeredBytes;
    config.token_id = tokenId;
    config.token_value.token = kTokenValue;
    config.flag.bs.token_policy = URMA_TOKEN_NONE;
    config.flag.bs.cacheable = URMA_NON_CACHEABLE;
    config.flag.bs.access = URMA_ACCESS_READ | URMA_ACCESS_WRITE | URMA_ACCESS_ATOMIC;
    config.flag.bs.token_id_valid = URMA_TOKEN_ID_VALID;

    segment = urma_register_seg(context, &config);
    if (segment == nullptr) {
        std::fprintf(stderr, "urma_register_seg(base=0x%llx, bytes=%llu) failed\n",
                     static_cast<unsigned long long>(config.va),
                     static_cast<unsigned long long>(config.len));
        goto cleanup_token;
    }

    // This is the control-plane data Hcomm must associate with the pool.  The
    // operator itself still only needs the 64-bit `dram_block_table` GVA.
    std::printf("URMA_MOCK_POOL_READY\n");
    std::printf("device=%s\n", options.deviceName.c_str());
    std::printf("eid_index=%u\n", options.eidIndex);
    std::printf("local_eid_hex=");
    PrintHex(context->eid.raw, sizeof(context->eid.raw));
    std::printf("\n");
    std::printf("local_uasid=%u\n", context->uasid);
    if (!options.hostNic.empty()) {
        std::printf("host_nic=%s\n", options.hostNic.c_str());
        std::printf("host_nic_ip=%s\n", hostNicIp.c_str());
        std::printf("host_nic_eid_hex=");
        PrintHex(hostNicEid.raw, sizeof(hostNicEid.raw));
        std::printf("\n");
    }
    std::printf("pool_host_va=0x%llx\n", static_cast<unsigned long long>(config.va));
    segmentGva = segment->seg.ubva.va;
    aggregateGvas = {
        segmentGva + poolBytes + commandBytes,
        options.pipelineMib == 0 ? 0 :
            segmentGva + poolBytes + commandBytes + kAggregateBytes};
    std::printf("pool_gva=0x%llx\n", static_cast<unsigned long long>(segmentGva));
    std::printf("pool_uasid=%u\n", segment->seg.ubva.uasid);
    std::printf("pool_bytes=%llu\n", static_cast<unsigned long long>(poolBytes));
    std::printf("registered_bytes=%llu\n", static_cast<unsigned long long>(registeredBytes));
    std::printf("command_gva=0x%llx\n",
                static_cast<unsigned long long>(segmentGva + poolBytes));
    std::printf("aggregate_gva=0x%llx\n",
                static_cast<unsigned long long>(
                    segmentGva + poolBytes + commandBytes));
    if (options.pipelineMib != 0) {
        std::printf("aggregate_gva_1=0x%llx\n",
            static_cast<unsigned long long>(aggregateGvas[1]));
    }
    std::printf("aggregate_bytes=%llu\n",
                static_cast<unsigned long long>(kAggregateBytes));
    std::printf("gather_kernel=%s\n", GatherKernelName(options.gatherKernel));
    std::printf("gather_threads=%u\n", options.gatherThreads);
    PrintCpuPlacement("gather_cpu_placement", options.gatherCpus);
    PrintCpuPlacement("poll_cpu_placement", options.pollCpus);
    std::printf("pipeline_mib=%u\n", options.pipelineMib);
    std::printf("pipeline_mode=%s\n",
                options.pipelineMib == 0 ? "non_pipelined" : "double_buffered");
    std::printf("command_slots=%u\n", kRawUbCommandSlots);
    std::printf("transport_mode=RM\n");
    std::printf("jetty_count=%u\n", options.jettyCount);
    std::printf("jetty_id=%u\n", jettys[0]->jetty_id.id);
    std::printf("jetty_uasid=%u\n", jettys[0]->jetty_id.uasid);
    std::printf("link_state=%s\n", jettyBound ? "bound_rc" : "advertise_only");
    if (peerJetty != nullptr) {
        std::printf("reverse_import_peer_jetty_id=%u\n", peerJetty->id.id);
        std::printf("reverse_import_peer_uasid=%u\n", peerJetty->id.uasid);
        std::printf("reverse_import_tpn=%u\n", peerJetty->tp.tpn);
    }
    std::printf("blocks=%u\n", options.blocks);
    std::printf("pool_pattern=%s\n",
                PoolPatternName(options.poolPattern));
    std::printf("ckv_bytes_per_block=%llu\n", static_cast<unsigned long long>(ckvBytesPerBlock));
    std::printf("kpe_bytes_per_block=%llu\n", static_cast<unsigned long long>(kpeBytesPerBlock));
    std::printf("token_value=0x%x\n", kTokenValue);
    std::printf("token_id=%u\n", segment->seg.token_id);
    std::printf("hcomm_token_id=%u\n", segment->seg.token_id >> kUrmaTokenIdShift);
    std::printf("stats_hint=urma_admin show_stats -d %s -R 6 -k %u\n",
                options.deviceName.c_str(), jettys[0]->jetty_id.id);
    std::printf("pattern_at_pool_gva=%02x %02x %02x %02x %02x %02x %02x %02x\n",
                bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6], bytes[7]);
    std::printf("segment_blob_hex=");
    PrintHex(reinterpret_cast<const uint8_t*>(&segment->seg), sizeof(segment->seg));
    std::printf("\n");
    std::printf("block0_ckv_gva=0x%llx\n", static_cast<unsigned long long>(segmentGva));
    std::printf("block0_kpe_gva=0x%llx\n",
                static_cast<unsigned long long>(segmentGva + ckvBytesPerBlock));
    for (uint32_t lane = 0; lane < options.jettyCount; ++lane) {
        auto& descriptor = descriptors[lane];
        descriptor.magic = kRawUbPeerMagic;
        descriptor.version = kRawUbPeerVersion;
        std::memcpy(descriptor.eid, jettys[lane]->jetty_id.eid.raw, sizeof(descriptor.eid));
        descriptor.uasid = jettys[lane]->jetty_id.uasid;
        descriptor.jettyId = jettys[lane]->jetty_id.id;
        descriptor.transportMode = URMA_TM_RM;
        descriptor.tokenValue = kTokenValue;
        descriptor.gva = segmentGva;
        descriptor.bytes = registeredBytes;
        descriptor.segmentBytes = sizeof(segment->seg);
        descriptor.tokenId = segment->seg.token_id;
        std::memcpy(descriptor.segment, &segment->seg, sizeof(segment->seg));
    }
    static_assert(sizeof(segment->seg) <= sizeof(descriptors[0].segment),
                  "Hcomm raw peer descriptor must hold public urma_seg_t");
    std::fflush(stdout);

    if (options.controlPort != 0) {
        controlListenFd = OpenControlListener(options.controlPort);
        if (controlListenFd < 0) {
            std::fprintf(stderr, "cannot listen on raw UB control port %u\n",
                options.controlPort);
            goto cleanup_segment;
        }
        urmaPerf.Start(options.urmaPerf);
        const auto acceptDeadline = std::chrono::steady_clock::now() +
            std::chrono::seconds(options.holdSeconds);
        uint32_t sessions = 0;
        if (options.holdSeconds != 0) {
            std::fprintf(stderr,
                "holding registered pool for %u seconds; reconnect enabled\n",
                options.holdSeconds);
        }
        while (gStop == 0) {
            if (sessions != 0 && options.holdSeconds == 0) break;
            if (options.holdSeconds != 0 &&
                std::chrono::steady_clock::now() >= acceptDeadline) {
                break;
            }
            const int clientFd = AcceptControlClient(controlListenFd, 1000);
            if (clientFd == -2) continue;
            if (clientFd < 0) {
                std::fprintf(stderr, "raw UB control accept failed\n");
                break;
            }

            // 新客户端到达即成为唯一 active session。必须先停掉旧 poller，
            // 再释放旧 NPU segment/jetty，避免跨 session 复用 stale GVA。
            StopPollers();
            ReleaseReverseResources(jettys, &reverse);
            std::memset(commandSlots, 0, commandBytes);
            const bool exchanged = ExchangeResources(clientFd,
                static_cast<uint64_t>(options.pipelineMib) *
                    1024ULL * 1024ULL,
                descriptors, options.jettyCount,
                segmentGva, poolBytes, segmentGva + poolBytes,
                context, jettys, &reverse);
            if (!exchanged) {
                ReleaseReverseResources(jettys, &reverse);
                std::fprintf(stderr,
                    "raw UB reverse resource exchange failed; "
                    "waiting for the next client\n");
                continue;
            }
            ++sessions;
            std::printf("aggregation_max_subios_per_wqe=%u\n",
                reverse.maxSubIosPerWqe);
            std::printf("aggregation_fixed_wqe_bytes=%u\n",
                reverse.fixedWqeBytes);
            StartPollers();
            std::printf(
                "HOST_PUSH_READY poll_threads=%u session=%u reconnect=1\n",
                options.pollThreads, sessions);
            std::fflush(stdout);
        }
        if (sessions == 0 && gStop == 0) goto cleanup_segment;
    } else if (options.holdSeconds != 0) {
        std::fprintf(stderr, "holding registered pool for %u seconds\n",
            options.holdSeconds);
        for (uint32_t second = 0;
             second < options.holdSeconds && gStop == 0; ++second) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
    StopPollers();
    urmaPerf.Print();
    if (pushStats.commands.load() != 0) {
        const double seconds = static_cast<double>(pushStats.elapsedNs.load()) / 1.0e9;
        const double bandwidth = seconds == 0.0 ? 0.0 :
            static_cast<double>(pushStats.bytes.load()) / seconds / 1.0e9;
        const double wireSeconds = static_cast<double>(pushStats.wireNs.load()) / 1.0e9;
        const double wireBandwidth = wireSeconds == 0.0 ? 0.0 :
            static_cast<double>(pushStats.bytes.load()) / wireSeconds / 1.0e9;
        const double prepareUs = static_cast<double>(pushStats.prepareNs.load()) /
            static_cast<double>(pushStats.commands.load()) / 1000.0;
        const double postUs = static_cast<double>(pushStats.postNs.load()) /
            static_cast<double>(pushStats.commands.load()) / 1000.0;
        const double pollUs = static_cast<double>(pushStats.pollNs.load()) /
            static_cast<double>(pushStats.commands.load()) / 1000.0;
        const double completionUs = static_cast<double>(pushStats.completionNs.load()) /
            static_cast<double>(pushStats.commands.load()) / 1000.0;
        const double entriesPerSecond = static_cast<double>(pushStats.blocks.load()) / seconds;
        const double subIoIops = static_cast<double>(pushStats.subIos.load()) / seconds;
        const double wqeIops = static_cast<double>(pushStats.dataWqes.load()) / seconds;
        const double subIosPerWqe = pushStats.dataWqes.load() == 0 ? 0.0 :
            static_cast<double>(pushStats.subIos.load()) /
                static_cast<double>(pushStats.dataWqes.load());
        const double physicalWireBandwidth = wireSeconds == 0.0 ? 0.0 :
            static_cast<double>(pushStats.wireBytes.load()) / wireSeconds / 1.0e9;
        std::printf("HOST_PUSH_STATS commands=%llu entries=%llu sub_ios=%llu "
                    "data_wqes=%llu signaled_data_wqes=%llu payload_bytes=%llu "
                    "wire_bytes=%llu total_GBps=%.3f wire_GBps=%.3f "
                    "physical_wire_GBps=%.3f entries_per_s=%.3f "
                    "subio_IOPS=%.0f wqe_IOPS=%.0f actual_subios_per_wqe=%.3f "
                    "prepare_avg_us=%.3f post_avg_us=%.3f poll_avg_us=%.3f "
                    "completion_avg_us=%.3f\n",
            static_cast<unsigned long long>(pushStats.commands.load()),
            static_cast<unsigned long long>(pushStats.blocks.load()),
            static_cast<unsigned long long>(pushStats.subIos.load()),
            static_cast<unsigned long long>(pushStats.dataWqes.load()),
            static_cast<unsigned long long>(pushStats.signaledDataWqes.load()),
            static_cast<unsigned long long>(pushStats.bytes.load()),
            static_cast<unsigned long long>(pushStats.wireBytes.load()),
            bandwidth, wireBandwidth, physicalWireBandwidth,
            entriesPerSecond, subIoIops, wqeIops, subIosPerWqe,
            prepareUs, postUs, pollUs, completionUs);
    }
    if (pushStats.aggregateCommands.load() != 0) {
        const double gatherSeconds = static_cast<double>(pushStats.gatherNs.load()) / 1.0e9;
        const double wireSeconds = static_cast<double>(pushStats.aggregateWireNs.load()) / 1.0e9;
        const double totalSeconds = static_cast<double>(pushStats.aggregateElapsedNs.load()) / 1.0e9;
        const double gatherBandwidth = gatherSeconds == 0.0 ? 0.0 :
            static_cast<double>(pushStats.aggregateBytes.load()) / gatherSeconds / 1.0e9;
        const double wireBandwidth = wireSeconds == 0.0 ? 0.0 :
            static_cast<double>(pushStats.aggregateBytes.load()) / wireSeconds / 1.0e9;
        const double totalBandwidth = totalSeconds == 0.0 ? 0.0 :
            static_cast<double>(pushStats.aggregateBytes.load()) / totalSeconds / 1.0e9;
        const double serialPrediction =
            gatherBandwidth == 0.0 || wireBandwidth == 0.0 ? 0.0 :
            1.0 / (1.0 / gatherBandwidth + 1.0 / wireBandwidth);
        const double pipelinePrediction = std::min(gatherBandwidth, wireBandwidth);
        std::printf("HOST_AGGREGATE_STATS commands=%llu bytes=%llu "
                    "gather_GBps=%.3f wire_GBps=%.3f total_GBps=%.3f "
                    "serial_prediction_GBps=%.3f pipeline_prediction_GBps=%.3f\n",
            static_cast<unsigned long long>(pushStats.aggregateCommands.load()),
            static_cast<unsigned long long>(pushStats.aggregateBytes.load()),
            gatherBandwidth, wireBandwidth, totalBandwidth,
            serialPrediction, pipelinePrediction);
    }
    if (pushStats.tokenGatherCommands.load() != 0) {
        const double gatherSeconds =
            static_cast<double>(pushStats.tokenGatherNs.load()) / 1.0e9;
        const double wireSeconds =
            static_cast<double>(pushStats.tokenGatherWireNs.load()) / 1.0e9;
        const double totalSeconds =
            static_cast<double>(pushStats.tokenGatherElapsedNs.load()) / 1.0e9;
        const double gatherBandwidth = gatherSeconds == 0.0 ? 0.0 :
            static_cast<double>(pushStats.tokenGatherBytes.load()) /
                gatherSeconds / 1.0e9;
        const double wireBandwidth = wireSeconds == 0.0 ? 0.0 :
            static_cast<double>(pushStats.tokenGatherBytes.load()) /
                wireSeconds / 1.0e9;
        const double totalBandwidth = totalSeconds == 0.0 ? 0.0 :
            static_cast<double>(pushStats.tokenGatherBytes.load()) /
                totalSeconds / 1.0e9;
        std::printf("HOST_TOKEN_GATHER_STATS pipeline_mib=%u "
                    "max_subios_per_wqe=%u fixed_wqe_bytes=%u "
                    "commands=%llu bytes=%llu "
                    "gather_GBps=%.3f wire_GBps=%.3f total_GBps=%.3f\n",
            options.pipelineMib,
            reverse.maxSubIosPerWqe,
            reverse.fixedWqeBytes,
            static_cast<unsigned long long>(
                pushStats.tokenGatherCommands.load()),
            static_cast<unsigned long long>(
                pushStats.tokenGatherBytes.load()),
            gatherBandwidth, wireBandwidth, totalBandwidth);
    }
    if (pushStats.directCommands.load() != 0) {
        const double wireSeconds = static_cast<double>(pushStats.directWireNs.load()) / 1.0e9;
        const double totalSeconds = static_cast<double>(pushStats.directElapsedNs.load()) / 1.0e9;
        const double wireBandwidth = wireSeconds == 0.0 ? 0.0 :
            static_cast<double>(pushStats.directBytes.load()) / wireSeconds / 1.0e9;
        const double totalBandwidth = totalSeconds == 0.0 ? 0.0 :
            static_cast<double>(pushStats.directBytes.load()) / totalSeconds / 1.0e9;
        std::printf("HOST_DIRECT_STATS commands=%llu bytes=%llu "
                    "wire_GBps=%.3f total_GBps=%.3f\n",
            static_cast<unsigned long long>(pushStats.directCommands.load()),
            static_cast<unsigned long long>(pushStats.directBytes.load()),
            wireBandwidth, totalBandwidth);
    }
    for (size_t index = 0; index < kProbeBytes.size(); ++index) {
        const auto PrintSize = [index](const char* mode, const PushSizeStats& stats) {
            if (stats.commands == 0) return;
            const double gatherSeconds = static_cast<double>(stats.gatherNs) / 1.0e9;
            const double wireSeconds = static_cast<double>(stats.wireNs) / 1.0e9;
            const double totalSeconds = static_cast<double>(stats.elapsedNs) / 1.0e9;
            const double gatherGbps = gatherSeconds == 0.0 ? 0.0 :
                static_cast<double>(stats.bytes) / gatherSeconds / 1.0e9;
            const double wireGbps = wireSeconds == 0.0 ? 0.0 :
                static_cast<double>(stats.bytes) / wireSeconds / 1.0e9;
            const double totalGbps = totalSeconds == 0.0 ? 0.0 :
                static_cast<double>(stats.bytes) / totalSeconds / 1.0e9;
            const double prepareUs = static_cast<double>(stats.prepareNs) /
                static_cast<double>(stats.commands) / 1000.0;
            const double postUs = static_cast<double>(stats.postNs) /
                static_cast<double>(stats.commands) / 1000.0;
            const double pollUs = static_cast<double>(stats.pollNs) /
                static_cast<double>(stats.commands) / 1000.0;
            const double completionUs = static_cast<double>(stats.completionNs) /
                static_cast<double>(stats.commands) / 1000.0;
            std::printf("HOST_SIZE_STATS mode=%s size_MiB=%llu commands=%llu "
                        "gather_GBps=%.3f wire_GBps=%.3f total_GBps=%.3f "
                        "prepare_avg_us=%.3f post_avg_us=%.3f poll_avg_us=%.3f "
                        "completion_avg_us=%.3f\n",
                mode, static_cast<unsigned long long>(kProbeBytes[index] / 1024 / 1024),
                static_cast<unsigned long long>(stats.commands),
                gatherGbps, wireGbps, totalGbps,
                prepareUs, postUs, pollUs, completionUs);
        };
        PrintSize("push_contiguous", pushStats.directSizes[index]);
        PrintSize("push_aggregate", pushStats.aggregateSizes[index]);
    }
    PrintStagePercentiles(
        &pushStats, kRawUbCommandModeDirect, "push_direct",
        options.pipelineMib);
    PrintStagePercentiles(
        &pushStats, kRawUbCommandModeAggregate, "push_aggregate",
        options.pipelineMib);
    PrintStagePercentiles(
        &pushStats, kRawUbCommandModeTokenGather, "token_gather",
        options.pipelineMib);
    exitCode = 0;

cleanup_segment:
    StopPollers();
    if (controlListenFd >= 0) {
        close(controlListenFd);
        controlListenFd = -1;
    }
    ReleaseReverseResources(jettys, &reverse);
    (void)urma_unregister_seg(segment);
cleanup_token:
    (void)urma_free_token_id(tokenId);
    if (jettyBound) (void)urma_unbind_jetty(jettys[0]);
    if (peerJetty != nullptr) (void)urma_unimport_jetty(peerJetty);
cleanup_jetty:
    for (auto* jetty : jettys) if (jetty != nullptr) (void)urma_delete_jetty(jetty);
    (void)urma_delete_jfr(jfr);
cleanup_jfc:
    (void)urma_delete_jfc(jfc);
cleanup_jfce:
    (void)urma_delete_jfce(jfce);
cleanup_context:
    (void)urma_delete_context(context);
cleanup_uninit:
    urmaPerf.Print();
    (void)urma_uninit();
cleanup:
    (void)munlock(commandSlots, commandBytes);
    std::free(pool);
    return exitCode;
}
