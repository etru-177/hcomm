// SPDX-License-Identifier: Apache-2.0
#pragma once

#include "raw_ub_peer_descriptor.h"

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <string>
#include <thread>
#include <vector>

enum class GatherKernel {
    LIBC,
    NEON,
    SVE2,
};

struct GatherItem {
    const uint8_t* src;
    uint8_t* dst;
    uint32_t bytes;
};

// One source block contains [128 CKV][128 KPE]. The fused path copies one
// 1024-byte CKV and its 128-byte KPE into adjacent workspace bytes.
struct TokenGatherItem {
    const uint8_t* block;
    uint8_t* dst;
    uint32_t tokenOffset;
};

// Wire-compatible view used by the real Host-push path. Keeping the compact
// descriptor avoids materializing one pointer-heavy TokenGatherItem per token
// before every gather.
using TokenGatherDescriptor = RawUbTokenGatherEntry;

bool ParseGatherKernel(const std::string& name, GatherKernel* kernel);
const char* GatherKernelName(GatherKernel kernel);
bool GatherKernelAvailable(GatherKernel kernel);

// The optimized paths specialize the two KV-cache copy sizes (1024-byte CKV
// and 128-byte KPE). Other sizes intentionally fall back to memcpy so the same
// executor can also run the older block/chunk aggregate probe.
void GatherCopyItems(const GatherItem* items, size_t begin, size_t end,
    GatherKernel kernel);
void GatherCopyTokens(const TokenGatherItem* items, size_t begin, size_t end,
    GatherKernel kernel);
void GatherCopyTokenDescriptors(const TokenGatherDescriptor* descriptors,
    size_t begin, size_t end, const uint8_t* poolHost, uint64_t poolGva,
    uint8_t* destination, GatherKernel kernel);

class GatherExecutor {
public:
    GatherExecutor(uint32_t threadCount, const std::vector<uint32_t>& cpus,
        GatherKernel kernel);
    ~GatherExecutor();

    GatherExecutor(const GatherExecutor&) = delete;
    GatherExecutor& operator=(const GatherExecutor&) = delete;

    void Start(const GatherItem* items, size_t count);
    void StartTokens(const TokenGatherItem* items, size_t count);
    void StartTokenDescriptors(const TokenGatherDescriptor* descriptors,
        size_t count, const uint8_t* poolHost, uint64_t poolGva,
        uint8_t* destination);
    uint64_t Wait();
    uint64_t Run(const GatherItem* items, size_t count);
    uint64_t RunTokens(const TokenGatherItem* items, size_t count);

private:
    void Worker(uint32_t worker);

    uint32_t threadCount_;
    std::vector<uint32_t> cpus_;
    GatherKernel kernel_;
    std::vector<std::thread> workers_;
    const GatherItem* items_ = nullptr;
    const TokenGatherItem* tokenItems_ = nullptr;
    const TokenGatherDescriptor* tokenDescriptors_ = nullptr;
    const uint8_t* poolHost_ = nullptr;
    uint64_t poolGva_ = 0;
    uint8_t* destination_ = nullptr;
    enum class Mode {
        ITEMS,
        TOKENS,
        TOKEN_DESCRIPTORS,
    };
    Mode mode_ = Mode::ITEMS;
    size_t itemCount_ = 0;
    uint64_t startNs_ = 0;
    uint64_t endNs_ = 0;
    std::atomic<uint64_t>* generation_;
    std::atomic<uint32_t>* done_;
    std::atomic<bool>* stopping_;
};
