// SPDX-License-Identifier: Apache-2.0

#include "gather_kernels.h"

#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <thread>

#if defined(__aarch64__)
#include <arm_neon.h>
#endif

#if defined(__linux__)
#include <pthread.h>
#include <sched.h>
#endif

#if defined(__ARM_FEATURE_SVE2)
#include <arm_sve.h>
#endif

namespace {
constexpr uint32_t kCkvTokenBytes = 1024;
constexpr uint32_t kKpeTokenBytes = 128;
constexpr uint32_t kTokensPerBlock = 128;

uint64_t NowNs()
{
    return static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count());
}

inline void CpuRelax()
{
#if defined(__aarch64__)
    __asm__ __volatile__("yield");
#elif defined(__x86_64__)
    __asm__ __volatile__("pause");
#else
    std::this_thread::yield();
#endif
}

#if defined(__aarch64__)
inline void Copy64Neon(const uint8_t* src, uint8_t* dst)
{
    const uint8x16_t v0 = vld1q_u8(src);
    const uint8x16_t v1 = vld1q_u8(src + 16);
    const uint8x16_t v2 = vld1q_u8(src + 32);
    const uint8x16_t v3 = vld1q_u8(src + 48);
    vst1q_u8(dst, v0);
    vst1q_u8(dst + 16, v1);
    vst1q_u8(dst + 32, v2);
    vst1q_u8(dst + 48, v3);
}

template <uint32_t Bytes>
inline void CopyFixedNeon(const uint8_t* src, uint8_t* dst)
{
    for (uint32_t offset = 0; offset < Bytes; offset += 64) {
        Copy64Neon(src + offset, dst + offset);
    }
}
#endif

#if defined(__ARM_FEATURE_SVE2)
template <uint32_t Bytes>
inline void CopyFixedSve(const uint8_t* src, uint8_t* dst)
{
    const uint64_t vectorBytes = svcntb();
    uint64_t offset = 0;
    const svbool_t all = svptrue_b8();
    while (offset + 4 * vectorBytes <= Bytes) {
        const svuint8_t v0 = svld1_u8(all, src + offset);
        const svuint8_t v1 = svld1_u8(all, src + offset + vectorBytes);
        const svuint8_t v2 = svld1_u8(all, src + offset + 2 * vectorBytes);
        const svuint8_t v3 = svld1_u8(all, src + offset + 3 * vectorBytes);
        svst1_u8(all, dst + offset, v0);
        svst1_u8(all, dst + offset + vectorBytes, v1);
        svst1_u8(all, dst + offset + 2 * vectorBytes, v2);
        svst1_u8(all, dst + offset + 3 * vectorBytes, v3);
        offset += 4 * vectorBytes;
    }
    while (offset < Bytes) {
        const svbool_t p0 = svwhilelt_b8(offset, static_cast<uint64_t>(Bytes));
        const svuint8_t v0 = svld1_u8(p0, src + offset);
        svst1_u8(p0, dst + offset, v0);
        offset += vectorBytes;
    }
}
#endif

inline void CopyOne(const GatherItem& item, GatherKernel kernel)
{
    if (item.bytes != 1024 && item.bytes != 128) {
        std::memcpy(item.dst, item.src, item.bytes);
        return;
    }
    switch (kernel) {
        case GatherKernel::LIBC:
            std::memcpy(item.dst, item.src, item.bytes);
            return;
        case GatherKernel::NEON:
#if defined(__aarch64__)
            if (item.bytes == 1024) CopyFixedNeon<1024>(item.src, item.dst);
            else CopyFixedNeon<128>(item.src, item.dst);
            return;
#else
            std::memcpy(item.dst, item.src, item.bytes);
            return;
#endif
        case GatherKernel::SVE2:
#if defined(__ARM_FEATURE_SVE2)
            if (item.bytes == 1024) CopyFixedSve<1024>(item.src, item.dst);
            else CopyFixedSve<128>(item.src, item.dst);
            return;
#else
            std::memcpy(item.dst, item.src, item.bytes);
            return;
#endif
    }
}

inline void CopyToken(const TokenGatherItem& item, GatherKernel kernel)
{
    const uint8_t* ckv =
        item.block + static_cast<size_t>(item.tokenOffset) * kCkvTokenBytes;
    const uint8_t* kpe =
        item.block + kTokensPerBlock * kCkvTokenBytes +
        static_cast<size_t>(item.tokenOffset) * kKpeTokenBytes;
    uint8_t* const destinationCkv = item.dst;
    uint8_t* const destinationKpe = item.dst + kCkvTokenBytes;
    switch (kernel) {
        case GatherKernel::LIBC:
            std::memcpy(destinationCkv, ckv, kCkvTokenBytes);
            std::memcpy(destinationKpe, kpe, kKpeTokenBytes);
            return;
        case GatherKernel::NEON:
#if defined(__aarch64__)
            CopyFixedNeon<kCkvTokenBytes>(ckv, destinationCkv);
            CopyFixedNeon<kKpeTokenBytes>(kpe, destinationKpe);
            return;
#else
            std::memcpy(destinationCkv, ckv, kCkvTokenBytes);
            std::memcpy(destinationKpe, kpe, kKpeTokenBytes);
            return;
#endif
        case GatherKernel::SVE2:
#if defined(__ARM_FEATURE_SVE2)
            CopyFixedSve<kCkvTokenBytes>(ckv, destinationCkv);
            CopyFixedSve<kKpeTokenBytes>(kpe, destinationKpe);
            return;
#else
            std::memcpy(destinationCkv, ckv, kCkvTokenBytes);
            std::memcpy(destinationKpe, kpe, kKpeTokenBytes);
            return;
#endif
    }
}

}  // namespace

bool ParseGatherKernel(const std::string& name, GatherKernel* kernel)
{
    if (name == "libc") {
        *kernel = GatherKernel::LIBC;
        return true;
    }
    if (name == "neon") {
        *kernel = GatherKernel::NEON;
        return true;
    }
    if (name == "sve2") {
        *kernel = GatherKernel::SVE2;
        return true;
    }
    return false;
}

const char* GatherKernelName(GatherKernel kernel)
{
    switch (kernel) {
        case GatherKernel::LIBC: return "libc";
        case GatherKernel::NEON: return "neon";
        case GatherKernel::SVE2: return "sve2";
    }
    return "unknown";
}

bool GatherKernelAvailable(GatherKernel kernel)
{
    if (kernel == GatherKernel::LIBC) return true;
#if defined(__aarch64__)
    if (kernel == GatherKernel::NEON) return true;
#endif
#if defined(__ARM_FEATURE_SVE2)
    if (kernel == GatherKernel::SVE2) return true;
#endif
    return false;
}

void GatherCopyItems(const GatherItem* items, size_t begin, size_t end,
    GatherKernel kernel)
{
    for (size_t index = begin; index < end; ++index) {
        CopyOne(items[index], kernel);
    }
}

void GatherCopyTokens(const TokenGatherItem* items, size_t begin, size_t end,
    GatherKernel kernel)
{
    for (size_t index = begin; index < end; ++index) {
        CopyToken(items[index], kernel);
    }
}

void GatherCopyTokenDescriptors(const TokenGatherDescriptor* descriptors,
    size_t begin, size_t end, const uint8_t* poolHost, uint64_t poolGva,
    uint8_t* destination, GatherKernel kernel)
{
    for (size_t index = begin; index < end; ++index) {
        const auto& descriptor = descriptors[index];
        if (descriptor.tokenBytes == kRawUbFlatFp8TokenBytes ||
            descriptor.tokenBytes == kRawUbFlatC8TokenBytes) {
            const GatherItem item{
                poolHost + (descriptor.blockGva - poolGva) +
                    static_cast<size_t>(descriptor.tokenOffset) *
                        descriptor.tokenBytes,
                destination + index * descriptor.tokenBytes,
                descriptor.tokenBytes};
            CopyOne(item, kernel);
            continue;
        }
        const TokenGatherItem item{
            poolHost + (descriptor.blockGva - poolGva),
            destination + index * (kCkvTokenBytes + kKpeTokenBytes),
            descriptor.tokenOffset};
        CopyToken(item, kernel);
    }
}

GatherExecutor::GatherExecutor(uint32_t threadCount, const std::vector<uint32_t>& cpus,
    GatherKernel kernel)
    : threadCount_(threadCount), cpus_(cpus), kernel_(kernel),
      generation_(new std::atomic<uint64_t>(0)),
      done_(new std::atomic<uint32_t>(threadCount + 1)),
      stopping_(new std::atomic<bool>(false))
{
    workers_.reserve(threadCount_);
    for (uint32_t worker = 0; worker < threadCount_; ++worker) {
        workers_.emplace_back(&GatherExecutor::Worker, this, worker);
    }
}

GatherExecutor::~GatherExecutor()
{
    stopping_->store(true, std::memory_order_release);
    generation_->fetch_add(1, std::memory_order_release);
    for (auto& worker : workers_) worker.join();
    delete stopping_;
    delete done_;
    delete generation_;
}

void GatherExecutor::Start(const GatherItem* items, size_t count)
{
    while (done_->load(std::memory_order_acquire) != threadCount_ + 1 &&
           generation_->load(std::memory_order_relaxed) != 0) {
        CpuRelax();
    }
    items_ = items;
    tokenItems_ = nullptr;
    tokenDescriptors_ = nullptr;
    mode_ = Mode::ITEMS;
    itemCount_ = count;
    startNs_ = NowNs();
    done_->store(0, std::memory_order_relaxed);
    generation_->fetch_add(1, std::memory_order_release);
}

void GatherExecutor::StartTokens(const TokenGatherItem* items, size_t count)
{
    while (done_->load(std::memory_order_acquire) != threadCount_ + 1 &&
           generation_->load(std::memory_order_relaxed) != 0) {
        CpuRelax();
    }
    items_ = nullptr;
    tokenItems_ = items;
    tokenDescriptors_ = nullptr;
    mode_ = Mode::TOKENS;
    itemCount_ = count;
    startNs_ = NowNs();
    done_->store(0, std::memory_order_relaxed);
    generation_->fetch_add(1, std::memory_order_release);
}

void GatherExecutor::StartTokenDescriptors(
    const TokenGatherDescriptor* descriptors, size_t count,
    const uint8_t* poolHost, uint64_t poolGva, uint8_t* destination)
{
    while (done_->load(std::memory_order_acquire) != threadCount_ + 1 &&
           generation_->load(std::memory_order_relaxed) != 0) {
        CpuRelax();
    }
    items_ = nullptr;
    tokenItems_ = nullptr;
    tokenDescriptors_ = descriptors;
    poolHost_ = poolHost;
    poolGva_ = poolGva;
    destination_ = destination;
    mode_ = Mode::TOKEN_DESCRIPTORS;
    itemCount_ = count;
    startNs_ = NowNs();
    done_->store(0, std::memory_order_relaxed);
    generation_->fetch_add(1, std::memory_order_release);
}

uint64_t GatherExecutor::Wait()
{
    while (done_->load(std::memory_order_acquire) != threadCount_ + 1) CpuRelax();
    return endNs_ - startNs_;
}

uint64_t GatherExecutor::Run(const GatherItem* items, size_t count)
{
    Start(items, count);
    return Wait();
}

uint64_t GatherExecutor::RunTokens(const TokenGatherItem* items, size_t count)
{
    StartTokens(items, count);
    return Wait();
}

void GatherExecutor::Worker(uint32_t worker)
{
#if defined(__linux__)
    if (worker < cpus_.size()) {
        cpu_set_t set;
        CPU_ZERO(&set);
        CPU_SET(cpus_[worker], &set);
        const int result =
            pthread_setaffinity_np(pthread_self(), sizeof(set), &set);
        if (result != 0) {
            std::fprintf(stderr,
                "gather affinity failed: worker=%u cpu=%u error=%d\n",
                worker, cpus_[worker], result);
        }
    }
#endif
    uint64_t seen = 0;
    while (true) {
        uint64_t generation = generation_->load(std::memory_order_acquire);
        while (generation == seen && !stopping_->load(std::memory_order_relaxed)) {
            CpuRelax();
            generation = generation_->load(std::memory_order_acquire);
        }
        if (stopping_->load(std::memory_order_acquire)) return;
        seen = generation;
        const size_t begin = itemCount_ * worker / threadCount_;
        const size_t end = itemCount_ * (worker + 1) / threadCount_;
        switch (mode_) {
            case Mode::ITEMS:
                GatherCopyItems(items_, begin, end, kernel_);
                break;
            case Mode::TOKENS:
                GatherCopyTokens(tokenItems_, begin, end, kernel_);
                break;
            case Mode::TOKEN_DESCRIPTORS:
                GatherCopyTokenDescriptors(tokenDescriptors_, begin, end,
                    poolHost_, poolGva_, destination_, kernel_);
                break;
        }
        const uint32_t finished = done_->fetch_add(1, std::memory_order_acq_rel) + 1;
        if (finished == threadCount_) {
            endNs_ = NowNs();
            done_->store(threadCount_ + 1, std::memory_order_release);
        }
    }
}
