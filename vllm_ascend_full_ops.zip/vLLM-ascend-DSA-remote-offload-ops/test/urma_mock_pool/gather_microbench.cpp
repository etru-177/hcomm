// SPDX-License-Identifier: Apache-2.0

#include "gather_kernels.h"

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <numeric>
#include <random>
#include <string>
#include <sys/mman.h>
#include <vector>

namespace {
constexpr uint64_t kCkvBytes = 1024;
constexpr uint64_t kKpeBytes = 128;
constexpr uint64_t kTokensPerBlock = 128;
constexpr uint64_t kTokenBytes = kCkvBytes + kKpeBytes;
constexpr uint64_t kBlockBytes = kTokensPerBlock * kTokenBytes;

uint32_t ParseU32(const char* text)
{
    return static_cast<uint32_t>(std::strtoul(text, nullptr, 0));
}

std::vector<uint32_t> ParseCpus(const std::string& text)
{
    std::vector<uint32_t> cpus;
    size_t begin = 0;
    while (begin < text.size()) {
        const size_t end = text.find(',', begin);
        cpus.push_back(ParseU32(text.substr(begin, end - begin).c_str()));
        if (end == std::string::npos) break;
        begin = end + 1;
    }
    return cpus;
}
}  // namespace

int main(int argc, char** argv)
{
    uint32_t tokens = 400;
    uint32_t poolTokens = 262144;
    uint32_t threads = 1;
    uint32_t warmup = 5;
    uint32_t iterations = 50;
    uint32_t seed = 2026;
    bool random = true;
    GatherKernel kernel = GatherKernel::LIBC;
    std::vector<uint32_t> cpus;
    for (int i = 1; i < argc; ++i) {
        const std::string arg(argv[i]);
        if (arg == "--tokens") tokens = ParseU32(argv[++i]);
        else if (arg == "--pool-tokens") poolTokens = ParseU32(argv[++i]);
        else if (arg == "--threads") threads = ParseU32(argv[++i]);
        else if (arg == "--warmup") warmup = ParseU32(argv[++i]);
        else if (arg == "--iterations") iterations = ParseU32(argv[++i]);
        else if (arg == "--seed") seed = ParseU32(argv[++i]);
        else if (arg == "--pattern") random = std::string(argv[++i]) == "random";
        else if (arg == "--cpus") cpus = ParseCpus(argv[++i]);
        else if (arg == "--kernel") {
            if (!ParseGatherKernel(argv[++i], &kernel)) return 2;
        }
        else return 2;
    }
    if (tokens == 0 || poolTokens < tokens || threads == 0 || iterations == 0 ||
        (!cpus.empty() && cpus.size() != threads) || !GatherKernelAvailable(kernel)) {
        return 2;
    }

    const size_t poolBlocks =
        (static_cast<size_t>(poolTokens) + kTokensPerBlock - 1) /
        kTokensPerBlock;
    std::vector<uint8_t> pool(poolBlocks * kBlockBytes);
    std::vector<uint8_t> output(static_cast<size_t>(tokens) * kTokenBytes);
#if defined(MADV_HUGEPAGE)
    (void)madvise(pool.data(), pool.size(), MADV_HUGEPAGE);
#endif
    for (uint32_t token = 0; token < poolTokens; ++token) {
        const size_t block = token / kTokensPerBlock;
        const size_t offset = token % kTokensPerBlock;
        auto* ckv = pool.data() + block * kBlockBytes + offset * kCkvBytes;
        auto* kpe = pool.data() + block * kBlockBytes +
            kTokensPerBlock * kCkvBytes + offset * kKpeBytes;
        for (size_t byte = 0; byte < kCkvBytes; ++byte) {
            ckv[byte] = static_cast<uint8_t>(
                (static_cast<size_t>(token) * kCkvBytes + byte) % 251);
        }
        for (size_t byte = 0; byte < kKpeBytes; ++byte) {
            kpe[byte] = static_cast<uint8_t>(
                (static_cast<size_t>(token) * kKpeBytes + byte + 17) % 251);
        }
    }

    std::vector<uint32_t> indices(poolTokens);
    std::iota(indices.begin(), indices.end(), 0);
    if (random) std::shuffle(indices.begin(), indices.end(), std::mt19937(seed));
    const uint32_t runs = warmup + iterations;
    constexpr uint64_t kPoolGva = 0x100000000ULL;
    std::vector<std::vector<TokenGatherDescriptor>> runItems(runs);
    for (uint32_t run = 0; run < runs; ++run) {
        auto& items = runItems[run];
        items.reserve(tokens);
        for (uint32_t token = 0; token < tokens; ++token) {
            const uint64_t ordinal = static_cast<uint64_t>(run) * tokens + token;
            const uint32_t source = random
                ? indices[ordinal % poolTokens]
                : static_cast<uint32_t>(ordinal % poolTokens);
            items.push_back({
                kPoolGva + static_cast<uint64_t>(
                    source / kTokensPerBlock) * kBlockBytes,
                static_cast<uint32_t>(source % kTokensPerBlock),
                0});
        }
    }

    GatherExecutor executor(threads, cpus, kernel);
    for (uint32_t i = 0; i < warmup; ++i) {
        executor.StartTokenDescriptors(runItems[i].data(), runItems[i].size(),
            pool.data(), kPoolGva, output.data());
        (void)executor.Wait();
    }
    if (warmup != 0) {
        for (size_t index = 0; index < runItems[warmup - 1].size(); ++index) {
            const auto& item = runItems[warmup - 1][index];
            const auto* block = pool.data() + (item.blockGva - kPoolGva);
            const auto* ckv =
                block + static_cast<size_t>(item.tokenOffset) * kCkvBytes;
            const auto* kpe = block + kTokensPerBlock * kCkvBytes +
                static_cast<size_t>(item.tokenOffset) * kKpeBytes;
            const auto* dst = output.data() + index * kTokenBytes;
            if (std::memcmp(ckv, dst, kCkvBytes) != 0 ||
                std::memcmp(kpe, dst + kCkvBytes, kKpeBytes) != 0) {
                std::fprintf(stderr, "gather validation failed\n");
                return 1;
            }
        }
    }
    std::vector<uint64_t> elapsed;
    elapsed.reserve(iterations);
    for (uint32_t i = 0; i < iterations; ++i) {
        const auto& items = runItems[warmup + i];
        executor.StartTokenDescriptors(items.data(), items.size(),
            pool.data(), kPoolGva, output.data());
        elapsed.push_back(executor.Wait());
    }
    std::sort(elapsed.begin(), elapsed.end());
    const uint64_t totalNs = std::accumulate(elapsed.begin(), elapsed.end(), uint64_t{0});
    const double avgNs = static_cast<double>(totalNs) / elapsed.size();
    const uint64_t p50Ns = elapsed[elapsed.size() / 2];
    const uint64_t p99Ns = elapsed[(elapsed.size() * 99 + 99) / 100 - 1];
    const double bytes = static_cast<double>(tokens) * (kCkvBytes + kKpeBytes);
    std::printf("HOST_GATHER_PROBE kernel=%s threads=%u pattern=%s "
                "tokens=%u pool_tokens=%u avg_us=%.3f p50_us=%.3f p99_us=%.3f "
                "tokens_per_s=%.3f payload_GBps=%.3f\n",
        GatherKernelName(kernel), threads, random ? "random" : "contiguous",
        tokens, poolTokens, avgNs / 1000.0, p50Ns / 1000.0, p99Ns / 1000.0,
        static_cast<double>(tokens) * 1.0e9 / avgNs, bytes / avgNs);
    return 0;
}
