# URMA Mock 内存池

## 1. 用途和数据布局

该程序是只依赖公开 UMDK 头文件和 `liburma.so` 的 Host 侧测试内存池。它创建
RM Jetty，注册远端 KV backing segment，并轮询命令环。数据面只使用普通单边
READ/WRITE，不发送 Send/Recv WQE。

每个 block 的布局如下：

```text
[ CKV：128 token × 1024B ][ KPE：128 token × 128B ]
```

内存池可以执行三类基础路径：

- NPU/AICPU 对远端 block 发起 READ；
- Pool 将选定 block 或 token 主动 WRITE 到 NPU HBM staging；
- Pool 在 Host 上用 libc、NEON 或 SVE2 聚合 token，再用大 WQE 写入 HBM。

命令页会通过 `mlock` 保持驻留。Linux 没有可移植接口保证某个分配永久驻留在
LLC，因此不能把该测试理解为 LLC 锁定测试。

## 2. 构建

推荐直接使用公开 UMDK 源码：

```bash
git clone https://atomgit.com/openeuler/umdk.git
cd vLLM-ascend-DSA/test/urma_mock_pool
UMDK_SOURCE_DIR=/absolute/path/to/umdk ./build_umdk.sh
```

`build_umdk.sh` 只配置和构建 `umdk/src/urma`，不会安装系统文件或使用
`nids_*` 组件。也可以安装 `umdk-urma-devel` 后直接执行：

```bash
./build.sh
```

非标准安装路径使用：

```bash
URMA_INCLUDE_DIR=/opt/umdk/include \
URMA_LIBRARY_DIR=/opt/umdk/lib64 \
./build.sh
```

`liburma.so` 仍然需要匹配的 UB/URMA 内核驱动和 A5 设备，不能在纯软件环境中
模拟。运行前应使用 UMDK 自带的 `urma_admin` 确认设备可见，并确认动态链接器
可以找到 provider 动态库。

## 3. 最小启动

默认 1024 个 block，约占 144MiB：

```bash
./urma_mock_pool --jetty-count 1 --hold-seconds 300
```

推荐显式选择设备：

```bash
./urma_mock_pool \
  --device <urma-device-name> \
  --eid-index 0 \
  --host-nic <host-interface> \
  --blocks 1024 --jetty-count 1 \
  --control-port 18515 --poll-threads 1 --poll-cpus 8 \
  --hold-seconds 300
```

关键参数：

- `--device`：URMA 设备名；
- `--eid-index`：设备上的 EID 序号；
- `--host-nic`：Linux 网络接口名，不是 URMA 设备名；
- `--jetty-count`：协议可创建 1～4 个独立 Host Jetty，客户端 `RAW_LANES` 必须一致；
  当前硬件测试固定为 `1`，暂不使用 4 Jetty；
- `--control-port`：普通 Host TCP 控制端口，只用于资源交换；
- `--poll-threads/--poll-cpus`：命令环轮询线程及绑核；
- `--blocks`：远端 block 数量；
- `--hold-seconds`：进程保持时间。

指定 `--host-nic` 时，程序调用公开的 `urma_get_eid_by_ip()` 验证该网卡地址确实
属于所选 URMA context。省略该参数时，由 `--device` 和 `--eid-index` 决定 UB
endpoint。这个参数不会选择 TCP 控制接口，也不参与单边数据路径。

## 4. 建链和完成语义

控制连接先发布 Host Jetty、内存池 segment 和 token，然后 NPU 返回本地 Jetty
描述符及导出的 HBM staging segment。Pool 导入反向资源后打印：

```text
HOST_PUSH_READY
```

TCP 随即关闭；命令通知、KV 传输和 completion 都使用单边 UB 操作。该控制连接
不是 RaSocket，也不传输 KV payload。AICPU 的 `dram_block_table` 只保存
`pool_gva + offset`。

控制监听 socket 在 Pool 生命周期内保持打开，支持 NPU 客户端断链后串行重建。
新客户端到达时，Pool 先停止旧 command poller，撤销旧 NPU Jetty/segment 导入并
清空 command ring，再导入新客户端资源并重启 poller。日志中的
`HOST_PUSH_READY ... session=N reconnect=1` 表示第 N 次建链已经可用。当前只允许
一个 active session，不支持多个 NPU 客户端并发共享同一套 command/bounce buffer。
因此连续矩阵不必为每个 case 重启 Pool，但 NPU 侧每个进程仍必须正常调用
disconnect；异常退出后也会在下一个客户端连接时替换旧资源。

普通数据 WQE 默认不请求 CQE；每条 lane/链的末尾 WQE，以及最终 completion
WRITE，才设置 `complete_enable`。最终 completion 把 generation 写入 NPU HBM。

## 5. 数据模式

- `--pool-pattern bytes`：默认模式，内容为 `byte_offset % 251`，供
  `urma_remote_demo.py` 和 `urma_remote_perf.py` 校验；
- `--pool-pattern bf16`：生成有限且随维度变化的 BF16 数据，供融合 SFA 测试。

融合 SFA 的启动示例：

```bash
./urma_mock_pool \
  --device <urma-device-name> --blocks 4096 --jetty-count 1 \
  --control-port 19090 --pool-pattern bf16 --hold-seconds 600
```

## 6. 最小端到端散拷测试

终端一启动内存池：

```bash
cd test/urma_mock_pool
./build.sh
./urma_mock_pool \
  --device <urma-device-name> --blocks 2 \
  --control-port 19090 --pool-pattern bytes --hold-seconds 300
```

终端二设置匹配的 Hcomm，并运行最小用例：

```bash
export CANN_ROOT=/usr/local/Ascend/cann-9.1.T560
export HCOMM_HOME_PATH="${CANN_ROOT}/aarch64-linux"
export HCOMM_KVCACHE_SCATTER_COPY_JSON=\
"${CANN_ROOT}/opp/built-in/op_impl/aicpu/config/ccl_kernel.json"
python test/urma_remote_demo.py
```

运行前修改脚本顶部的 `DEVICE`、`DEVICE_EID`、`DEVICE_PHY_ID`、`POOL_IP`、
`CONTROL_PORT`、`RAW_LANES`、`HOST_PUSH_PERCENT`、`HOST_TOKEN_GATHER` 和
`SCATTER_AFTER_GATHER`。成功时打印：

```text
URMA_REMOTE_SCATTER_COPY_OK
```

建议按以下顺序定位问题：

1. 先用 `RAW_LANES=1`、`HOST_PUSH_PERCENT=100`；
2. 再启用 `HOST_TOKEN_GATHER=True`；
3. 最后启用 local AIV 或 fused SFA；
4. 确认 Host `libhcomm.so`、device `libccl_kernel.so` 和
   `ccl_kernel.json` 来自同一次构建。

## 7. 散拷性能测试

为了减少反复访问少量 cache-hot 地址，性能测试建议使用 4096 个 block，并在远端
bank 间轮转：

```bash
./urma_mock_pool \
  --device <urma-device-name> --blocks 4096 --jetty-count 1 \
  --control-port 19090 --pool-pattern bytes --hold-seconds 600
python test/urma_remote_perf.py
```

脚本覆盖 BS `1/2/4/8/16/32/64`，以及每 batch `100/200/300/400` token。
源 token、目标 slot 和 block table 在计时前生成；内存池容量允许时，每次调用
轮转到不相交的远端 bank。

`URMA_IO_BYTES` 支持：

- `1152`：一个逻辑 IO 拆成 1024B CKV 和 128B KPE；
- `576`：FP8 flat IO；
- `656`：C8 packed IO。

576/656B 当前要求 `HOST_TOKEN_GATHER=True`。它们已支持 gather 和 local scatter
原型，但现有 BF16 remote SFA 不能作为 C8 CopySFA 使用。

## 8. URMA 链路基线

`test/urma_bandwidth_perf.py` 排除 token scatter，测试 4/16/32/64MiB：

- `pull_contiguous`：AICPU/Hcomm READ；
- `push_contiguous`：每个 Jetty 一个连续大 WRITE；
- `push_aggregate`：Host 聚合 256KiB 随机 chunk 后连续 WRITE。

运行方式：

```bash
./urma_mock_pool \
  --device <urma-device-name> --blocks 4096 --jetty-count 1 \
  --control-port 19090 --poll-threads 1 --poll-cpus 8 \
  --hold-seconds 600
python test/urma_bandwidth_perf.py
```

Python 输出是包含 AICPU launch、Hcomm submit 和同步的端到端 Event 带宽。停止
Pool 后会打印 Host 侧 `wire_GBps`、`gather_GBps` 和 `total_GBps`：

- `wire_GBps`：数据 WRITE post 到观察到 CQE；
- `gather_GBps`：Host 聚合到注册 bounce buffer；
- `total_GBps`：从 Host 看到命令到 completion WRITE 完成。

这些数值都不包含最终 token scatter。

## 9. Host gather 和 pipeline

SVE2 示例：

```bash
ENABLE_SVE2=1 ./build.sh
./urma_mock_pool \
  --device <urma-device-name> --blocks 4096 --jetty-count 1 \
  --control-port 19090 --poll-threads 1 --poll-cpus 8 \
  --gather-threads 4 --gather-cpus 9,10,11,12 \
  --gather-kernel sve2 --pipeline-mib 2 --hold-seconds 600
```

`--pipeline-mib 1/2/4/8/.../64` 指定双缓冲每半边的聚合粒度；`0` 或
`--no-pipeline` 是非 pipeline 基线。选择 pipeline 时应比较端到端有效带宽，不能
只比较 `wire_GBps`，因为较小 WQE 会用链路效率换取 gather/WRITE 重叠。

绑核时应让 `--gather-cpus` 位于同一 NUMA node，并为 `--poll-cpus` 单独预留同一
node 的 CPU。程序会打印 `cpu:node` 和绑核失败，不会静默忽略错误。绑核不会执行
`mbind`，也不会改变注册内存的 NUMA 位置。

## 10. 限制每个 WQE 的子 IO 数

`URMA_MAX_SUBIOS_PER_WQE` 限制一个数据 WQE 可聚合的物理子 IO 数。1152B 逻辑
IO 计为两个子 IO，576/656B 计为一个。`0` 保留最大聚合率基线：

```bash
URMA_MAX_SUBIOS_PER_WQE=0 URMA_FIXED_WQE_BYTES=0 \
  python test/urma_remote_perf.py
```

固定 8KiB 存储 IO 模型：

```bash
URMA_IO_BYTES=576 URMA_SCATTER_AFTER_GATHER=0 \
URMA_MAX_SUBIOS_PER_WQE=1 URMA_FIXED_WQE_BYTES=8192 \
python test/urma_remote_perf.py

URMA_IO_BYTES=576 URMA_SCATTER_AFTER_GATHER=0 \
URMA_MAX_SUBIOS_PER_WQE=3 URMA_FIXED_WQE_BYTES=8192 \
python test/urma_remote_perf.py

URMA_IO_BYTES=576 URMA_SCATTER_AFTER_GATHER=0 \
URMA_MAX_SUBIOS_PER_WQE=4 URMA_FIXED_WQE_BYTES=8192 \
python test/urma_remote_perf.py
```

聚合率实验必须使用 `--pipeline-mib 0`。非零 pipeline 与 capped aggregation/
fixed WQE 会被拒绝，避免 pipeline 改变实际聚合率。Pool 分别统计逻辑 payload、
物理 wire bytes、整数 `subio_IOPS`、`data_wqes`、`wqe_IOPS` 和实际每 WQE 子 IO
数。bounded WQE chain 只为每条链的末尾请求 CQE。

## 11. 常见故障

- `cannot connect to raw urma pool control port`：确认 Pool 已监听、IP/端口正确，
  且不是把 URMA 设备名当作 TCP IP；
- `invalid lane descriptors`：Pool 与客户端的 lane/jetty 数或协议版本不一致；
- `raw UB reverse resource exchange failed`：检查 NPU HBM segment 导出、CTP/EXP
  模式以及 Host/NPU Hcomm 版本；
- 建链后卡住：先观察 `HOST_PUSH_READY`、`HOST_PUSH_COMMAND_SEEN` 和 completion
  target 日志，再区分命令未到达、数据 CQE 未返回或 completion WRITE 未完成；
- `ScatterIoFromStaging`/C8 算子找不到：清理旧 OPP 后使用匹配源码重新构建安装，
  并检查 `ASCEND_CUSTOM_OPP_PATH`。
