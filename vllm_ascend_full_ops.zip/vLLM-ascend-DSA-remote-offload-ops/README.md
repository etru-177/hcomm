# KvcacheScatterCopy

本仓库实现 Ascend A5 上的 KV Cache 散拷、raw URMA 内存池访问、本地/远端融合
SFA，以及 CPU DU Remote Offload 原型。

当前开发基线：

- `remote-offload`：修改前的 hotfix tag；
- `remote-offload-ops`：Remote Offload 开发分支；
- `high-bw-baseline`：URMA 高带宽历史基线。

Remote Offload 的架构、协议、测试矩阵和当前限制见
[`docs/remote_offload_ops.md`](docs/remote_offload_ops.md)。URMA Mock Pool 的完整
运行说明见 [`test/urma_mock_pool/README.md`](test/urma_mock_pool/README.md)。

> 文档规范：项目说明文档统一使用中文；代码符号、CLI 参数、环境变量和日志字段
> 保留英文，并在首次出现时给出中文解释。

## 1. 当前能力

- AICPU 根据逻辑 token 构造 CKV/KPE 远端访问并写入稀疏 HBM cache；
- raw URMA 支持 NPU READ、Pool WRITE、Host token gather 和 AIV local scatter；
- raw Mock Pool 支持客户端断链后的串行资源重建，可连续运行多进程矩阵；
- IO 粒度支持 1024+128、576、656 和 4096B 基线/原型；
- 支持限制 `max_subios_per_wqe`、固定 WQE 大小和 Host gather pipeline；
- 数据 WQE 默认不请求 CQE，链尾/最终 completion 请求 CQE；
- BF16 fused remote SFA 可以轮询 Pool generation completion；
- 656B packed C8 支持 AICPU IO-only 与专用 AIV completion poll/scatter；
- C8 LIDU、MTP3 LIDU、local scatter、SFA 和 MTP3 SFA 已作为仓内算子统一构建；
- 标准 BF16/FP16 `NanovllmFusedLiManageMtp` 已按固定上游提交引入，但仅支持
  910B/910_93；A5 不构建这个空 kernel；
- CPU DU 支持 1～4 路 MTP、稳定 union、唯一 miss、owner、事务更新和快照；
- CPU DU 性能矩阵支持一次注册、最多 256 个常驻线程和按 request 并行；
- `SwappedCpuDuImplicitDbaRuntime` 支持 BS=32 的固定地址 polling、32 路常驻 DU 和
  两个 16-request IO ready group，热路径无逐轮 D2H/H2D 或 Host wait；
- 固定地址 generation ring、常驻 CPU DU worker 和版本化 Get/Put/metadata 协议
  ABI 已定义；
- Host metadata 状态机已实现 payload-before-commit、幂等重试、tail 边界和回滚。

当前 656B AIV poll/scatter 不等同于完整 C8 CopySFA 真融合。C8 MTP CopySFA、
MTE、Host 命令提交和 Pool Put handler 仍在 `remote-offload-ops` 上继续接入。

## 2. 数据布局

BF16 CKV/KPE 远端 block：

```text
[ 128 × 1024B CKV ][ 128 × 128B KPE ]
```

常用逻辑 IO：

| `io_bytes` | 语义 | 物理子 IO 数 |
|---:|---|---:|
| 1152 | 1024B CKV + 128B KPE | 2 |
| 576 | FP8 flat token | 1 |
| 656 | C8 packed token | 1 |
| 4096 | URMA 链路/存储粒度实验 | 1 |

## 3. PyTorch 接口

基础散拷接口：

```python
torch_npu.npu_kvcache_scatter_copy(
    hbm_k_rope,       # bf16/fp16[S_BLOCKS,128,64]，原地更新
    hbm_kv_cache,     # bf16/fp16[S_BLOCKS,128,512]，原地更新
    dram_k_rope,      # 兼容参数；remote-GVA 路径不直接读取
    dram_kv_cache,    # 兼容参数；remote-GVA 路径不直接读取
    hbm_block_table,  # int32[B,S_MAX_BLOCKS]
    dram_block_table, # uint64[B,MAX_BLOCKS]，当前 layer 的 GVA 表
    src_token_ids,    # int32[B,1,16384]
    dst_slots,        # int32[B,1,16384]
    copy_counts,      # int32[B]
    ready_flag=None,  # 可选 int32[1] completion flag
    layer_id=0,
)
```

每个 batch row 只消费 `:copy_counts[b]`。有效目标 slot 必须唯一。`ready_flag`
在 dispatch 前清零，全部同步 Hcomm batch 成功后以 release 语义写 `1`；校验或
Hcomm 失败时保持 `0`。复用 buffer 前，调用方必须先重置对应 generation/flag。

raw Pool 建链：

```python
channel = ops.npu_hcomm_kvcache_pool_connect_raw(
    device_eid,
    device_phy_id,
    pool_ip,
    control_port,
    hbm_kpe,
    hbm_ckv,
    lane_count=4,
    host_push_percent=100,
    host_token_gather=True,
    scatter_after_gather=True,
    defer_completion_to_attention=False,
    io_bytes=1152,
    max_subios_per_wqe=0,
    fixed_wqe_bytes=0,
)
```

Host `libhcomm.so`、device `libccl_kernel.so`、`ccl_kernel.json` 和自定义 OPP 必须
来自匹配构建。描述符 ABI 不一致通常会表现为 lane descriptor、reverse resource
exchange 或 channel create 失败。

### 3.1 仓内 C8 MTP 算子

本节算子的 CANN 源码、Torch adapter 和测试均已并入当前仓库，不依赖运行时兄弟
目录。MTP3 LIDU 使用 `xwLearnsLLM/nanovllm-DSA-offload` 的 `ops_a5` 分支，固定于
`2802bddfc895d6e0fffe8b4e9cdbe55190230d8d`；其余算子来自
`xiaohu9/nanovllm-DSA-offload@sfa_c8_mtp@06be4016`。详细来源记录见
[`VENDORED.md`](VENDORED.md)。Torch namespace 保持为 `nanovllm_dsa`。

| Torch 接口 | CANN 算子 | 功能 |
|---|---|---|
| `fused_li_manage_c8` | `A5FusedLiManageC8` | 单路 C8 LI Top-2048 与 request-pool DU |
| `fused_li_manage_mtp_c8` | `A5FusedLiManageMtpC8` | `ops_a5` MTP3 性能基线、TopK union 与一次性 DU |
| `kvcache_scatter_copy_c8` | `A5KvcacheScatterCopyC8` | 本地 packed C8 DRAM → HBM scatter，并生成 SFA metadata |
| `sparse_tail_attention_c8` | `A5SparseTailAttentionC8` | 单路 C8 Top-2048 + dense tail attention |
| `sparse_tail_attention_mtp_c8` | `A5SparseTailAttentionMtpC8` | 1～4 路 packed query C8 sparse+dense-tail attention |

LIDU 接口：

```python
source_ids, destination_slots, miss_counts, cache_alias = \
    torch.ops.nanovllm_dsa.fused_li_manage_c8(
        query,                 # fp8_e4m3fn[B,32|64,128]
        key,                   # fp8_e4m3fn[BLOCKS,128,1,128]
        weights,               # bf16[B,32|64]
        query_dequant_scale,   # fp32[B,32|64]
        key_dequant_scale,     # fp32[BLOCKS,128,1]
        actual_seq_lengths_query,
        req_pool_entries,
        cache_slots_pool,      # int32[POOL_SIZE,SOURCE_CAPACITY]，原地更新
        cache_tokens,
        candidate_lens,
        block_table,
    )

topk_slots, miss_ids, miss_slots, miss_counts, cache_alias = \
    torch.ops.nanovllm_dsa.fused_li_manage_mtp_c8(
        query,                 # fp8_e4m3fn[4B,32|64,128]，固定 MTP3 四路
        key, weights, query_dequant_scale, key_dequant_scale,
        actual_seq_lengths_query,  # cumulative int32[B]
        req_pool_entries,
        cache_slots_pool,
        cache_tokens,
        candidate_lens,
        block_table,
    )
```

两种 LIDU 均提供同名 `_out` 接口，由调用方传入固定地址输出 buffer，适合图模式。
MTP 输出分别为 `topk_slots[T,1,2048]`、request 级
`miss_ids/miss_slots[B,8192]` 和 `miss_counts[B]`。

本地 C8 scatter 接口：

```python
hbm_alias, attention_slots, resident_seq_lengths = \
    torch.ops.nanovllm_dsa.kvcache_scatter_copy_c8(
        hbm_kv_bytes,          # int8[HBM_BLOCKS,128,1,656]，原地更新
        dram_kv_bytes,         # int8[DRAM_BLOCKS,128,1,656]
        hbm_block_table,
        dram_block_table,
        source_token_ids,
        destination_slots,
        copy_counts,
        cache_tokens,
        candidate_lens,
        actual_seq_lengths_kv,
        max_tail_tokens,
    )
```

该算子同样提供 `_out` 接口。Remote Offload 数据面不使用这个本地 DRAM scatter，
而是使用 AICPU IO-only 加 `npu_scatter_io_from_staging_c8`；保留该接口用于 split
基线和功能对照。

C8 SFA 接口：

```python
attention = torch.ops.nanovllm_dsa.sparse_tail_attention_c8(
    query,                    # bf16/fp16[T,Q_HEAD,576]
    packed_kv,                # fp8/int8[BLOCKS,128,1,656]
    sparse_and_tail_slots,    # int32[T,1,2048+TAIL]
    block_table,
    actual_seq_lengths_query,
    resident_seq_lengths,
    scale_value,
)

attention = torch.ops.nanovllm_dsa.sparse_tail_attention_mtp_c8(
    query, packed_kv, sparse_and_tail_slots, block_table,
    actual_seq_lengths_query, resident_seq_lengths, scale_value,
)
```

固定约束为 block size 128、packed KV row 656B、TopK 2048、`Q_HEAD<=64`、source
capacity 不超过 `2^18`。当前性能基线的 MTP LIDU 固定支持四路 MTP3；MTP SFA
支持 1～4 路。
不要在同一 Python 进程中再导入旧的 `nanovllm_dsa_a5` 扩展，否则同名
`nanovllm_dsa` schema 会重复注册；当前仓库已经提供完整 adapter。

CPU 隐式 DBA runtime 由 PyTorch 扩展直接导出：

```python
from kvcache_scatter_copy_custom_ops import SwappedCpuDuImplicitDbaRuntime

runtime = SwappedCpuDuImplicitDbaRuntime(first_cpu=-1)
runtime.register_pipeline(...)  # 一次注册 swapped TopK/metadata/ready 地址
runtime.start()                  # 固定启动 32 个 request worker
```

LI 仍调用官方 `aclnnQuantLightningIndexer` 且完整 BS=32 只 launch 一次；CPU 根据
四路 TopK 的实际可见顺序处理 request，并分别为 request 0～15、16～31 发布 ready。
完整参数与输出 ABI 见 [`docs/remote_offload_ops.md`](docs/remote_offload_ops.md)。

### 3.2 标准化 LIM-MTP 算子

`NanovllmFusedLiManageMtp` 来自
`git@github.com:xwLearnsLLM/nanovllm-DSA-offload.git` 的
`ops_lim_standardization` 分支，固定提交与本仓库适配记录见
[`VENDORED.md`](VENDORED.md)。它使用 BF16/FP16 标准 LI，而不是上述 FP8 C8 LI；
来源实现仅支持 910B/910_93。A5 Remote Offload 矩阵不调用这个融合算子：NPU
LIDU 路径使用 `A5FusedLiManageMtpC8`，CPU DU 路径调用同输入口径的官方 A5 C8
LightningIndexer caller-owned `_out` adapter。

```python
torch.ops.nanovllm_dsa.fused_li_manage_mtp_standard_out(
    index_weights, query_dequant_scale, query,
    index_key_dequant_scale, index_key_cache, index_block_table,
    actual_seq_lengths_query, actual_seq_lengths_key,
    offload_seq_lengths_key, num_cache_tokens, request_state,
    req_pool_entries, cache_slots_pool,
    topk_src_ids, topk_dst_slots, topk_miss_counts,
    miss_src_ids, miss_dst_slots, miss_counts,
)
```

主要 shape 为 `query[T,32|64,128]`、`key[blocks,128,1,128]`、
`topk_*[T,1,2048]`、`miss_*[B,16384]`。`cache_slots_pool` 原地更新，空槽
sentinel 为 `INT32_MIN`。当前仓库以 `_out` 固定地址接口接入，便于后续图模式。

## 4. 构建

非 Ascend 950 默认只构建 AICPU：

```bash
BUILD_JOBS=16 bash build_and_install.sh
```

`SOC_VERSION=ascend950` 时默认启用 local AIV 与 C8 MTP；若只需 AICPU，
可显式关闭：

```bash
BUILD_JOBS=16 SOC_VERSION=ascend950 \
ENABLE_LOCAL_AIV=0 ENABLE_C8_MTP_OPS=0 ENABLE_STANDARD_LIM=0 \
bash build_and_install.sh
```

启用 local AIV 与融合 SFA：

```bash
BUILD_JOBS=16 SOC_VERSION=ascend950 \
ENABLE_LOCAL_AIV=1 ENABLE_SFA_FUSION=1 \
bash build_and_install.sh
```

编译 Remote Offload 所需的仓内 C8 MTP 算子和 AIV completion scatter：

```bash
BUILD_JOBS=16 SOC_VERSION=ascend950 \
ENABLE_C8_MTP_OPS=1 ENABLE_LOCAL_AIV=1 \
bash build_and_install.sh
```

标准 LIM 可在 910B/910_93 上单独通过 `ENABLE_STANDARD_LIM=1` 控制：

```bash
BUILD_JOBS=16 SOC_VERSION=ascend910_9391 \
ENABLE_STANDARD_LIM=1 ENABLE_LOCAL_AIV=0 ENABLE_C8_MTP_OPS=0 \
bash build_and_install.sh
```

来源 kernel 在 Ascend 950 架构宏下为空函数，因此构建脚本会拒绝 A5 上显式设置
`ENABLE_STANDARD_LIM=1`。A5 Remote Offload 使用 C8 MTP LIDU；拆分的 C8 LI + CPU
DU 路径调用与 `torch_npu.npu_quant_lightning_indexer` 相同的 ACLNN kernel。

启用 C8 后，脚本会使用 `msopgen` 生成 C8 的标准 ACLNN 工程，并将其安装至
`opp_c8/`；原有 AICPU/AIV 算子仍安装至 `opp/`。这是 C8 FP8 接口所需的构建路径，
不要将 C8 源码重新加入通用 `op_build libop_host_aclnn.so` 流程。

常用环境变量：

- `HCOMM_HOME_PATH`：Host Hcomm 安装根目录；
- `HCOMM_KVCACHE_SCATTER_COPY_JSON`：匹配的 device kernel JSON；
- `KVCACHE_SCATTER_COPY_INSTALL_OPP_PATH`：本地 OPP 安装目录；
- `KVCACHE_SCATTER_COPY_C8_INSTALL_OPP_PATH`：C8 OPP 安装目录，默认 `opp_c8/`；
- `BUILD_JOBS`：并行编译数；
- `SOC_VERSION`：A5 使用 `ascend950`。
- `ENABLE_C8_MTP_OPS=1`：构建上述五个 C8 算子，并安装其独立 C8 OPP；
- `ENABLE_STANDARD_LIM=1`：仅在 910B/910_93 构建标准 BF16/FP16 LIM-MTP 算子；
- `MEMFABRIC_SMEM_LIB`：可选的 `libmf_smem.so` 绝对路径，供 CPU DU MTE 接口
  运行时加载。

示例：

```bash
export CANN_ROOT=/usr/local/Ascend/cann-9.1.T560
export HCOMM_HOME_PATH="${CANN_ROOT}/aarch64-linux"
export HCOMM_KVCACHE_SCATTER_COPY_JSON=\
"${CANN_ROOT}/opp/built-in/op_impl/aicpu/config/ccl_kernel.json"

source "${CANN_ROOT}/set_env.sh"
BUILD_JOBS=16 SOC_VERSION=ascend950 \
ENABLE_LOCAL_AIV=1 ENABLE_SFA_FUSION=1 \
bash build_and_install.sh
```

安装脚本会清理本算子的陈旧 OPP 文件，避免旧 `customize_impl` 覆盖新 kernel。
它不会清理其他 vendor 或系统级 OPP。

## 5. Hcomm 与内存池

### 5.1 raw URMA Mock Pool

构建和运行：

```bash
cd test/urma_mock_pool
./build.sh
./urma_mock_pool \
  --device <urma-device-name> --blocks 4096 --jetty-count 1 \
  --control-port 19090 --poll-threads 1 --poll-cpus 8 \
  --pool-pattern bytes --hold-seconds 600
```

控制连接使用普通 Host TCP，只交换 EID、Jetty 和 segment 描述符。TCP 建链完成后
关闭，KV payload、命令通知和 completion 均走 UB 单边操作。

### 5.2 原生 Hcomm Pool

RaSocket/Hcomm channel 的最小服务端见
[`test/hcomm_pool_server/README.md`](test/hcomm_pool_server/README.md)。该路径与 raw
Mock Pool 的普通 TCP 控制连接不是同一种建链方式。

## 6. 功能测试

### 6.1 无 NPU 的 CPU DU/ring 测试

```bash
bash test/run_cpu_du_host_test.sh
```

脚本打印完整复现命令，覆盖 CPU DU、MTP union/owner、事务回滚、snapshot、ring
generation 和协议 ABI。

统一的阶段 1A 入口：

```bash
python test/run_remote_offload_single_op_tests.py \
  --components host \
  --json /tmp/remote_offload_single_op.json
```

构建 PyTorch 扩展后，可同时验证同步 Host ABI、64 槽 ring worker 和批量常驻
worker：

```bash
python test/run_remote_offload_single_op_tests.py \
  --components cpu_du_extension
```

在 A5 上验证 swapped-memory polling、32 路隐式 DBA DU、状态提交和两组 ready：

```bash
python test/run_remote_offload_single_op_tests.py \
  --components cpu_du_implicit_dba
```

### 6.2 AICPU 散拷正确性

```bash
python test/correctness.py --device npu:0 --dtypes bf16,fp16
```

### 6.3 最小 raw URMA 测试

先启动两个 block 的 Mock Pool，再执行：

```bash
python test/urma_remote_demo.py
```

成功时打印 `URMA_REMOTE_SCATTER_COPY_OK`。

### 6.4 BF16 remote SFA

先使用 `--pool-pattern bf16` 启动 Pool：

```bash
python test/sfa_remote_perf.py
```

该脚本校验 staging 内容、attention 输出和最终 HBM sparse row，然后才报告性能。

### 6.5 仓内 C8 单算子

完成 `ENABLE_C8_MTP_OPS=1` 构建后，可分别运行：

```bash
PYTHONPATH=./torch_extension python test/test_fused_li_manage_c8.py
PYTHONPATH=./torch_extension python test/test_fused_li_manage_mtp_c8.py
PYTHONPATH=./torch_extension python test/test_kvcache_scatter_copy_c8.py
PYTHONPATH=./torch_extension python test/test_sparse_tail_attention_c8.py
PYTHONPATH=./torch_extension python test/test_sparse_tail_attention_mtp_c8.py
```

也可通过统一入口选择组件：

```bash
python test/run_remote_offload_single_op_tests.py \
  --components c8_lidu,c8_mtp_lidu,c8_scatter,c8_sfa,c8_mtp_sfa
```

标准 LIM-MTP 单算子测试仅适用于 910B/910_93；A5 会明确打印 skipped：

```bash
PYTHONPATH=./torch_extension \
python test/test_fused_li_manage_mtp_standard.py
```

## 7. 性能测试

### 7.1 远端散拷

```bash
python test/urma_remote_perf.py
```

`local_aiv_token` 在每个 shape 正式计时前默认持续预热 2 秒，并每 32 次下发同步
一次，降低低功耗唤醒和冷卡状态对微秒级结果的影响。可以调整或关闭：

```bash
URMA_LOCAL_AIV_WARMUP_MS=3000 \
URMA_LOCAL_AIV_WARMUP_BATCH=32 \
python test/urma_remote_perf.py

# 设为 0 时恢复为固定 WARMUP 次调用。
URMA_LOCAL_AIV_WARMUP_MS=0 python test/urma_remote_perf.py
```

常用环境变量：

```bash
URMA_IO_BYTES=656 \
URMA_SCATTER_AFTER_GATHER=0 \
URMA_MAX_SUBIOS_PER_WQE=3 \
URMA_FIXED_WQE_BYTES=8192 \
python test/urma_remote_perf.py
```

输出包括端到端平均/p50/p99、整数 IOPS、subIO IOPS、payload GB/s、物理 wire
bytes，以及 AICPU prepare/submit/sync/host wait/local scatter 分阶段时间。

### 7.2 URMA 链路基线

```bash
python test/urma_bandwidth_perf.py
```

该脚本测试连续 pull、连续 push 和 Host aggregate push。它不包含最终 token
scatter，适合区分 URMA wire ceiling、命令率和 Host gather 瓶颈。

### 7.3 聚合率限制

`URMA_MAX_SUBIOS_PER_WQE=0` 表示当前最大聚合率基线；`1/2/3/4` 表示一个物理
WQE 最多包含对应数量子 IO。固定 8KiB 模型使用
`URMA_FIXED_WQE_BYTES=8192`。

聚合率实验要求 Pool 使用 `--pipeline-mib 0`。非零 pipeline 会改变实际 WQE
拆分，不能与聚合率结果混在同一组比较。

## 8. Remote Offload 功能矩阵与性能准入

算子链固定为 656B packed C8、BS=32、LI candidate SeqLen=128K 和 MTP3
（3 个 draft 加 1 个 root，`query_count=4`）。SFA 固定 Top-2048、dense tail 256
以及每路 causal 1/2/3/4；测试每 request union miss 100/200 和四条执行路径。

默认 matrix 仅执行功能链路；Event 仅可用于依赖同步。启用 `--with-msprof` 后，
同一 matrix 会逐 case 调用 msprof、直接解析 `task_time`，并输出合并性能 CSV。

矩阵驱动：

```bash
python test/run_remote_offload_matrix.py \
  --device-eid <32位EID> --pool-ip <pool控制面IPv4> --dry-run
```

实际性能矩阵示例：

```bash
python test/run_remote_offload_matrix.py \
  --device-eid <32位EID> --device-phy-id 0 \
  --pool-ip <pool控制面IPv4> --lanes 1 \
  --with-msprof --profile-root remote_offload_msprof \
  --csv remote_offload_msprof_results.csv
```

每个 case 的 msprof 输出放在 `remote_offload_msprof` 的一个扁平子目录，标准输出和
错误输出写到该目录的 `msprof.log`。最终 CSV 不含命令，保留各模式的 chain、设备
task、task 间 gap，以及隐式 DBA 的两个 16-request IO/scatter、LI 重叠、CPU DU
request p50、IOPS、payload 带宽和相对 no-offload 的比例；终端末尾还会再次打印
不含命令的性能汇总。

CPU DU batch 与 C8 MTP LIDU 的单算子性能可以独立运行，不需要启动内存池：

```bash
python test/run_remote_offload_operator_perf.py \
  --device npu:0 --bs 32 --query-count 4 \
  --candidate-length 131072 --cache-budget 8192 \
  --misses 100,200 --cpu-du-threads 32 \
  --profile-root operator_msprof --csv operator_perf_results.csv
```

CPU DU 使用一次 batch `run()` 覆盖 BS=32，C8 LIDU 使用 msprof task-time，不使用
NPU Event。两者的计时边界和 `timing_source` 会写入合并 CSV；详细口径见
[`docs/remote_offload_ops.md`](docs/remote_offload_ops.md)。

### 8.1 C8 MTP LI 与 CPU polling 穿刺实验

该实验用于隔离判断 CPU 并发读取 swapped-memory TopK 是否拖慢 LI。基线对齐
`nanovllm-DSA-offload` 的 `ops_a5` 分支（提交 `2802bdd`）中官方 A5 C8 MTP3
benchmark：调用 `torch_npu.npu_quant_lightning_indexer` 对应的
`aclnnQuantLightningIndexer`，使用 FP8 E4M3、packed `T=4*BS`、TopK 2048、
TND/PA_BSND 和 `sparse_mode=3`。本仓库的 `_out` adapter 只替换输出 allocator，
不替换 LI kernel，也不增加 NPU copy。

矩阵包含三组：HBM 输出且不 polling、swapped 输出且不 polling、swapped 输出且
多线程 polling。录图前先做 eager warmup；一张图固定包含连续 10 个 LI，每个 LI
写不同 output slice。之后只用图重放完成 warmup 和正式 iteration。每次 replay 前在
图外将 10 个 slice 重置为 `-1`，同步完成后再启动 polling，避免把上一次结果误判为
本次完成。默认多线程各扫描 slice 的不重叠分区；`--poll-scan replicated` 可让每个
线程读取完整 slice，作为更强的总线压力测试。

```bash
python test/run_li_c8_mtp_polling_matrix.py \
  --device npu:0 --bs 32 --queries-per-request 4 \
  --source-len 131072 --poll-threads 32 \
  --poll-first-cpu <起始逻辑CPU> \
  --profile-root li_polling_msprof \
  --csv li_polling_results.csv
```

驱动在每个 case 前打印可复现的 msprof 命令。最终 CSV 和终端性能汇总只使用
msprof `task_time` 中的 `QuantLightningIndexer` task：忽略 eager warmup、图重放
warmup、output reset、host synchronize 和 polling wait。主要判断
`swapped_poll` 相对 `swapped_no_poll` 的 `li_call_avg_us` 回退；
`hbm_no_poll` 仅用于区分 swapped output 本身的影响。运行环境必须支持
swapped-memory VA 地址归一化，否则 NPU tensor 的地址不能由 CPU 直接读取，测试会
在启动 polling 前明确失败。

## 9. 输出规范

- 执行每条命令前打印可复制的等效命令；
- 运行末尾再次打印只包含 case 状态的汇总；
- CSV 不保存命令，只保存关键维度和功能状态；
- 单算子功能结果写 JUnit/JSON，详细打点写诊断 JSON；
- 性能比较至少包含 warmup、交替运行和多次重复，使用中位数判定。

## 10. 常见问题

- **找不到自定义算子**：清理本仓库旧 OPP，重新构建，并检查
  `ASCEND_CUSTOM_OPP_PATH`；
- **compile info 不含 `_pattern`**：通常是 op host、kernel 与 OPP 版本混装；
- **lane descriptor 无效**：检查 Pool `--jetty-count` 与客户端 `RAW_LANES`；当前硬件
  测试固定两者均为 `1`。
- **建链后无进展**：依次检查命令是否到达、数据 CQE、最终 completion WRITE；
- **Host gather 远高于端到端带宽**：Host memcpy 带宽不包含 URMA post/poll、
  completion、AICPU launch 和最终 scatter；
- **频繁访问相同地址导致结果偏高**：扩大 Pool 并轮转不相交 remote bank，分别
  报告 cache-hot 和 working-set 结果。
