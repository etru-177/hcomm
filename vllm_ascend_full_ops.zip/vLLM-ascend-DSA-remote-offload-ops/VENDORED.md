# 内部源码快照

## C8 MTP 算子

当前仓库中的下列目录来自内部仓库：

- 原仓库：`git@github.com:xiaohu9/nanovllm-DSA-offload.git`
- 原分支：`sfa_c8_mtp`
- 固定提交：`06be4016de2a6c68b004369b1eb58a6f3c993f5c`
- 提交说明：`补充文档说明`
- 快照日期：2026-08-17

该快照当前保留的 CANN 算子源码为：

- `A5FusedLiManageC8`
- `A5KvcacheScatterCopyC8`
- `A5SparseTailAttentionC8`
- `A5SparseTailAttentionMtpC8`

源码已经并入 `csrc/src/`，Torch adapter 已经并入 `torch_extension/csrc/`，不使用
Git submodule，也不在运行时依赖兄弟目录。当前仓库的构建、测试和接口适配可以在
vendor 快照之上继续演进；同步上游时应重新记录来源提交，并保留本仓库的 Hcomm、
AIV completion scatter 和统一 OPP 构建改动。

### ops_a5 性能优化版 MTP3 LIDU

矩阵使用的 `A5FusedLiManageMtpC8` 已替换为内部 `ops_a5` 性能基线：

- 原仓库：`git@github.com:xwLearnsLLM/nanovllm-DSA-offload.git`
- 原分支：`ops_a5`
- 固定提交：`2802bddfc895d6e0fffe8b4e9cdbe55190230d8d`
- 提交说明：`test: 增加 C8 综合组图用例`
- 快照日期：2026-08-31
- CANN 算子：`A5FusedLiManageMtpC8`

该版本固定服务 MTP3（每请求四路 query），使用四路 LI route、request-level union
和专用 workspace/payload，不再使用原 `sfa_c8_mtp` 快照中按 request 串行执行多路
query 的 correctness-first kernel。来源 CANN ABI 新增每路 `topk_source_ids` 和
`topk_miss_count` 输出；本仓库 `_out` 热路径要求调用方预分配这两个 buffer，同时
保留原有五返回值 Torch 接口，避免上层 Hcomm 和矩阵 mode 改名。

算子依赖的 `arch35_payload_c8/` 和 `a5_fused_li_manage_classify_vf.h` 在来源仓库中
位于 `fused_li_manage_c8/op_kernel/`。当前仓库将这组 header 一并复制到 MTP3
算子的 `op_kernel/` 下，使 `A5FusedLiManageMtpC8` 的构建不依赖是否同时启用另一
个算子，也不会误用本仓库旧快照中的 C8 LI payload。

来源仓库在 Ascend950DT_9581、BS=32、MTP3、N=32、序列长度 131072、C=12288、
每路 miss=100/union miss=300 下报告：官方 C8 LI 为 349.555 us，优化版
LIM-MTP3 为 479.857 us，额外 DU 开销 130.302 us。本仓库仍以相同机器上的 msprof
task-time 复测结果为准，不直接把来源 Event 数据作为当前准入结果。

## 标准化 LIM-MTP 算子

标准 BF16/FP16 LightningIndexer + DU 融合算子来自内部仓库：

- 原仓库：`git@github.com:xwLearnsLLM/nanovllm-DSA-offload.git`
- 原分支：`ops_lim_standardization`
- 固定提交：`876665fa0b6ac3a0953cbf61a1ac6df0f142d90b`
- 提交说明：`docs: integrate long-source validation and scans`
- 快照日期：2026-08-31
- CANN 算子：`NanovllmFusedLiManageMtp`

源码快照位于 `csrc/src/nanovllm_fused_li_manage_mtp/`，按本仓库自有算子参与统一
构建，不使用 submodule 或 `third_party`。相对上游快照的适配仅接入本仓库通用
CMake/Torch `_out` ABI，算子算法和 kernel 主体保持来源提交版本。

该来源提交只支持 910B/910_93：kernel 对 `__CCE_AICORE__ == 310`/
`__DAV_310R6__` 明确编译为空，不能通过仅增加 `ascend950` host 注册来移植到 A5。
因此 A5 默认不构建该算子；A5 的融合 LIDU 使用仓内 `A5FusedLiManageMtpC8`，CPU DU
实验使用官方 A5 C8 LightningIndexer 的 caller-owned `_out` adapter，不调用此
BF16/FP16 算子。
