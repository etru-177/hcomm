// SPDX-License-Identifier: Apache-2.0

#include "offload_ring.h"

#include <cstring>
#include <stdexcept>

namespace remote_offload {

OffloadRingView::OffloadRingView(OffloadRingSlot* slots, uint32_t slotCount)
    : slots_(slots), slotCount_(slotCount)
{
    if (slots_ == nullptr || slotCount_ < 2) {
        throw std::invalid_argument(
            "offload ring requires a non-null buffer and at least two slots");
    }
}

uint32_t OffloadRingView::Index(uint64_t generation) const
{
    if (generation == 0) {
        throw std::invalid_argument("offload generation zero is reserved");
    }
    return static_cast<uint32_t>((generation - 1) % slotCount_);
}

void OffloadRingView::Initialize()
{
    for (uint32_t index = 0; index < slotCount_; ++index) {
        std::memset(&slots_[index], 0, sizeof(slots_[index]));
        slots_[index].magic = kOffloadRingMagic;
        slots_[index].version = kOffloadRingVersion;
        __atomic_store_n(&slots_[index].state,
            static_cast<uint32_t>(OffloadSlotState::kFree), __ATOMIC_RELEASE);
    }
}

bool OffloadRingView::TryAcquire(uint64_t generation,
    const OffloadSlotMetadata& metadata, uint32_t* slotIndex)
{
    if (metadata.queryCount == 0 || metadata.queryCount > 4) {
        throw std::invalid_argument("offload query count must be in [1, 4]");
    }
    const uint32_t index = Index(generation);
    OffloadRingSlot& slot = slots_[index];
    uint32_t expected = static_cast<uint32_t>(OffloadSlotState::kFree);
    if (!__atomic_compare_exchange_n(&slot.state, &expected,
            static_cast<uint32_t>(OffloadSlotState::kNpuLiWriting), false,
            __ATOMIC_ACQ_REL, __ATOMIC_ACQUIRE)) {
        return false;
    }
    slot.status = static_cast<uint32_t>(OffloadStatus::kOk);
    slot.requestId = metadata.requestId;
    slot.epoch = metadata.epoch;
    slot.layerId = metadata.layerId;
    slot.queryCount = metadata.queryCount;
    slot.candidateLength = metadata.candidateLength;
    slot.uniqueMissCount = 0;
    slot.duGeneration = 0;
    slot.liPayloadOffset = metadata.liPayloadOffset;
    slot.duPayloadOffset = metadata.duPayloadOffset;
    slot.commandOffset = metadata.commandOffset;
    slot.completionOffset = metadata.completionOffset;
    __atomic_store_n(&slot.generation, generation, __ATOMIC_RELEASE);
    if (slotIndex != nullptr) {
        *slotIndex = index;
    }
    return true;
}

bool OffloadRingView::TryTransition(uint64_t generation,
    OffloadSlotState expectedState, OffloadSlotState desired,
    OffloadStatus status)
{
    OffloadRingSlot& slot = slots_[Index(generation)];
    if (__atomic_load_n(&slot.generation, __ATOMIC_ACQUIRE) != generation) {
        return false;
    }
    if (desired == OffloadSlotState::kError) {
        slot.status = static_cast<uint32_t>(status);
    }
    uint32_t expected = static_cast<uint32_t>(expectedState);
    return __atomic_compare_exchange_n(&slot.state, &expected,
        static_cast<uint32_t>(desired), false,
        __ATOMIC_RELEASE, __ATOMIC_ACQUIRE);
}

bool OffloadRingView::Release(uint64_t generation)
{
    OffloadRingSlot& slot = slots_[Index(generation)];
    if (__atomic_load_n(&slot.generation, __ATOMIC_ACQUIRE) != generation) {
        return false;
    }
    const uint32_t state = __atomic_load_n(&slot.state, __ATOMIC_ACQUIRE);
    if (state != static_cast<uint32_t>(OffloadSlotState::kDataReady) &&
        state != static_cast<uint32_t>(OffloadSlotState::kError)) {
        return false;
    }
    __atomic_store_n(&slot.generation, uint64_t{0}, __ATOMIC_RELAXED);
    __atomic_store_n(&slot.state,
        static_cast<uint32_t>(OffloadSlotState::kFree), __ATOMIC_RELEASE);
    return true;
}

const OffloadRingSlot* OffloadRingView::Find(uint64_t generation) const
{
    const OffloadRingSlot& slot = slots_[Index(generation)];
    if (__atomic_load_n(&slot.generation, __ATOMIC_ACQUIRE) != generation) {
        return nullptr;
    }
    return &slot;
}

}  // namespace remote_offload
