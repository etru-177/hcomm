// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <cstdint>
#include <vector>

namespace remote_offload {

constexpr int32_t kSparseCount = 2048;
constexpr int32_t kMaxMtpQueries = 4;
constexpr int32_t kSourceRefOwnerBit = 1 << 30;
constexpr uint32_t kCpuDuSnapshotVersion = 1;

enum class DuOutputOrder {
    // CopySFA consumes local hits first and remote misses last.
    kHitsThenMisses,
    // Compatibility order used by the existing NPU LIDU update operator.
    kMissesThenHits,
};

struct CpuDuSnapshot {
    uint32_t version{kCpuDuSnapshotVersion};
    uint64_t generation{0};
    int32_t cacheBudget{0};
    std::vector<int32_t> tokenToSlot;
};

struct CpuDuResult {
    uint64_t generation{0};
    DuOutputOrder order{DuOutputOrder::kHitsThenMisses};
    // One 2048-entry row per query. sourceRefs contains an HBM slot for a hit
    // and a request-local staging ordinal for a miss. The first occurrence of
    // each unique miss also carries kSourceRefOwnerBit.
    std::vector<std::vector<int32_t>> sourceIds;
    std::vector<std::vector<int32_t>> destinationSlots;
    std::vector<std::vector<int32_t>> sourceRefs;
    std::vector<int32_t> missCounts;

    // The command path submits only these unique misses to the memory pool.
    std::vector<int32_t> uniqueMissSourceIds;
    std::vector<int32_t> uniqueMissDestinationSlots;
    std::vector<int32_t> evictedSourceIds;
    std::vector<int32_t> uniqueMissQueryMasks;

    // Stable first-occurrence union of all pre-update HBM hits. A ref count
    // larger than one identifies a shared hit; one identifies a private hit.
    // unionOrdinals follows sourceIds order. Hit ordinals index these arrays;
    // miss ordinals start at unionHitSourceIds.size() and then index the
    // existing unique-miss arrays.
    std::vector<int32_t> unionHitSourceIds;
    std::vector<int32_t> unionHitSlots;
    std::vector<int32_t> unionHitRefCounts;
    std::vector<int32_t> unionHitQueryMasks;
    std::vector<std::vector<int32_t>> unionOrdinals;
};

class CpuDuState {
public:
    CpuDuState(int32_t cacheBudget, std::vector<int32_t> tokenToSlot,
        uint64_t generation = 0);

    CpuDuResult Update(
        const std::vector<std::vector<int32_t>>& topkRows,
        int32_t candidateLength,
        DuOutputOrder order = DuOutputOrder::kHitsThenMisses,
        bool buildUnion = true);

    CpuDuSnapshot Snapshot() const;
    void Restore(const CpuDuSnapshot& snapshot);
    // 性能路径在注册阶段已经校验过模板。每轮复现实验时复用 vector
    // capacity，避免 snapshot 校验和临时 vector 带来的无关开销。
    void RestoreValidatedTemplate(
        const std::vector<int32_t>& tokenToSlot, uint64_t generation);

    int32_t cache_budget() const { return cacheBudget_; }
    uint64_t generation() const { return generation_; }
    const std::vector<int32_t>& token_to_slot() const { return tokenToSlot_; }

private:
    void ValidateState() const;

    int32_t cacheBudget_;
    uint64_t generation_;
    std::vector<int32_t> tokenToSlot_;
};

}  // namespace remote_offload
