// SPDX-License-Identifier: Apache-2.0

#include "cpu_du.h"

#include <algorithm>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>

namespace remote_offload {
namespace {

[[noreturn]] void Invalid(const std::string& message)
{
    throw std::invalid_argument("CPU DU: " + message);
}

struct RowClassification {
    std::vector<int32_t> hits;
    std::vector<int32_t> misses;
};

}  // namespace

CpuDuState::CpuDuState(int32_t cacheBudget,
    std::vector<int32_t> tokenToSlot, uint64_t generation)
    : cacheBudget_(cacheBudget), generation_(generation),
      tokenToSlot_(std::move(tokenToSlot))
{
    ValidateState();
}

void CpuDuState::ValidateState() const
{
    if (cacheBudget_ != 0 && cacheBudget_ < kSparseCount) {
        Invalid("cache budget must be zero or at least 2048");
    }
    if (tokenToSlot_.empty()) {
        Invalid("token-to-slot state must not be empty");
    }
    std::vector<uint8_t> used(static_cast<size_t>(cacheBudget_), 0);
    for (size_t token = 0; token < tokenToSlot_.size(); ++token) {
        const int32_t slot = tokenToSlot_[token];
        if (slot == -1) {
            continue;
        }
        if (slot < 0 || slot >= cacheBudget_) {
            Invalid("slot is outside the cache budget at token " +
                std::to_string(token));
        }
        if (used[static_cast<size_t>(slot)] != 0) {
            Invalid("two tokens own the same cache slot " +
                std::to_string(slot));
        }
        used[static_cast<size_t>(slot)] = 1;
    }
}

CpuDuResult CpuDuState::Update(
    const std::vector<std::vector<int32_t>>& topkRows,
    int32_t candidateLength, DuOutputOrder order, bool buildUnion)
{
    if (topkRows.empty() || topkRows.size() > kMaxMtpQueries) {
        Invalid("query row count must be in [1, 4]");
    }
    if (candidateLength < kSparseCount ||
        candidateLength > static_cast<int32_t>(tokenToSlot_.size())) {
        Invalid("candidate length is outside [2048, source capacity]");
    }

    if (cacheBudget_ == 0) {
        CpuDuResult result;
        result.generation = generation_ + 1;
        result.order = order;
        result.sourceIds.resize(topkRows.size());
        result.destinationSlots.resize(topkRows.size());
        result.sourceRefs.resize(topkRows.size());
        result.unionOrdinals.resize(topkRows.size());
        result.missCounts.assign(topkRows.size(), 0);
        for (size_t row = 0; row < topkRows.size(); ++row) {
            if (topkRows[row].size() != kSparseCount) {
                Invalid("each query row must contain exactly 2048 token IDs");
            }
            result.sourceIds[row].assign(kSparseCount, -1);
            result.destinationSlots[row].assign(kSparseCount, -1);
            result.sourceRefs[row].assign(kSparseCount, -1);
            result.unionOrdinals[row].assign(kSparseCount, -1);
        }
        generation_ = result.generation;
        return result;
    }

    const std::vector<int32_t> oldState = tokenToSlot_;
    std::vector<RowClassification> classified(topkRows.size());
    std::vector<int32_t> unionHits;
    std::vector<int32_t> unionHitRefCounts;
    std::vector<int32_t> unionHitQueryMasks;
    std::vector<int32_t> unionHitOrdinalsBySlot;
    if (buildUnion) {
        unionHitOrdinalsBySlot.assign(
            static_cast<size_t>(cacheBudget_), -1);
    }
    std::vector<int32_t> uniqueMisses;
    std::vector<int32_t> uniqueMissQueryMasks;
    std::unordered_map<int32_t, int32_t> stagingOrdinals;
    std::vector<uint8_t> protectedSlots(static_cast<size_t>(cacheBudget_), 0);

    for (size_t row = 0; row < topkRows.size(); ++row) {
        if (topkRows[row].size() != kSparseCount) {
            Invalid("each query row must contain exactly 2048 token IDs");
        }
        std::unordered_set<int32_t> rowTokens;
        rowTokens.reserve(kSparseCount);
        for (const int32_t token : topkRows[row]) {
            if (token < 0 || token >= candidateLength) {
                Invalid("TopK token is outside the candidate range");
            }
            if (!rowTokens.insert(token).second) {
                Invalid("a TopK query row contains a duplicate token");
            }
            const int32_t slot = oldState[static_cast<size_t>(token)];
            if (slot >= 0) {
                classified[row].hits.push_back(token);
                protectedSlots[static_cast<size_t>(slot)] = 1;
                if (buildUnion) {
                    int32_t& ordinal = unionHitOrdinalsBySlot[
                        static_cast<size_t>(slot)];
                    if (ordinal < 0) {
                        ordinal = static_cast<int32_t>(unionHits.size());
                        unionHits.push_back(token);
                        unionHitRefCounts.push_back(1);
                        unionHitQueryMasks.push_back(1 << row);
                    } else {
                        ++unionHitRefCounts[static_cast<size_t>(ordinal)];
                        unionHitQueryMasks[static_cast<size_t>(ordinal)] |=
                            1 << row;
                    }
                }
            } else {
                classified[row].misses.push_back(token);
                const auto inserted = stagingOrdinals.emplace(
                    token, static_cast<int32_t>(uniqueMisses.size()));
                if (inserted.second) {
                    uniqueMisses.push_back(token);
                    if (buildUnion) {
                        uniqueMissQueryMasks.push_back(1 << row);
                    }
                } else if (buildUnion) {
                    uniqueMissQueryMasks[
                        static_cast<size_t>(inserted.first->second)] |=
                        1 << row;
                }
            }
        }
    }

    // Work on a copy so an invalid command cannot leave partially updated DU
    // state. Victim selection intentionally scans token IDs in ascending order,
    // matching the deterministic storage-offload reference policy.
    std::vector<int32_t> nextState = oldState;
    std::vector<int32_t> missSlots;
    std::vector<int32_t> victims;
    missSlots.reserve(uniqueMisses.size());
    victims.reserve(uniqueMisses.size());
    std::vector<uint8_t> occupiedSlots(static_cast<size_t>(cacheBudget_), 0);
    for (const int32_t slot : oldState) {
        if (slot >= 0) {
            occupiedSlots[static_cast<size_t>(slot)] = 1;
        }
    }
    // A restored or newly allocated cache can be partially populated. Consume
    // free slots before evicting resident tokens so DU does not manufacture an
    // unnecessary eviction or fail while capacity is still available.
    for (int32_t slot = 0;
         slot < cacheBudget_ && missSlots.size() < uniqueMisses.size(); ++slot) {
        if (occupiedSlots[static_cast<size_t>(slot)] == 0) {
            missSlots.push_back(slot);
            victims.push_back(-1);
        }
    }
    for (int32_t token = 0;
         token < candidateLength && missSlots.size() < uniqueMisses.size();
         ++token) {
        const int32_t slot = oldState[static_cast<size_t>(token)];
        if (slot < 0 || protectedSlots[static_cast<size_t>(slot)] != 0) {
            continue;
        }
        protectedSlots[static_cast<size_t>(slot)] = 2;
        victims.push_back(token);
        missSlots.push_back(slot);
    }
    if (missSlots.size() != uniqueMisses.size()) {
        throw std::runtime_error(
            "CPU DU: insufficient unprotected victim slots for unique misses");
    }

    for (size_t index = 0; index < uniqueMisses.size(); ++index) {
        if (victims[index] >= 0) {
            nextState[static_cast<size_t>(victims[index])] = -1;
        }
        nextState[static_cast<size_t>(uniqueMisses[index])] = missSlots[index];
    }

    CpuDuResult result;
    result.generation = generation_ + 1;
    result.order = order;
    result.uniqueMissSourceIds = uniqueMisses;
    result.uniqueMissDestinationSlots = missSlots;
    result.evictedSourceIds = victims;
    result.uniqueMissQueryMasks = uniqueMissQueryMasks;
    result.unionHitSourceIds = unionHits;
    result.unionHitRefCounts = unionHitRefCounts;
    result.unionHitQueryMasks = unionHitQueryMasks;
    result.unionHitSlots.reserve(unionHits.size());
    for (const int32_t token : unionHits) {
        result.unionHitSlots.push_back(oldState[static_cast<size_t>(token)]);
    }
    result.sourceIds.resize(topkRows.size());
    result.destinationSlots.resize(topkRows.size());
    result.sourceRefs.resize(topkRows.size());
    result.unionOrdinals.resize(topkRows.size());
    result.missCounts.resize(topkRows.size());

    for (size_t row = 0; row < topkRows.size(); ++row) {
        const RowClassification& values = classified[row];
        result.missCounts[row] = static_cast<int32_t>(values.misses.size());
        std::vector<int32_t> ordered;
        ordered.reserve(kSparseCount);
        if (order == DuOutputOrder::kHitsThenMisses) {
            ordered.insert(ordered.end(), values.hits.begin(), values.hits.end());
            ordered.insert(ordered.end(), values.misses.begin(), values.misses.end());
        } else {
            ordered.insert(ordered.end(), values.misses.begin(), values.misses.end());
            ordered.insert(ordered.end(), values.hits.begin(), values.hits.end());
        }

        auto& ids = result.sourceIds[row];
        auto& slots = result.destinationSlots[row];
        auto& refs = result.sourceRefs[row];
        auto& unionRefs = result.unionOrdinals[row];
        ids = ordered;
        slots.reserve(kSparseCount);
        refs.reserve(kSparseCount);
        if (buildUnion) {
            unionRefs.reserve(kSparseCount);
        }
        for (const int32_t token : ordered) {
            const int32_t destination = nextState[static_cast<size_t>(token)];
            slots.push_back(destination);
            const auto miss = stagingOrdinals.find(token);
            if (oldState[static_cast<size_t>(token)] >= 0) {
                refs.push_back(destination);
                if (buildUnion) {
                    unionRefs.push_back(unionHitOrdinalsBySlot[
                        static_cast<size_t>(
                            oldState[static_cast<size_t>(token)])]);
                }
                continue;
            }
            int32_t ref = miss->second;
            if (buildUnion) {
                unionRefs.push_back(
                    static_cast<int32_t>(unionHits.size()) + ref);
            }
            // The first occurrence in packed query order owns the persistent
            // HBM write. All later MTP occurrences reuse the same staging row.
            bool first = true;
            for (size_t previous = 0; previous < row && first; ++previous) {
                first = std::find(topkRows[previous].begin(),
                    topkRows[previous].end(), token) ==
                    topkRows[previous].end();
            }
            if (first) {
                ref |= kSourceRefOwnerBit;
            }
            refs.push_back(ref);
        }
    }

    tokenToSlot_.swap(nextState);
    generation_ = result.generation;
    return result;
}

CpuDuSnapshot CpuDuState::Snapshot() const
{
    return CpuDuSnapshot{
        kCpuDuSnapshotVersion, generation_, cacheBudget_, tokenToSlot_};
}

void CpuDuState::Restore(const CpuDuSnapshot& snapshot)
{
    if (snapshot.version != kCpuDuSnapshotVersion) {
        Invalid("unsupported snapshot version");
    }
    const int32_t previousBudget = cacheBudget_;
    const uint64_t previousGeneration = generation_;
    std::vector<int32_t> previousState = tokenToSlot_;
    cacheBudget_ = snapshot.cacheBudget;
    generation_ = snapshot.generation;
    tokenToSlot_ = snapshot.tokenToSlot;
    try {
        ValidateState();
    } catch (...) {
        cacheBudget_ = previousBudget;
        generation_ = previousGeneration;
        tokenToSlot_ = std::move(previousState);
        throw;
    }
}

void CpuDuState::RestoreValidatedTemplate(
    const std::vector<int32_t>& tokenToSlot, uint64_t generation)
{
    if (tokenToSlot.size() != tokenToSlot_.size()) {
        Invalid("validated template size changed after registration");
    }
    std::copy(tokenToSlot.begin(), tokenToSlot.end(), tokenToSlot_.begin());
    generation_ = generation;
}

}  // namespace remote_offload
