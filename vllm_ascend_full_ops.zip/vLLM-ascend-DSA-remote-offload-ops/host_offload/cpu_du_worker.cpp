// SPDX-License-Identifier: Apache-2.0

#include "cpu_du_worker.h"

#include <algorithm>
#include <cstring>
#include <stdexcept>
#include <utility>
#include <vector>

#if defined(__linux__)
#include <pthread.h>
#include <sched.h>
#endif

namespace remote_offload {

size_t CpuDuWorker::StateKeyHash::operator()(const StateKey& key) const
{
    size_t value = std::hash<uint64_t>{}(key.requestId);
    value ^= std::hash<uint64_t>{}(key.epoch) + 0x9e3779b9 +
        (value << 6) + (value >> 2);
    value ^= std::hash<uint32_t>{}(key.layerId) + 0x9e3779b9 +
        (value << 6) + (value >> 2);
    return value;
}

CpuDuWorker::CpuDuWorker(OffloadRingSlot* slots, uint32_t slotCount,
    uint8_t* payloadArena, size_t payloadArenaBytes)
    : slots_(slots), slotCount_(slotCount), payloadArena_(payloadArena),
      payloadArenaBytes_(payloadArenaBytes), ring_(slots, slotCount)
{
    if (payloadArena_ == nullptr || payloadArenaBytes_ == 0) {
        throw std::invalid_argument("CPU DU worker requires a payload arena");
    }
}

CpuDuWorker::~CpuDuWorker()
{
    Stop();
}

void CpuDuWorker::RegisterState(uint64_t requestId, uint64_t epoch,
    uint32_t layerId, const CpuDuSnapshot& snapshot)
{
    auto state = std::make_unique<CpuDuState>(
        snapshot.cacheBudget, snapshot.tokenToSlot, snapshot.generation);
    const StateKey key{requestId, epoch, layerId};
    std::lock_guard<std::mutex> lock(statesMutex_);
    states_[key] = std::move(state);
}

CpuDuSnapshot CpuDuWorker::SnapshotState(uint64_t requestId, uint64_t epoch,
    uint32_t layerId) const
{
    const StateKey key{requestId, epoch, layerId};
    std::lock_guard<std::mutex> lock(statesMutex_);
    const auto found = states_.find(key);
    if (found == states_.end()) {
        throw std::out_of_range("CPU DU worker state is not registered");
    }
    return found->second->Snapshot();
}

bool CpuDuWorker::RemoveState(uint64_t requestId, uint64_t epoch,
    uint32_t layerId)
{
    const StateKey key{requestId, epoch, layerId};
    std::lock_guard<std::mutex> lock(statesMutex_);
    return states_.erase(key) != 0;
}

void CpuDuWorker::Start(int cpu)
{
    bool expected = false;
    if (!running_.compare_exchange_strong(expected, true)) {
        throw std::logic_error("CPU DU worker is already running");
    }
    thread_ = std::thread(&CpuDuWorker::Run, this, cpu);
}

void CpuDuWorker::Stop()
{
    if (!running_.exchange(false)) {
        return;
    }
    if (thread_.joinable()) {
        thread_.join();
    }
}

bool CpuDuWorker::ValidateRange(uint64_t offset, size_t bytes) const
{
    return offset <= payloadArenaBytes_ &&
        bytes <= payloadArenaBytes_ - static_cast<size_t>(offset);
}

void CpuDuWorker::Run(int cpu)
{
#if defined(__linux__)
    if (cpu >= 0) {
        cpu_set_t cpus;
        CPU_ZERO(&cpus);
        CPU_SET(cpu, &cpus);
        (void)pthread_setaffinity_np(pthread_self(), sizeof(cpus), &cpus);
    }
#else
    (void)cpu;
#endif
    while (running_.load(std::memory_order_acquire)) {
        bool progressed = false;
        for (uint32_t index = 0; index < slotCount_; ++index) {
            const uint32_t state = __atomic_load_n(
                &slots_[index].state, __ATOMIC_ACQUIRE);
            if (state != static_cast<uint32_t>(OffloadSlotState::kLiReady)) {
                continue;
            }
            const uint64_t generation = __atomic_load_n(
                &slots_[index].generation, __ATOMIC_ACQUIRE);
            if (generation == 0 || !ring_.TryTransition(generation,
                    OffloadSlotState::kLiReady,
                    OffloadSlotState::kCpuDuRunning)) {
                continue;
            }
            Process(index, generation);
            progressed = true;
        }
        if (!progressed) {
            std::this_thread::yield();
        }
    }
}

void CpuDuWorker::Process(uint32_t index, uint64_t generation)
{
    OffloadRingSlot& slot = slots_[index];
    if (!ValidateRange(slot.liPayloadOffset, sizeof(OffloadLiPayload)) ||
        !ValidateRange(slot.duPayloadOffset, sizeof(OffloadDuPayload)) ||
        slot.queryCount == 0 || slot.queryCount > kMaxMtpQueries) {
        (void)ring_.TryTransition(generation,
            OffloadSlotState::kCpuDuRunning, OffloadSlotState::kError,
            OffloadStatus::kInvalidArgument);
        return;
    }
    auto* input = reinterpret_cast<const OffloadLiPayload*>(
        payloadArena_ + slot.liPayloadOffset);
    auto* output = reinterpret_cast<OffloadDuPayload*>(
        payloadArena_ + slot.duPayloadOffset);
    std::vector<std::vector<int32_t>> rows(slot.queryCount);
    for (uint32_t row = 0; row < slot.queryCount; ++row) {
        rows[row].assign(input->topk[row], input->topk[row] + kSparseCount);
    }

    try {
        const StateKey key{slot.requestId, slot.epoch, slot.layerId};
        std::lock_guard<std::mutex> lock(statesMutex_);
        const auto found = states_.find(key);
        if (found == states_.end()) {
            throw std::out_of_range("request state is not registered");
        }
        const CpuDuResult result = found->second->Update(
            rows, static_cast<int32_t>(slot.candidateLength),
            DuOutputOrder::kHitsThenMisses);
        std::memset(output, 0xff, sizeof(*output));
        for (uint32_t row = 0; row < slot.queryCount; ++row) {
            std::memcpy(output->sourceIds[row], result.sourceIds[row].data(),
                kSparseCount * sizeof(int32_t));
            std::memcpy(output->destinationSlots[row],
                result.destinationSlots[row].data(),
                kSparseCount * sizeof(int32_t));
            std::memcpy(output->sourceRefs[row], result.sourceRefs[row].data(),
                kSparseCount * sizeof(int32_t));
            std::memcpy(output->unionOrdinals[row],
                result.unionOrdinals[row].data(),
                kSparseCount * sizeof(int32_t));
            output->missCounts[row] = result.missCounts[row];
        }
        const size_t unique = result.uniqueMissSourceIds.size();
        std::copy(result.uniqueMissSourceIds.begin(),
            result.uniqueMissSourceIds.end(), output->uniqueMissSourceIds);
        std::copy(result.uniqueMissDestinationSlots.begin(),
            result.uniqueMissDestinationSlots.end(),
            output->uniqueMissDestinationSlots);
        std::copy(result.evictedSourceIds.begin(),
            result.evictedSourceIds.end(), output->evictedSourceIds);
        std::copy(result.uniqueMissQueryMasks.begin(),
            result.uniqueMissQueryMasks.end(),
            output->uniqueMissQueryMasks);
        const size_t unionHits = result.unionHitSourceIds.size();
        std::copy(result.unionHitSourceIds.begin(),
            result.unionHitSourceIds.end(), output->unionHitSourceIds);
        std::copy(result.unionHitSlots.begin(),
            result.unionHitSlots.end(), output->unionHitSlots);
        std::copy(result.unionHitRefCounts.begin(),
            result.unionHitRefCounts.end(), output->unionHitRefCounts);
        std::copy(result.unionHitQueryMasks.begin(),
            result.unionHitQueryMasks.end(), output->unionHitQueryMasks);
        output->unionHitCount = static_cast<uint32_t>(unionHits);
        slot.uniqueMissCount = static_cast<uint32_t>(unique);
        slot.duGeneration = result.generation;
    } catch (...) {
        (void)ring_.TryTransition(generation,
            OffloadSlotState::kCpuDuRunning, OffloadSlotState::kError,
            OffloadStatus::kDuFailed);
        return;
    }
    (void)ring_.TryTransition(generation,
        OffloadSlotState::kCpuDuRunning, OffloadSlotState::kDuReady);
}

}  // namespace remote_offload
