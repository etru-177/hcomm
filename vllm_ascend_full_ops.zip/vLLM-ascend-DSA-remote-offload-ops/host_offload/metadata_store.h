// SPDX-License-Identifier: Apache-2.0
#pragma once

#include "cpu_du.h"

#include <cstdint>
#include <mutex>
#include <optional>
#include <unordered_map>
#include <vector>

namespace remote_offload {

enum class PutPayloadKind {
    kFullBlock,
    kTail,
};

struct TokenSlotDelta {
    int32_t tokenId;
    int32_t slot;

    bool operator==(const TokenSlotDelta& other) const
    {
        return tokenId == other.tokenId && slot == other.slot;
    }
};

struct LayerOffloadMetadata {
    uint32_t layerId{0};
    PutPayloadKind payloadKind{PutPayloadKind::kFullBlock};
    uint64_t logicalLength{0};
    uint32_t tailValidLength{0};
    std::vector<uint64_t> remoteBlockTable;
    std::vector<TokenSlotDelta> tokenSlotDeltas;
    CpuDuSnapshot duSnapshot;
    bool payloadComplete{false};
};

struct RequestOffloadMetadata {
    uint64_t requestId{0};
    uint64_t epoch{0};
    uint64_t generation{0};
    uint32_t expectedLayers{0};
    std::unordered_map<uint32_t, LayerOffloadMetadata> layers;
};

class RemoteMetadataStore {
public:
    bool Begin(uint64_t requestId, uint64_t epoch, uint64_t generation,
        uint32_t expectedLayers);
    bool RecordPayload(uint64_t requestId, uint64_t epoch,
        uint64_t generation, LayerOffloadMetadata metadata);
    bool Commit(uint64_t requestId, uint64_t epoch, uint64_t generation);
    bool Abort(uint64_t requestId, uint64_t epoch, uint64_t generation);
    std::optional<RequestOffloadMetadata> GetCommitted(
        uint64_t requestId) const;

private:
    static bool SameTransaction(const RequestOffloadMetadata& metadata,
        uint64_t epoch, uint64_t generation);

    mutable std::mutex mutex_;
    std::unordered_map<uint64_t, RequestOffloadMetadata> pending_;
    std::unordered_map<uint64_t, RequestOffloadMetadata> committed_;
};

}  // namespace remote_offload
