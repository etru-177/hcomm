// SPDX-License-Identifier: Apache-2.0

#include "metadata_store.h"

#include <unordered_set>
#include <utility>

namespace remote_offload {
namespace {

bool SameSnapshot(const CpuDuSnapshot& left, const CpuDuSnapshot& right)
{
    return left.version == right.version &&
        left.generation == right.generation &&
        left.cacheBudget == right.cacheBudget &&
        left.tokenToSlot == right.tokenToSlot;
}

bool SameLayer(const LayerOffloadMetadata& left,
    const LayerOffloadMetadata& right)
{
    return left.layerId == right.layerId &&
        left.payloadKind == right.payloadKind &&
        left.logicalLength == right.logicalLength &&
        left.tailValidLength == right.tailValidLength &&
        left.remoteBlockTable == right.remoteBlockTable &&
        left.tokenSlotDeltas == right.tokenSlotDeltas &&
        SameSnapshot(left.duSnapshot, right.duSnapshot) &&
        left.payloadComplete == right.payloadComplete;
}

bool ValidLayer(const LayerOffloadMetadata& metadata)
{
    if (!metadata.payloadComplete || metadata.logicalLength == 0 ||
        metadata.remoteBlockTable.empty() ||
        metadata.duSnapshot.version != kCpuDuSnapshotVersion) {
        return false;
    }
    try {
        CpuDuState state(metadata.duSnapshot.cacheBudget,
            metadata.duSnapshot.tokenToSlot,
            metadata.duSnapshot.generation);
        (void)state;
    } catch (...) {
        return false;
    }
    std::unordered_set<int32_t> changedTokens;
    changedTokens.reserve(metadata.tokenSlotDeltas.size());
    for (const TokenSlotDelta& delta : metadata.tokenSlotDeltas) {
        if (delta.tokenId < 0 || delta.slot < 0 ||
            delta.slot >= metadata.duSnapshot.cacheBudget ||
            static_cast<size_t>(delta.tokenId) >=
                metadata.duSnapshot.tokenToSlot.size() ||
            metadata.duSnapshot.tokenToSlot[
                static_cast<size_t>(delta.tokenId)] != delta.slot ||
            !changedTokens.insert(delta.tokenId).second) {
            return false;
        }
    }
    return true;
}

}  // namespace

bool RemoteMetadataStore::SameTransaction(
    const RequestOffloadMetadata& metadata, uint64_t epoch,
    uint64_t generation)
{
    return metadata.epoch == epoch && metadata.generation == generation;
}

bool RemoteMetadataStore::Begin(uint64_t requestId, uint64_t epoch,
    uint64_t generation, uint32_t expectedLayers)
{
    if (requestId == 0 || epoch == 0 || generation == 0 ||
        expectedLayers == 0) {
        return false;
    }
    std::lock_guard<std::mutex> lock(mutex_);
    const auto committed = committed_.find(requestId);
    if (committed != committed_.end()) {
        if (SameTransaction(committed->second, epoch, generation)) {
            return committed->second.expectedLayers == expectedLayers;
        }
        if (epoch < committed->second.epoch ||
            (epoch == committed->second.epoch &&
             generation <= committed->second.generation)) {
            return false;
        }
    }
    const auto pending = pending_.find(requestId);
    if (pending != pending_.end()) {
        return SameTransaction(pending->second, epoch, generation) &&
            pending->second.expectedLayers == expectedLayers;
    }
    pending_.emplace(requestId, RequestOffloadMetadata{
        requestId, epoch, generation, expectedLayers, {}});
    return true;
}

bool RemoteMetadataStore::RecordPayload(uint64_t requestId, uint64_t epoch,
    uint64_t generation, LayerOffloadMetadata metadata)
{
    if (!ValidLayer(metadata)) {
        return false;
    }
    if ((metadata.payloadKind == PutPayloadKind::kFullBlock &&
         (metadata.tailValidLength != 0 ||
          metadata.logicalLength % 128 != 0)) ||
        (metadata.payloadKind == PutPayloadKind::kTail &&
         (metadata.tailValidLength == 0 ||
          metadata.tailValidLength > 127 ||
          metadata.logicalLength % 128 != metadata.tailValidLength))) {
        return false;
    }
    std::lock_guard<std::mutex> lock(mutex_);
    const auto pending = pending_.find(requestId);
    if (pending == pending_.end() ||
        !SameTransaction(pending->second, epoch, generation)) {
        return false;
    }
    if (pending->second.layers.size() >= pending->second.expectedLayers &&
        pending->second.layers.find(metadata.layerId) ==
            pending->second.layers.end()) {
        return false;
    }
    if (!pending->second.layers.empty() &&
        pending->second.layers.begin()->second.logicalLength !=
            metadata.logicalLength) {
        return false;
    }
    const auto existing = pending->second.layers.find(metadata.layerId);
    if (existing != pending->second.layers.end()) {
        return SameLayer(existing->second, metadata);
    }
    pending->second.layers.emplace(metadata.layerId, std::move(metadata));
    return true;
}

bool RemoteMetadataStore::Commit(uint64_t requestId, uint64_t epoch,
    uint64_t generation)
{
    std::lock_guard<std::mutex> lock(mutex_);
    const auto committed = committed_.find(requestId);
    if (committed != committed_.end() &&
        SameTransaction(committed->second, epoch, generation)) {
        return true;
    }
    const auto pending = pending_.find(requestId);
    if (pending == pending_.end() ||
        !SameTransaction(pending->second, epoch, generation) ||
        pending->second.layers.size() != pending->second.expectedLayers) {
        return false;
    }
    for (const auto& layer : pending->second.layers) {
        if (!layer.second.payloadComplete) {
            return false;
        }
    }
    committed_[requestId] = pending->second;
    pending_.erase(pending);
    return true;
}

bool RemoteMetadataStore::Abort(uint64_t requestId, uint64_t epoch,
    uint64_t generation)
{
    std::lock_guard<std::mutex> lock(mutex_);
    const auto pending = pending_.find(requestId);
    if (pending == pending_.end() ||
        !SameTransaction(pending->second, epoch, generation)) {
        return false;
    }
    pending_.erase(pending);
    return true;
}

std::optional<RequestOffloadMetadata> RemoteMetadataStore::GetCommitted(
    uint64_t requestId) const
{
    std::lock_guard<std::mutex> lock(mutex_);
    const auto found = committed_.find(requestId);
    if (found == committed_.end()) {
        return std::nullopt;
    }
    return found->second;
}

}  // namespace remote_offload
