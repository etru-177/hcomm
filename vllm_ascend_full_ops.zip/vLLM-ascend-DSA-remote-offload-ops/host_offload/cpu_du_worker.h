// SPDX-License-Identifier: Apache-2.0
#pragma once

#include "cpu_du.h"
#include "offload_ring.h"

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <mutex>
#include <thread>
#include <unordered_map>

namespace remote_offload {

constexpr int32_t kMtpUnionCapacity = kSparseCount * kMaxMtpQueries;

struct OffloadLiPayload {
    int32_t topk[kMaxMtpQueries][kSparseCount];
};

struct OffloadDuPayload {
    int32_t sourceIds[kMaxMtpQueries][kSparseCount];
    int32_t destinationSlots[kMaxMtpQueries][kSparseCount];
    int32_t sourceRefs[kMaxMtpQueries][kSparseCount];
    int32_t missCounts[kMaxMtpQueries];
    int32_t uniqueMissSourceIds[kMtpUnionCapacity];
    int32_t uniqueMissDestinationSlots[kMtpUnionCapacity];
    int32_t evictedSourceIds[kMtpUnionCapacity];
    int32_t uniqueMissQueryMasks[kMtpUnionCapacity];
    int32_t unionOrdinals[kMaxMtpQueries][kSparseCount];
    int32_t unionHitSourceIds[kMtpUnionCapacity];
    int32_t unionHitSlots[kMtpUnionCapacity];
    int32_t unionHitRefCounts[kMtpUnionCapacity];
    int32_t unionHitQueryMasks[kMtpUnionCapacity];
    uint32_t unionHitCount;
};

class CpuDuWorker {
public:
    CpuDuWorker(OffloadRingSlot* slots, uint32_t slotCount,
        uint8_t* payloadArena, size_t payloadArenaBytes);
    ~CpuDuWorker();

    CpuDuWorker(const CpuDuWorker&) = delete;
    CpuDuWorker& operator=(const CpuDuWorker&) = delete;

    void RegisterState(uint64_t requestId, uint64_t epoch, uint32_t layerId,
        const CpuDuSnapshot& snapshot);
    CpuDuSnapshot SnapshotState(
        uint64_t requestId, uint64_t epoch, uint32_t layerId) const;
    bool RemoveState(uint64_t requestId, uint64_t epoch, uint32_t layerId);

    void Start(int cpu = -1);
    void Stop();

private:
    struct StateKey {
        uint64_t requestId;
        uint64_t epoch;
        uint32_t layerId;

        bool operator==(const StateKey& other) const
        {
            return requestId == other.requestId && epoch == other.epoch &&
                layerId == other.layerId;
        }
    };

    struct StateKeyHash {
        size_t operator()(const StateKey& key) const;
    };

    bool ValidateRange(uint64_t offset, size_t bytes) const;
    void Run(int cpu);
    void Process(uint32_t index, uint64_t generation);

    OffloadRingSlot* slots_;
    uint32_t slotCount_;
    uint8_t* payloadArena_;
    size_t payloadArenaBytes_;
    OffloadRingView ring_;
    mutable std::mutex statesMutex_;
    std::unordered_map<StateKey, std::unique_ptr<CpuDuState>, StateKeyHash>
        states_;
    std::atomic<bool> running_{false};
    std::thread thread_;
};

}  // namespace remote_offload
