// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <cstddef>
#include <cstdint>

namespace remote_offload {

constexpr uint32_t kOffloadRingMagic = 0x52464f31;  // "RFO1"
constexpr uint32_t kOffloadRingVersion = 1;
constexpr uint32_t kDefaultOffloadRingSlots = 64;

enum class OffloadSlotState : uint32_t {
    kFree = 0,
    kNpuLiWriting = 1,
    kLiReady = 2,
    kCpuDuRunning = 3,
    kDuReady = 4,
    kCommandSubmitted = 5,
    kDataReady = 6,
    kError = 7,
};

enum class OffloadStatus : uint32_t {
    kOk = 0,
    kInvalidArgument = 1,
    kStaleGeneration = 2,
    kRingFull = 3,
    kDuFailed = 4,
    kCommandFailed = 5,
    kPoolFailed = 6,
    kTimeout = 7,
};

// Only offsets are put in the header. The registered LI/DU/command payload
// arenas are allocated once beside the headers, so graph replay never changes
// an address.
struct alignas(64) OffloadRingSlot {
    uint32_t magic;
    uint32_t version;
    uint64_t generation;
    uint32_t state;
    uint32_t status;
    uint64_t requestId;
    uint64_t epoch;
    uint32_t layerId;
    uint32_t queryCount;
    uint32_t candidateLength;
    uint32_t uniqueMissCount;
    uint64_t liPayloadOffset;
    uint64_t duPayloadOffset;
    uint64_t commandOffset;
    uint64_t completionOffset;
    uint64_t duGeneration;
    uint8_t reserved[32];
};

static_assert(sizeof(OffloadRingSlot) == 128);

struct OffloadSlotMetadata {
    uint64_t requestId{0};
    uint64_t epoch{0};
    uint32_t layerId{0};
    uint32_t queryCount{0};
    uint32_t candidateLength{0};
    uint64_t liPayloadOffset{0};
    uint64_t duPayloadOffset{0};
    uint64_t commandOffset{0};
    uint64_t completionOffset{0};
};

class OffloadRingView {
public:
    OffloadRingView(OffloadRingSlot* slots, uint32_t slotCount);

    void Initialize();
    bool TryAcquire(uint64_t generation, const OffloadSlotMetadata& metadata,
        uint32_t* slotIndex);
    bool TryTransition(uint64_t generation, OffloadSlotState expected,
        OffloadSlotState desired, OffloadStatus status = OffloadStatus::kOk);
    bool Release(uint64_t generation);
    const OffloadRingSlot* Find(uint64_t generation) const;

    uint32_t slot_count() const { return slotCount_; }

private:
    uint32_t Index(uint64_t generation) const;

    OffloadRingSlot* slots_;
    uint32_t slotCount_;
};

}  // namespace remote_offload
