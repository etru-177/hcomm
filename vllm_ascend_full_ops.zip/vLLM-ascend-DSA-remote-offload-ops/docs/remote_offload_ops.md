# Remote Offload 算子与协议说明

## 1. 文档目的

本文说明 `remote-offload-ops` 分支中的远端 KV 卸载原型，包括 CPU DU、
固定地址通信环、内存池协议、单算子测试和后续性能准入。文档只把已经合入当前
分支的能力写成“已实现”；需要 A5、MTE 或内存池配合的部分会明确标为“待接入”。

当前代码基线如下：

- `remote-offload`：修改前的 hotfix 基线，指向 `37742f448`；
- `remote-offload-ops`：本功能的开发分支；
- `high-bw-baseline`：历史 URMA 高带宽基线。

## 2. 术语

| 缩写 | 含义 |
|---|---|
| LI | Lightning Indexer，产生每路 query 的 TopK token ID |
| DU | Dynamic Update，根据 TopK 更新 token 到 HBM slot 的映射 |
| LIDU | LI 与 DU 组成的索引及缓存更新链路 |
| MTP3 | Multi-Token Prediction，3 个 draft 加 1 个 root；固定 `query_count=4` |
| MTE | NPU 与 Host 之间的内存搬运引擎 |
| WQE/CQE | URMA 工作请求/完成队列项 |
| generation | 环槽位和数据完成状态的单调递增代次 |
| owner | 某个唯一 miss 首次出现的位置，负责将 staging 数据写入持久 HBM slot |

## 3. 四种执行路径

阶段 1 固定使用 656B packed C8、MTP3、Top-2048 和 256 个 dense tail token：

| 模式 | 执行链 | 当前实现 |
|---|---|---|
| `no_offload` | A5 C8 MTP LIDU（0 miss）→ 普通 MTP3 SFA | HBM resident 基线 |
| `lidu_aicpu_poll_aiv` | A5 C8 MTP LIDU → AICPU 下发并等待 IO → AIV scatter → SFA | 已实现 |
| `lidu_aicpu_defer_aiv_poll` | A5 C8 MTP LIDU → AICPU 只下发 IO → AIV poll/scatter → SFA | 已实现原型 |
| `li_cpu_du_implicit_dba` | 官方 A5 C8 MTP3 LI → swapped-memory polling → 32 线程 CPU DU → 两组 AICPU IO/AIV scatter → SFA | 已实现隐式 DBA 原型 |

所有 AICPU IO 路径都强制 `host_token_gather=true`、
`scatter_after_gather=false`。AICPU 只负责命令组织、提交和可选 completion polling，
绝不执行 staging 到 packed HBM 的 scatter。后者统一由
`ScatterIoFromStagingC8` AIV 算子完成。

`lidu_aicpu_defer_aiv_poll` 当前把 completion polling 放进独立 AIV scatter，随后再
启动普通 SFA。它用于验证异步语义和流水空间；真正把 polling、source-aware copy
与 SFA 流水合成一个 C8 CopySFA kernel 是下一阶段工作，当前结果不能标记为
`copy_sfa_fused=1`。

前面三条 NPU LIDU 路径使用 `ops_a5@2802bdd` 的性能优化版 A5 C8 MTP3 算子。
隐式 DBA 路径使用同一套 FP8 E4M3 输入和官方 A5 C8 LightningIndexer；
caller-owned `_out` adapter 只替换输出地址，不替换 ACLNN kernel。LI 始终以 BS=32
一次 launch 写入预注册的 swapped-memory TopK ring，不修改 LI tiling，也不显式拆
micro-batch。32 个常驻 CPU worker 各自轮询一个 request 的四路 TopK，完成 DU 后
直接写预分配 swapped-memory metadata。该路径没有逐轮 `.cpu()` D2H、`.to(device)`
H2D 或 Python wait，因此不会用 Host 中转复制绕过 MemFabric/UB.mem 地址语义。

### 3.1 当前同步与断图边界

`li_cpu_du_implicit_dba` 的热循环没有逐轮 Host synchronize、Host Event wait、D2H
或 H2D tensor copy。TopK、DU 输出和 ready flag 都是注册期固定的 swapped-memory
地址；CPU 以 `-1 → token ID` 识别四路 LI 输出完成，以 release store 发布两个 IO
group 的 ready flag。IO stream 上顺序执行
`Hcomm[0] → AIV scatter[0] → Hcomm[1] → AIV scatter[1]`，主 stream 只提交一次
LI，并在全 batch SFA 前等待一个设备 Event。该 Event 是 NPU stream 依赖，不会让
Host 等待。

当前 workload 尚未执行 NPUGraph capture；Hcomm completion slot 仍由 Python runtime
逐轮获取，因此矩阵仍记录 `graph_safe=0`。循环结束后的单次
`torch_npu.npu.synchronize()` 只用于整体校验，不属于单迭代链路。运行期不设置超时、
poison 恢复或失败降级：输入和地址在注册时完整校验，注册后若固定协议不变量被破坏，
进程直接终止，避免把恢复逻辑混入性能热路径。

## 4. CPU DU

### 4.1 输入状态

`host_offload/cpu_du.h` 提供 `CpuDuState`。每个 request/layer 保有一份状态：

- `cacheBudget`：可用 HBM slot 数，至少为 2048；
- `tokenToSlot`：候选 token 到 slot 的映射，未驻留项为 `-1`；
- `generation`：最后一次成功更新的代次；
- `topkRows`：1～4 路 query，每路固定 2048 个不重复 token ID。

PyTorch 扩展导出同一实现的 Host 接口：

```python
outputs = cpu_lidu_du_update(
    topk_indices,       # CPU int32[Q,2048] 或 [Q,1,2048]
    token_to_slot,      # CPU int32[source_capacity]，成功时原地更新
    cache_budget,
    candidate_length,
    generation=0,
    hits_first=True,
)
```

该接口返回 source IDs、destination slots、source refs、每路 miss counts、唯一 miss
source/destination、victim、原状态 alias 和下一 generation。它是 MTE worker 接入前
的同步 Host ABI，失败时不会改写调用方状态。

### 4.2 更新算法

更新遵循确定性顺序：

1. 按 packed query 顺序构造稳定 union；
2. 使用更新前的状态判定每路 hit/miss；
3. union 中首次出现的 miss 成为唯一 IO；
4. 保护 union 中全部 hit 所占的 slot；
5. 先按 slot ID 使用尚未占用的空闲 slot，再按 token ID 从小到大扫描未保护
   victim；
6. 在状态副本上完成全部更新，成功后一次性提交。

如果 victim 不足、输入越界或 TopK 内有重复 token，本次更新失败且原状态和
generation 均保持不变。

### 4.3 输出

`CpuDuResult` 包含：

- 每路 `sourceIds`、`destinationSlots` 和 `sourceRefs`；
- 每路 miss 数；
- request 级唯一 miss source/destination；
- 被淘汰 token ID；
- 稳定 first-occurrence 顺序的 union hit ID、HBM slot、引用计数和 query mask；
- 每个 union miss 的 query mask；
- 每路按最终 `[hits][misses]` 顺序排列的 union ordinal；
- 提交后的 generation。

union ordinal 的布局固定为 `[union hits][union misses]`。union hit 的引用计数大于
1 表示 shared hit，等于 1 表示 private hit；union miss 继续复用唯一 miss ordinal。
现有同步 ABI `cpu_lidu_du_update` 仍只返回原有 9 项；新增接口
`cpu_lidu_du_update_union` 在前 9 项之后依次返回
`union_ordinals/union_hit_source_ids/union_hit_slots/union_hit_ref_counts/`
`union_hit_query_masks/union_miss_query_masks`。常驻 worker 的 `wait_du` 仍返回原有
8 项；`wait_du_union` 才在其后追加这六项。query mask 的低四位分别对应四路 MTP
query，SFA 可以直接据此决定一个 union KV tile 需要更新哪些 query，旧调用者不受
返回数量变化影响。

这些元数据为 union-aware SFA 提供输入，但 CPU DU 本身不会改变 attention 数学量。
SFA 后续应按 union token tile 驱动，在片上保留 shared hit/union miss KV，并依据
query mask 更新对应 query；private hit 仍直接读取 HBM。不能简单增加一个独立算子
把 union KV 写到 HBM workspace，否则写一次再按 query 读取可能比当前流量更大。
不同 query 即使引用同一个 KV，仍需分别执行 QK/PV，因此该优化减少的是重复 KV
加载和离散 gather，不会减少 attention FLOPs。

CopySFA 默认使用 `[hits][misses]` 排列。hit 的 `sourceRef` 是 HBM slot；miss 的
`sourceRef` 是 request-local staging ordinal。唯一 miss 的首次出现位置设置 bit 30
作为 owner，其余 MTP query 复用同一 staging ordinal。兼容当前 NPU LIDU 测试时，
可选择 `[misses][hits]` 输出顺序。

### 4.4 快照与恢复

`Snapshot()` 保存版本、generation、cache budget 和完整 token-to-slot 状态；
`Restore()` 先验证版本、slot 范围和唯一性，再原子替换当前状态。失败的恢复不会
破坏原状态。

### 4.5 批量常驻线程性能接口

`CpuDuBatchWorkerRuntime` 为矩阵提供低额外开销路径：构造时创建线程，
`register_states()` 一次性校验并保存全部 request 模板，`run()` 只发布一个批量任务。
worker 按 batch row 静态分片，输出复用同一块扁平 int32 buffer。示例：

```python
worker = CpuDuBatchWorkerRuntime(thread_count=32, first_cpu=-1)
worker.register_states(initial_states, cache_budgets,
                       candidate_lengths, query_counts)
packed_metadata = worker.run(topk_cpu, generation=1, hits_first=True)
```

BS=32 在语义上仍是 32 份相互独立的 DU 状态更新，但热路径只有一次 Python/C++
`run()` 调用。常驻线程按 request 静态分片；线程数为 32 时，每个线程通常处理一个
request。不要用同步 ABI 循环调用 32 次的结果代表当前矩阵路径。

`first_cpu>=0` 时在 Linux 上依次绑定线程；应选择 LI/URMA poll/gather 线程未占用且
同 NUMA 的 CPU。该接口消除了每轮 32 次 Python 调用、逐 request tensor clone 和
线程创建；它本身仍接收/返回普通 CPU tensor，若直接和 NPU LI 串接仍需要显式
D2H/H2D，因此端到端矩阵改用下一节的 swapped-memory runtime。

### 4.6 隐式 DBA swapped-memory 接口

`SwappedCpuDuImplicitDbaRuntime` 是端到端矩阵使用的异步接口。其固定约束为 BS=32、
MTP3/query=4、TopK=2048、cache budget=8192、32 个常驻 worker，以及每 16 个 request
发布一个 IO ready flag。注册接口一次性接收所有 generation 的 TopK ring、初始状态、
legacy DU 输出、union hit/miss 输出和 `[generation,2]` ready flags：

```python
runtime = SwappedCpuDuImplicitDbaRuntime(first_cpu=-1)
runtime.register_pipeline(
    topk_ring=topk_ring,
    initial_states=initial_states,
    cache_budgets=cache_budgets,
    candidate_lengths=candidate_lengths,
    source_ids=source_ids,
    attention_slots=attention_slots,
    source_refs=source_refs,
    query_miss_counts=query_miss_counts,
    hcomm_sources=hcomm_sources,
    hcomm_destinations=hcomm_destinations,
    hcomm_counts=hcomm_counts,
    evicted_source_ids=evicted_source_ids,
    union_miss_masks=union_miss_masks,
    union_hit_source_ids=union_hit_source_ids,
    union_hit_slots=union_hit_slots,
    union_hit_ref_counts=union_hit_ref_counts,
    union_hit_masks=union_hit_masks,
    union_hit_counts=union_hit_counts,
    union_ordinals=union_ordinals,
    ready_flags=ready_flags,
)
runtime.start()
```

每个 worker 只处理同一个 request 的全部 generation。四路 TopK 均完成后，它一次性
计算 legacy `[hits][misses]`、owner/source refs、union common/private hit、union miss、
query mask 和 ordinal。request 0～15 全部完成后发布 group 0；request 16～31 全部
完成后发布 group 1。LI 本身不感知这个拆分，因此称为“隐式 DBA”。全部 legacy 与
union 输出均保留；每个 request 的 miss/victim 映射最后一次性提交回对应 generation
的 `initial_states`，后续 CopySFA 可以在接口稳定后直接消费 union 元数据。

`profile_records()` 在所有 worker 完成后返回 request polling/DU 时间和两个 group 的
ready 时间。矩阵输出 `cpu_topk_poll_wait_p50_us`、`cpu_du_request_p50_us` 和
`io_group1_minus_group0_ready_p50_us`；最后一项为 group 1 减 group 0，正值表示前 16
个 request 更早完成。它们只用于诊断 CPU 调度与两组完成偏斜，不参与设备端准入
计时。

## 5. 固定地址 generation ring

`host_offload/offload_ring.h` 定义 128B 对齐槽位。默认规划 64 个槽位，明显大于
当前 raw URMA 的 8 个命令槽，避免命令发布成为瓶颈。payload 使用预分配 arena，
槽位只保存固定 offset，因此后续可以用于图重放。

`host_offload/cpu_du_worker.h` 提供常驻 C++ worker。状态按
`request_id + epoch + layer_id` 隔离，支持注册、快照和删除；worker 轮询
`LI_READY`，可绑到指定 CPU 上执行 DU，并发布 `DU_READY`。LI 和 DU payload 都是
固定大小结构，四路 TopK、三组 source/destination/ref 和最大 8192 个 union miss
不会在热路径动态改变地址。线程可以通过 `Start(cpu)` 固定到指定 CPU。

状态机如下：

```text
FREE
  -> NPU_LI_WRITING
  -> LI_READY
  -> CPU_DU_RUNNING
  -> DU_READY
  -> COMMAND_SUBMITTED
  -> DATA_READY
  -> FREE
```

任意执行阶段都可以进入 `ERROR`，消费方记录错误后再释放槽位。所有状态转换同时
校验 generation；环回后，旧 generation 不能操作被新请求复用的槽位。

PyTorch 扩展导出 `CpuDuWorkerRuntime`，用于在上层接入之前独立验证完整状态机：

```python
worker = CpuDuWorkerRuntime(slot_count=64, cpu=-1)
worker.register_state(request_id, epoch, layer_id, token_to_slot,
                      cache_budget, generation=0)
slot, li_address, du_address = worker.acquire(
    ring_generation, request_id, epoch, layer_id,
    query_count=4, candidate_length=token_to_slot.numel(),
)
worker.write_li(ring_generation, topk_indices)  # 或由 MTE 写 li_address
worker.publish_li(ring_generation)
du = worker.wait_du(ring_generation, timeout_ms=1000)
worker.mark_command_submitted(ring_generation)
worker.mark_data_ready(ring_generation)
worker.release(ring_generation)
```

`li_address` 和 `du_address` 在 runtime 生命周期内固定。当前 arena 是普通 Host
预分配内存；A5 集成时仍需按 MemFabric 要求完成注册/绑 NUMA，不能仅凭地址固定
就假设已经具备 MTE 零拷贝属性。

MTE 接入时使用 `smem_bm_copy_batch`：LI payload 走 `G2H`，CPU DU 输出走 `H2G`。
发布方必须先写 payload，最后以 release 语义发布状态；消费方以 acquire 语义读取。

PyTorch 扩展通过运行时加载 `libmf_smem.so` 暴露批量接口，因此普通 AICPU 构建
不新增 MemFabric 链接依赖：

```python
ret = cpu_du_mte_copy_batch(
    handle,          # smem_bm_t 的整数值
    sources,         # CPU uint64[N]
    destinations,    # CPU uint64[N]
    data_sizes,      # CPU uint64[N]
    direction=2,     # 2=G2H，3=H2G
    stream=0,
    async_copy=True,
)
ret = cpu_du_mte_wait(handle)
```

非标准安装位置通过 `MEMFABRIC_SMEM_LIB=/absolute/path/libmf_smem.so` 指定。异步
G2H 必须在发布 `LI_READY` 前 wait；异步 H2G 必须在 AICPU/Host 消费 DU payload
或提交数据命令前 wait。`DU_READY` 表示 CPU 已经写完 Host 侧结果，并不表示 H2G
已经完成。

## 6. 内存池协议

`hcomm_kernel/remote_offload_protocol.h` 定义独立的版本 1 协议，避免在原型阶段改变
现有 raw URMA GET benchmark 的字节 ABI。

操作码包括：

- `GET`：Pool 数据写入 HBM staging；
- `PUT_FULL`：拉取已经封闭的完整 KV block；
- `PUT_TAIL`：拉取当前 decode step 的 partial tail；
- `METADATA_COMMIT`：提交 request-step 元数据；
- `SNAPSHOT`：保存/恢复 DU 状态；
- `POOL_DU_PUSH`：远端 DU 原型。

Put 的数据方向为 Pool 发起 URMA READ：`sourceGva` 是 NPU HBM，`destinationGva`
是 Pool 内存。必须先完成所有层的 payload，再提交 request-step metadata。元数据
包含 request、epoch、generation、逻辑长度、tail 有效长度、block table 数量和
token-slot 增量数量。失败时上一 committed generation 仍然有效。

`host_offload/metadata_store.h` 已实现 Host 参考状态机：

- transaction 按 `request_id + epoch + generation` 标识；
- 所有预期 layer 都标记 payload complete 后才能 commit；
- 相同 transaction 的 Begin、Record 和 Commit 可以幂等重试；
- 旧 epoch/generation 被拒绝；
- Abort 只删除 pending transaction，不影响上一 committed snapshot；
- tail 有效长度限制为 1～127，且必须等于逻辑长度对 128 的余数；sealed full
  block 的逻辑长度必须按 128 对齐且 tail 有效长度为 0。

该状态机已进入无 NPU 单测；Pool 侧 URMA READ handler 尚待 A5/UMDK 环境接入。

## 7. 构建和单算子测试

无需 NPU 的 CPU DU/ring 测试：

```bash
bash test/run_cpu_du_host_test.sh
```

### 7.1 CPU DU 性能测试

`cpu_du_perf.py` 不访问 NPU、URMA 或 MemFabric，分别测试同步 Host ABI、ring
单 worker 和按 batch 并行的常驻 worker：

```bash
python test/cpu_du_perf.py \
  --modes sync,worker,batch \
  --batch-sizes 1,8,32 \
  --candidate-lengths 65536,131072,262144 \
  --misses 0,100,200,400 \
  --query-count 4 --warmup 10 --iterations 50 \
  --csv cpu_du_perf.csv
```

- `sync_union_abi` 包含 union 同步接口的状态导入/校验、DU、状态提交和输出 tensor
  构造；
- `worker_union_e2e` 包含 ring acquire、LI payload 写入与发布、常驻线程 DU、等待、结果
  tensor 构造和槽位释放，不包含测试用的状态重新注册；
- `batch_union_parallel` 在构造阶段创建线程并注册 BS 份状态，计时区只包含模板恢复、
  一次批量任务发布、按 request 并行 DU、等待和预分配输出写入；通过
  `--batch-threads`/`--batch-first-cpu` 控制线程数和连续绑核；
- `request_IOPS` 是每秒完成的 request/layer DU 数；
- `selected_token_IOPS` 是所有 MTP query 每秒处理的 TopK token 数；
- `unique_miss_IOPS` 是 DU 每秒产生的唯一远端 IO 数，不代表这些 IO 已经由 URMA
  完成。
- `potential_kv_ref_reduction_pct` 根据当前 TopK 重叠率计算
  `1-(union_hits+union_misses)/(query_count*2048)`，只表示 union-driven SFA 可复用的
  KV 引用上限，不等同于最终 kernel 加速比。

每个样本使用相同初始缓存状态，因此不同迭代具有相同 miss 数。同步/ring 模式在
计时区外恢复或注册状态；batch 模式为复现真实固定状态开销，在计时区内把已校验
模板复制回常驻状态。需要降低调度噪声时，可通过 `--main-cpu` 固定主线程，使用
`--worker-cpu` 固定 ring worker，或用 `--batch-first-cpu` 连续绑定 batch worker；
这些 CPU 应与 URMA poll/gather 线程隔离并位于合适的 NUMA node。脚本在每个 case
前打印等效复现命令，结束时再次打印纯性能汇总；CSV 只保存结构化性能字段，不保存
命令。

这个脚本只评价当前已经实现的 CPU DU，不包含 LightningIndexer 本身，也不包含
MTE/UB.mem、AICPU 命令下发或 URMA 数据传输。后续接入完整 NPU 标准 LI + CPU DU
链路时，应将这些阶段单独打点，避免把通信等待误记为 DU 计算时间。

CPU DU batch 与 C8 MTP LIDU 的统一单算子性能入口如下：

```bash
python test/run_remote_offload_operator_perf.py \
  --device npu:0 --bs 32 --query-count 4 \
  --candidate-length 131072 --cache-budget 8192 \
  --misses 100,200 --cpu-du-threads 32 \
  --cpu-du-first-cpu <起始CPU或-1> \
  --profile-root operator_msprof \
  --csv operator_perf_results.csv
```

CPU DU 只测试一次 `CpuDuBatchWorkerRuntime.run()` 覆盖整个 BS 的
`batch_union_parallel`，计时源为 Host `perf_counter`。其 `low_overlap` 输入让四路
query 的 hit 尽量不重叠，同时共享同一组 100/200 unique miss，比全共享 TopK 更接近
真实 MTP3 的 union 工作量。C8 MTP LIDU 不使用 Event；驱动通过 msprof task-time
提取 `A5FusedLiManageMtpC8`，忽略 pool restore。最终 CSV 只保留关键延迟、整数 IOPS、
线程数、计时源和状态，不保存命令。

两者不是端到端的直接速度对比：CPU DU 行不含 LI、D2H/H2D，C8 行是 NPU LI+DU
融合 kernel。它们分别回答“整批 CPU DU 是否足够快”和“融合 C8 LIDU 本身多慢”。

统一的阶段 1A 入口默认只运行 Host 用例：

```bash
python test/run_remote_offload_single_op_tests.py \
  --components host \
  --json /tmp/remote_offload_single_op.json
```

在已经启动 Mock Pool 并完成 A5 环境配置后，可以运行全部现有硬件组件：

```bash
python test/run_remote_offload_single_op_tests.py \
  --components host,cpu_du_extension,cpu_du_implicit_dba,aicpu,pool_get,copy_sfa,c8_aiv_scatter,c8_lidu,c8_mtp_lidu,c8_scatter,c8_sfa,c8_mtp_sfa \
  --json /tmp/remote_offload_single_op.json
```

脚本会先打印完整复现命令，临时构建目录退出时自动清理。测试覆盖：

- 零 miss；
- 单路 miss 与 NPU 兼容排列；
- 两路 MTP 重复 miss 和 owner；
- 四路 `0/100/200/300` miss；
- 同步 CPU DU 与 64 槽常驻 worker 扩展接口；
- victim 不足时事务回滚；
- 非法重复 slot；
- generation 正常状态机、环回和 stale generation；
- 错误状态释放；
- 协议 ABI 大小和操作码。

A5 上已有算子的基础功能测试：

```bash
python test/correctness.py --device npu:0 --dtypes bf16,fp16
```

内存池链路的最小功能测试见
[`test/urma_mock_pool/README.md`](../test/urma_mock_pool/README.md)。656B 使用专用
`ScatterIoFromStagingC8`，目标张量是 `[blocks,128,656]` 的 packed byte view。
不能把旧的 BF16 拆分 KV scatter 或 BF16 remote SFA 当作 C8 CopySFA 使用。

## 8. 功能矩阵与性能准入

阶段 1 的矩阵不再展开盘模型，只固定以下口径：

- 656B packed C8；
- BS=32，LI candidate SeqLen=128K；
- MTP3，即 3 个 draft、1 个 root、`query_count=4`；
- 每路 SFA 为 Top-2048 + dense tail 256 + causal 1/2/3/4，因此四路分别读取
  2305/2306/2307/2308 个 slot；
- 每 request 的 union miss 为 100/200；
- 1 lane / 1 jetty、Host push 100%、最大聚合率；当前硬件暂不支持 4 Jetty；
- `max_subios_per_wqe=0`、`fixed_wqe_bytes=0`，不引入 64 IO command cap；
- Pool 使用 `--pipeline-mib 2`。

矩阵的每个 case 是独立 Python 进程，会在结束时 disconnect，并在下一 case 重新
建链。Mock Pool 已支持串行 session 重建：新连接到达后先停止旧 poller、释放旧
NPU reverse resource，再导入新资源。Pool 只需启动一次；当前不支持多个 active
客户端并发。

先编译仓内 C8 LIDU/SFA 与 656B AIV completion scatter：

```bash
ENABLE_C8_MTP_OPS=1 ENABLE_LOCAL_AIV=1 \
SOC_VERSION=ascend950 bash build_and_install.sh
```

远端 Pool 推荐命令如下；`poll-cpus` 和 `gather-cpus` 需按机器 NUMA 拓扑调整：

```bash
test/urma_mock_pool/urma_mock_pool \
  --device <urma-device> --blocks 4096 --jetty-count 1 \
  --control-port 19090 --poll-threads 1 --poll-cpus <cpu> \
  --gather-threads 4 --gather-cpus <cpu,cpu,cpu,cpu> \
  --gather-kernel sve2 --pipeline-mib 2 --hold-seconds 3600
```

NPU 侧一次运行 8 个 case 的纯功能矩阵：

```bash
python test/run_remote_offload_matrix.py \
  --device-eid <32位EID> --device-phy-id 0 \
  --pool-ip <pool控制面IPv4> --control-port 19090 \
  --lanes 1 --cpu-du-threads 32 --cpu-du-first-cpu <起始CPU或-1> \
  --csv remote_offload_results.csv
```

`remote_offload_656_perf.py` 不创建 timing Event，也不调用 `elapsed_time`。普通路径在
同一 stream 保序；隐式 DBA 路径使用一个只表达 stream 依赖的 NPU Event，让主 stream
的 SFA 等待两个 IO ubatch 完成，不在 Host 上等待或计时。最终只做一次同步。纯功能
矩阵仅验证 LIDU/LI、CPU DU、AICPU IO、AIV scatter 和 SFA 的功能及 IO-only 约束；
基于 Event 的数字不能用于准入。

每个 case 执行前打印完整 `REPRODUCE_COMMAND`，紧接着打印功能状态；全部完成后再次
打印纯 case 汇总。CSV 不保存命令，仅保存关键结构与 `ok_functional` 或 `failed_*`
状态。

性能矩阵在同一驱动中启用 `--with-msprof`。每个 case 都由 msprof 运行，脚本随即
解析该 case 的 `task_time`，最后生成一份合并性能 CSV：

```bash
python test/run_remote_offload_matrix.py \
  --device-eid <32位EID> --device-phy-id 0 \
  --pool-ip <pool控制面IPv4> --control-port 19090 --lanes 1 \
  --with-msprof --profile-root remote_offload_msprof \
  --csv remote_offload_msprof_results.csv
```

`remote_offload_msprof` 下每个 case 只有一个扁平目录，目录名包含运行时间、模式和
miss 数；msprof 原始标准输出和标准错误写入该目录的 `msprof.log`，避免污染矩阵终端。
终端仍先打印可复现命令和单 case 性能，结束后再打印不含命令的性能汇总。合并 CSV
只包含关键维度、index/chain/AICPU IO/AIV scatter/SFA p50、两个 16-request ubatch 的
独立 IO/scatter p50、LI 与 IO/scatter 重叠时间、CPU DU request 时间、IOPS、有效
payload GB/s、相对同 miss `no_offload` 的 p50 比例、同步/常驻线程语义和状态，不
包含命令。
`ok_profiled` 表示 workload 和 task-time 解析均成功；该比例用于观察，不在脚本中
强制性能门槛。

任一 case 失败时脚本仍写完 CSV，最后返回非零；失败 profiling 的详细输出可查看其
`msprof.log`。

单独解析一个 msprof task-time CSV（也支持直接传入 profiling 目录）：

```bash
python test/analyze_remote_offload_msprof.py \
  task_time_20260831162142.csv \
  --mode lidu_aicpu_poll_aiv --warmup 10 --iterations 20 \
  --bs 32 --misses-per-request 100 \
  --json remote_offload_msprof_baseline.json
```

解析结果包含端到端 chain，LI/LIDU、AICPU IO、AIV scatter、SFA 设备 task，以及
`index→IO`、`IO→scatter`、`scatter→SFA` 的 task 间 gap。隐式 DBA 还从
`msprof.log` 合并 LI/IO/scatter/SFA submit、每 request CPU DU 和两组 ready 的完成
偏斜；旧 profiling 日志中的 D2H/H2D Host 字段仍能被独立解析，但当前模式不再生成，
合并矩阵 CSV 也不保留这些废弃列。CSV 中 `index_p50_us` 对融合路径表示 LIDU task，
对 CPU 路径表示独立 C8 LI task。隐式 DBA 每轮的两个 Hcomm 和两个 AIV scatter 按
IO stream 提交
顺序配对，`io_p50_us`/`aiv_scatter_p50_us` 是两组 duration 之和，ubatch0/1 另有独立
列。`ubatch_handoff_gap_p50_us` 表示 scatter0 结束到 IO1 开始的空洞，
`ubatch1_io_to_scatter_gap_p50_us` 表示 IO1 到 scatter1 的空洞；`total_gap` 已包含两者。
NPU 时间只依赖 task-time CSV，不引入 Event；`op_summary` 缺失不会阻塞。

`bridge_device_task_p50_us` 汇总 LI/LIDU 结束到首个 AICPU IO 开始之间 msprof 可见的
device task；`bridge_non_device_gap_p50_us` 是同一窗口扣除这些 task 后的剩余时间。
隐式 DBA 允许首个 IO 在完整 LI task 结束前启动，因此 gap 可以为负；此时应结合
`li_io_overlap_p50_us` 和 `li_scatter_overlap_p50_us` 判断隐式拆批是否真正形成重叠，
不能把负 gap 当作解析错误。

## 9. 输出规范

- 每条命令执行前打印可复制的等效命令；
- 运行末尾再次输出仅包含 case 状态的汇总；
- CSV 不写命令，只写关键结构、性能、CPU DU 并行与同步语义和状态；
- 单算子功能结果使用 JUnit/JSON，详细阶段打点使用诊断 JSON；
- 所有新增说明文档使用中文，代码符号、协议字段和日志原文保留英文并给出中文解释。

## 10. 当前限制

- 当前已经实现 CPU DU、批量常驻线程、MTP union/owner、快照、generation ring、
  A5 C8 MTP LIDU、官方 C8 LI 调用、656B AICPU IO-only 路径和 packed C8 AIV
  scatter；标准化融合 LIM 源码仅支持 910B/910_93；
- 隐式 DBA 已移除逐轮 `.cpu()`/`.to(device)` 和 Host wait，但尚未完成 NPUGraph
  capture；Hcomm completion 获取仍需改成可重放的固定地址机制；
- C8 CopySFA 真融合、MTE 注册/绑 NUMA 内存、Host 命令提交和 Pool Put handler
  尚待接入 A5 环境；
- `pool_du_push` 只定义协议，不参与第一阶段 1% 性能准入；
- 现有 raw Pool 控制连接使用普通 Host TCP，仅用于资源交换，不传输 KV payload；
- Host、Hcomm device kernel 和 OPP 必须使用匹配构建，避免描述符 ABI 不一致。
