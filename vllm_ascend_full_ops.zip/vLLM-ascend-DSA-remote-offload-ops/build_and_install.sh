#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ASCENDC_DIR="${ROOT}/csrc"
TORCH_EXTENSION_DIR="${ROOT}/torch_extension"
ENV_FILE="${ROOT}/.kvcache_scatter_copy_env"

RAW_SOC="${SOC_VERSION:-ascend910_9391}"
RAW_SOC_LOWER="${RAW_SOC,,}"
BUILD_JOBS="${BUILD_JOBS:-$(nproc)}"
OP_NAME="${KVCACHE_SCATTER_COPY_OP_NAME:-ALL}"
CLEAN_ASCENDC_BUILD="${CLEAN_ASCENDC_BUILD:-1}"
USER_CMAKE_ARGS="${KVCACHE_EXTRA_CMAKE_ARGS:-}"

case "${RAW_SOC_LOWER}" in
  ascend910_9391)
    SOC="ascend910_93"
    DEFAULT_ENABLE_LOCAL_AIV=0
    DEFAULT_ENABLE_C8_MTP_OPS=0
    DEFAULT_ENABLE_STANDARD_LIM=0
    ;;
  ascend910b1)
    SOC="ascend910b"
    DEFAULT_ENABLE_LOCAL_AIV=0
    DEFAULT_ENABLE_C8_MTP_OPS=0
    DEFAULT_ENABLE_STANDARD_LIM=0
    ;;
  ascend950|ascend950pr*|ascend950dt*)
    SOC="${RAW_SOC_LOWER}"
    DEFAULT_ENABLE_LOCAL_AIV=1
    DEFAULT_ENABLE_C8_MTP_OPS=1
    # 上游标准 LIM kernel 只实现了 910B/910_93；A5 架构分支是空函数。
    # A5 的 LIDU 路径使用仓内 C8 MTP 算子，CPU DU 路径使用官方标准 LI。
    DEFAULT_ENABLE_STANDARD_LIM=0
    ;;
  *)
    SOC="${RAW_SOC_LOWER}"
    DEFAULT_ENABLE_LOCAL_AIV=0
    DEFAULT_ENABLE_C8_MTP_OPS=0
    DEFAULT_ENABLE_STANDARD_LIM=0
    ;;
esac

ENABLE_LOCAL_AIV="${ENABLE_LOCAL_AIV:-${DEFAULT_ENABLE_LOCAL_AIV}}"
ENABLE_C8_MTP_OPS="${ENABLE_C8_MTP_OPS:-${DEFAULT_ENABLE_C8_MTP_OPS}}"
ENABLE_STANDARD_LIM="${ENABLE_STANDARD_LIM:-${DEFAULT_ENABLE_STANDARD_LIM}}"
ENABLE_SFA_FUSION="${ENABLE_SFA_FUSION:-0}"

if [[ "${RAW_SOC_LOWER}" == ascend950* && "${ENABLE_STANDARD_LIM}" == "1" ]]; then
  echo "[kvcache-scatter-copy] standard LIM only supports ascend910b/ascend910_93; use C8 MTP LIDU on A5." >&2
  exit 2
fi

export TMPDIR="${ROOT}/.tmp"
export TMP="${TMPDIR}"
export TEMP="${TMPDIR}"
export OPS_CPU_NUMBER="${BUILD_JOBS}"
mkdir -p "${TMPDIR}"

echo "[kvcache-scatter-copy] root: ${ROOT}"
echo "[kvcache-scatter-copy] raw soc: ${RAW_SOC}, build soc: ${SOC}"
echo "[kvcache-scatter-copy] build jobs: ${BUILD_JOBS}"
echo "[kvcache-scatter-copy] local-aiv=${ENABLE_LOCAL_AIV}, c8-mtp=${ENABLE_C8_MTP_OPS}, standard-lim=${ENABLE_STANDARD_LIM}, sfa-fusion=${ENABLE_SFA_FUSION}"

if [[ "${CLEAN_ASCENDC_BUILD}" == "1" ]]; then
  case "${ASCENDC_DIR}" in
    "${ROOT}/csrc")
      rm -rf "${ASCENDC_DIR}/build" "${ASCENDC_DIR}/output"
      ;;
    *)
      echo "[kvcache-scatter-copy] refusing to clean unexpected path: ${ASCENDC_DIR}" >&2
      exit 1
      ;;
  esac
fi

pushd "${ASCENDC_DIR}" >/dev/null
# C8 uses its vendored msopgen ACLNN project below. Keeping it out of this
# generic project's op_build stage avoids an opaque -1 during FP8 wrapper
# generation. These controlled settings come last and override stale user
# KVCACHE_EXTRA_CMAKE_ARGS values from prior experiments.
export KVCACHE_EXTRA_CMAKE_ARGS="${USER_CMAKE_ARGS} \
-DENABLE_LOCAL_AIV=$([[ "${ENABLE_LOCAL_AIV}" == "1" ]] && echo ON || echo OFF) \
-DENABLE_SFA_FUSION=$([[ "${ENABLE_SFA_FUSION}" == "1" ]] && echo ON || echo OFF) \
-DENABLE_C8_MTP_OPS=OFF \
-DENABLE_STANDARD_LIM=$([[ "${ENABLE_STANDARD_LIM}" == "1" ]] && echo ON || echo OFF) \
-DENABLE_ASCENDC_PIPELINE=ON"
if [[ "${ENABLE_LOCAL_AIV}" == "1" || "${ENABLE_SFA_FUSION}" == "1" || "${ENABLE_STANDARD_LIM}" == "1" ]]; then
  bash build.sh -n "${OP_NAME}" -c "${SOC}"
else
  # The normal package is AI CPU-only and deliberately skips AscendC.
  bash build.sh -n "${OP_NAME}" -c "${SOC}" -b host
fi
popd >/dev/null

pushd "${TORCH_EXTENSION_DIR}" >/dev/null
rm -rf build
rm -f kvcache_scatter_copy_custom_ops/*.so
MAX_JOBS="${BUILD_JOBS}" python3 setup.py build_ext --inplace
popd >/dev/null

RUN_PKG="$(find "${ASCENDC_DIR}/output" -maxdepth 1 -name 'CANN-custom_ops-*.run' | head -n 1)"
if [[ -z "${RUN_PKG}" ]]; then
  echo "[kvcache-scatter-copy] custom op package was not generated." >&2
  exit 1
fi

DEFAULT_INSTALL_OPP="${ROOT}/opp"
INSTALL_OPP="${KVCACHE_SCATTER_COPY_INSTALL_OPP_PATH:-${DEFAULT_INSTALL_OPP}}"
if [[ "${INSTALL_OPP}" == "${DEFAULT_INSTALL_OPP}" ]]; then
  case "${INSTALL_OPP}/vendors/customize" in
    "${ROOT}/opp/vendors/customize")
      rm -rf "${INSTALL_OPP}/vendors/customize"
      ;;
    *)
      echo "[kvcache-scatter-copy] refusing to clean unexpected OPP path" >&2
      exit 1
      ;;
  esac
fi
mkdir -p "${INSTALL_OPP}"
# The CANN installer merges upgrades and leaves files that a newer package no
# longer ships. Remove only this operator's obsolete AscendC artifacts so they
# cannot shadow the AICPU-only implementation.
LEGACY_IMPL_ROOT="${INSTALL_OPP}/vendors/customize/op_impl/ai_core/tbe/customize_impl"
rm -f "${LEGACY_IMPL_ROOT}/dynamic/kvcache_scatter_copy.py"
rm -rf "${LEGACY_IMPL_ROOT}/ascendc/kvcache_scatter_copy"
if [[ "${ENABLE_LOCAL_AIV}" != "1" ]]; then
  rm -f "${LEGACY_IMPL_ROOT}/dynamic/kvcache_scatter_local_aiv.py"
  rm -rf "${LEGACY_IMPL_ROOT}/ascendc/kvcache_scatter_local_aiv"
  rm -f "${LEGACY_IMPL_ROOT}/dynamic/scatter_io_from_staging_c8.py"
  rm -rf "${LEGACY_IMPL_ROOT}/ascendc/scatter_io_from_staging_c8"
fi
if [[ "${ENABLE_SFA_FUSION}" != "1" ]]; then
  rm -f "${LEGACY_IMPL_ROOT}/dynamic/a5_sparse_and_tail_attention_and_scatter_copy.py"
  rm -rf "${LEGACY_IMPL_ROOT}/ascendc/a5_sparse_and_tail_attention_and_scatter_copy"
  rm -f "${LEGACY_IMPL_ROOT}/dynamic/a5_sparse_and_tail_attention_and_remote_scatter_copy.py"
  rm -rf "${LEGACY_IMPL_ROOT}/ascendc/a5_sparse_and_tail_attention_and_remote_scatter_copy"
fi
if [[ "${ENABLE_STANDARD_LIM}" != "1" ]]; then
  rm -f "${LEGACY_IMPL_ROOT}/dynamic/nanovllm_fused_li_manage_mtp.py"
  rm -rf "${LEGACY_IMPL_ROOT}/ascendc/nanovllm_fused_li_manage_mtp"
fi
# C8 is installed in its own msopgen-built OPP.  Remove artifacts from the
# former generic-CMake experiment so they cannot register a stale duplicate.
for op in \
  a5_fused_li_manage_c8 \
  a5_fused_li_manage_mtp_c8 \
  a5_kvcache_scatter_copy_c8 \
  a5_sparse_tail_attention_c8 \
  a5_sparse_tail_attention_mtp_c8; do
  rm -f "${LEGACY_IMPL_ROOT}/dynamic/${op}.py"
  rm -rf "${LEGACY_IMPL_ROOT}/ascendc/${op}"
done
chmod +x "${RUN_PKG}"
"${RUN_PKG}" --quiet --install-path="${INSTALL_OPP}"

C8_INSTALL_OPP=""
if [[ "${ENABLE_C8_MTP_OPS}" == "1" ]]; then
  C8_INSTALL_OPP="${KVCACHE_SCATTER_COPY_C8_INSTALL_OPP_PATH:-${ROOT}/opp_c8}"
  KVCACHE_SCATTER_COPY_C8_INSTALL_OPP_PATH="${C8_INSTALL_OPP}" \
    BUILD_JOBS="${BUILD_JOBS}" SOC_VERSION="${RAW_SOC}" \
    bash "${ASCENDC_DIR}/build_c8_ops.sh"
fi

{
  printf 'KVCACHE_SCATTER_COPY_INSTALL_OPP_PATH=%s\n' "${INSTALL_OPP}"
  printf 'KVCACHE_SCATTER_COPY_C8_INSTALL_OPP_PATH=%s\n' "${C8_INSTALL_OPP}"
  printf 'KVCACHE_SCATTER_COPY_TORCH_EXTENSION_DIR=%s\n' "${TORCH_EXTENSION_DIR}"
} > "${ENV_FILE}"

if ! compgen -G "${TORCH_EXTENSION_DIR}/kvcache_scatter_copy_custom_ops/*.so" >/dev/null; then
  echo "[kvcache-scatter-copy] torch extension was not generated." >&2
  exit 1
fi

echo "[kvcache-scatter-copy] build and local install done"
