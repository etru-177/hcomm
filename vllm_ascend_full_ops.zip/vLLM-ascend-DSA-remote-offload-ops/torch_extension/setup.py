import glob
import multiprocessing
import os

import torch_npu
from setuptools import find_packages, setup
from torch.utils.cpp_extension import BuildExtension, verify_ninja_availability
from torch_npu.utils.cpp_extension import NpuExtension


BASE_DIR = os.path.dirname(os.path.realpath(__file__))
PYTORCH_NPU_INSTALL_PATH = os.path.dirname(os.path.abspath(torch_npu.__file__))
ASCEND_HOME_PATH = "/usr/local/Ascend/cann-9.1.T560/aarch64-linux"
# Point this at the aarch64-linux directory of a locally built Hcomm package
# when testing APIs that are newer than the Hcomm bundled in CANN.
HCOMM_HOME_PATH = os.getenv("HCOMM_HOME_PATH", ASCEND_HOME_PATH)
USE_NINJA = os.getenv("USE_NINJA") == "1"
MAX_JOBS = int(os.getenv("MAX_JOBS", multiprocessing.cpu_count()))

if USE_NINJA:
    verify_ninja_availability()

source_files = glob.glob(os.path.join(BASE_DIR, "csrc", "*.cpp"))
source_files.extend([
    os.path.join(BASE_DIR, "..", "host_offload", "cpu_du.cpp"),
    os.path.join(BASE_DIR, "..", "host_offload", "offload_ring.cpp"),
    os.path.join(BASE_DIR, "..", "host_offload", "cpu_du_worker.cpp"),
    os.path.join(BASE_DIR, "..", "host_offload", "metadata_store.cpp"),
])

setup(
    name="kvcache_scatter_copy_custom_ops",
    version="0.1.0",
    packages=find_packages(),
    ext_modules=[
        NpuExtension(
            name="kvcache_scatter_copy_custom_ops.custom_ops_lib",
            sources=source_files,
            include_dirs=[
                os.path.join(BASE_DIR, "..", "host_offload"),
                os.path.join(HCOMM_HOME_PATH, "include"),
                os.path.join(ASCEND_HOME_PATH, "include"),
            ],
            extra_compile_args=[
                "-I" + os.path.join(PYTORCH_NPU_INSTALL_PATH, "include/third_party/acl/inc"),
                "-O3",
                "-std=c++17",
                "-fvisibility=hidden",
                "-pthread",
            ],
            extra_link_args=["-pthread"],
            library_dirs=[
                os.path.join(HCOMM_HOME_PATH, "lib64"),
                os.path.join(ASCEND_HOME_PATH, "lib64"),
            ],
            libraries=["hcomm", "hccl", "dl"],
        )
    ],
    cmdclass={"build_ext": BuildExtension.with_options(use_ninja=USE_NINJA, parallel=MAX_JOBS)},
)
