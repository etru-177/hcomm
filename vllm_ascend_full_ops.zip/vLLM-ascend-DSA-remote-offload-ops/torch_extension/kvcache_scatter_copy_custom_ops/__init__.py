import importlib
import os
from pathlib import Path

import torch
import torch_npu


def _prepend_custom_opp_path(path: Path) -> None:
    lib_path = path / "op_api" / "lib" / "libcust_opapi.so"
    if not lib_path.exists():
        return
    current = os.environ.get("ASCEND_CUSTOM_OPP_PATH", "")
    parts = [item for item in current.split(":") if item]
    text = str(path)
    if text not in parts:
        os.environ["ASCEND_CUSTOM_OPP_PATH"] = ":".join([text] + parts)


def _read_recorded_opp_path(key: str) -> str:
    env_file = Path(__file__).resolve().parents[2] / ".kvcache_scatter_copy_env"
    if not env_file.exists():
        return ""
    try:
        lines = env_file.read_text(encoding="utf-8").splitlines()
    except OSError:
        return ""
    prefix = f"{key}="
    for line in lines:
        if line.startswith(prefix):
            return line[len(prefix):].strip()
    return ""


def _read_recorded_install_opp() -> str:
    return _read_recorded_opp_path("KVCACHE_SCATTER_COPY_INSTALL_OPP_PATH")


def _read_recorded_c8_install_opp() -> str:
    return _read_recorded_opp_path("KVCACHE_SCATTER_COPY_C8_INSTALL_OPP_PATH")


def _setup_custom_opp_path() -> None:
    ascend_home = os.environ.get("ASCEND_HOME_PATH")
    if ascend_home:
        _prepend_custom_opp_path(Path(ascend_home) / "opp" / "vendors" / "customize")

    ascend_opp = os.environ.get("ASCEND_OPP_PATH")
    if ascend_opp:
        _prepend_custom_opp_path(Path(ascend_opp) / "vendors" / "customize")

    install_opp = (
        os.environ.get("KVCACHE_SCATTER_COPY_INSTALL_OPP_PATH")
        or _read_recorded_install_opp()
    )
    c8_install_opp = (
        os.environ.get("KVCACHE_SCATTER_COPY_C8_INSTALL_OPP_PATH")
        or _read_recorded_c8_install_opp()
    )
    # Add the base path first: _prepend_custom_opp_path prepends, therefore
    # the C8 path has priority for C8 ACLNN APIs while both OPP packages stay
    # visible to the runtime.
    for candidate in (install_opp, c8_install_opp):
        if not candidate:
            continue
        vendor = Path(candidate) / "vendors" / "customize"
        _prepend_custom_opp_path(vendor)

    if c8_install_opp:
        vendor = Path(c8_install_opp) / "vendors" / "customize"
        opapi = vendor / "op_api" / "lib" / "libcust_opapi.so"
        if opapi.exists():
            os.environ["NANOVLLM_CUST_OPAPI_LIB"] = str(opapi)
    elif install_opp:
        vendor = Path(install_opp) / "vendors" / "customize"
        opapi = vendor / "op_api" / "lib" / "libcust_opapi.so"
        if opapi.exists():
            os.environ["NANOVLLM_CUST_OPAPI_LIB"] = str(opapi)


def local_opapi_path() -> str:
    explicit = os.environ.get("NANOVLLM_CUST_OPAPI_LIB", "")
    if explicit:
        return explicit
    install_opp = (
        os.environ.get("KVCACHE_SCATTER_COPY_C8_INSTALL_OPP_PATH")
        or _read_recorded_c8_install_opp()
        or os.environ.get("KVCACHE_SCATTER_COPY_INSTALL_OPP_PATH")
        or _read_recorded_install_opp()
    )
    if not install_opp:
        return ""
    return str(
        Path(install_opp)
        / "vendors" / "customize" / "op_api" / "lib" / "libcust_opapi.so"
    )


def validate_mtp_c8_packing(
    actual_seq_lengths_query: torch.Tensor,
    resident_seq_lengths: torch.Tensor,
    packed_query_rows: int,
    slots_row_width: int,
) -> list[int]:
    """在图 capture 外校验 C8 MTP packed metadata。"""
    if actual_seq_lengths_query.dim() != 1 or resident_seq_lengths.dim() != 1:
        raise ValueError("seq-length tensors must be 1-D")
    if resident_seq_lengths.numel() != actual_seq_lengths_query.numel():
        raise ValueError(
            "resident_seq_lengths must match actual_seq_lengths_query length"
        )
    totals = actual_seq_lengths_query.cpu().tolist()
    residents = resident_seq_lengths.cpu().tolist()
    query_counts: list[int] = []
    previous = 0
    for request, total in enumerate(totals):
        count = total - previous
        if not 1 <= count <= 4:
            raise ValueError(
                "actual_seq_lengths_query must be strictly increasing with "
                f"per-request diffs in [1,4]; request {request} has {count}"
            )
        if residents[request] < count:
            raise ValueError(
                f"resident_seq_lengths[{request}] must cover "
                f"query_counts={count}, got {residents[request]}"
            )
        cache_tokens = residents[request] - count
        if cache_tokens != 0 and (cache_tokens < 2048 or cache_tokens % 128):
            raise ValueError(
                "cache_tokens must be 0 or block-aligned >= 2048; "
                f"request {request} has {cache_tokens}"
            )
        query_counts.append(count)
        previous = total
    if previous != packed_query_rows:
        raise ValueError(
            f"actual_seq_lengths_query last value {previous} must equal "
            f"the packed query row count T={packed_query_rows}"
        )
    if slots_row_width < 2048 + max(query_counts):
        raise ValueError(
            f"slots row width {slots_row_width} must cover "
            f"2048 + max(query_counts)={max(query_counts)}"
        )
    return query_counts


_setup_custom_opp_path()
custom_ops_lib = importlib.import_module(".custom_ops_lib", __name__)

_custom = getattr(torch.ops, "custom", None)
_nanovllm_dsa = getattr(torch.ops, "nanovllm_dsa", None)
if hasattr(custom_ops_lib, "CpuDuWorkerRuntime"):
    CpuDuWorkerRuntime = custom_ops_lib.CpuDuWorkerRuntime
if hasattr(custom_ops_lib, "CpuDuBatchWorkerRuntime"):
    CpuDuBatchWorkerRuntime = custom_ops_lib.CpuDuBatchWorkerRuntime
if hasattr(custom_ops_lib, "SwappedSlicePollerRuntime"):
    SwappedSlicePollerRuntime = custom_ops_lib.SwappedSlicePollerRuntime
if hasattr(custom_ops_lib, "SwappedCpuDuImplicitDbaRuntime"):
    SwappedCpuDuImplicitDbaRuntime = (
        custom_ops_lib.SwappedCpuDuImplicitDbaRuntime
    )
if hasattr(custom_ops_lib, "cpu_lidu_du_update"):
    cpu_lidu_du_update = custom_ops_lib.cpu_lidu_du_update
if hasattr(custom_ops_lib, "cpu_lidu_du_update_union"):
    cpu_lidu_du_update_union = custom_ops_lib.cpu_lidu_du_update_union
if hasattr(custom_ops_lib, "cpu_du_mte_copy_batch"):
    cpu_du_mte_copy_batch = custom_ops_lib.cpu_du_mte_copy_batch
if hasattr(custom_ops_lib, "cpu_du_mte_wait"):
    cpu_du_mte_wait = custom_ops_lib.cpu_du_mte_wait
if hasattr(custom_ops_lib, "npu_hcomm_kvcache_pool_connect"):
    npu_hcomm_kvcache_pool_connect = custom_ops_lib.npu_hcomm_kvcache_pool_connect
    torch_npu.npu_hcomm_kvcache_pool_connect = npu_hcomm_kvcache_pool_connect

if hasattr(custom_ops_lib, "npu_hcomm_kvcache_pool_connect_raw"):
    npu_hcomm_kvcache_pool_connect_raw = custom_ops_lib.npu_hcomm_kvcache_pool_connect_raw
    torch_npu.npu_hcomm_kvcache_pool_connect_raw = npu_hcomm_kvcache_pool_connect_raw

if hasattr(custom_ops_lib, "npu_hcomm_kvcache_pool_connect_raw_packed"):
    npu_hcomm_kvcache_pool_connect_raw_packed = (
        custom_ops_lib.npu_hcomm_kvcache_pool_connect_raw_packed
    )
    torch_npu.npu_hcomm_kvcache_pool_connect_raw_packed = (
        npu_hcomm_kvcache_pool_connect_raw_packed
    )

if hasattr(custom_ops_lib, "npu_hcomm_kvcache_pool_disconnect_raw"):
    npu_hcomm_kvcache_pool_disconnect_raw = custom_ops_lib.npu_hcomm_kvcache_pool_disconnect_raw
    torch_npu.npu_hcomm_kvcache_pool_disconnect_raw = npu_hcomm_kvcache_pool_disconnect_raw

if hasattr(custom_ops_lib, "npu_hcomm_kvcache_pool_get_raw_context"):
    npu_hcomm_kvcache_pool_get_raw_context = custom_ops_lib.npu_hcomm_kvcache_pool_get_raw_context
    torch_npu.npu_hcomm_kvcache_pool_get_raw_context = npu_hcomm_kvcache_pool_get_raw_context

if hasattr(custom_ops_lib, "npu_hcomm_kvcache_pool_get_profile"):
    npu_hcomm_kvcache_pool_get_profile = custom_ops_lib.npu_hcomm_kvcache_pool_get_profile
    torch_npu.npu_hcomm_kvcache_pool_get_profile = npu_hcomm_kvcache_pool_get_profile

if hasattr(custom_ops_lib, "npu_hcomm_kvcache_pool_get_staging"):
    npu_hcomm_kvcache_pool_get_staging = custom_ops_lib.npu_hcomm_kvcache_pool_get_staging
    torch_npu.npu_hcomm_kvcache_pool_get_staging = npu_hcomm_kvcache_pool_get_staging
if hasattr(custom_ops_lib, "npu_hcomm_kvcache_pool_get_next_completion"):
    npu_hcomm_kvcache_pool_get_next_completion = (
        custom_ops_lib.npu_hcomm_kvcache_pool_get_next_completion
    )
    torch_npu.npu_hcomm_kvcache_pool_get_next_completion = (
        npu_hcomm_kvcache_pool_get_next_completion
    )

if hasattr(custom_ops_lib, "npu_hcomm_kvcache_scatter_copy"):
    npu_hcomm_kvcache_scatter_copy = custom_ops_lib.npu_hcomm_kvcache_scatter_copy
    torch_npu.npu_hcomm_kvcache_scatter_copy = npu_hcomm_kvcache_scatter_copy

if hasattr(custom_ops_lib, "npu_hcomm_kvcache_io"):
    npu_hcomm_kvcache_io = custom_ops_lib.npu_hcomm_kvcache_io
    torch_npu.npu_hcomm_kvcache_io = npu_hcomm_kvcache_io

if hasattr(torch.ops.custom, "npu_scatter_io_from_staging_c8"):
    npu_scatter_io_from_staging_c8 = (
        torch.ops.custom.npu_scatter_io_from_staging_c8
    )
    torch_npu.npu_scatter_io_from_staging_c8 = (
        npu_scatter_io_from_staging_c8
    )

if _nanovllm_dsa is not None:
    for _name in (
        "quant_lightning_indexer_c8_out",
        "fused_li_manage_mtp_standard_out",
        "fused_li_manage_c8",
        "fused_li_manage_c8_out",
        "fused_li_manage_mtp_c8",
        "fused_li_manage_mtp_c8_out",
        "kvcache_scatter_copy_c8",
        "kvcache_scatter_copy_c8_out",
        "sparse_tail_attention_c8",
        "sparse_tail_attention_mtp_c8",
    ):
        if hasattr(_nanovllm_dsa, _name):
            globals()[_name] = getattr(_nanovllm_dsa, _name)

if hasattr(custom_ops_lib, "npu_hcomm_kvcache_local_scatter"):
    npu_hcomm_kvcache_local_scatter = custom_ops_lib.npu_hcomm_kvcache_local_scatter
    torch_npu.npu_hcomm_kvcache_local_scatter = npu_hcomm_kvcache_local_scatter

if hasattr(custom_ops_lib, "npu_hcomm_kvcache_bandwidth_probe"):
    npu_hcomm_kvcache_bandwidth_probe = custom_ops_lib.npu_hcomm_kvcache_bandwidth_probe
    torch_npu.npu_hcomm_kvcache_bandwidth_probe = npu_hcomm_kvcache_bandwidth_probe

if _custom is not None and hasattr(_custom, "npu_kvcache_scatter_copy"):
    _op = getattr(_custom, "npu_kvcache_scatter_copy")

    def npu_kvcache_scatter_copy(
        hbm_k_rope,
        hbm_kv_cache,
        dram_k_rope,
        dram_kv_cache,
        hbm_block_table,
        dram_block_table,
        src_token_ids,
        dst_slots,
        copy_counts,
        ready_flag=None,
        layer_id=0,
    ):
        return _op(
            hbm_k_rope,
            hbm_kv_cache,
            dram_k_rope,
            dram_kv_cache,
            hbm_block_table,
            dram_block_table,
            src_token_ids,
            dst_slots,
            copy_counts,
            ready_flag,
            layer_id,
        )

    setattr(torch_npu, "npu_kvcache_scatter_copy", npu_kvcache_scatter_copy)

if _custom is not None and hasattr(
    _custom, "npu_sparse_and_tail_attention_and_scatter_copy"
):
    npu_sparse_and_tail_attention_and_scatter_copy = getattr(
        _custom, "npu_sparse_and_tail_attention_and_scatter_copy"
    )
    setattr(
        torch_npu,
        "npu_sparse_and_tail_attention_and_scatter_copy",
        npu_sparse_and_tail_attention_and_scatter_copy,
    )

if _custom is not None and hasattr(
    _custom, "npu_sparse_and_tail_attention_and_remote_scatter_copy"
):
    npu_sparse_and_tail_attention_and_remote_scatter_copy = getattr(
        _custom,
        "npu_sparse_and_tail_attention_and_remote_scatter_copy",
    )
    setattr(
        torch_npu,
        "npu_sparse_and_tail_attention_and_remote_scatter_copy",
        npu_sparse_and_tail_attention_and_remote_scatter_copy,
    )

if _custom is not None and hasattr(
    _custom,
    "npu_sparse_and_tail_attention_and_remote_scatter_copy_ready",
):
    npu_sparse_and_tail_attention_and_remote_scatter_copy_ready = getattr(
        _custom,
        "npu_sparse_and_tail_attention_and_remote_scatter_copy_ready",
    )
    setattr(
        torch_npu,
        "npu_sparse_and_tail_attention_and_remote_scatter_copy_ready",
        npu_sparse_and_tail_attention_and_remote_scatter_copy_ready,
    )

__all__ = ["custom_ops_lib"]
__all__.extend(["local_opapi_path", "validate_mtp_c8_packing"])
if hasattr(custom_ops_lib, "CpuDuWorkerRuntime"):
    __all__.append("CpuDuWorkerRuntime")
if hasattr(custom_ops_lib, "CpuDuBatchWorkerRuntime"):
    __all__.append("CpuDuBatchWorkerRuntime")
if hasattr(custom_ops_lib, "SwappedSlicePollerRuntime"):
    __all__.append("SwappedSlicePollerRuntime")
if hasattr(custom_ops_lib, "SwappedCpuDuImplicitDbaRuntime"):
    __all__.append("SwappedCpuDuImplicitDbaRuntime")
if hasattr(custom_ops_lib, "cpu_lidu_du_update"):
    __all__.append("cpu_lidu_du_update")
if hasattr(custom_ops_lib, "cpu_lidu_du_update_union"):
    __all__.append("cpu_lidu_du_update_union")
if hasattr(custom_ops_lib, "cpu_du_mte_copy_batch"):
    __all__.append("cpu_du_mte_copy_batch")
if hasattr(custom_ops_lib, "cpu_du_mte_wait"):
    __all__.append("cpu_du_mte_wait")
if hasattr(custom_ops_lib, "npu_hcomm_kvcache_pool_connect"):
    __all__.append("npu_hcomm_kvcache_pool_connect")
if hasattr(custom_ops_lib, "npu_hcomm_kvcache_pool_connect_raw"):
    __all__.append("npu_hcomm_kvcache_pool_connect_raw")
if hasattr(custom_ops_lib, "npu_hcomm_kvcache_pool_connect_raw_packed"):
    __all__.append("npu_hcomm_kvcache_pool_connect_raw_packed")
if hasattr(custom_ops_lib, "npu_hcomm_kvcache_pool_disconnect_raw"):
    __all__.append("npu_hcomm_kvcache_pool_disconnect_raw")
if hasattr(custom_ops_lib, "npu_hcomm_kvcache_pool_get_raw_context"):
    __all__.append("npu_hcomm_kvcache_pool_get_raw_context")
if hasattr(custom_ops_lib, "npu_hcomm_kvcache_pool_get_profile"):
    __all__.append("npu_hcomm_kvcache_pool_get_profile")
if hasattr(custom_ops_lib, "npu_hcomm_kvcache_pool_get_staging"):
    __all__.append("npu_hcomm_kvcache_pool_get_staging")
if hasattr(custom_ops_lib, "npu_hcomm_kvcache_pool_get_next_completion"):
    __all__.append("npu_hcomm_kvcache_pool_get_next_completion")
if hasattr(custom_ops_lib, "npu_hcomm_kvcache_scatter_copy"):
    __all__.append("npu_hcomm_kvcache_scatter_copy")
if hasattr(custom_ops_lib, "npu_hcomm_kvcache_io"):
    __all__.append("npu_hcomm_kvcache_io")
if hasattr(torch.ops.custom, "npu_scatter_io_from_staging_c8"):
    __all__.append("npu_scatter_io_from_staging_c8")
for _name in (
    "quant_lightning_indexer_c8_out",
    "fused_li_manage_c8",
    "fused_li_manage_mtp_standard_out",
    "fused_li_manage_c8_out",
    "fused_li_manage_mtp_c8",
    "fused_li_manage_mtp_c8_out",
    "kvcache_scatter_copy_c8",
    "kvcache_scatter_copy_c8_out",
    "sparse_tail_attention_c8",
    "sparse_tail_attention_mtp_c8",
):
    if _name in globals():
        __all__.append(_name)
if hasattr(custom_ops_lib, "npu_hcomm_kvcache_local_scatter"):
    __all__.append("npu_hcomm_kvcache_local_scatter")
if hasattr(custom_ops_lib, "npu_hcomm_kvcache_bandwidth_probe"):
    __all__.append("npu_hcomm_kvcache_bandwidth_probe")
if "npu_kvcache_scatter_copy" in globals():
    __all__.append("npu_kvcache_scatter_copy")
if (
    "npu_sparse_and_tail_attention_and_remote_scatter_copy_ready"
    in globals()
):
    __all__.append(
        "npu_sparse_and_tail_attention_and_remote_scatter_copy_ready"
    )
if "npu_sparse_and_tail_attention_and_scatter_copy" in globals():
    __all__.append("npu_sparse_and_tail_attention_and_scatter_copy")
if "npu_sparse_and_tail_attention_and_remote_scatter_copy" in globals():
    __all__.append(
        "npu_sparse_and_tail_attention_and_remote_scatter_copy"
    )
