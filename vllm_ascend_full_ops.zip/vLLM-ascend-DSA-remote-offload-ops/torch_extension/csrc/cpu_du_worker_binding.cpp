// SPDX-License-Identifier: Apache-2.0

#include <chrono>
#include <climits>
#include <cstring>
#include <memory>
#include <stdexcept>
#include <thread>
#include <vector>

#include <torch/extension.h>

#include "cpu_du_worker.h"

namespace custom {
namespace {

namespace py = pybind11;

constexpr size_t Align64(size_t value)
{
    return (value + 63U) & ~size_t{63U};
}

uint32_t CheckSlotCount(uint32_t slotCount)
{
    TORCH_CHECK(slotCount >= 2 && slotCount <= 4096,
        "CPU DU ring slot_count must be in [2,4096].");
    return slotCount;
}

void CheckCpuInt32(const at::Tensor& tensor, const char* name)
{
    TORCH_CHECK(tensor.device().is_cpu(), name, " must be a CPU tensor.");
    TORCH_CHECK(tensor.scalar_type() == at::kInt,
        name, " must have dtype int32.");
    TORCH_CHECK(tensor.is_contiguous(), name, " must be contiguous.");
}

at::Tensor CopyVector(const int32_t* source, int64_t count)
{
    at::Tensor output = at::empty(
        {count}, at::TensorOptions().dtype(at::kInt).device(at::kCPU));
    if (count != 0) {
        std::memcpy(output.data_ptr<int32_t>(), source,
            static_cast<size_t>(count) * sizeof(int32_t));
    }
    return output;
}

at::Tensor CopyRows(const int32_t* source, int64_t queryCount)
{
    at::Tensor output = at::empty(
        {queryCount, 1, remote_offload::kSparseCount},
        at::TensorOptions().dtype(at::kInt).device(at::kCPU));
    std::memcpy(output.data_ptr<int32_t>(), source,
        static_cast<size_t>(queryCount) * remote_offload::kSparseCount *
        sizeof(int32_t));
    return output;
}

class CpuDuWorkerRuntime {
public:
    CpuDuWorkerRuntime(uint32_t slotCount, int cpu)
        : slotCount_(CheckSlotCount(slotCount)), slots_(slotCount_),
          payloadStride_(Align64(sizeof(remote_offload::OffloadLiPayload)) +
              Align64(sizeof(remote_offload::OffloadDuPayload))),
          arena_(static_cast<size_t>(slotCount) * payloadStride_),
          ring_(slots_.data(), slotCount),
          worker_(slots_.data(), slotCount, arena_.data(), arena_.size())
    {
        ring_.Initialize();
        worker_.Start(cpu);
    }

    ~CpuDuWorkerRuntime()
    {
        worker_.Stop();
    }

    CpuDuWorkerRuntime(const CpuDuWorkerRuntime&) = delete;
    CpuDuWorkerRuntime& operator=(const CpuDuWorkerRuntime&) = delete;

    void RegisterState(uint64_t requestId, uint64_t epoch, uint32_t layerId,
        const at::Tensor& tokenToSlot, int64_t cacheBudget,
        uint64_t generation)
    {
        CheckCpuInt32(tokenToSlot, "token_to_slot");
        TORCH_CHECK(tokenToSlot.dim() == 1 && tokenToSlot.numel() > 0,
            "token_to_slot must be a non-empty CPU int32 vector.");
        TORCH_CHECK(cacheBudget >= 0 && cacheBudget <= INT32_MAX,
            "cache_budget exceeds int32 range.");
        std::vector<int32_t> state(tokenToSlot.data_ptr<int32_t>(),
            tokenToSlot.data_ptr<int32_t>() + tokenToSlot.numel());
        remote_offload::CpuDuSnapshot snapshot;
        snapshot.generation = generation;
        snapshot.cacheBudget = static_cast<int32_t>(cacheBudget);
        snapshot.tokenToSlot = std::move(state);
        worker_.RegisterState(requestId, epoch, layerId, snapshot);
    }

    py::tuple SnapshotState(
        uint64_t requestId, uint64_t epoch, uint32_t layerId) const
    {
        const remote_offload::CpuDuSnapshot snapshot =
            worker_.SnapshotState(requestId, epoch, layerId);
        py::tuple output(3);
        output[0] = CopyVector(snapshot.tokenToSlot.data(),
            static_cast<int64_t>(snapshot.tokenToSlot.size()));
        output[1] = py::int_(snapshot.cacheBudget);
        output[2] = py::int_(snapshot.generation);
        return output;
    }

    bool RemoveState(uint64_t requestId, uint64_t epoch, uint32_t layerId)
    {
        return worker_.RemoveState(requestId, epoch, layerId);
    }

    py::tuple Acquire(uint64_t generation, uint64_t requestId,
        uint64_t epoch, uint32_t layerId, uint32_t queryCount,
        uint32_t candidateLength)
    {
        TORCH_CHECK(generation != 0, "generation zero is reserved.");
        TORCH_CHECK(queryCount >= 1 &&
            queryCount <= remote_offload::kMaxMtpQueries,
            "query_count must be in [1,4].");
        const uint32_t index = static_cast<uint32_t>(
            (generation - 1) % slotCount_);
        const uint64_t base = static_cast<uint64_t>(index) * payloadStride_;
        remote_offload::OffloadSlotMetadata metadata;
        metadata.requestId = requestId;
        metadata.epoch = epoch;
        metadata.layerId = layerId;
        metadata.queryCount = queryCount;
        metadata.candidateLength = candidateLength;
        metadata.liPayloadOffset = base;
        metadata.duPayloadOffset =
            base + Align64(sizeof(remote_offload::OffloadLiPayload));
        uint32_t acquiredIndex = 0;
        TORCH_CHECK(ring_.TryAcquire(generation, metadata, &acquiredIndex),
            "CPU DU ring slot is busy; release the previous generation first.");
        std::memset(arena_.data() + metadata.liPayloadOffset, 0xff,
            sizeof(remote_offload::OffloadLiPayload));
        std::memset(arena_.data() + metadata.duPayloadOffset, 0xff,
            sizeof(remote_offload::OffloadDuPayload));
        py::tuple output(3);
        output[0] = py::int_(acquiredIndex);
        output[1] = py::int_(reinterpret_cast<uint64_t>(
            arena_.data() + metadata.liPayloadOffset));
        output[2] = py::int_(reinterpret_cast<uint64_t>(
            arena_.data() + metadata.duPayloadOffset));
        return output;
    }

    void WriteLi(uint64_t generation, const at::Tensor& topkIndices)
    {
        CheckCpuInt32(topkIndices, "topk_indices");
        TORCH_CHECK(
            (topkIndices.dim() == 2 &&
             topkIndices.size(1) == remote_offload::kSparseCount) ||
            (topkIndices.dim() == 3 && topkIndices.size(1) == 1 &&
             topkIndices.size(2) == remote_offload::kSparseCount),
            "topk_indices must be [Q,2048] or [Q,1,2048].");
        const remote_offload::OffloadRingSlot* slot = ring_.Find(generation);
        TORCH_CHECK(slot != nullptr, "CPU DU ring generation is stale.");
        TORCH_CHECK(__atomic_load_n(&slot->state, __ATOMIC_ACQUIRE) ==
            static_cast<uint32_t>(
            remote_offload::OffloadSlotState::kNpuLiWriting),
            "CPU DU ring slot is not writable.");
        TORCH_CHECK(topkIndices.size(0) == slot->queryCount,
            "topk_indices query count does not match the ring slot.");
        auto* payload = reinterpret_cast<remote_offload::OffloadLiPayload*>(
            arena_.data() + slot->liPayloadOffset);
        std::memcpy(payload->topk, topkIndices.data_ptr<int32_t>(),
            static_cast<size_t>(slot->queryCount) *
            remote_offload::kSparseCount * sizeof(int32_t));
    }

    void PublishLi(uint64_t generation)
    {
        TORCH_CHECK(ring_.TryTransition(generation,
            remote_offload::OffloadSlotState::kNpuLiWriting,
            remote_offload::OffloadSlotState::kLiReady),
            "failed to publish LI payload; generation or state is invalid.");
    }

    py::tuple WaitDu(uint64_t generation, int64_t timeoutMs)
    {
        return WaitDuImpl(generation, timeoutMs, false);
    }

    py::tuple WaitDuUnion(uint64_t generation, int64_t timeoutMs)
    {
        return WaitDuImpl(generation, timeoutMs, true);
    }

    py::tuple WaitDuImpl(
        uint64_t generation, int64_t timeoutMs, bool includeUnion)
    {
        TORCH_CHECK(timeoutMs > 0, "timeout_ms must be positive.");
        const auto deadline = std::chrono::steady_clock::now() +
            std::chrono::milliseconds(timeoutMs);
        const remote_offload::OffloadRingSlot* ready = nullptr;
        {
            py::gil_scoped_release release;
            while (std::chrono::steady_clock::now() < deadline) {
                const remote_offload::OffloadRingSlot* slot =
                    ring_.Find(generation);
                if (slot == nullptr) {
                    throw std::runtime_error(
                        "CPU DU ring generation became stale while waiting");
                }
                const uint32_t state = __atomic_load_n(
                    &slot->state, __ATOMIC_ACQUIRE);
                if (state == static_cast<uint32_t>(
                        remote_offload::OffloadSlotState::kDuReady)) {
                    ready = slot;
                    break;
                }
                if (state == static_cast<uint32_t>(
                        remote_offload::OffloadSlotState::kError)) {
                    const uint32_t status = __atomic_load_n(
                        &slot->status, __ATOMIC_ACQUIRE);
                    throw std::runtime_error(
                        "CPU DU worker failed with status " +
                        std::to_string(status));
                }
                std::this_thread::yield();
            }
        }
        TORCH_CHECK(ready != nullptr, "timed out waiting for CPU DU result.");
        const auto* payload =
            reinterpret_cast<const remote_offload::OffloadDuPayload*>(
                arena_.data() + ready->duPayloadOffset);
        const int64_t queryCount = ready->queryCount;
        const int64_t uniqueCount = ready->uniqueMissCount;
        const int64_t unionHitCount = payload->unionHitCount;
        TORCH_CHECK(unionHitCount >= 0 &&
            unionHitCount <= remote_offload::kMtpUnionCapacity,
            "CPU DU worker produced an invalid union hit count.");
        py::tuple output(includeUnion ? 14 : 8);
        output[0] = CopyRows(&payload->sourceIds[0][0], queryCount);
        output[1] = CopyRows(&payload->destinationSlots[0][0], queryCount);
        output[2] = CopyRows(&payload->sourceRefs[0][0], queryCount);
        output[3] = CopyVector(payload->missCounts, queryCount);
        output[4] = CopyVector(payload->uniqueMissSourceIds, uniqueCount);
        output[5] = CopyVector(
            payload->uniqueMissDestinationSlots, uniqueCount);
        output[6] = CopyVector(payload->evictedSourceIds, uniqueCount);
        output[7] = py::int_(ready->duGeneration);
        if (includeUnion) {
            output[8] = CopyRows(
                &payload->unionOrdinals[0][0], queryCount);
            output[9] = CopyVector(
                payload->unionHitSourceIds, unionHitCount);
            output[10] = CopyVector(payload->unionHitSlots, unionHitCount);
            output[11] = CopyVector(
                payload->unionHitRefCounts, unionHitCount);
            output[12] = CopyVector(
                payload->unionHitQueryMasks, unionHitCount);
            output[13] = CopyVector(
                payload->uniqueMissQueryMasks, uniqueCount);
        }
        return output;
    }

    void MarkCommandSubmitted(uint64_t generation)
    {
        TORCH_CHECK(ring_.TryTransition(generation,
            remote_offload::OffloadSlotState::kDuReady,
            remote_offload::OffloadSlotState::kCommandSubmitted),
            "failed to mark command submitted.");
    }

    void MarkDataReady(uint64_t generation)
    {
        TORCH_CHECK(ring_.TryTransition(generation,
            remote_offload::OffloadSlotState::kCommandSubmitted,
            remote_offload::OffloadSlotState::kDataReady),
            "failed to mark data ready.");
    }

    void Release(uint64_t generation)
    {
        TORCH_CHECK(ring_.Release(generation),
            "failed to release CPU DU ring slot.");
    }

private:
    uint32_t slotCount_;
    std::vector<remote_offload::OffloadRingSlot> slots_;
    size_t payloadStride_;
    std::vector<uint8_t> arena_;
    remote_offload::OffloadRingView ring_;
    remote_offload::CpuDuWorker worker_;
};

}  // namespace

void RegisterCpuDuWorker(pybind11::module& module)
{
    py::class_<CpuDuWorkerRuntime>(module, "CpuDuWorkerRuntime")
        .def(py::init<uint32_t, int>(),
            py::arg("slot_count") = remote_offload::kDefaultOffloadRingSlots,
            py::arg("cpu") = -1)
        .def("register_state", &CpuDuWorkerRuntime::RegisterState,
            py::arg("request_id"), py::arg("epoch"), py::arg("layer_id"),
            py::arg("token_to_slot"), py::arg("cache_budget"),
            py::arg("generation") = 0)
        .def("snapshot_state", &CpuDuWorkerRuntime::SnapshotState,
            py::arg("request_id"), py::arg("epoch"), py::arg("layer_id"))
        .def("remove_state", &CpuDuWorkerRuntime::RemoveState,
            py::arg("request_id"), py::arg("epoch"), py::arg("layer_id"))
        .def("acquire", &CpuDuWorkerRuntime::Acquire,
            py::arg("generation"), py::arg("request_id"),
            py::arg("epoch"), py::arg("layer_id"),
            py::arg("query_count"), py::arg("candidate_length"))
        .def("write_li", &CpuDuWorkerRuntime::WriteLi,
            py::arg("generation"), py::arg("topk_indices"))
        .def("publish_li", &CpuDuWorkerRuntime::PublishLi,
            py::arg("generation"))
        .def("wait_du", &CpuDuWorkerRuntime::WaitDu,
            py::arg("generation"), py::arg("timeout_ms") = 1000)
        .def("wait_du_union", &CpuDuWorkerRuntime::WaitDuUnion,
            py::arg("generation"), py::arg("timeout_ms") = 1000)
        .def("mark_command_submitted",
            &CpuDuWorkerRuntime::MarkCommandSubmitted,
            py::arg("generation"))
        .def("mark_data_ready", &CpuDuWorkerRuntime::MarkDataReady,
            py::arg("generation"))
        .def("release", &CpuDuWorkerRuntime::Release,
            py::arg("generation"));
}

}  // namespace custom
