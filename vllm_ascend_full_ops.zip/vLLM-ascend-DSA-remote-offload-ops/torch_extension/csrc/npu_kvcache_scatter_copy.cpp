#include <torch/library.h>

#include <acl/acl_op_compiler.h>

#include "ops_common.h"

namespace custom {
bool npu_hcomm_kvcache_pool_get_default_raw_context(uint64_t& channel, uint64_t& aicpuThread);

namespace {
constexpr int64_t BLOCK_SIZE = 128;
constexpr int64_t K_ROPE_DIM = 64;
constexpr int64_t KV_CACHE_DIM = 512;
constexpr int64_t COPY_CAP = 16384;
constexpr char HCOMM_CHANNEL_ATTR[] = "hcomm_channel";
constexpr char HCOMM_THREAD_ATTR[] = "hcomm_thread";
constexpr char LAYER_ID_ATTR[] = "layer_id";

aclDataType ToAclDataType(const at::ScalarType dtype)
{
    switch (dtype) {
        case at::kBFloat16:
            return ACL_BF16;
        case at::kHalf:
            return ACL_FLOAT16;
        case at::kInt:
            return ACL_INT32;
        case at::kUInt64:
            return ACL_UINT64;
        default:
            return ACL_DT_UNDEFINED;
    }
}

aclTensorDesc* CreateTensorDesc(const at::Tensor& tensor)
{
    const aclDataType dtype = ToAclDataType(tensor.scalar_type());
    TORCH_CHECK(dtype != ACL_DT_UNDEFINED, "unsupported ACL dtype for KvcacheScatterCopy");
    return aclCreateTensorDesc(dtype, tensor.dim(), tensor.sizes().data(), ACL_FORMAT_ND);
}

void DestroyAclResources(std::vector<aclTensorDesc*>& descs, std::vector<aclDataBuffer*>& buffers)
{
    for (aclDataBuffer* buffer : buffers) {
        if (buffer != nullptr) {
            (void)aclDestroyDataBuffer(buffer);
        }
    }
    for (aclTensorDesc* desc : descs) {
        if (desc != nullptr) {
            (void)aclDestroyTensorDesc(desc);
        }
    }
}

void LaunchAicpuKvcacheScatterCopy(
    const at::Tensor& hbmKRoPE,
    const at::Tensor& hbmKvCache,
    const at::Tensor& dramKRoPE,
    const at::Tensor& dramKvCache,
    const at::Tensor& hbmBlockTable,
    const at::Tensor& dramBlockTable,
    const at::Tensor& srcTokenIds,
    const at::Tensor& dstSlots,
    const at::Tensor& copyCounts,
    const c10::optional<at::Tensor>& readyFlag,
    int64_t layerId,
    aclrtStream stream)
{
    std::vector<const at::Tensor*> inputs = {
        &hbmKRoPE, &hbmKvCache, &dramKRoPE, &dramKvCache, &hbmBlockTable,
        &dramBlockTable, &srcTokenIds, &dstSlots, &copyCounts};
    if (readyFlag.has_value() && readyFlag->defined()) {
        inputs.push_back(&*readyFlag);
    }
    const std::vector<const at::Tensor*> outputs = {&hbmKRoPE, &hbmKvCache};

    std::vector<aclTensorDesc*> inputDescs(inputs.size(), nullptr);
    std::vector<aclDataBuffer*> inputBuffers(inputs.size(), nullptr);
    std::vector<aclTensorDesc*> outputDescs(outputs.size(), nullptr);
    std::vector<aclDataBuffer*> outputBuffers(outputs.size(), nullptr);
    std::vector<aclTensorDesc*> allDescs;
    std::vector<aclDataBuffer*> allBuffers;
    allDescs.reserve(inputs.size() + outputs.size());
    allBuffers.reserve(inputs.size() + outputs.size());

    for (size_t i = 0; i < inputs.size(); ++i) {
        inputDescs[i] = CreateTensorDesc(*inputs[i]);
        inputBuffers[i] = aclCreateDataBuffer(inputs[i]->data_ptr(), inputs[i]->nbytes());
        allDescs.push_back(inputDescs[i]);
        allBuffers.push_back(inputBuffers[i]);
    }
    for (size_t i = 0; i < outputs.size(); ++i) {
        outputDescs[i] = CreateTensorDesc(*outputs[i]);
        outputBuffers[i] = aclCreateDataBuffer(outputs[i]->data_ptr(), outputs[i]->nbytes());
        allDescs.push_back(outputDescs[i]);
        allBuffers.push_back(outputBuffers[i]);
    }
    bool allocationFailed = false;
    for (aclTensorDesc* desc : allDescs) {
        allocationFailed = allocationFailed || desc == nullptr;
    }
    for (aclDataBuffer* buffer : allBuffers) {
        allocationFailed = allocationFailed || buffer == nullptr;
    }
    if (allocationFailed) {
        DestroyAclResources(allDescs, allBuffers);
        TORCH_CHECK(false, "failed to allocate ACL tensor descriptors or data buffers for KvcacheScatterCopy");
    }

    aclopAttr* attr = aclopCreateAttr();
    if (attr == nullptr) {
        DestroyAclResources(allDescs, allBuffers);
        TORCH_CHECK(false, "aclopCreateAttr(KvcacheScatterCopy) failed");
    }
    const aclError layerIdResult = aclopSetAttrInt(attr, LAYER_ID_ATTR, layerId);
    if (layerIdResult != ACL_SUCCESS) {
        (void)aclopDestroyAttr(attr);
        DestroyAclResources(allDescs, allBuffers);
        TORCH_CHECK(false, "failed to attach layer_id to KvcacheScatterCopy");
    }
    uint64_t channel = 0;
    uint64_t aicpuThread = 0;
    if (npu_hcomm_kvcache_pool_get_default_raw_context(channel, aicpuThread)) {
        const aclError channelResult = aclopSetAttrInt(attr, HCOMM_CHANNEL_ATTR,
            static_cast<int64_t>(channel));
        const aclError threadResult = aclopSetAttrInt(attr, HCOMM_THREAD_ATTR,
            static_cast<int64_t>(aicpuThread));
        if (channelResult != ACL_SUCCESS || threadResult != ACL_SUCCESS) {
            (void)aclopDestroyAttr(attr);
            DestroyAclResources(allDescs, allBuffers);
            TORCH_CHECK(false, "failed to attach raw Hcomm context to KvcacheScatterCopy");
        }
    }
    const aclError result = aclopCompileAndExecute("KvcacheScatterCopy", inputDescs.size(), inputDescs.data(),
        inputBuffers.data(), outputDescs.size(), outputDescs.data(), outputBuffers.data(), attr, ACL_ENGINE_SYS,
        ACL_COMPILE_SYS, nullptr, stream);
    (void)aclopDestroyAttr(attr);
    DestroyAclResources(allDescs, allBuffers);
    TORCH_CHECK(result == ACL_SUCCESS, "aclopCompileAndExecute(KvcacheScatterCopy) failed: ", result);
}

void CheckKvcacheScatterCopyInputs(
    const at::Tensor& hbmKRoPE,
    const at::Tensor& hbmKvCache,
    const at::Tensor& dramKRoPE,
    const at::Tensor& dramKvCache,
    const at::Tensor& hbmBlockTable,
    const at::Tensor& dramBlockTable,
    const at::Tensor& srcTokenIds,
    const at::Tensor& dstSlots,
    const at::Tensor& copyCounts,
    const c10::optional<at::Tensor>& readyFlag,
    int64_t layerId)
{
    TORCH_CHECK(hbmKRoPE.dim() == 3 && hbmKRoPE.size(1) == BLOCK_SIZE && hbmKRoPE.size(2) == K_ROPE_DIM,
        "hbm_k_rope must have shape [S_BLOCKS, 128, 64].");
    (void)layerId;
    TORCH_CHECK(hbmKvCache.dim() == 3 && hbmKvCache.size(1) == BLOCK_SIZE &&
                    hbmKvCache.size(2) == KV_CACHE_DIM,
        "hbm_kv_cache must have shape [S_BLOCKS, 128, 512].");
    TORCH_CHECK(dramKRoPE.dim() == 3 && dramKRoPE.size(1) == BLOCK_SIZE && dramKRoPE.size(2) == K_ROPE_DIM,
        "dram_k_rope must have shape [F_BLOCKS, 128, 64].");
    TORCH_CHECK(dramKvCache.dim() == 3 && dramKvCache.size(1) == BLOCK_SIZE &&
                    dramKvCache.size(2) == KV_CACHE_DIM,
        "dram_kv_cache must have shape [F_BLOCKS, 128, 512].");
    TORCH_CHECK(hbmKRoPE.size(0) == hbmKvCache.size(0),
        "hbm_k_rope and hbm_kv_cache block counts must match.");
    TORCH_CHECK(dramKRoPE.size(0) == dramKvCache.size(0),
        "dram_k_rope and dram_kv_cache block counts must match.");

    TORCH_CHECK(hbmBlockTable.dim() == 2 && hbmBlockTable.size(1) > 0,
        "hbm_block_table must have shape [B, S_MAX_BLOCKS] with S_MAX_BLOCKS > 0.");
    TORCH_CHECK(dramBlockTable.dim() == 2 && dramBlockTable.size(1) > 0,
        "dram_block_table must have shape [B, F_MAX_BLOCKS] with F_MAX_BLOCKS > 0.");
    TORCH_CHECK(srcTokenIds.dim() == 3 && srcTokenIds.size(1) == 1 && srcTokenIds.size(2) == COPY_CAP,
        "src_token_ids must have shape [B, 1, 16384].");
    TORCH_CHECK(dstSlots.dim() == 3 && dstSlots.size(1) == 1 && dstSlots.size(2) == COPY_CAP,
        "dst_slots must have shape [B, 1, 16384].");
    TORCH_CHECK(copyCounts.dim() == 1, "copy_counts must have shape [B].");

    int64_t batchSize = copyCounts.size(0);
    TORCH_CHECK(hbmBlockTable.size(0) == batchSize && dramBlockTable.size(0) == batchSize &&
                    srcTokenIds.size(0) == batchSize && dstSlots.size(0) == batchSize,
        "all batch dimensions must match copy_counts.");

    auto kvDtype = hbmKRoPE.scalar_type();
    TORCH_CHECK(kvDtype == at::kBFloat16 || kvDtype == at::kHalf,
        "K-RoPE and KV tensors only support bf16/fp16.");
    TORCH_CHECK(hbmKvCache.scalar_type() == kvDtype && dramKRoPE.scalar_type() == kvDtype &&
                    dramKvCache.scalar_type() == kvDtype,
        "all K-RoPE and KV tensors must have the same dtype.");
    TORCH_CHECK(hbmBlockTable.scalar_type() == at::kInt &&
                    srcTokenIds.scalar_type() == at::kInt && dstSlots.scalar_type() == at::kInt &&
                    copyCounts.scalar_type() == at::kInt,
        "hbm_block_table, src_token_ids, dst_slots and copy_counts must be int32.");
    TORCH_CHECK(dramBlockTable.scalar_type() == at::kUInt64,
        "dram_block_table must be uint64.");

    TORCH_CHECK(hbmKRoPE.is_contiguous() && hbmKvCache.is_contiguous() && dramKRoPE.is_contiguous() &&
                    dramKvCache.is_contiguous() && hbmBlockTable.is_contiguous() &&
                    dramBlockTable.is_contiguous() && srcTokenIds.is_contiguous() && dstSlots.is_contiguous() &&
                    copyCounts.is_contiguous(),
        "all inputs must be contiguous.");
    auto device = hbmKRoPE.device();
    TORCH_CHECK(hbmKvCache.device() == device && dramKRoPE.device() == device && dramKvCache.device() == device &&
                    hbmBlockTable.device() == device && dramBlockTable.device() == device &&
                    srcTokenIds.device() == device && dstSlots.device() == device && copyCounts.device() == device,
        "all inputs must be on the same NPU device.");
    if (readyFlag.has_value() && readyFlag->defined()) {
        TORCH_CHECK(readyFlag->dim() == 1 && readyFlag->numel() == 1,
            "ready_flag must have shape [1].");
        TORCH_CHECK(readyFlag->scalar_type() == at::kInt,
            "ready_flag must have dtype int32.");
        TORCH_CHECK(readyFlag->is_contiguous(), "ready_flag must be contiguous.");
        TORCH_CHECK(readyFlag->device() == device,
            "ready_flag must be on the same NPU device as the cache tensors.");
    }
}
} // namespace

void npu_kvcache_scatter_copy_npu(
    const at::Tensor& hbmKRoPE,
    const at::Tensor& hbmKvCache,
    const at::Tensor& dramKRoPE,
    const at::Tensor& dramKvCache,
    const at::Tensor& hbmBlockTable,
    const at::Tensor& dramBlockTable,
    const at::Tensor& srcTokenIds,
    const at::Tensor& dstSlots,
    const at::Tensor& copyCounts,
    const c10::optional<at::Tensor>& readyFlag,
    int64_t layerId)
{
    CheckKvcacheScatterCopyInputs(hbmKRoPE, hbmKvCache, dramKRoPE, dramKvCache, hbmBlockTable,
        dramBlockTable, srcTokenIds, dstSlots, copyCounts, readyFlag, layerId);
    const aclrtStream stream = c10_npu::getCurrentNPUStream().stream(true);
    const auto aclCall = [hbmKRoPE, hbmKvCache, dramKRoPE, dramKvCache, hbmBlockTable, dramBlockTable,
                              srcTokenIds, dstSlots, copyCounts, readyFlag, layerId, stream]() -> int {
        LaunchAicpuKvcacheScatterCopy(hbmKRoPE, hbmKvCache, dramKRoPE, dramKvCache, hbmBlockTable,
            dramBlockTable, srcTokenIds, dstSlots, copyCounts, readyFlag, layerId, stream);
        return 0;
    };
    at_npu::native::OpCommand::RunOpApiV2("KvcacheScatterCopy", aclCall);
}

void npu_kvcache_scatter_copy_meta(
    const at::Tensor& hbmKRoPE,
    const at::Tensor& hbmKvCache,
    const at::Tensor& dramKRoPE,
    const at::Tensor& dramKvCache,
    const at::Tensor& hbmBlockTable,
    const at::Tensor& dramBlockTable,
    const at::Tensor& srcTokenIds,
    const at::Tensor& dstSlots,
    const at::Tensor& copyCounts,
    const c10::optional<at::Tensor>& readyFlag,
    int64_t layerId)
{
    CheckKvcacheScatterCopyInputs(hbmKRoPE, hbmKvCache, dramKRoPE, dramKvCache, hbmBlockTable,
        dramBlockTable, srcTokenIds, dstSlots, copyCounts, readyFlag, layerId);
}

} // namespace custom

TORCH_LIBRARY_IMPL(custom, PrivateUse1, m)
{
    m.impl("npu_kvcache_scatter_copy", &custom::npu_kvcache_scatter_copy_npu);
}

TORCH_LIBRARY_IMPL(custom, Meta, m)
{
    m.impl("npu_kvcache_scatter_copy", &custom::npu_kvcache_scatter_copy_meta);
}
