#include <torch/library.h>

#include "ops_common.h"

namespace custom {
namespace {
constexpr int64_t BLOCK_SIZE = 128;
constexpr int64_t TOKEN_BYTES = 656;
constexpr int64_t COPY_CAP = 16384;
constexpr int64_t COMPLETION_BYTES = 64;

void CheckInputs(
    const at::Tensor& packedHbmKv, const at::Tensor& staging,
    const at::Tensor& completion, const at::Tensor& hbmBlockTable,
    const at::Tensor& dstSlots, const at::Tensor& copyCounts)
{
    TORCH_CHECK(
        packedHbmKv.dim() == 3 && packedHbmKv.size(0) > 0 &&
            packedHbmKv.size(1) == BLOCK_SIZE &&
            packedHbmKv.size(2) == TOKEN_BYTES &&
            packedHbmKv.scalar_type() == at::kByte,
        "packed_hbm_kv must be uint8 [blocks,128,656].");
    TORCH_CHECK(
        staging.dim() == 2 && staging.size(0) > 0 &&
            staging.size(1) == TOKEN_BYTES &&
            staging.scalar_type() == at::kByte,
        "staging must be uint8 [tokens,656].");
    TORCH_CHECK(
        completion.dim() == 1 &&
            completion.numel() >= COMPLETION_BYTES &&
            completion.scalar_type() == at::kByte,
        "completion must be a uint8 vector with at least 64 bytes.");
    TORCH_CHECK(
        hbmBlockTable.dim() == 2 && hbmBlockTable.size(0) > 0 &&
            hbmBlockTable.size(1) > 0 &&
            hbmBlockTable.scalar_type() == at::kInt,
        "hbm_block_table must be non-empty int32 [B,max_blocks].");
    TORCH_CHECK(
        dstSlots.dim() == 3 &&
            dstSlots.size(0) == hbmBlockTable.size(0) &&
            dstSlots.size(1) == 1 && dstSlots.size(2) == COPY_CAP &&
            dstSlots.scalar_type() == at::kInt,
        "dst_slots must be int32 [B,1,16384].");
    TORCH_CHECK(
        copyCounts.dim() == 1 &&
            copyCounts.size(0) == hbmBlockTable.size(0) &&
            copyCounts.scalar_type() == at::kInt,
        "copy_counts must be int32 [B].");
    TORCH_CHECK(
        packedHbmKv.is_contiguous() && staging.is_contiguous() &&
            completion.is_contiguous() && hbmBlockTable.is_contiguous() &&
            dstSlots.is_contiguous() && copyCounts.is_contiguous(),
        "all ScatterIoFromStagingC8 inputs must be contiguous.");
}
}  // namespace

at::Tensor npu_scatter_io_from_staging_c8_npu(
    at::Tensor packedHbmKv, const at::Tensor& staging,
    const at::Tensor& completion, const at::Tensor& hbmBlockTable,
    const at::Tensor& dstSlots, const at::Tensor& copyCounts)
{
    CheckInputs(packedHbmKv, staging, completion, hbmBlockTable,
        dstSlots, copyCounts);
    at_npu::native::OpCommand command;
    command.Name("ScatterIoFromStagingC8")
        .Input(packedHbmKv)
        .Input(staging)
        .Input(completion)
        .Input(hbmBlockTable)
        .Input(dstSlots)
        .Input(copyCounts)
        .Output(packedHbmKv)
        .Run();
    return packedHbmKv;
}

at::Tensor npu_scatter_io_from_staging_c8_meta(
    at::Tensor packedHbmKv, const at::Tensor& staging,
    const at::Tensor& completion, const at::Tensor& hbmBlockTable,
    const at::Tensor& dstSlots, const at::Tensor& copyCounts)
{
    CheckInputs(packedHbmKv, staging, completion, hbmBlockTable,
        dstSlots, copyCounts);
    return packedHbmKv;
}
}  // namespace custom

TORCH_LIBRARY_IMPL(custom, PrivateUse1, m)
{
    m.impl("npu_scatter_io_from_staging_c8",
        &custom::npu_scatter_io_from_staging_c8_npu);
}

TORCH_LIBRARY_IMPL(custom, Meta, m)
{
    m.impl("npu_scatter_io_from_staging_c8",
        &custom::npu_scatter_io_from_staging_c8_meta);
}
