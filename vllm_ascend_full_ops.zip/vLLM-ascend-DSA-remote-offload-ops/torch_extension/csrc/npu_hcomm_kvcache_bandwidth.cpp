#include <acl/acl.h>

#include <cstdlib>
#include <torch/extension.h>

#include "ops_common.h"
#include "../../hcomm_kernel/kvcache_scatter_copy_hcomm_args.h"
#include "../../hcomm_kernel/raw_ub_hybrid_protocol.h"

namespace custom {
bool npu_hcomm_kvcache_pool_get_default_hybrid_context(HcommRawScatterRuntimeContext& context);

namespace {

aclrtFuncHandle GetBandwidthKernel()
{
    static aclrtBinHandle binary = nullptr;
    static aclrtFuncHandle function = nullptr;
    if (function == nullptr) {
        const char* json = std::getenv("HCOMM_KVCACHE_SCATTER_COPY_JSON");
        if (json == nullptr) {
            json = "/usr/local/Ascend/cann/opp/built-in/op_impl/aicpu/config/ccl_kernel.json";
        }
        aclrtBinaryLoadOption option{};
        option.type = ACL_RT_BINARY_LOAD_OPT_CPU_KERNEL_MODE;
        option.value.cpuKernelMode = 0;
        aclrtBinaryLoadOptions options{};
        options.numOpt = 1;
        options.options = &option;
        aclError result = aclrtBinaryLoadFromFile(json, &options, &binary);
        TORCH_CHECK(result == ACL_SUCCESS, "aclrtBinaryLoadFromFile failed for ", json, ": ", result);
        result = aclrtBinaryGetFunction(binary, "HcommKvcacheBandwidthProbe", &function);
        TORCH_CHECK(result == ACL_SUCCESS,
            "aclrtBinaryGetFunction(HcommKvcacheBandwidthProbe) failed: ", result);
    }
    return function;
}

} // namespace

void npu_hcomm_kvcache_bandwidth_probe(
    const at::Tensor& remoteGvas, int64_t transferBytes, int64_t mode, int64_t segments)
{
    TORCH_CHECK(remoteGvas.scalar_type() == at::kUInt64 && remoteGvas.dim() == 1 &&
        remoteGvas.is_contiguous() && remoteGvas.numel() != 0,
        "remote_gvas must be a non-empty contiguous uint64 NPU vector.");
    TORCH_CHECK(transferBytes > 0, "transfer_bytes must be positive.");
    TORCH_CHECK(mode >= static_cast<int64_t>(HcommKvcacheBandwidthMode::PULL_CONTIGUOUS) &&
        mode <= static_cast<int64_t>(HcommKvcacheBandwidthMode::PUSH_AGGREGATE),
        "mode must be 0 (pull), 1 (push), or 2 (aggregate push).");
    TORCH_CHECK(segments > 0 && segments <= static_cast<int64_t>(kRawUbMaxPushEntries),
        "segments must be in [1, ", kRawUbMaxPushEntries, "].");
    TORCH_CHECK(transferBytes % segments == 0,
        "transfer_bytes must be divisible by segments.");

    HcommRawScatterRuntimeContext context{};
    TORCH_CHECK(npu_hcomm_kvcache_pool_get_default_hybrid_context(context),
        "no raw Hcomm connection in this Python process");
    HcommKvcacheBandwidthArgs params{
        context.hbmStaging, remoteGvas.data_ptr<uint64_t>(),
        static_cast<uint64_t>(remoteGvas.numel()), static_cast<uint64_t>(transferBytes),
        static_cast<uint64_t>(mode), context.hbmStagingBlocks * kRawUbBlockBytes,
        context.laneCount, {}, {}, context.stagingGva, context.commandGva,
        context.deviceControl, context.generation, context.commandSlots,
        static_cast<uint64_t>(segments), context.profileRing, context.profileSlots};
    for (uint64_t lane = 0; lane < context.laneCount; ++lane) {
        params.laneThreads[lane] = context.laneThreads[lane];
        params.laneChannels[lane] = context.laneChannels[lane];
    }

    aclrtFuncHandle function = GetBandwidthKernel();
    aclrtArgsHandle args = nullptr;
    aclError result = aclrtKernelArgsInit(function, &args);
    TORCH_CHECK(result == ACL_SUCCESS,
        "aclrtKernelArgsInit(HcommKvcacheBandwidthProbe) failed: ", result);
    aclrtParamHandle parameter;
    result = aclrtKernelArgsAppend(args, &params, sizeof(params), &parameter);
    TORCH_CHECK(result == ACL_SUCCESS,
        "aclrtKernelArgsAppend(HcommKvcacheBandwidthProbe) failed: ", result);
    result = aclrtKernelArgsFinalize(args);
    TORCH_CHECK(result == ACL_SUCCESS,
        "aclrtKernelArgsFinalize(HcommKvcacheBandwidthProbe) failed: ", result);
    aclrtLaunchKernelAttr attribute{};
    attribute.id = ACL_RT_LAUNCH_KERNEL_ATTR_TIMEOUT;
    attribute.value.timeout = 30;
    aclrtLaunchKernelCfg config{};
    config.numAttrs = 1;
    config.attrs = &attribute;
    result = aclrtLaunchKernelWithConfig(function, 1, c10_npu::getCurrentNPUStream().stream(true),
        &config, args, nullptr);
    TORCH_CHECK(result == ACL_SUCCESS,
        "aclrtLaunchKernelWithConfig(HcommKvcacheBandwidthProbe) failed: ", result);
}

} // namespace custom
