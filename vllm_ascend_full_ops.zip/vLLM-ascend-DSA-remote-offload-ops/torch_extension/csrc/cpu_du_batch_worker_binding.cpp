// SPDX-License-Identifier: Apache-2.0

#include <algorithm>
#include <atomic>
#include <climits>
#include <cstring>
#include <exception>
#include <memory>
#include <mutex>
#include <stdexcept>
#include <thread>
#include <vector>

#if defined(__linux__)
#include <pthread.h>
#include <sched.h>
#endif

#include <torch/extension.h>

#include "cpu_du.h"

namespace custom {
namespace {

namespace py = pybind11;

// 与标准 LIDU/Hcomm ABI 保持一致；MTP3 实际 union 上限仍为 8192。
constexpr int64_t kUnionCapacity = 16384;

void CheckCpuInt32(const at::Tensor& tensor, const char* name)
{
    TORCH_CHECK(tensor.device().is_cpu(), name, " must be a CPU tensor.");
    TORCH_CHECK(tensor.scalar_type() == at::kInt,
        name, " must have dtype int32.");
    TORCH_CHECK(tensor.is_contiguous(), name, " must be contiguous.");
}

inline void CpuRelax()
{
#if defined(__aarch64__)
    asm volatile("yield" ::: "memory");
#elif defined(__x86_64__) || defined(__i386__)
    asm volatile("pause" ::: "memory");
#else
    std::this_thread::yield();
#endif
}

class CpuDuBatchWorkerRuntime {
public:
    explicit CpuDuBatchWorkerRuntime(int64_t threadCount, int64_t firstCpu)
        : threadCount_(CheckThreadCount(threadCount)),
          firstCpu_(CheckFirstCpu(firstCpu))
    {
        workers_.reserve(static_cast<size_t>(threadCount_));
        try {
            for (int64_t worker = 0; worker < threadCount_; ++worker) {
                workers_.emplace_back(
                    &CpuDuBatchWorkerRuntime::WorkerMain, this, worker);
            }
        } catch (...) {
            stop_.store(true, std::memory_order_release);
            taskSequence_.fetch_add(1, std::memory_order_release);
            for (std::thread& worker : workers_) {
                if (worker.joinable()) {
                    worker.join();
                }
            }
            throw;
        }
        while (readyWorkers_.load(std::memory_order_acquire) != threadCount_) {
            CpuRelax();
        }
    }

    ~CpuDuBatchWorkerRuntime()
    {
        stop_.store(true, std::memory_order_release);
        taskSequence_.fetch_add(1, std::memory_order_release);
        for (std::thread& worker : workers_) {
            if (worker.joinable()) {
                worker.join();
            }
        }
    }

    CpuDuBatchWorkerRuntime(const CpuDuBatchWorkerRuntime&) = delete;
    CpuDuBatchWorkerRuntime& operator=(const CpuDuBatchWorkerRuntime&) = delete;

    void RegisterStates(const at::Tensor& initialStates,
        const at::Tensor& cacheBudgets, const at::Tensor& candidateLengths,
        const at::Tensor& queryCounts)
    {
        std::lock_guard<std::mutex> lock(runMutex_);
        CheckCpuInt32(initialStates, "initial_states");
        CheckCpuInt32(cacheBudgets, "cache_budgets");
        CheckCpuInt32(candidateLengths, "candidate_lengths");
        CheckCpuInt32(queryCounts, "query_counts");
        TORCH_CHECK(initialStates.dim() == 2 && initialStates.size(0) > 0,
            "initial_states must have shape [B, source_capacity].");
        const int64_t batch = initialStates.size(0);
        const int64_t capacity = initialStates.size(1);
        TORCH_CHECK(cacheBudgets.dim() == 1 && cacheBudgets.numel() == batch,
            "cache_budgets must have shape [B].");
        TORCH_CHECK(candidateLengths.dim() == 1 &&
            candidateLengths.numel() == batch,
            "candidate_lengths must have shape [B].");
        TORCH_CHECK(queryCounts.dim() == 1 && queryCounts.numel() == batch,
            "query_counts must have shape [B].");

        std::vector<std::vector<int32_t>> templates;
        std::vector<std::unique_ptr<remote_offload::CpuDuState>> states;
        std::vector<int32_t> candidates;
        std::vector<int32_t> queries;
        std::vector<int64_t> rowOffsets;
        templates.reserve(static_cast<size_t>(batch));
        states.reserve(static_cast<size_t>(batch));
        candidates.reserve(static_cast<size_t>(batch));
        queries.reserve(static_cast<size_t>(batch));
        rowOffsets.reserve(static_cast<size_t>(batch + 1));
        rowOffsets.push_back(0);
        const int32_t* initial = initialStates.data_ptr<int32_t>();
        const int32_t* budgets = cacheBudgets.data_ptr<int32_t>();
        const int32_t* lengths = candidateLengths.data_ptr<int32_t>();
        const int32_t* counts = queryCounts.data_ptr<int32_t>();
        for (int64_t request = 0; request < batch; ++request) {
            TORCH_CHECK(counts[request] >= 1 &&
                counts[request] <= remote_offload::kMaxMtpQueries,
                "query_counts values must be in [1,4].");
            TORCH_CHECK(lengths[request] >= remote_offload::kSparseCount &&
                lengths[request] <= capacity,
                "candidate_lengths values must be in [2048,source_capacity].");
            TORCH_CHECK(budgets[request] >= 0 && budgets[request] <= INT32_MAX,
                "cache budget exceeds int32 range.");
            const int32_t* begin = initial + request * capacity;
            templates.emplace_back(begin, begin + capacity);
            states.push_back(std::make_unique<remote_offload::CpuDuState>(
                budgets[request], templates.back(), 0));
            candidates.push_back(lengths[request]);
            queries.push_back(counts[request]);
            rowOffsets.push_back(rowOffsets.back() + counts[request]);
        }

        const int64_t totalRows = rowOffsets.back();
        const int64_t topkElements =
            totalRows * remote_offload::kSparseCount;
        const int64_t unionElements = batch * kUnionCapacity;
        at::Tensor output = at::empty(
            {topkElements + 2 * unionElements + batch},
            at::TensorOptions().dtype(at::kInt).device(at::kCPU));

        templates_ = std::move(templates);
        states_ = std::move(states);
        candidateLengths_ = std::move(candidates);
        queryCounts_ = std::move(queries);
        rowOffsets_ = std::move(rowOffsets);
        output_ = std::move(output);
        batch_ = batch;
        topkElements_ = topkElements;
        unionElements_ = unionElements;
    }

    at::Tensor Run(
        const at::Tensor& topkIndices, uint64_t generation, bool hitsFirst)
    {
        std::lock_guard<std::mutex> lock(runMutex_);
        TORCH_CHECK(!states_.empty(),
            "register_states must be called before run.");
        CheckCpuInt32(topkIndices, "topk_indices");
        TORCH_CHECK(topkIndices.numel() == topkElements_,
            "topk_indices must contain T*2048 values registered by query_counts.");
        TORCH_CHECK(generation != 0, "generation zero is reserved.");
        {
            std::lock_guard<std::mutex> errorLock(errorMutex_);
            if (initializationError_) {
                std::rethrow_exception(initializationError_);
            }
        }

        std::fill(output_.data_ptr<int32_t>(),
            output_.data_ptr<int32_t>() + output_.numel(), -1);
        topkInput_ = topkIndices.data_ptr<int32_t>();
        generation_ = generation;
        order_ = hitsFirst ? remote_offload::DuOutputOrder::kHitsThenMisses
                           : remote_offload::DuOutputOrder::kMissesThenHits;
        {
            std::lock_guard<std::mutex> errorLock(errorMutex_);
            workerError_ = nullptr;
        }
        completedWorkers_.store(0, std::memory_order_relaxed);
        taskSequence_.fetch_add(1, std::memory_order_release);
        {
            py::gil_scoped_release release;
            while (completedWorkers_.load(std::memory_order_acquire) !=
                threadCount_) {
                CpuRelax();
            }
        }
        std::exception_ptr error;
        {
            std::lock_guard<std::mutex> errorLock(errorMutex_);
            error = workerError_;
        }
        if (error) {
            std::rethrow_exception(error);
        }
        return output_;
    }

    int64_t thread_count() const { return threadCount_; }
    int64_t batch_size() const { return batch_; }
    int64_t topk_elements() const { return topkElements_; }
    int64_t union_capacity() const { return kUnionCapacity; }

private:
    static int64_t CheckThreadCount(int64_t value)
    {
        TORCH_CHECK(value >= 1 && value <= 256,
            "thread_count must be in [1,256].");
        return value;
    }

    static int64_t CheckFirstCpu(int64_t value)
    {
        TORCH_CHECK(value >= -1 && value <= INT_MAX,
            "first_cpu must be -1 or a non-negative CPU ID.");
        return value;
    }

    void BindWorker(int64_t worker)
    {
#if defined(__linux__)
        if (firstCpu_ < 0) {
            return;
        }
        if (firstCpu_ + worker >= CPU_SETSIZE) {
            throw std::runtime_error(
                "CPU DU requested CPU ID exceeds CPU_SETSIZE");
        }
        cpu_set_t set;
        CPU_ZERO(&set);
        CPU_SET(static_cast<int>(firstCpu_ + worker), &set);
        const int status = pthread_setaffinity_np(
            pthread_self(), sizeof(set), &set);
        if (status != 0) {
            throw std::runtime_error(
                "CPU DU failed to bind worker to requested CPU");
        }
#else
        (void)worker;
        if (firstCpu_ >= 0) {
            throw std::runtime_error(
                "CPU DU affinity is supported only on Linux");
        }
#endif
    }

    void RecordError()
    {
        std::lock_guard<std::mutex> lock(errorMutex_);
        if (!workerError_) {
            workerError_ = std::current_exception();
        }
    }

    void WorkerMain(int64_t worker)
    {
        try {
            BindWorker(worker);
        } catch (...) {
            std::lock_guard<std::mutex> lock(errorMutex_);
            if (!initializationError_) {
                initializationError_ = std::current_exception();
            }
        }
        uint64_t observed = taskSequence_.load(std::memory_order_acquire);
        readyWorkers_.fetch_add(1, std::memory_order_release);
        while (!stop_.load(std::memory_order_acquire)) {
            const uint64_t sequence =
                taskSequence_.load(std::memory_order_acquire);
            if (sequence == observed) {
                CpuRelax();
                continue;
            }
            observed = sequence;
            if (stop_.load(std::memory_order_acquire)) {
                break;
            }
            try {
                ProcessRequests(worker);
            } catch (...) {
                RecordError();
            }
            completedWorkers_.fetch_add(1, std::memory_order_release);
        }
    }

    void ProcessRequests(int64_t worker)
    {
        int32_t* output = output_.data_ptr<int32_t>();
        int32_t* topkSlots = output;
        int32_t* missSources = output + topkElements_;
        int32_t* missDestinations = missSources + unionElements_;
        int32_t* missCounts = missDestinations + unionElements_;
        for (int64_t request = worker; request < batch_;
             request += threadCount_) {
            remote_offload::CpuDuState& state = *states_[request];
            state.RestoreValidatedTemplate(
                templates_[request], generation_ - 1);
            std::vector<std::vector<int32_t>> rows;
            rows.reserve(static_cast<size_t>(queryCounts_[request]));
            for (int64_t row = rowOffsets_[request];
                 row < rowOffsets_[request + 1]; ++row) {
                const int32_t* begin = topkInput_ +
                    row * remote_offload::kSparseCount;
                rows.emplace_back(begin, begin + remote_offload::kSparseCount);
            }
            remote_offload::CpuDuResult result = state.Update(
                rows, candidateLengths_[request], order_, false);
            for (size_t query = 0; query < result.destinationSlots.size();
                 ++query) {
                const int64_t row = rowOffsets_[request] +
                    static_cast<int64_t>(query);
                std::memcpy(topkSlots + row * remote_offload::kSparseCount,
                    result.destinationSlots[query].data(),
                    remote_offload::kSparseCount * sizeof(int32_t));
            }
            TORCH_CHECK(result.uniqueMissSourceIds.size() <=
                static_cast<size_t>(kUnionCapacity),
                "unique miss union exceeds the 16384-entry metadata ABI.");
            const int64_t unionOffset = request * kUnionCapacity;
            const size_t bytes = result.uniqueMissSourceIds.size() *
                sizeof(int32_t);
            if (bytes != 0) {
                std::memcpy(missSources + unionOffset,
                    result.uniqueMissSourceIds.data(), bytes);
                std::memcpy(missDestinations + unionOffset,
                    result.uniqueMissDestinationSlots.data(), bytes);
            }
            missCounts[request] = static_cast<int32_t>(
                result.uniqueMissSourceIds.size());
        }
    }

    const int64_t threadCount_;
    const int64_t firstCpu_;
    std::vector<std::thread> workers_;
    std::atomic<bool> stop_{false};
    std::atomic<uint64_t> taskSequence_{0};
    std::atomic<int64_t> readyWorkers_{0};
    std::atomic<int64_t> completedWorkers_{0};
    std::mutex runMutex_;
    std::mutex errorMutex_;
    std::exception_ptr workerError_;
    std::exception_ptr initializationError_;

    std::vector<std::vector<int32_t>> templates_;
    std::vector<std::unique_ptr<remote_offload::CpuDuState>> states_;
    std::vector<int32_t> candidateLengths_;
    std::vector<int32_t> queryCounts_;
    std::vector<int64_t> rowOffsets_;
    at::Tensor output_;
    int64_t batch_{0};
    int64_t topkElements_{0};
    int64_t unionElements_{0};

    const int32_t* topkInput_{nullptr};
    uint64_t generation_{0};
    remote_offload::DuOutputOrder order_{
        remote_offload::DuOutputOrder::kHitsThenMisses};
};

}  // namespace

void RegisterCpuDuBatchWorker(pybind11::module& module)
{
    py::class_<CpuDuBatchWorkerRuntime>(module, "CpuDuBatchWorkerRuntime")
        .def(py::init<int64_t, int64_t>(),
            py::arg("thread_count"), py::arg("first_cpu") = -1)
        .def("register_states", &CpuDuBatchWorkerRuntime::RegisterStates,
            py::arg("initial_states"), py::arg("cache_budgets"),
            py::arg("candidate_lengths"), py::arg("query_counts"))
        .def("run", &CpuDuBatchWorkerRuntime::Run,
            py::arg("topk_indices"), py::arg("generation"),
            py::arg("hits_first") = true)
        .def_property_readonly(
            "thread_count", &CpuDuBatchWorkerRuntime::thread_count)
        .def_property_readonly(
            "batch_size", &CpuDuBatchWorkerRuntime::batch_size)
        .def_property_readonly(
            "topk_elements", &CpuDuBatchWorkerRuntime::topk_elements)
        .def_property_readonly(
            "union_capacity", &CpuDuBatchWorkerRuntime::union_capacity);
}

}  // namespace custom
