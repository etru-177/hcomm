#include <limits>
#include <string>
#include <tuple>

#include <torch/library.h>

#include "ops_common.h"

namespace custom {
bool npu_hcomm_kvcache_pool_get_default_remote_attention_context(
    at::Tensor& staging, at::Tensor& completion,
    uint64_t& generation);

namespace {
constexpr int64_t kBlockSize = 128;
constexpr int64_t kKpeDim = 64;
constexpr int64_t kCkvDim = 512;
constexpr int64_t kSparseCount = 2048;
constexpr int64_t kMaxRegularLocalHeads = 64;
constexpr int64_t kSplitGLocalHeads = 128;

void CheckAttentionInputs(
    const at::Tensor& query,
    const at::Tensor& hbmKvCache,
    const at::Tensor& sparseSlots,
    const at::Tensor& cacheTokens,
    const at::Tensor& hbmBlockTable,
    const at::Tensor& actualQ,
    const at::Tensor& actualKv,
    const at::Tensor& queryRoPE,
    const at::Tensor& hbmKRoPE,
    const at::Tensor& copyCounts)
{
    TORCH_CHECK(
        query.dim() == 3 && query.size(0) > 0 &&
            query.size(1) > 0 &&
            (query.size(1) <= kMaxRegularLocalHeads ||
             query.size(1) == kSplitGLocalHeads) &&
            query.size(2) == kCkvDim,
        "A5 remote sparse-attention query must be [B,N,512], "
        "with 1 <= N <= 64 or N == 128.");
    const int64_t batch = query.size(0);
    const int64_t heads = query.size(1);
    TORCH_CHECK(
        hbmKvCache.dim() == 4 &&
            hbmKvCache.size(1) == kBlockSize &&
            hbmKvCache.size(2) == 1 &&
            hbmKvCache.size(3) == kCkvDim,
        "HBM CKV must be [blocks,128,1,512].");
    TORCH_CHECK(
        hbmKRoPE.dim() == 4 &&
            hbmKRoPE.size(0) == hbmKvCache.size(0) &&
            hbmKRoPE.size(1) == kBlockSize &&
            hbmKRoPE.size(2) == 1 &&
            hbmKRoPE.size(3) == kKpeDim,
        "HBM KPE must be [blocks,128,1,64].");
    TORCH_CHECK(
        queryRoPE.dim() == 3 &&
            queryRoPE.size(0) == batch &&
            queryRoPE.size(1) == heads &&
            queryRoPE.size(2) == kKpeDim,
        "Query RoPE must be [B,N,64].");
    TORCH_CHECK(
        sparseSlots.dim() == 3 &&
            sparseSlots.size(0) == batch &&
            sparseSlots.size(1) == 1 &&
            sparseSlots.size(2) == kSparseCount,
        "Sparse slots must be [B,1,2048].");
    TORCH_CHECK(
        cacheTokens.dim() == 1 &&
            hbmBlockTable.dim() == 2 &&
            actualQ.dim() == 1 &&
            actualKv.dim() == 1 &&
            copyCounts.dim() == 1 &&
            cacheTokens.size(0) == batch &&
            hbmBlockTable.size(0) == batch &&
            actualQ.size(0) == batch &&
            actualKv.size(0) == batch &&
            copyCounts.size(0) == batch &&
            hbmBlockTable.size(1) > 0,
        "Remote attention metadata must have one row per request.");

    const auto dtype = query.scalar_type();
    TORCH_CHECK(
        dtype == at::kBFloat16 || dtype == at::kHalf,
        "A5 remote sparse attention supports bf16/fp16.");
    for (const at::Tensor* tensor :
         {&hbmKvCache, &queryRoPE, &hbmKRoPE}) {
        TORCH_CHECK(
            tensor->scalar_type() == dtype,
            "All attention floating inputs must use one dtype.");
    }
    for (const at::Tensor* tensor :
         {&sparseSlots, &cacheTokens, &hbmBlockTable,
          &actualQ, &actualKv, &copyCounts}) {
        TORCH_CHECK(
            tensor->scalar_type() == at::kInt,
            "All remote attention metadata must be int32.");
    }
    for (const at::Tensor* tensor :
         {&query, &hbmKvCache, &sparseSlots, &cacheTokens,
          &hbmBlockTable, &actualQ, &actualKv, &queryRoPE,
          &hbmKRoPE, &copyCounts}) {
        TORCH_CHECK(
            tensor->device() == query.device() &&
                tensor->is_contiguous(),
            "All remote attention inputs must be contiguous "
            "tensors on one NPU.");
    }
}

void AddSparseAttentionAttrs(
    at_npu::native::OpCommand& cmd,
    double scaleValue)
{
    cmd.Attr("scale_value", static_cast<float>(scaleValue))
        .Attr("sparse_block_size", static_cast<int64_t>(1))
        .Attr("layout_query", std::string("TND"))
        .Attr("layout_kv", std::string("PA_BSND"))
        .Attr("sparse_mode", static_cast<int64_t>(3))
        .Attr("pre_tokens", std::numeric_limits<int64_t>::max())
        .Attr("next_tokens", std::numeric_limits<int64_t>::max())
        .Attr("attention_mode", static_cast<int64_t>(2))
        .Attr("return_softmax_lse", false)
        // Runtime generations live in the completion slot. Keep this
        // registration-only attribute constant so OpCommand can reuse its
        // compiled kernel cache across requests.
        .Attr("expected_generation", static_cast<int64_t>(1));
}

void CheckRemoteBuffers(
    const at::Tensor& query,
    const at::Tensor& staging,
    const at::Tensor& completion)
{
    TORCH_CHECK(
        staging.device() == query.device() &&
            completion.device() == query.device() &&
            staging.scalar_type() == at::kByte &&
            completion.scalar_type() == at::kByte &&
            staging.dim() == 1 &&
            completion.dim() == 1 &&
            completion.numel() >= 64 &&
            staging.is_contiguous() &&
            completion.is_contiguous(),
        "remote staging and completion must be contiguous "
        "one-dimensional uint8 tensors on the attention device.");
}

std::tuple<at::Tensor, at::Tensor, at::Tensor>
RunRemoteAttention(
    const at::Tensor& query,
    at::Tensor hbmKvCache,
    const at::Tensor& sparseSlots,
    const at::Tensor& cacheTokens,
    const at::Tensor& hbmBlockTable,
    const at::Tensor& actualQ,
    const at::Tensor& actualKv,
    const at::Tensor& queryRoPE,
    at::Tensor hbmKRoPE,
    const at::Tensor& staging,
    const at::Tensor& completion,
    const at::Tensor& copyCounts,
    double scaleValue)
{
    CheckAttentionInputs(
        query, hbmKvCache, sparseSlots, cacheTokens,
        hbmBlockTable, actualQ, actualKv, queryRoPE,
        hbmKRoPE, copyCounts);
    CheckRemoteBuffers(query, staging, completion);

    auto output = at::empty_like(query);
    auto softmaxMax = at::empty(
        {1}, query.options().dtype(at::kFloat));
    auto softmaxSum = at::empty(
        {1}, query.options().dtype(at::kFloat));
    at_npu::native::OpCommand cmd;
    cmd.Name("A5SparseAndTailAttentionAndRemoteScatterCopy")
        .Input(query)
        .Input(hbmKvCache)
        .Input(hbmKvCache)
        .Input(sparseSlots)
        .Input(hbmBlockTable)
        .Input(actualQ)
        .Input(actualKv)
        .Input(queryRoPE)
        .Input(hbmKRoPE)
        .Input(cacheTokens)
        .Input(staging)
        .Input(completion)
        .Input(copyCounts)
        .Output(output)
        .Output(softmaxMax)
        .Output(softmaxSum)
        .Output(hbmKRoPE)
        .Output(hbmKvCache);
    AddSparseAttentionAttrs(cmd, scaleValue);
    cmd.Run();
    return std::make_tuple(output, hbmKRoPE, hbmKvCache);
}
}  // namespace

std::tuple<at::Tensor, at::Tensor, at::Tensor>
npu_sparse_and_tail_attention_and_remote_scatter_copy_npu(
    const at::Tensor& query,
    at::Tensor hbmKvCache,
    const at::Tensor& sparseSlots,
    const at::Tensor& cacheTokens,
    const at::Tensor& hbmBlockTable,
    const at::Tensor& actualQ,
    const at::Tensor& actualKv,
    const at::Tensor& queryRoPE,
    at::Tensor hbmKRoPE,
    const at::Tensor& copyCounts,
    double scaleValue)
{
    at::Tensor staging;
    at::Tensor completion;
    uint64_t expectedGeneration = 0;
    TORCH_CHECK(
        npu_hcomm_kvcache_pool_get_default_remote_attention_context(
            staging, completion, expectedGeneration),
        "no pending raw-Hcomm token-gather generation for remote attention");
    return RunRemoteAttention(
        query, hbmKvCache, sparseSlots, cacheTokens,
        hbmBlockTable, actualQ, actualKv, queryRoPE,
        hbmKRoPE, staging, completion, copyCounts,
        scaleValue);
}

std::tuple<at::Tensor, at::Tensor, at::Tensor>
npu_sparse_and_tail_attention_and_remote_scatter_copy_ready_npu(
    const at::Tensor& query,
    at::Tensor hbmKvCache,
    const at::Tensor& sparseSlots,
    const at::Tensor& cacheTokens,
    const at::Tensor& hbmBlockTable,
    const at::Tensor& actualQ,
    const at::Tensor& actualKv,
    const at::Tensor& queryRoPE,
    at::Tensor hbmKRoPE,
    const at::Tensor& staging,
    const at::Tensor& completion,
    const at::Tensor& copyCounts,
    double scaleValue)
{
    return RunRemoteAttention(
        query, hbmKvCache, sparseSlots, cacheTokens,
        hbmBlockTable, actualQ, actualKv, queryRoPE,
        hbmKRoPE, staging, completion, copyCounts,
        scaleValue);
}

std::tuple<at::Tensor, at::Tensor, at::Tensor>
npu_sparse_and_tail_attention_and_remote_scatter_copy_meta(
    const at::Tensor& query,
    at::Tensor hbmKvCache,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    at::Tensor hbmKRoPE,
    const at::Tensor&,
    double)
{
    return std::make_tuple(
        at::empty_like(query), hbmKRoPE, hbmKvCache);
}

std::tuple<at::Tensor, at::Tensor, at::Tensor>
npu_sparse_and_tail_attention_and_remote_scatter_copy_ready_meta(
    const at::Tensor& query,
    at::Tensor hbmKvCache,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    at::Tensor hbmKRoPE,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    double)
{
    return std::make_tuple(
        at::empty_like(query), hbmKRoPE, hbmKvCache);
}
}  // namespace custom

TORCH_LIBRARY_IMPL(custom, PrivateUse1, m)
{
    m.impl(
        "npu_sparse_and_tail_attention_and_remote_scatter_copy",
        &custom::
            npu_sparse_and_tail_attention_and_remote_scatter_copy_npu);
    m.impl(
        "npu_sparse_and_tail_attention_and_remote_scatter_copy_ready",
        &custom::
            npu_sparse_and_tail_attention_and_remote_scatter_copy_ready_npu);
}

TORCH_LIBRARY_IMPL(custom, Meta, m)
{
    m.impl(
        "npu_sparse_and_tail_attention_and_remote_scatter_copy",
        &custom::
            npu_sparse_and_tail_attention_and_remote_scatter_copy_meta);
    m.impl(
        "npu_sparse_and_tail_attention_and_remote_scatter_copy_ready",
        &custom::
            npu_sparse_and_tail_attention_and_remote_scatter_copy_ready_meta);
}
