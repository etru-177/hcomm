// 标准化 LIM-MTP Torch adapter；上游来源见 VENDORED.md。

#include <tuple>

#include "c8_ops_common.h"

namespace nanovllm_dsa_a5_impl {
namespace {
constexpr int64_t kStandardMissCapacity = 16384;

void CheckBatchVector(
    const at::Tensor& tensor, int64_t batch, const char* name) {
  TORCH_CHECK(
      tensor.dim() == 1 && tensor.size(0) == batch &&
          tensor.scalar_type() == at::kInt,
      name, " must be int32 [B].");
}

void CheckStandardLim(
    const at::Tensor& index_weights,
    const at::Tensor& query_dequant_scale,
    const at::Tensor& query,
    const at::Tensor& index_key_dequant_scale,
    const at::Tensor& index_key_cache,
    const at::Tensor& index_block_table,
    const at::Tensor& actual_seq_lengths_query,
    const at::Tensor& actual_seq_lengths_key,
    const at::Tensor& offload_seq_lengths_key,
    const at::Tensor& num_cache_tokens,
    const at::Tensor& request_state,
    const at::Tensor& req_pool_entries,
    const at::Tensor& cache_slots_pool,
    const at::Tensor& topk_src_ids,
    const at::Tensor& topk_dst_slots,
    const at::Tensor& topk_miss_counts,
    const at::Tensor& miss_src_ids,
    const at::Tensor& miss_dst_slots,
    const at::Tensor& miss_counts) {
  TORCH_CHECK(
      query.dim() == 3 && query.size(0) > 0 &&
          (query.size(1) == 32 || query.size(1) == 64) &&
          query.size(2) == kIndexerDim,
      "standard LIM query must be [T,32|64,128].");
  TORCH_CHECK(
      query.scalar_type() == at::kBFloat16 ||
          query.scalar_type() == at::kHalf,
      "standard LIM query must be BF16 or FP16.");
  const int64_t total_queries = query.size(0);
  TORCH_CHECK(
      index_weights.dim() == 2 && index_weights.size(0) == total_queries &&
          index_weights.size(1) == query.size(1) &&
          index_weights.scalar_type() == query.scalar_type(),
      "standard LIM index_weights must match [T,H] and query dtype.");
  TORCH_CHECK(
      query_dequant_scale.sizes() == index_weights.sizes() &&
          query_dequant_scale.scalar_type() == at::kFloat,
      "standard LIM query_dequant_scale must be FP32 [T,H].");
  TORCH_CHECK(
      index_key_cache.dim() == 4 && index_key_cache.size(0) > 0 &&
          index_key_cache.size(1) == kBlockSize &&
          index_key_cache.size(2) == 1 &&
          index_key_cache.size(3) == kIndexerDim &&
          index_key_cache.scalar_type() == query.scalar_type(),
      "standard LIM index_key_cache must be [blocks,128,1,128] ",
      "and match query dtype.");
  TORCH_CHECK(
      index_key_dequant_scale.dim() == 3 &&
          index_key_dequant_scale.size(0) == index_key_cache.size(0) &&
          index_key_dequant_scale.size(1) == kBlockSize &&
          index_key_dequant_scale.size(2) == 1 &&
          index_key_dequant_scale.scalar_type() == at::kFloat,
      "standard LIM index_key_dequant_scale must be FP32 [blocks,128,1].");
  TORCH_CHECK(
      index_block_table.dim() == 2 && index_block_table.size(0) > 0 &&
          index_block_table.scalar_type() == at::kInt,
      "standard LIM index_block_table must be int32 [B,max_blocks].");
  const int64_t batch = index_block_table.size(0);
  CheckBatchVector(actual_seq_lengths_query, batch, "actual_seq_lengths_query");
  CheckBatchVector(actual_seq_lengths_key, batch, "actual_seq_lengths_key");
  CheckBatchVector(offload_seq_lengths_key, batch, "offload_seq_lengths_key");
  CheckBatchVector(num_cache_tokens, batch, "num_cache_tokens");
  CheckBatchVector(request_state, batch, "request_state");
  CheckBatchVector(req_pool_entries, batch, "req_pool_entries");
  TORCH_CHECK(
      cache_slots_pool.dim() == 2 && cache_slots_pool.size(0) > 0 &&
          cache_slots_pool.size(1) == index_block_table.size(1) * kBlockSize &&
          cache_slots_pool.scalar_type() == at::kInt,
      "standard LIM cache_slots_pool width must equal max_blocks*128.");
  TORCH_CHECK(
      topk_src_ids.dim() == 3 && topk_src_ids.size(0) == total_queries &&
          topk_src_ids.size(1) == 1 &&
          topk_src_ids.size(2) == kSparseCount &&
          topk_dst_slots.sizes() == topk_src_ids.sizes() &&
          topk_miss_counts.dim() == 1 &&
          topk_miss_counts.size(0) == total_queries &&
          miss_src_ids.dim() == 2 && miss_src_ids.size(0) == batch &&
          miss_src_ids.size(1) == kStandardMissCapacity &&
          miss_dst_slots.sizes() == miss_src_ids.sizes() &&
          miss_counts.dim() == 1 && miss_counts.size(0) == batch,
      "standard LIM output shapes do not match the standardized ABI.");
  for (const at::Tensor* tensor : {
           &topk_src_ids, &topk_dst_slots, &topk_miss_counts,
           &miss_src_ids, &miss_dst_slots, &miss_counts}) {
    TORCH_CHECK(tensor->scalar_type() == at::kInt,
                "standard LIM outputs must be int32.");
  }
  CheckOneDeviceAndContiguous(
      query,
      {&index_weights, &query_dequant_scale, &query,
       &index_key_dequant_scale, &index_key_cache, &index_block_table,
       &actual_seq_lengths_query, &actual_seq_lengths_key,
       &offload_seq_lengths_key, &num_cache_tokens, &request_state,
       &req_pool_entries, &cache_slots_pool, &topk_src_ids,
       &topk_dst_slots, &topk_miss_counts, &miss_src_ids,
       &miss_dst_slots, &miss_counts},
      "standard LIM-MTP");
}
}  // namespace

void FusedLiManageMtpStandardOutNpu(
    const at::Tensor& index_weights,
    const at::Tensor& query_dequant_scale,
    const at::Tensor& query,
    const at::Tensor& index_key_dequant_scale,
    const at::Tensor& index_key_cache,
    const at::Tensor& index_block_table,
    const at::Tensor& actual_seq_lengths_query,
    const at::Tensor& actual_seq_lengths_key,
    const at::Tensor& offload_seq_lengths_key,
    const at::Tensor& num_cache_tokens,
    const at::Tensor& request_state,
    const at::Tensor& req_pool_entries,
    at::Tensor cache_slots_pool,
    at::Tensor topk_src_ids,
    at::Tensor topk_dst_slots,
    at::Tensor topk_miss_counts,
    at::Tensor miss_src_ids,
    at::Tensor miss_dst_slots,
    at::Tensor miss_counts) {
  CheckStandardLim(
      index_weights, query_dequant_scale, query, index_key_dequant_scale,
      index_key_cache, index_block_table, actual_seq_lengths_query,
      actual_seq_lengths_key, offload_seq_lengths_key, num_cache_tokens,
      request_state, req_pool_entries, cache_slots_pool, topk_src_ids,
      topk_dst_slots, topk_miss_counts, miss_src_ids, miss_dst_slots,
      miss_counts);
  auto keepalive = std::make_tuple(
      index_weights, query_dequant_scale, query, index_key_dequant_scale,
      index_key_cache, index_block_table, actual_seq_lengths_query,
      actual_seq_lengths_key, offload_seq_lengths_key, num_cache_tokens,
      request_state, req_pool_entries, cache_slots_pool, topk_src_ids,
      topk_dst_slots, topk_miss_counts, miss_src_ids, miss_dst_slots,
      miss_counts);
  EXEC_NPU_CMD_ORDERED(
      aclnnNanovllmFusedLiManageMtp,
      keepalive,
      index_weights, query_dequant_scale, query, index_key_dequant_scale,
      index_key_cache, index_block_table, actual_seq_lengths_query,
      actual_seq_lengths_key, offload_seq_lengths_key, num_cache_tokens,
      request_state, req_pool_entries, cache_slots_pool, topk_src_ids,
      topk_dst_slots, topk_miss_counts, miss_src_ids, miss_dst_slots,
      miss_counts, cache_slots_pool);
}

void FusedLiManageMtpStandardOutMeta(
    const at::Tensor&, const at::Tensor&, const at::Tensor&,
    const at::Tensor&, const at::Tensor&, const at::Tensor&,
    const at::Tensor&, const at::Tensor&, const at::Tensor&,
    const at::Tensor&, const at::Tensor&, const at::Tensor&,
    at::Tensor, at::Tensor, at::Tensor, at::Tensor, at::Tensor,
    at::Tensor, at::Tensor) {}

}  // namespace nanovllm_dsa_a5_impl

TORCH_LIBRARY_IMPL(nanovllm_dsa, PrivateUse1, m) {
  m.impl(
      "fused_li_manage_mtp_standard_out",
      &nanovllm_dsa_a5_impl::FusedLiManageMtpStandardOutNpu);
}

TORCH_LIBRARY_IMPL(nanovllm_dsa, Meta, m) {
  m.impl(
      "fused_li_manage_mtp_standard_out",
      &nanovllm_dsa_a5_impl::FusedLiManageMtpStandardOutMeta);
}
