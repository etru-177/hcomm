#include <limits>
#include <string>
#include <tuple>

#include <torch/library.h>

#include "ops_common.h"

namespace custom {
namespace {
constexpr int64_t BLOCK_SIZE = 128;
constexpr int64_t K_ROPE_DIM = 64;
constexpr int64_t KV_CACHE_DIM = 512;
constexpr int64_t SPARSE_COUNT = 2048;
constexpr int64_t MAX_REGULAR_LOCAL_HEADS = 64;
constexpr int64_t SPLIT_G_LOCAL_HEADS = 128;

void CheckAttentionInputs(
    const at::Tensor& query,
    const at::Tensor& hbmKvCache,
    const at::Tensor& sparseSlots,
    const at::Tensor& cacheTokens,
    const at::Tensor& hbmBlockTable,
    const at::Tensor& actualQ,
    const at::Tensor& actualKv,
    const at::Tensor& queryRoPE,
    const at::Tensor& hbmKRoPE)
{
    TORCH_CHECK(
        query.dim() == 3 && query.size(0) > 0 &&
            query.size(1) > 0 &&
            (query.size(1) <= MAX_REGULAR_LOCAL_HEADS ||
             query.size(1) == SPLIT_G_LOCAL_HEADS) &&
            query.size(2) == KV_CACHE_DIM,
        "A5 sparse attention query must be [B,N,512], "
        "with 1 <= N <= 64 or N == 128.");
    const int64_t batch = query.size(0);
    const int64_t heads = query.size(1);
    TORCH_CHECK(
        hbmKvCache.dim() == 4 &&
            hbmKvCache.size(1) == BLOCK_SIZE &&
            hbmKvCache.size(2) == 1 &&
            hbmKvCache.size(3) == KV_CACHE_DIM,
        "HBM CKV must be [blocks,128,1,512].");
    TORCH_CHECK(
        hbmKRoPE.dim() == 4 &&
            hbmKRoPE.size(0) == hbmKvCache.size(0) &&
            hbmKRoPE.size(1) == BLOCK_SIZE &&
            hbmKRoPE.size(2) == 1 &&
            hbmKRoPE.size(3) == K_ROPE_DIM,
        "HBM KPE must be [blocks,128,1,64].");
    TORCH_CHECK(
        queryRoPE.dim() == 3 &&
            queryRoPE.size(0) == batch &&
            queryRoPE.size(1) == heads &&
            queryRoPE.size(2) == K_ROPE_DIM,
        "Query RoPE must be [B,N,64].");
    TORCH_CHECK(
        sparseSlots.dim() == 3 &&
            sparseSlots.size(0) == batch &&
            sparseSlots.size(1) == 1 &&
            sparseSlots.size(2) == SPARSE_COUNT,
        "Sparse slots must be [B,1,2048].");
    TORCH_CHECK(
        cacheTokens.dim() == 1 &&
            hbmBlockTable.dim() == 2 &&
            actualQ.dim() == 1 &&
            actualKv.dim() == 1 &&
            cacheTokens.size(0) == batch &&
            hbmBlockTable.size(0) == batch &&
            actualQ.size(0) == batch &&
            actualKv.size(0) == batch &&
            hbmBlockTable.size(1) > 0,
        "Attention metadata must have one row per decode request.");

    const auto dtype = query.scalar_type();
    TORCH_CHECK(
        dtype == at::kBFloat16 || dtype == at::kHalf,
        "A5 sparse attention supports bf16/fp16.");
    for (const at::Tensor* tensor :
         {&hbmKvCache, &queryRoPE, &hbmKRoPE}) {
        TORCH_CHECK(
            tensor->scalar_type() == dtype,
            "All attention floating inputs must use one dtype.");
    }
    for (const at::Tensor* tensor :
         {&sparseSlots, &cacheTokens, &hbmBlockTable,
          &actualQ, &actualKv}) {
        TORCH_CHECK(
            tensor->scalar_type() == at::kInt,
            "All attention metadata must be int32.");
    }
    for (const at::Tensor* tensor :
         {&query, &hbmKvCache, &sparseSlots, &cacheTokens,
          &hbmBlockTable, &actualQ, &actualKv,
          &queryRoPE, &hbmKRoPE}) {
        TORCH_CHECK(
            tensor->device() == query.device() &&
                tensor->is_contiguous(),
            "All attention inputs must be contiguous tensors "
            "on one NPU.");
    }
}

void AddSparseAttentionAttrs(
    at_npu::native::OpCommand& cmd,
    double scaleValue)
{
    cmd.Attr("scale_value", static_cast<float>(scaleValue))
        .Attr("sparse_block_size", static_cast<int64_t>(1))
        .Attr("layout_query", std::string("TND"))
        .Attr("layout_kv", std::string("PA_BSND"))
        .Attr("sparse_mode", static_cast<int64_t>(3))
        .Attr("pre_tokens", std::numeric_limits<int64_t>::max())
        .Attr("next_tokens", std::numeric_limits<int64_t>::max())
        .Attr("attention_mode", static_cast<int64_t>(2))
        .Attr("return_softmax_lse", false);
}

void CheckSourceInputs(
    const at::Tensor& query,
    const at::Tensor& dramKRoPE,
    const at::Tensor& dramKvCache,
    const at::Tensor& dramBlockTable,
    const at::Tensor& sourceTokenIds,
    const at::Tensor& copyCounts)
{
    const int64_t batch = query.size(0);
    TORCH_CHECK(
        dramKvCache.dim() == 3 &&
            dramKvCache.size(1) == BLOCK_SIZE &&
            dramKvCache.size(2) == KV_CACHE_DIM &&
            dramKRoPE.dim() == 3 &&
            dramKRoPE.size(0) == dramKvCache.size(0) &&
            dramKRoPE.size(1) == BLOCK_SIZE &&
            dramKRoPE.size(2) == K_ROPE_DIM,
        "DRAM CKV/KPE must be [blocks,128,512/64].");
    TORCH_CHECK(
        dramBlockTable.dim() == 2 &&
            dramBlockTable.size(0) == batch &&
            dramBlockTable.size(1) > 0 &&
            sourceTokenIds.dim() == 2 &&
            sourceTokenIds.size(0) == batch &&
            sourceTokenIds.size(1) == SPARSE_COUNT &&
            copyCounts.dim() == 1 &&
            copyCounts.size(0) == batch,
        "Fused DRAM metadata must be block_table[B,*], "
        "source_ids[B,2048], copy_counts[B].");
    for (const at::Tensor* tensor :
         {&dramKRoPE, &dramKvCache}) {
        TORCH_CHECK(
            tensor->scalar_type() == query.scalar_type(),
            "DRAM and HBM KV tensors must use one dtype.");
    }
    for (const at::Tensor* tensor :
         {&dramBlockTable, &sourceTokenIds, &copyCounts}) {
        TORCH_CHECK(
            tensor->scalar_type() == at::kInt,
            "Fused DRAM metadata must be int32.");
    }
    for (const at::Tensor* tensor :
         {&dramKRoPE, &dramKvCache, &dramBlockTable,
          &sourceTokenIds, &copyCounts}) {
        TORCH_CHECK(
            tensor->device() == query.device() &&
                tensor->is_contiguous(),
            "Fused DRAM inputs must be contiguous tensors "
            "on the same NPU device.");
    }
}
}  // namespace

std::tuple<at::Tensor, at::Tensor, at::Tensor>
npu_sparse_and_tail_attention_and_scatter_copy_npu(
    const at::Tensor& query,
    at::Tensor hbmKvCache,
    const at::Tensor& sparseSlots,
    const at::Tensor& cacheTokens,
    const at::Tensor& hbmBlockTable,
    const at::Tensor& actualQ,
    const at::Tensor& actualKv,
    const at::Tensor& queryRoPE,
    at::Tensor hbmKRoPE,
    const at::Tensor& dramKRoPE,
    const at::Tensor& dramKvCache,
    const at::Tensor& dramBlockTable,
    const at::Tensor& sourceTokenIds,
    const at::Tensor& copyCounts,
    double scaleValue)
{
    CheckAttentionInputs(
        query, hbmKvCache, sparseSlots, cacheTokens, hbmBlockTable,
        actualQ, actualKv, queryRoPE, hbmKRoPE);
    CheckSourceInputs(
        query, dramKRoPE, dramKvCache, dramBlockTable,
        sourceTokenIds, copyCounts);

    auto output = at::empty_like(query);
    // OpCommand requires every REQUIRED output to own storage on A5.
    auto softmaxMax = at::empty(
        {1}, query.options().dtype(at::kFloat));
    auto softmaxSum = at::empty(
        {1}, query.options().dtype(at::kFloat));
    at_npu::native::OpCommand cmd;
    cmd.Name("A5SparseAndTailAttentionAndScatterCopy")
        .Input(query)
        .Input(hbmKvCache)
        .Input(hbmKvCache)
        .Input(sparseSlots)
        .Input(hbmBlockTable)
        .Input(actualQ)
        .Input(actualKv)
        .Input(queryRoPE)
        .Input(hbmKRoPE)
        .Input(cacheTokens)
        .Input(dramKRoPE)
        .Input(dramKvCache)
        .Input(dramBlockTable)
        .Input(sourceTokenIds)
        .Input(copyCounts)
        .Output(output)
        .Output(softmaxMax)
        .Output(softmaxSum)
        .Output(hbmKRoPE)
        .Output(hbmKvCache);
    AddSparseAttentionAttrs(cmd, scaleValue);
    cmd.Run();
    return std::make_tuple(output, hbmKRoPE, hbmKvCache);
}

std::tuple<at::Tensor, at::Tensor, at::Tensor>
npu_sparse_and_tail_attention_and_scatter_copy_meta(
    const at::Tensor& query,
    at::Tensor hbmKvCache,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    at::Tensor hbmKRoPE,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    double)
{
    return std::make_tuple(
        at::empty_like(query), hbmKRoPE, hbmKvCache);
}
}  // namespace custom

TORCH_LIBRARY_IMPL(custom, PrivateUse1, m)
{
    m.impl(
        "npu_sparse_and_tail_attention_and_scatter_copy",
        &custom::npu_sparse_and_tail_attention_and_scatter_copy_npu);
}

TORCH_LIBRARY_IMPL(custom, Meta, m)
{
    m.impl(
        "npu_sparse_and_tail_attention_and_scatter_copy",
        &custom::npu_sparse_and_tail_attention_and_scatter_copy_meta);
}
