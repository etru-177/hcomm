// SPDX-License-Identifier: Apache-2.0

#include <climits>
#include <cstring>
#include <utility>
#include <vector>

#include <torch/extension.h>

#include "cpu_du.h"

namespace custom {
namespace {

void CheckCpuInt32(const at::Tensor& tensor, const char* name)
{
    TORCH_CHECK(tensor.device().is_cpu(), name, " must be a CPU tensor.");
    TORCH_CHECK(tensor.scalar_type() == at::kInt,
        name, " must have dtype int32.");
    TORCH_CHECK(tensor.is_contiguous(), name, " must be contiguous.");
}

at::Tensor VectorTensor(const std::vector<int32_t>& values,
    const at::TensorOptions& options)
{
    at::Tensor output = at::empty(
        {static_cast<int64_t>(values.size())}, options);
    if (!values.empty()) {
        std::memcpy(output.data_ptr<int32_t>(), values.data(),
            values.size() * sizeof(int32_t));
    }
    return output;
}

at::Tensor RowsTensor(const std::vector<std::vector<int32_t>>& rows,
    const at::TensorOptions& options)
{
    at::Tensor output = at::empty(
        {static_cast<int64_t>(rows.size()), 1,
         remote_offload::kSparseCount}, options);
    int32_t* destination = output.data_ptr<int32_t>();
    for (const auto& row : rows) {
        TORCH_CHECK(row.size() == remote_offload::kSparseCount,
            "CPU DU produced an invalid output row.");
        std::memcpy(destination, row.data(), row.size() * sizeof(int32_t));
        destination += row.size();
    }
    return output;
}

}  // namespace

pybind11::tuple RunCpuLiduDuUpdate(const at::Tensor& topkIndices,
    at::Tensor tokenToSlot, int64_t cacheBudget, int64_t candidateLength,
    uint64_t generation, bool hitsFirst, bool includeUnion)
{
    CheckCpuInt32(topkIndices, "topk_indices");
    CheckCpuInt32(tokenToSlot, "token_to_slot");
    TORCH_CHECK(tokenToSlot.dim() == 1 && tokenToSlot.numel() > 0,
        "token_to_slot must be a non-empty int32 CPU vector.");
    TORCH_CHECK(
        (topkIndices.dim() == 2 &&
         topkIndices.size(1) == remote_offload::kSparseCount) ||
        (topkIndices.dim() == 3 && topkIndices.size(1) == 1 &&
         topkIndices.size(2) == remote_offload::kSparseCount),
        "topk_indices must be int32 [Q,2048] or [Q,1,2048].");
    const int64_t queryCount = topkIndices.size(0);
    TORCH_CHECK(queryCount >= 1 &&
        queryCount <= remote_offload::kMaxMtpQueries,
        "CPU DU query count must be in [1,4].");
    TORCH_CHECK(cacheBudget >= 0 && cacheBudget <= INT32_MAX &&
        candidateLength >= 0 && candidateLength <= INT32_MAX,
        "CPU DU integer arguments exceed int32 range.");

    const int32_t* topk = topkIndices.data_ptr<int32_t>();
    std::vector<std::vector<int32_t>> rows(
        static_cast<size_t>(queryCount));
    for (int64_t query = 0; query < queryCount; ++query) {
        rows[static_cast<size_t>(query)].assign(
            topk + query * remote_offload::kSparseCount,
            topk + (query + 1) * remote_offload::kSparseCount);
    }
    std::vector<int32_t> state(
        tokenToSlot.data_ptr<int32_t>(),
        tokenToSlot.data_ptr<int32_t>() + tokenToSlot.numel());
    remote_offload::CpuDuState du(
        static_cast<int32_t>(cacheBudget), std::move(state), generation);
    const remote_offload::CpuDuResult result = du.Update(
        rows, static_cast<int32_t>(candidateLength),
        hitsFirst ? remote_offload::DuOutputOrder::kHitsThenMisses :
                    remote_offload::DuOutputOrder::kMissesThenHits,
        includeUnion);

    std::memcpy(tokenToSlot.data_ptr<int32_t>(),
        du.token_to_slot().data(),
        du.token_to_slot().size() * sizeof(int32_t));
    const at::TensorOptions options = tokenToSlot.options();
    pybind11::tuple outputs(includeUnion ? 15 : 9);
    outputs[0] = RowsTensor(result.sourceIds, options);
    outputs[1] = RowsTensor(result.destinationSlots, options);
    outputs[2] = RowsTensor(result.sourceRefs, options);
    outputs[3] = VectorTensor(result.missCounts, options);
    outputs[4] = VectorTensor(result.uniqueMissSourceIds, options);
    outputs[5] = VectorTensor(result.uniqueMissDestinationSlots, options);
    outputs[6] = VectorTensor(result.evictedSourceIds, options);
    outputs[7] = tokenToSlot;
    outputs[8] = pybind11::int_(result.generation);
    if (includeUnion) {
        outputs[9] = RowsTensor(result.unionOrdinals, options);
        outputs[10] = VectorTensor(result.unionHitSourceIds, options);
        outputs[11] = VectorTensor(result.unionHitSlots, options);
        outputs[12] = VectorTensor(result.unionHitRefCounts, options);
        outputs[13] = VectorTensor(result.unionHitQueryMasks, options);
        outputs[14] = VectorTensor(result.uniqueMissQueryMasks, options);
    }
    return outputs;
}

pybind11::tuple cpu_lidu_du_update(const at::Tensor& topkIndices,
    at::Tensor tokenToSlot, int64_t cacheBudget, int64_t candidateLength,
    uint64_t generation, bool hitsFirst)
{
    return RunCpuLiduDuUpdate(topkIndices, std::move(tokenToSlot),
        cacheBudget, candidateLength, generation, hitsFirst, false);
}

pybind11::tuple cpu_lidu_du_update_union(const at::Tensor& topkIndices,
    at::Tensor tokenToSlot, int64_t cacheBudget, int64_t candidateLength,
    uint64_t generation, bool hitsFirst)
{
    return RunCpuLiduDuUpdate(topkIndices, std::move(tokenToSlot),
        cacheBudget, candidateLength, generation, hitsFirst, true);
}

}  // namespace custom
