#include <torch/extension.h>
#include <torch/library.h>

#include <cstdint>
#include <string>
#include <vector>

namespace custom {
pybind11::tuple cpu_lidu_du_update(const at::Tensor& topkIndices,
    at::Tensor tokenToSlot, int64_t cacheBudget, int64_t candidateLength,
    uint64_t generation, bool hitsFirst);
pybind11::tuple cpu_lidu_du_update_union(const at::Tensor& topkIndices,
    at::Tensor tokenToSlot, int64_t cacheBudget, int64_t candidateLength,
    uint64_t generation, bool hitsFirst);
int32_t cpu_du_mte_copy_batch(uint64_t handle,
    const at::Tensor& sources, const at::Tensor& destinations,
    const at::Tensor& dataSizes, int64_t direction, uint64_t stream,
    bool asyncCopy);
int32_t cpu_du_mte_wait(uint64_t handle);
void RegisterCpuDuWorker(pybind11::module& module);
void RegisterCpuDuBatchWorker(pybind11::module& module);
void RegisterSwappedSlicePoller(pybind11::module& module);
void RegisterCpuDuImplicitDba(pybind11::module& module);
uint64_t npu_hcomm_kvcache_pool_connect(const std::string& deviceEid, const std::string& hostEid,
    int64_t devicePhyId, int64_t port, const std::string& channelName);
uint64_t npu_hcomm_kvcache_pool_connect_raw(const std::string& deviceEid, int64_t devicePhyId,
    const std::string& poolIp, int64_t controlPort, const at::Tensor& hbmKpe, const at::Tensor& hbmCkv,
    int64_t laneCount, int64_t hostPushPercent, bool hostTokenGather,
    bool scatterAfterGather, bool deferCompletionToAttention, int64_t ioBytes,
    int64_t maxSubIosPerWqe, int64_t fixedWqeBytes);
uint64_t npu_hcomm_kvcache_pool_connect_raw_packed(
    const std::string& deviceEid, int64_t devicePhyId,
    const std::string& poolIp, int64_t controlPort,
    const at::Tensor& packedHbmKv, int64_t laneCount,
    int64_t hostPushPercent, bool deferCompletionToAiv,
    int64_t maxSubIosPerWqe, int64_t fixedWqeBytes);
bool npu_hcomm_kvcache_pool_disconnect_raw(uint64_t channel);
std::vector<uint64_t> npu_hcomm_kvcache_pool_get_raw_context(uint64_t channel);
at::Tensor npu_hcomm_kvcache_pool_get_profile(uint64_t channel);
at::Tensor npu_hcomm_kvcache_pool_get_staging(uint64_t channel);
at::Tensor npu_hcomm_kvcache_pool_get_next_completion(uint64_t channel);
void npu_hcomm_kvcache_scatter_copy(const at::Tensor& hbmKpe, const at::Tensor& hbmCkv,
    const at::Tensor& hbmBlockTable, const at::Tensor& dramBlockTable,
    const at::Tensor& srcTokenIds, const at::Tensor& dstSlots, const at::Tensor& copyCounts,
    const at::Tensor& readyFlag, int64_t layerId);
void npu_hcomm_kvcache_io(const at::Tensor& packedHbmKv,
    const at::Tensor& hbmBlockTable, const at::Tensor& dramBlockTable,
    const at::Tensor& srcTokenIds, const at::Tensor& dstSlots,
    const at::Tensor& copyCounts, const at::Tensor& readyFlag,
    int64_t layerId);
void npu_hcomm_kvcache_local_scatter(const at::Tensor& hbmKpe, const at::Tensor& hbmCkv,
    const at::Tensor& hbmBlockTable, const at::Tensor& dramBlockTable,
    const at::Tensor& srcTokenIds, const at::Tensor& dstSlots, const at::Tensor& copyCounts,
    const at::Tensor& readyFlag, int64_t layerId);
void npu_hcomm_kvcache_bandwidth_probe(
    const at::Tensor& remoteGvas, int64_t transferBytes, int64_t mode, int64_t segments);
}

TORCH_LIBRARY_FRAGMENT(custom, m)
{
    m.def(
        "npu_kvcache_scatter_copy(Tensor(a!) hbm_k_rope, Tensor(b!) hbm_kv_cache, "
        "Tensor dram_k_rope, Tensor dram_kv_cache, Tensor hbm_block_table, Tensor dram_block_table, "
        "Tensor src_token_ids, Tensor dst_slots, Tensor copy_counts, "
        "Tensor(c!)? ready_flag=None, int layer_id=0) -> ()");
    m.def(
        "npu_kvcache_scatter_local_aiv(Tensor(a!) hbm_kpe, Tensor(b!) hbm_ckv, "
        "Tensor hbm_staging, Tensor hbm_block_table, Tensor src_token_ids, "
        "Tensor dst_slots, Tensor copy_counts) -> (Tensor(a!), Tensor(b!))");
    m.def(
        "npu_scatter_io_from_staging_c8(Tensor(a!) packed_hbm_kv, "
        "Tensor hbm_staging, Tensor completion, Tensor hbm_block_table, "
        "Tensor dst_slots, Tensor copy_counts) -> Tensor(a!)");
    m.def(
        "npu_sparse_and_tail_attention_and_scatter_copy("
        "Tensor query, Tensor(a!) hbm_kv_cache, Tensor sparse_slots, "
        "Tensor cache_tokens, Tensor hbm_block_table, "
        "Tensor actual_seq_lengths_query, Tensor actual_seq_lengths_kv, "
        "Tensor query_rope, Tensor(b!) hbm_k_rope, Tensor dram_k_rope, "
        "Tensor dram_kv_cache, Tensor dram_block_table, "
        "Tensor source_token_ids, Tensor copy_counts, float scale_value"
        ") -> (Tensor, Tensor(b!), Tensor(a!))");
    m.def(
        "npu_sparse_and_tail_attention_and_remote_scatter_copy("
        "Tensor query, Tensor(a!) hbm_kv_cache, Tensor sparse_slots, "
        "Tensor cache_tokens, Tensor hbm_block_table, "
        "Tensor actual_seq_lengths_query, Tensor actual_seq_lengths_kv, "
        "Tensor query_rope, Tensor(b!) hbm_k_rope, "
        "Tensor copy_counts, float scale_value"
        ") -> (Tensor, Tensor(b!), Tensor(a!))");
    m.def(
        "npu_sparse_and_tail_attention_and_remote_scatter_copy_ready("
        "Tensor query, Tensor(a!) hbm_kv_cache, Tensor sparse_slots, "
        "Tensor cache_tokens, Tensor hbm_block_table, "
        "Tensor actual_seq_lengths_query, Tensor actual_seq_lengths_kv, "
        "Tensor query_rope, Tensor(b!) hbm_k_rope, "
        "Tensor staging, Tensor completion, Tensor copy_counts, "
        "float scale_value"
        ") -> (Tensor, Tensor(b!), Tensor(a!))");
}

// C8 decode-offload operators vendored into this extension.  Keep the
// upstream nanovllm_dsa ABI so existing graph callers do not need adapters.
TORCH_LIBRARY_FRAGMENT(nanovllm_dsa, m)
{
    m.def(
        "quant_lightning_indexer_c8_out("
        "Tensor query, Tensor key, Tensor weights, "
        "Tensor query_dequant_scale, Tensor key_dequant_scale, "
        "Tensor actual_seq_lengths_query, "
        "Tensor actual_seq_lengths_key, Tensor block_table, "
        "Tensor(a!) sparse_indices_out) -> Tensor(a!)");
    m.def(
        "fused_li_manage_mtp_standard_out("
        "Tensor index_weights, Tensor query_dequant_scale, Tensor query, "
        "Tensor index_key_dequant_scale, Tensor index_key_cache, "
        "Tensor index_block_table, Tensor actual_seq_lengths_query, "
        "Tensor actual_seq_lengths_key, Tensor offload_seq_lengths_key, "
        "Tensor num_cache_tokens, Tensor request_state, "
        "Tensor req_pool_entries, Tensor(a!) cache_slots_pool, "
        "Tensor(b!) topk_src_ids, Tensor(c!) topk_dst_slots, "
        "Tensor(d!) topk_miss_counts, Tensor(e!) miss_src_ids, "
        "Tensor(f!) miss_dst_slots, Tensor(g!) miss_counts) -> ()");
    m.def(
        "fused_li_manage_c8(Tensor query, Tensor key, Tensor weights, "
        "Tensor query_dequant_scale, Tensor key_dequant_scale, "
        "Tensor actual_seq_lengths_query, Tensor req_pool_entries, "
        "Tensor(a!) cache_slots_pool, Tensor cache_tokens, "
        "Tensor candidate_lens, Tensor block_table) "
        "-> (Tensor, Tensor, Tensor, Tensor(a!))");
    m.def(
        "fused_li_manage_c8_out(Tensor query, Tensor key, "
        "Tensor weights, Tensor query_dequant_scale, "
        "Tensor key_dequant_scale, Tensor actual_seq_lengths_query, "
        "Tensor req_pool_entries, Tensor(a!) cache_slots_pool, "
        "Tensor cache_tokens, Tensor candidate_lens, "
        "Tensor block_table, Tensor(b!) source_ids, "
        "Tensor(c!) destination_slots, Tensor(d!) miss_counts) "
        "-> (Tensor(b!), Tensor(c!), Tensor(d!), Tensor(a!))");
    m.def(
        "fused_li_manage_mtp_c8("
        "Tensor query, Tensor key, Tensor weights, "
        "Tensor query_dequant_scale, Tensor key_dequant_scale, "
        "Tensor actual_seq_lengths_query, Tensor req_pool_entries, "
        "Tensor(a!) cache_slots_pool, Tensor cache_tokens, "
        "Tensor candidate_lens, Tensor block_table) "
        "-> (Tensor, Tensor, Tensor, Tensor, Tensor(a!))");
    m.def(
        "fused_li_manage_mtp_c8_out("
        "Tensor query, Tensor key, Tensor weights, "
        "Tensor query_dequant_scale, Tensor key_dequant_scale, "
        "Tensor actual_seq_lengths_query, Tensor req_pool_entries, "
        "Tensor(a!) cache_slots_pool, Tensor cache_tokens, "
        "Tensor candidate_lens, Tensor block_table, "
        "Tensor(f!) topk_source_ids, "
        "Tensor(b!) topk_destination_slots, "
        "Tensor(g!) topk_miss_counts, Tensor(c!) miss_source_ids, "
        "Tensor(d!) miss_destination_slots, Tensor(e!) miss_counts) "
        "-> (Tensor(b!), Tensor(c!), Tensor(d!), Tensor(e!), Tensor(a!))");
    m.def(
        "kvcache_scatter_copy_c8(Tensor(a!) hbm_kv_bytes, "
        "Tensor dram_kv_bytes, Tensor hbm_block_table, "
        "Tensor dram_block_table, Tensor source_token_ids, "
        "Tensor destination_slots, Tensor copy_counts, "
        "Tensor cache_tokens, Tensor candidate_lens, "
        "Tensor actual_seq_lengths_kv, int max_tail_tokens) "
        "-> (Tensor(a!), Tensor, Tensor)");
    m.def(
        "kvcache_scatter_copy_c8_out(Tensor(a!) hbm_kv_bytes, "
        "Tensor dram_kv_bytes, Tensor hbm_block_table, "
        "Tensor dram_block_table, Tensor source_token_ids, "
        "Tensor destination_slots, Tensor copy_counts, "
        "Tensor cache_tokens, Tensor candidate_lens, "
        "Tensor actual_seq_lengths_kv, int max_tail_tokens, "
        "Tensor(b!) attention_slots, Tensor(c!) resident_seq_lengths) "
        "-> (Tensor(a!), Tensor(b!), Tensor(c!))");
    m.def(
        "sparse_tail_attention_c8("
        "Tensor query, Tensor packed_kv, Tensor sparse_and_tail_slots, "
        "Tensor block_table, Tensor actual_seq_lengths_query, "
        "Tensor resident_seq_lengths, float scale_value) -> Tensor");
    m.def(
        "sparse_tail_attention_mtp_c8("
        "Tensor query, Tensor packed_kv, Tensor sparse_and_tail_slots, "
        "Tensor block_table, Tensor actual_seq_lengths_query, "
        "Tensor resident_seq_lengths, float scale_value) -> Tensor");
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m)
{
    custom::RegisterCpuDuWorker(m);
    custom::RegisterCpuDuBatchWorker(m);
    custom::RegisterSwappedSlicePoller(m);
    custom::RegisterCpuDuImplicitDba(m);
    m.def("cpu_lidu_du_update", &custom::cpu_lidu_du_update,
        pybind11::arg("topk_indices"), pybind11::arg("token_to_slot"),
        pybind11::arg("cache_budget"), pybind11::arg("candidate_length"),
        pybind11::arg("generation") = 0,
        pybind11::arg("hits_first") = true);
    m.def("cpu_lidu_du_update_union", &custom::cpu_lidu_du_update_union,
        pybind11::arg("topk_indices"), pybind11::arg("token_to_slot"),
        pybind11::arg("cache_budget"), pybind11::arg("candidate_length"),
        pybind11::arg("generation") = 0,
        pybind11::arg("hits_first") = true);
    m.def("cpu_du_mte_copy_batch", &custom::cpu_du_mte_copy_batch,
        pybind11::arg("handle"), pybind11::arg("sources"),
        pybind11::arg("destinations"), pybind11::arg("data_sizes"),
        pybind11::arg("direction"), pybind11::arg("stream") = 0,
        pybind11::arg("async_copy") = true);
    m.def("cpu_du_mte_wait", &custom::cpu_du_mte_wait,
        pybind11::arg("handle"));
    m.def("npu_hcomm_kvcache_pool_connect", &custom::npu_hcomm_kvcache_pool_connect,
        pybind11::arg("device_eid"), pybind11::arg("host_eid"), pybind11::arg("device_phy_id"),
        pybind11::arg("port") = 60001, pybind11::arg("channel_name") = "kvcache_pool");
    m.def("npu_hcomm_kvcache_pool_connect_raw", &custom::npu_hcomm_kvcache_pool_connect_raw,
        pybind11::arg("device_eid"), pybind11::arg("device_phy_id"), pybind11::arg("pool_ip"),
        pybind11::arg("control_port"), pybind11::arg("hbm_kpe"), pybind11::arg("hbm_ckv"),
        pybind11::arg("lane_count") = 1, pybind11::arg("host_push_percent") = 50,
        pybind11::arg("host_token_gather") = false,
        pybind11::arg("scatter_after_gather") = true,
        pybind11::arg("defer_completion_to_attention") = false,
        pybind11::arg("io_bytes") = 1152,
        pybind11::arg("max_subios_per_wqe") = 0,
        pybind11::arg("fixed_wqe_bytes") = 0);
    m.def("npu_hcomm_kvcache_pool_connect_raw_packed",
        &custom::npu_hcomm_kvcache_pool_connect_raw_packed,
        pybind11::arg("device_eid"), pybind11::arg("device_phy_id"),
        pybind11::arg("pool_ip"), pybind11::arg("control_port"),
        pybind11::arg("packed_hbm_kv"), pybind11::arg("lane_count") = 4,
        pybind11::arg("host_push_percent") = 100,
        pybind11::arg("defer_completion_to_aiv") = false,
        pybind11::arg("max_subios_per_wqe") = 0,
        pybind11::arg("fixed_wqe_bytes") = 0);
    m.def("npu_hcomm_kvcache_pool_disconnect_raw",
        &custom::npu_hcomm_kvcache_pool_disconnect_raw,
        pybind11::arg("channel"));
    m.def("npu_hcomm_kvcache_pool_get_raw_context", &custom::npu_hcomm_kvcache_pool_get_raw_context,
        pybind11::arg("channel"));
    m.def("npu_hcomm_kvcache_pool_get_profile", &custom::npu_hcomm_kvcache_pool_get_profile,
        pybind11::arg("channel"));
    m.def("npu_hcomm_kvcache_pool_get_staging", &custom::npu_hcomm_kvcache_pool_get_staging,
        pybind11::arg("channel"));
    m.def("npu_hcomm_kvcache_pool_get_next_completion",
        &custom::npu_hcomm_kvcache_pool_get_next_completion,
        pybind11::arg("channel"));
    m.def("npu_hcomm_kvcache_scatter_copy", &custom::npu_hcomm_kvcache_scatter_copy,
        pybind11::arg("hbm_kpe"), pybind11::arg("hbm_ckv"),
        pybind11::arg("hbm_block_table"), pybind11::arg("dram_block_table"),
        pybind11::arg("src_token_ids"), pybind11::arg("dst_slots"),
        pybind11::arg("copy_counts"), pybind11::arg("ready_flag"),
        pybind11::arg("layer_id") = 0);
    m.def("npu_hcomm_kvcache_io", &custom::npu_hcomm_kvcache_io,
        pybind11::arg("packed_hbm_kv"),
        pybind11::arg("hbm_block_table"),
        pybind11::arg("dram_block_table"),
        pybind11::arg("src_token_ids"), pybind11::arg("dst_slots"),
        pybind11::arg("copy_counts"), pybind11::arg("ready_flag"),
        pybind11::arg("layer_id") = 0);
    m.def("npu_hcomm_kvcache_local_scatter", &custom::npu_hcomm_kvcache_local_scatter,
        pybind11::arg("hbm_kpe"), pybind11::arg("hbm_ckv"),
        pybind11::arg("hbm_block_table"), pybind11::arg("dram_block_table"),
        pybind11::arg("src_token_ids"), pybind11::arg("dst_slots"),
        pybind11::arg("copy_counts"), pybind11::arg("ready_flag"),
        pybind11::arg("layer_id") = 0);
    m.def("npu_hcomm_kvcache_bandwidth_probe", &custom::npu_hcomm_kvcache_bandwidth_probe,
        pybind11::arg("remote_gvas"), pybind11::arg("transfer_bytes"),
        pybind11::arg("mode"), pybind11::arg("segments") = 1);
}
