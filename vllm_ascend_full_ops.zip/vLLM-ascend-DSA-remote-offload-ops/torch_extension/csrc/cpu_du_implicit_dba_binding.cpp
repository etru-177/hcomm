// SPDX-License-Identifier: Apache-2.0

#include <array>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <climits>
#include <cstdint>
#include <cstring>
#include <exception>
#include <memory>
#include <mutex>
#include <stdexcept>
#include <thread>
#include <utility>
#include <vector>

#if defined(__linux__)
#include <pthread.h>
#include <sched.h>
#include <sys/mman.h>
#include <unistd.h>
#endif

#include <torch/extension.h>

#include "cpu_du.h"

namespace custom {
namespace {

namespace py = pybind11;

constexpr int64_t kBatch = 32;
constexpr int64_t kQueries = 4;
constexpr int64_t kRows = kBatch * kQueries;
constexpr int64_t kTopk = remote_offload::kSparseCount;
constexpr int64_t kIoUbatch = 16;
constexpr int64_t kIoGroups = kBatch / kIoUbatch;
constexpr int64_t kHcommCapacity = 16384;
constexpr int64_t kUnionCapacity =
    remote_offload::kSparseCount * remote_offload::kMaxMtpQueries;
constexpr int32_t kInvalidTopk = -1;

inline void CpuRelax()
{
#if defined(__aarch64__)
    asm volatile("yield" ::: "memory");
#elif defined(__x86_64__) || defined(__i386__)
    asm volatile("pause" ::: "memory");
#else
    std::this_thread::yield();
#endif
}

uint64_t NowNs()
{
    return static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count());
}

void CheckHostMappedRange(const void* pointer, size_t bytes, const char* name)
{
#if defined(__linux__)
    TORCH_CHECK(pointer != nullptr && bytes != 0, name, " is empty.");
    const long pageSizeValue = sysconf(_SC_PAGESIZE);
    TORCH_CHECK(pageSizeValue > 0, "failed to query host page size.");
    const uintptr_t pageSize = static_cast<uintptr_t>(pageSizeValue);
    const uintptr_t address = reinterpret_cast<uintptr_t>(pointer);
    TORCH_CHECK(bytes <= UINTPTR_MAX - address,
        name, " overflows the host address space.");
    const uintptr_t begin = address & ~(pageSize - 1);
    const uintptr_t last = address + bytes;
    TORCH_CHECK(pageSize - 1 <= UINTPTR_MAX - last,
        name, " overflows the host address space.");
    const uintptr_t end = (last + pageSize - 1) & ~(pageSize - 1);
    std::vector<unsigned char> residency(
        static_cast<size_t>((end - begin) / pageSize));
    errno = 0;
    const int result = mincore(
        reinterpret_cast<void*>(begin), end - begin, residency.data());
    TORCH_CHECK(result == 0,
        name, " is not backed by a host-readable swapped-memory VA: ",
        std::strerror(errno));
#else
    (void)pointer;
    (void)bytes;
    (void)name;
    TORCH_CHECK(false,
        "implicit DBA swapped-memory polling is supported only on Linux.");
#endif
}

void CheckCpuInt32(const at::Tensor& tensor, const char* name)
{
    TORCH_CHECK(tensor.device().is_cpu(), name, " must be on CPU.");
    TORCH_CHECK(tensor.scalar_type() == at::kInt && tensor.is_contiguous(),
        name, " must be contiguous int32.");
}

void CheckSwappedInt32(const at::Tensor& tensor, const char* name)
{
    TORCH_CHECK(tensor.device().type() == c10::DeviceType::PrivateUse1,
        name, " must be a PrivateUse1 swapped-memory tensor.");
    TORCH_CHECK(tensor.scalar_type() == at::kInt && tensor.is_contiguous() &&
        tensor.numel() > 0, name, " must be non-empty contiguous int32.");
    CheckHostMappedRange(tensor.data_ptr<int32_t>(),
        static_cast<size_t>(tensor.numel()) * sizeof(int32_t), name);
}

void CheckShape(const at::Tensor& tensor,
    std::initializer_list<int64_t> shape, const char* name)
{
    TORCH_CHECK(tensor.dim() == static_cast<int64_t>(shape.size()),
        name, " has an unexpected rank.");
    int64_t dimension = 0;
    for (const int64_t expected : shape) {
        TORCH_CHECK(expected < 0 || tensor.size(dimension) == expected,
            name, " has an unexpected shape at dimension ", dimension, ".");
        ++dimension;
    }
}

struct StateAux {
    std::vector<int32_t> freeSlots;
    std::vector<int32_t> residentTokens;
};

struct WorkerScratch {
    std::array<std::array<int32_t, kTopk>, kQueries> hits{};
    std::array<std::array<int32_t, kTopk>, kQueries> misses{};
    std::array<int32_t, kQueries> hitCounts{};
    std::array<int32_t, kQueries> missCounts{};

    std::array<int32_t, kUnionCapacity> unionHitTokens{};
    std::array<int32_t, kUnionCapacity> unionHitSlots{};
    std::array<int32_t, kUnionCapacity> unionHitRefs{};
    std::array<int32_t, kUnionCapacity> unionHitMasks{};
    std::array<int32_t, kUnionCapacity> unionMissTokens{};
    std::array<int32_t, kUnionCapacity> unionMissSlots{};
    std::array<int32_t, kUnionCapacity> unionMissVictims{};
    std::array<int32_t, kUnionCapacity> unionMissMasks{};
    std::array<int32_t, kUnionCapacity> unionMissOwnerQuery{};
    int32_t unionHitCount{0};
    int32_t unionMissCount{0};

    std::vector<uint32_t> tokenEpoch;
    std::vector<int32_t> tokenOrdinal;
    std::vector<uint32_t> protectedEpoch;
};

class SwappedCpuDuImplicitDbaRuntime {
public:
    explicit SwappedCpuDuImplicitDbaRuntime(int64_t firstCpu)
        : firstCpu_(CheckFirstCpu(firstCpu))
    {
    }

    ~SwappedCpuDuImplicitDbaRuntime()
    {
        JoinWorkers();
    }

    SwappedCpuDuImplicitDbaRuntime(
        const SwappedCpuDuImplicitDbaRuntime&) = delete;
    SwappedCpuDuImplicitDbaRuntime& operator=(
        const SwappedCpuDuImplicitDbaRuntime&) = delete;

    void RegisterPipeline(
        const at::Tensor& topkRing,
        const at::Tensor& initialStates,
        const at::Tensor& cacheBudgets,
        const at::Tensor& candidateLengths,
        const at::Tensor& sourceIds,
        const at::Tensor& attentionSlots,
        const at::Tensor& sourceRefs,
        const at::Tensor& queryMissCounts,
        const at::Tensor& hcommSources,
        const at::Tensor& hcommDestinations,
        const at::Tensor& hcommCounts,
        const at::Tensor& evictedSourceIds,
        const at::Tensor& unionMissMasks,
        const at::Tensor& unionHitSourceIds,
        const at::Tensor& unionHitSlots,
        const at::Tensor& unionHitRefCounts,
        const at::Tensor& unionHitMasks,
        const at::Tensor& unionHitCounts,
        const at::Tensor& unionOrdinals,
        const at::Tensor& readyFlags)
    {
        std::lock_guard<std::mutex> lock(mutex_);
        TORCH_CHECK(!started_, "cannot register after runtime start.");

        CheckSwappedInt32(topkRing, "topk_ring");
        CheckCpuInt32(initialStates, "initial_states");
        CheckCpuInt32(cacheBudgets, "cache_budgets");
        CheckCpuInt32(candidateLengths, "candidate_lengths");
        for (const auto& item : std::array<std::pair<const at::Tensor*, const char*>, 16>{
                 std::make_pair(&sourceIds, "source_ids"),
                 std::make_pair(&attentionSlots, "attention_slots"),
                 std::make_pair(&sourceRefs, "source_refs"),
                 std::make_pair(&queryMissCounts, "query_miss_counts"),
                 std::make_pair(&hcommSources, "hcomm_sources"),
                 std::make_pair(&hcommDestinations, "hcomm_destinations"),
                 std::make_pair(&hcommCounts, "hcomm_counts"),
                 std::make_pair(&evictedSourceIds, "evicted_source_ids"),
                 std::make_pair(&unionMissMasks, "union_miss_masks"),
                 std::make_pair(&unionHitSourceIds, "union_hit_source_ids"),
                 std::make_pair(&unionHitSlots, "union_hit_slots"),
                 std::make_pair(&unionHitRefCounts, "union_hit_ref_counts"),
                 std::make_pair(&unionHitMasks, "union_hit_masks"),
                 std::make_pair(&unionHitCounts, "union_hit_counts"),
                 std::make_pair(&unionOrdinals, "union_ordinals"),
                 std::make_pair(&readyFlags, "ready_flags")}) {
            CheckSwappedInt32(*item.first, item.second);
        }

        CheckShape(topkRing, {-1, kRows, 1, kTopk}, "topk_ring");
        generations_ = topkRing.size(0);
        TORCH_CHECK(generations_ > 0 &&
            generations_ < static_cast<int64_t>(UINT32_MAX),
            "topk_ring generation count is out of range.");
        CheckShape(initialStates, {generations_, kBatch, -1}, "initial_states");
        sourceCapacity_ = initialStates.size(2);
        TORCH_CHECK(sourceCapacity_ > 0 && sourceCapacity_ <= INT32_MAX,
            "initial state capacity is out of range.");
        CheckShape(cacheBudgets, {kBatch}, "cache_budgets");
        CheckShape(candidateLengths, {kBatch}, "candidate_lengths");
        CheckShape(sourceIds, {kRows, kTopk}, "source_ids");
        TORCH_CHECK(attentionSlots.dim() == 3 &&
            attentionSlots.size(0) == kRows && attentionSlots.size(1) == 1 &&
            attentionSlots.size(2) >= kTopk,
            "attention_slots must be [128,1,width>=2048].");
        attentionWidth_ = attentionSlots.size(2);
        CheckShape(sourceRefs, {kRows, kTopk}, "source_refs");
        CheckShape(queryMissCounts, {kRows}, "query_miss_counts");
        CheckShape(hcommSources,
            {kBatch, 1, kHcommCapacity}, "hcomm_sources");
        CheckShape(hcommDestinations,
            {kBatch, 1, kHcommCapacity}, "hcomm_destinations");
        CheckShape(hcommCounts, {kBatch}, "hcomm_counts");
        CheckShape(evictedSourceIds,
            {kBatch, kUnionCapacity}, "evicted_source_ids");
        CheckShape(unionMissMasks,
            {kBatch, kUnionCapacity}, "union_miss_masks");
        CheckShape(unionHitSourceIds,
            {kBatch, kUnionCapacity}, "union_hit_source_ids");
        CheckShape(unionHitSlots,
            {kBatch, kUnionCapacity}, "union_hit_slots");
        CheckShape(unionHitRefCounts,
            {kBatch, kUnionCapacity}, "union_hit_ref_counts");
        CheckShape(unionHitMasks,
            {kBatch, kUnionCapacity}, "union_hit_masks");
        CheckShape(unionHitCounts, {kBatch}, "union_hit_counts");
        CheckShape(unionOrdinals,
            {kRows, kTopk}, "union_ordinals");
        CheckShape(readyFlags,
            {generations_, kIoGroups}, "ready_flags");

        const int32_t* budgets = cacheBudgets.data_ptr<int32_t>();
        const int32_t* candidates = candidateLengths.data_ptr<int32_t>();
        cacheBudgets_.assign(budgets, budgets + kBatch);
        candidateLengths_.assign(candidates, candidates + kBatch);
        stateAux_.clear();
        stateAux_.resize(static_cast<size_t>(generations_ * kBatch));
        const int32_t* states = initialStates.data_ptr<int32_t>();
        std::vector<uint8_t> occupied;
        for (int64_t request = 0; request < kBatch; ++request) {
            TORCH_CHECK(cacheBudgets_[request] == kUnionCapacity,
                "implicit DBA requires cache_budget=8192.");
            TORCH_CHECK(candidateLengths_[request] == sourceCapacity_,
                "candidate length must equal state capacity.");
        }
        for (int64_t generation = 0; generation < generations_; ++generation) {
            for (int64_t request = 0; request < kBatch; ++request) {
                const int32_t budget = cacheBudgets_[request];
                occupied.assign(static_cast<size_t>(budget), 0);
                StateAux& aux = stateAux_[StateIndex(generation, request)];
                aux.freeSlots.clear();
                aux.residentTokens.clear();
                aux.freeSlots.reserve(static_cast<size_t>(budget));
                aux.residentTokens.reserve(static_cast<size_t>(budget));
                const int32_t* state = states +
                    (generation * kBatch + request) * sourceCapacity_;
                for (int64_t token = 0; token < sourceCapacity_; ++token) {
                    const int32_t slot = state[token];
                    TORCH_CHECK(slot == -1 || (slot >= 0 && slot < budget),
                        "initial state contains an invalid slot.");
                    if (slot < 0) {
                        continue;
                    }
                    TORCH_CHECK(occupied[static_cast<size_t>(slot)] == 0,
                        "initial state contains duplicate slots.");
                    occupied[static_cast<size_t>(slot)] = 1;
                    aux.residentTokens.push_back(static_cast<int32_t>(token));
                }
                for (int32_t slot = 0; slot < budget; ++slot) {
                    if (occupied[static_cast<size_t>(slot)] == 0) {
                        aux.freeSlots.push_back(slot);
                    }
                }
            }
        }

        topkRing_ = topkRing;
        initialStates_ = initialStates;
        sourceIds_ = sourceIds;
        attentionSlots_ = attentionSlots;
        sourceRefs_ = sourceRefs;
        queryMissCounts_ = queryMissCounts;
        hcommSources_ = hcommSources;
        hcommDestinations_ = hcommDestinations;
        hcommCounts_ = hcommCounts;
        evictedSourceIds_ = evictedSourceIds;
        unionMissMasks_ = unionMissMasks;
        unionHitSourceIds_ = unionHitSourceIds;
        unionHitSlots_ = unionHitSlots;
        unionHitRefCounts_ = unionHitRefCounts;
        unionHitMasks_ = unionHitMasks;
        unionHitCounts_ = unionHitCounts;
        unionOrdinals_ = unionOrdinals;
        readyFlags_ = readyFlags;

        scratches_.clear();
        scratches_.resize(kBatch);
        for (WorkerScratch& scratch : scratches_) {
            scratch.tokenEpoch.assign(static_cast<size_t>(sourceCapacity_), 0);
            scratch.tokenOrdinal.resize(static_cast<size_t>(sourceCapacity_));
            scratch.protectedEpoch.assign(
                static_cast<size_t>(kUnionCapacity), 0);
        }
        groupCompleted_ = std::make_unique<std::atomic<uint32_t>[]>(
            static_cast<size_t>(generations_ * kIoGroups));
        for (int64_t index = 0; index < generations_ * kIoGroups; ++index) {
            groupCompleted_[index].store(0, std::memory_order_relaxed);
        }
        requestProfile_ = at::zeros({generations_, kBatch, 4},
            at::TensorOptions().dtype(at::kLong).device(at::kCPU));
        groupReadyProfile_ = at::zeros({generations_, kIoGroups},
            at::TensorOptions().dtype(at::kLong).device(at::kCPU));
        registered_ = true;
    }

    void Start()
    {
        std::lock_guard<std::mutex> lock(mutex_);
        TORCH_CHECK(registered_, "register_pipeline must be called first.");
        TORCH_CHECK(!started_, "runtime is already started.");
        started_ = true;
        workers_.reserve(kBatch);
        for (int64_t worker = 0; worker < kBatch; ++worker) {
            workers_.emplace_back(
                &SwappedCpuDuImplicitDbaRuntime::WorkerMain, this, worker);
        }
        while (readyWorkers_.load(std::memory_order_acquire) != kBatch) {
            CpuRelax();
        }
    }

    void WaitAll()
    {
        TORCH_CHECK(started_, "runtime is not started.");
        {
            py::gil_scoped_release release;
            while (finishedWorkers_.load(std::memory_order_acquire) != kBatch) {
                CpuRelax();
            }
        }
        JoinWorkers();
    }

    py::tuple ProfileRecords() const
    {
        TORCH_CHECK(finishedWorkers_.load(std::memory_order_acquire) == kBatch,
            "profile_records requires a completed runtime.");
        return py::make_tuple(requestProfile_, groupReadyProfile_);
    }

    int64_t generations() const { return generations_; }
    int64_t thread_count() const { return kBatch; }
    int64_t io_ubatch_requests() const { return kIoUbatch; }

private:
    static int64_t CheckFirstCpu(int64_t value)
    {
        TORCH_CHECK(value >= -1 && value <= INT_MAX,
            "first_cpu must be -1 or a non-negative CPU ID.");
#if defined(__linux__)
        if (value >= 0) {
            TORCH_CHECK(value + kBatch <= CPU_SETSIZE,
                "implicit DBA CPU range exceeds CPU_SETSIZE.");
        }
#else
        TORCH_CHECK(value == -1,
            "CPU affinity is supported only on Linux.");
#endif
        return value;
    }

    size_t StateIndex(int64_t generation, int64_t request) const
    {
        return static_cast<size_t>(generation * kBatch + request);
    }

    void BindWorker(int64_t worker)
    {
#if defined(__linux__)
        if (firstCpu_ < 0) {
            return;
        }
        cpu_set_t set;
        CPU_ZERO(&set);
        CPU_SET(static_cast<int>(firstCpu_ + worker), &set);
        if (pthread_setaffinity_np(pthread_self(), sizeof(set), &set) != 0) {
            std::terminate();
        }
#else
        (void)worker;
        if (firstCpu_ >= 0) {
            std::terminate();
        }
#endif
    }

    void WorkerMain(int64_t request)
    {
        BindWorker(request);
        readyWorkers_.fetch_add(1, std::memory_order_release);
        WorkerScratch& scratch = scratches_[static_cast<size_t>(request)];
        for (int64_t generation = 0; generation < generations_; ++generation) {
            int64_t* profile = requestProfile_.data_ptr<int64_t>() +
                (generation * kBatch + request) * 4;
            profile[0] = static_cast<int64_t>(NowNs());
            const int32_t* topk = topkRing_.data_ptr<int32_t>() +
                (generation * kRows + request * kQueries) * kTopk;
            PollRequest(topk);
            profile[1] = static_cast<int64_t>(NowNs());
            profile[2] = profile[1];
            ProcessRequest(generation, request, topk, scratch);
            profile[3] = static_cast<int64_t>(NowNs());
            PublishRequest(generation, request);
        }
        finishedWorkers_.fetch_add(1, std::memory_order_release);
    }

    void PollRequest(const int32_t* topk) const
    {
        bool ready = false;
        while (!ready) {
            ready = true;
            for (int64_t index = 0; index < kQueries * kTopk; ++index) {
                ready = ready &&
                    __atomic_load_n(topk + index, __ATOMIC_ACQUIRE) !=
                        kInvalidTopk;
            }
            if (!ready) {
                CpuRelax();
            }
        }
    }

    void ProcessRequest(int64_t generation, int64_t request,
        const int32_t* topk, WorkerScratch& scratch)
    {
        const uint32_t epoch = static_cast<uint32_t>(generation + 1);
        scratch.unionHitCount = 0;
        scratch.unionMissCount = 0;
        scratch.hitCounts.fill(0);
        scratch.missCounts.fill(0);
        int32_t* state = initialStates_.data_ptr<int32_t>() +
            (generation * kBatch + request) * sourceCapacity_;

        for (int32_t query = 0; query < kQueries; ++query) {
            for (int32_t position = 0; position < kTopk; ++position) {
                const int32_t token = topk[query * kTopk + position];
                if (token < 0 || token >= sourceCapacity_) {
                    std::terminate();
                }
                const int32_t slot = state[token];
                if (slot >= 0) {
                    scratch.hits[query][scratch.hitCounts[query]++] = token;
                    scratch.protectedEpoch[static_cast<size_t>(slot)] = epoch;
                    if (scratch.tokenEpoch[static_cast<size_t>(token)] != epoch) {
                        const int32_t ordinal = scratch.unionHitCount++;
                        scratch.tokenEpoch[static_cast<size_t>(token)] = epoch;
                        scratch.tokenOrdinal[static_cast<size_t>(token)] = ordinal;
                        scratch.unionHitTokens[ordinal] = token;
                        scratch.unionHitSlots[ordinal] = slot;
                        scratch.unionHitRefs[ordinal] = 1;
                        scratch.unionHitMasks[ordinal] = 1 << query;
                    } else {
                        const int32_t ordinal =
                            scratch.tokenOrdinal[static_cast<size_t>(token)];
                        ++scratch.unionHitRefs[ordinal];
                        scratch.unionHitMasks[ordinal] |= 1 << query;
                    }
                } else {
                    scratch.misses[query][scratch.missCounts[query]++] = token;
                    if (scratch.tokenEpoch[static_cast<size_t>(token)] != epoch) {
                        const int32_t ordinal = scratch.unionMissCount++;
                        scratch.tokenEpoch[static_cast<size_t>(token)] = epoch;
                        scratch.tokenOrdinal[static_cast<size_t>(token)] = ordinal;
                        scratch.unionMissTokens[ordinal] = token;
                        scratch.unionMissMasks[ordinal] = 1 << query;
                        scratch.unionMissOwnerQuery[ordinal] = query;
                    } else {
                        const int32_t ordinal =
                            scratch.tokenOrdinal[static_cast<size_t>(token)];
                        scratch.unionMissMasks[ordinal] |= 1 << query;
                    }
                }
            }
        }

        const StateAux& aux = stateAux_[StateIndex(generation, request)];
        int32_t assigned = 0;
        for (const int32_t slot : aux.freeSlots) {
            if (assigned == scratch.unionMissCount) {
                break;
            }
            scratch.unionMissSlots[assigned] = slot;
            scratch.unionMissVictims[assigned] = -1;
            ++assigned;
        }
        for (const int32_t victim : aux.residentTokens) {
            if (assigned == scratch.unionMissCount) {
                break;
            }
            const int32_t slot = state[victim];
            if (scratch.protectedEpoch[static_cast<size_t>(slot)] == epoch) {
                continue;
            }
            scratch.unionMissSlots[assigned] = slot;
            scratch.unionMissVictims[assigned] = victim;
            ++assigned;
        }
        if (assigned != scratch.unionMissCount) {
            std::terminate();
        }

        int32_t* sourceIds = sourceIds_.data_ptr<int32_t>();
        int32_t* attention = attentionSlots_.data_ptr<int32_t>();
        int32_t* sourceRefs = sourceRefs_.data_ptr<int32_t>();
        int32_t* queryMissCounts = queryMissCounts_.data_ptr<int32_t>();
        int32_t* unionOrdinals = unionOrdinals_.data_ptr<int32_t>();
        for (int32_t query = 0; query < kQueries; ++query) {
            const int64_t row = request * kQueries + query;
            const int64_t topkOffset = row * kTopk;
            int32_t output = 0;
            for (int32_t index = 0; index < scratch.hitCounts[query]; ++index) {
                const int32_t token = scratch.hits[query][index];
                const int32_t ordinal =
                    scratch.tokenOrdinal[static_cast<size_t>(token)];
                const int32_t slot = state[token];
                sourceIds[topkOffset + output] = token;
                attention[row * attentionWidth_ + output] = slot;
                sourceRefs[topkOffset + output] = slot;
                unionOrdinals[topkOffset + output] = ordinal;
                ++output;
            }
            for (int32_t index = 0; index < scratch.missCounts[query]; ++index) {
                const int32_t token = scratch.misses[query][index];
                const int32_t ordinal =
                    scratch.tokenOrdinal[static_cast<size_t>(token)];
                sourceIds[topkOffset + output] = token;
                attention[row * attentionWidth_ + output] =
                    scratch.unionMissSlots[ordinal];
                int32_t reference = ordinal;
                if (scratch.unionMissOwnerQuery[ordinal] == query) {
                    reference |= remote_offload::kSourceRefOwnerBit;
                }
                sourceRefs[topkOffset + output] = reference;
                unionOrdinals[topkOffset + output] =
                    scratch.unionHitCount + ordinal;
                ++output;
            }
            queryMissCounts[row] = scratch.missCounts[query];
        }

        const int64_t hcommOffset = request * kHcommCapacity;
        const int64_t unionOffset = request * kUnionCapacity;
        int32_t* hcommSources = hcommSources_.data_ptr<int32_t>();
        int32_t* hcommDestinations = hcommDestinations_.data_ptr<int32_t>();
        int32_t* evicted = evictedSourceIds_.data_ptr<int32_t>();
        int32_t* missMasks = unionMissMasks_.data_ptr<int32_t>();
        for (int32_t index = 0; index < scratch.unionMissCount; ++index) {
            hcommSources[hcommOffset + index] = scratch.unionMissTokens[index];
            hcommDestinations[hcommOffset + index] =
                scratch.unionMissSlots[index];
            evicted[unionOffset + index] = scratch.unionMissVictims[index];
            missMasks[unionOffset + index] = scratch.unionMissMasks[index];
        }
        hcommCounts_.data_ptr<int32_t>()[request] = scratch.unionMissCount;

        int32_t* hitIds = unionHitSourceIds_.data_ptr<int32_t>();
        int32_t* hitSlots = unionHitSlots_.data_ptr<int32_t>();
        int32_t* hitRefs = unionHitRefCounts_.data_ptr<int32_t>();
        int32_t* hitMasks = unionHitMasks_.data_ptr<int32_t>();
        for (int32_t index = 0; index < scratch.unionHitCount; ++index) {
            hitIds[unionOffset + index] = scratch.unionHitTokens[index];
            hitSlots[unionOffset + index] = scratch.unionHitSlots[index];
            hitRefs[unionOffset + index] = scratch.unionHitRefs[index];
            hitMasks[unionOffset + index] = scratch.unionHitMasks[index];
        }
        unionHitCounts_.data_ptr<int32_t>()[request] = scratch.unionHitCount;

        // All outputs above describe the pre-update state. Commit the DU state
        // only after every derived field is complete, matching CpuDuState's
        // transactional update semantics.
        for (int32_t index = 0; index < scratch.unionMissCount; ++index) {
            const int32_t victim = scratch.unionMissVictims[index];
            if (victim >= 0) {
                state[victim] = -1;
            }
            state[scratch.unionMissTokens[index]] =
                scratch.unionMissSlots[index];
        }
    }

    void PublishRequest(int64_t generation, int64_t request)
    {
        const int64_t group = request / kIoUbatch;
        std::atomic<uint32_t>& completed =
            groupCompleted_[generation * kIoGroups + group];
        if (completed.fetch_add(1, std::memory_order_acq_rel) + 1 ==
            kIoUbatch) {
            groupReadyProfile_.data_ptr<int64_t>()[
                generation * kIoGroups + group] =
                    static_cast<int64_t>(NowNs());
            __atomic_store_n(
                readyFlags_.data_ptr<int32_t>() +
                    generation * kIoGroups + group,
                1, __ATOMIC_RELEASE);
        }
    }

    void JoinWorkers()
    {
        if (joined_) {
            return;
        }
        for (std::thread& worker : workers_) {
            if (worker.joinable()) {
                worker.join();
            }
        }
        joined_ = true;
    }

    const int64_t firstCpu_;
    mutable std::mutex mutex_;
    bool registered_{false};
    bool started_{false};
    bool joined_{false};
    int64_t generations_{0};
    int64_t sourceCapacity_{0};
    int64_t attentionWidth_{0};

    std::vector<std::thread> workers_;
    std::atomic<int64_t> readyWorkers_{0};
    std::atomic<int64_t> finishedWorkers_{0};
    std::unique_ptr<std::atomic<uint32_t>[]> groupCompleted_;
    std::vector<StateAux> stateAux_;
    std::vector<WorkerScratch> scratches_;
    std::vector<int32_t> cacheBudgets_;
    std::vector<int32_t> candidateLengths_;

    at::Tensor topkRing_;
    at::Tensor initialStates_;
    at::Tensor sourceIds_;
    at::Tensor attentionSlots_;
    at::Tensor sourceRefs_;
    at::Tensor queryMissCounts_;
    at::Tensor hcommSources_;
    at::Tensor hcommDestinations_;
    at::Tensor hcommCounts_;
    at::Tensor evictedSourceIds_;
    at::Tensor unionMissMasks_;
    at::Tensor unionHitSourceIds_;
    at::Tensor unionHitSlots_;
    at::Tensor unionHitRefCounts_;
    at::Tensor unionHitMasks_;
    at::Tensor unionHitCounts_;
    at::Tensor unionOrdinals_;
    at::Tensor readyFlags_;
    at::Tensor requestProfile_;
    at::Tensor groupReadyProfile_;
};

}  // namespace

void RegisterCpuDuImplicitDba(pybind11::module& module)
{
    py::class_<SwappedCpuDuImplicitDbaRuntime>(
        module, "SwappedCpuDuImplicitDbaRuntime")
        .def(py::init<int64_t>(), py::arg("first_cpu") = -1)
        .def("register_pipeline",
            &SwappedCpuDuImplicitDbaRuntime::RegisterPipeline,
            py::arg("topk_ring"), py::arg("initial_states"),
            py::arg("cache_budgets"), py::arg("candidate_lengths"),
            py::arg("source_ids"), py::arg("attention_slots"),
            py::arg("source_refs"), py::arg("query_miss_counts"),
            py::arg("hcomm_sources"), py::arg("hcomm_destinations"),
            py::arg("hcomm_counts"), py::arg("evicted_source_ids"),
            py::arg("union_miss_masks"),
            py::arg("union_hit_source_ids"), py::arg("union_hit_slots"),
            py::arg("union_hit_ref_counts"), py::arg("union_hit_masks"),
            py::arg("union_hit_counts"), py::arg("union_ordinals"),
            py::arg("ready_flags"))
        .def("start", &SwappedCpuDuImplicitDbaRuntime::Start)
        .def("wait_all", &SwappedCpuDuImplicitDbaRuntime::WaitAll)
        .def("profile_records",
            &SwappedCpuDuImplicitDbaRuntime::ProfileRecords)
        .def_property_readonly("generations",
            &SwappedCpuDuImplicitDbaRuntime::generations)
        .def_property_readonly("thread_count",
            &SwappedCpuDuImplicitDbaRuntime::thread_count)
        .def_property_readonly("io_ubatch_requests",
            &SwappedCpuDuImplicitDbaRuntime::io_ubatch_requests);
}

}  // namespace custom
