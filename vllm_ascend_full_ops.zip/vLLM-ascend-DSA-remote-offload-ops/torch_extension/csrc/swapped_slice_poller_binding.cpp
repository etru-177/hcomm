// SPDX-License-Identifier: Apache-2.0

#include <algorithm>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <climits>
#include <cstdint>
#include <cstring>
#include <exception>
#include <mutex>
#include <stdexcept>
#include <thread>
#include <vector>

#if defined(__linux__)
#include <pthread.h>
#include <sched.h>
#include <sys/mman.h>
#include <unistd.h>
#endif

#include <torch/extension.h>

namespace custom {
namespace {

namespace py = pybind11;

constexpr int32_t kInvalidTopk = -1;

inline void CpuRelax() {
#if defined(__aarch64__)
  asm volatile("yield" ::: "memory");
#elif defined(__x86_64__) || defined(__i386__)
  asm volatile("pause" ::: "memory");
#else
  std::this_thread::yield();
#endif
}

void CheckHostMappedRange(const void* pointer, size_t bytes) {
#if defined(__linux__)
  TORCH_CHECK(pointer != nullptr && bytes > 0, "polling range is empty.");
  const long page_size_value = sysconf(_SC_PAGESIZE);
  TORCH_CHECK(page_size_value > 0, "failed to query the host page size.");
  const uintptr_t page_size = static_cast<uintptr_t>(page_size_value);
  const uintptr_t address = reinterpret_cast<uintptr_t>(pointer);
  TORCH_CHECK(
      bytes <= UINTPTR_MAX - address &&
          page_size - 1 <= UINTPTR_MAX - address - bytes,
      "swapped-memory polling range overflows the host address space.");
  const uintptr_t begin = address & ~(page_size - 1);
  const uintptr_t end = (address + bytes + page_size - 1) & ~(page_size - 1);
  const size_t pages = static_cast<size_t>((end - begin) / page_size);
  std::vector<unsigned char> residency(pages);
  errno = 0;
  const int result = mincore(
      reinterpret_cast<void*>(begin), end - begin, residency.data());
  TORCH_CHECK(
      result == 0,
      "the swapped tensor's NPU data_ptr is not a host-readable VA; "
      "CPU polling requires CANN VA address normalization (mincore: ",
      std::strerror(errno), ").");
#else
  (void)pointer;
  (void)bytes;
  TORCH_CHECK(false, "swapped-memory CPU polling is supported only on Linux.");
#endif
}

class SwappedSlicePollerRuntime {
 public:
  explicit SwappedSlicePollerRuntime(int64_t thread_count, int64_t first_cpu)
      : thread_count_(CheckThreadCount(thread_count)),
        first_cpu_(CheckFirstCpu(first_cpu)),
        scan_rounds_(static_cast<size_t>(thread_count_), 0) {
    workers_.reserve(static_cast<size_t>(thread_count_));
    try {
      for (int64_t worker = 0; worker < thread_count_; ++worker) {
        workers_.emplace_back(
            &SwappedSlicePollerRuntime::WorkerMain, this, worker);
      }
    } catch (...) {
      stop_.store(true, std::memory_order_release);
      task_sequence_.fetch_add(1, std::memory_order_release);
      for (std::thread& worker : workers_) {
        if (worker.joinable()) {
          worker.join();
        }
      }
      throw;
    }
    while (ready_workers_.load(std::memory_order_acquire) != thread_count_) {
      CpuRelax();
    }
  }

  ~SwappedSlicePollerRuntime() {
    cancel_.store(true, std::memory_order_release);
    stop_.store(true, std::memory_order_release);
    task_sequence_.fetch_add(1, std::memory_order_release);
    for (std::thread& worker : workers_) {
      if (worker.joinable()) {
        worker.join();
      }
    }
  }

  SwappedSlicePollerRuntime(const SwappedSlicePollerRuntime&) = delete;
  SwappedSlicePollerRuntime& operator=(const SwappedSlicePollerRuntime&) =
      delete;

  void RegisterTensor(const at::Tensor& tensor) {
    std::lock_guard<std::mutex> lock(run_mutex_);
    TORCH_CHECK(!armed_, "cannot replace the polling tensor while armed.");
    TORCH_CHECK(
        tensor.device().type() == c10::DeviceType::PrivateUse1,
        "polling tensor must be an NPU swapped-memory tensor.");
    TORCH_CHECK(
        tensor.scalar_type() == at::kInt && tensor.is_contiguous() &&
            tensor.numel() > 0,
        "polling tensor must be a non-empty contiguous INT32 tensor.");
    CheckHostMappedRange(
        tensor.data_ptr<int32_t>(),
        static_cast<size_t>(tensor.numel()) * sizeof(int32_t));
    tensor_ = tensor;
    base_ = tensor.data_ptr<int32_t>();
    elements_ = tensor.numel();
  }

  void Arm(
      int64_t element_offset,
      int64_t slice_count,
      int64_t slice_elements,
      bool replicated_scan) {
    std::lock_guard<std::mutex> lock(run_mutex_);
    RethrowInitializationError();
    TORCH_CHECK(tensor_.defined(), "register_tensor must be called first.");
    TORCH_CHECK(!armed_, "poller is already armed.");
    TORCH_CHECK(
        element_offset >= 0 && slice_count > 0 && slice_elements > 0,
        "polling offset/count/size must be non-negative and non-zero.");
    TORCH_CHECK(
        element_offset <= elements_ &&
            slice_count <= (elements_ - element_offset) / slice_elements,
        "polling slices exceed the registered tensor.");
    pointer_ = base_ + element_offset;
    slice_count_ = slice_count;
    slice_elements_ = slice_elements;
    replicated_scan_ = replicated_scan;
    std::fill(scan_rounds_.begin(), scan_rounds_.end(), 0);
    cancel_.store(false, std::memory_order_relaxed);
    completed_workers_.store(0, std::memory_order_relaxed);
    armed_ = true;
    task_sequence_.fetch_add(1, std::memory_order_release);
  }

  int64_t Wait(int64_t timeout_ms) {
    std::unique_lock<std::mutex> lock(run_mutex_);
    TORCH_CHECK(armed_, "poller is not armed.");
    TORCH_CHECK(timeout_ms > 0, "timeout_ms must be positive.");
    bool timed_out = false;
    {
      py::gil_scoped_release release;
      const auto deadline = std::chrono::steady_clock::now() +
          std::chrono::milliseconds(timeout_ms);
      while (completed_workers_.load(std::memory_order_acquire) !=
             thread_count_) {
        if (std::chrono::steady_clock::now() >= deadline) {
          timed_out = true;
          cancel_.store(true, std::memory_order_release);
          break;
        }
        CpuRelax();
      }
      while (completed_workers_.load(std::memory_order_acquire) !=
             thread_count_) {
        CpuRelax();
      }
    }
    armed_ = false;
    int64_t total_scan_rounds = 0;
    for (uint64_t value : scan_rounds_) {
      if (value > static_cast<uint64_t>(INT64_MAX - total_scan_rounds)) {
        total_scan_rounds = INT64_MAX;
        break;
      }
      total_scan_rounds += static_cast<int64_t>(value);
    }
    TORCH_CHECK(
        !timed_out,
        "CPU polling timed out before every TopK element changed from -1; "
        "check swapped-memory host visibility and LI output completion.");
    return total_scan_rounds;
  }

  int64_t thread_count() const { return thread_count_; }

 private:
  static int64_t CheckThreadCount(int64_t value) {
    TORCH_CHECK(value >= 1 && value <= 256,
                "thread_count must be in [1,256].");
    return value;
  }

  static int64_t CheckFirstCpu(int64_t value) {
    TORCH_CHECK(value >= -1 && value <= INT_MAX,
                "first_cpu must be -1 or a non-negative CPU ID.");
    return value;
  }

  void BindWorker(int64_t worker) {
#if defined(__linux__)
    if (first_cpu_ < 0) {
      return;
    }
    if (first_cpu_ + worker >= CPU_SETSIZE) {
      throw std::runtime_error("polling CPU ID exceeds CPU_SETSIZE");
    }
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(static_cast<int>(first_cpu_ + worker), &set);
    const int status = pthread_setaffinity_np(
        pthread_self(), sizeof(set), &set);
    if (status != 0) {
      throw std::runtime_error("failed to bind a polling worker to its CPU");
    }
#else
    (void)worker;
    if (first_cpu_ >= 0) {
      throw std::runtime_error("CPU affinity is supported only on Linux");
    }
#endif
  }

  void RethrowInitializationError() {
    std::lock_guard<std::mutex> lock(error_mutex_);
    if (initialization_error_) {
      std::rethrow_exception(initialization_error_);
    }
  }

  void WorkerMain(int64_t worker) {
    try {
      BindWorker(worker);
    } catch (...) {
      std::lock_guard<std::mutex> lock(error_mutex_);
      if (!initialization_error_) {
        initialization_error_ = std::current_exception();
      }
    }
    uint64_t observed = task_sequence_.load(std::memory_order_acquire);
    ready_workers_.fetch_add(1, std::memory_order_release);
    while (!stop_.load(std::memory_order_acquire)) {
      const uint64_t sequence =
          task_sequence_.load(std::memory_order_acquire);
      if (sequence == observed) {
        CpuRelax();
        continue;
      }
      observed = sequence;
      if (stop_.load(std::memory_order_acquire)) {
        break;
      }
      PollSlices(worker);
      completed_workers_.fetch_add(1, std::memory_order_release);
    }
  }

  void PollSlices(int64_t worker) {
    const int64_t begin = replicated_scan_
        ? 0
        : slice_elements_ * worker / thread_count_;
    const int64_t end = replicated_scan_
        ? slice_elements_
        : slice_elements_ * (worker + 1) / thread_count_;
    uint64_t rounds = 0;
    for (int64_t slice = 0; slice < slice_count_; ++slice) {
      const int32_t* data = pointer_ + slice * slice_elements_;
      bool ready = false;
      while (!ready && !cancel_.load(std::memory_order_acquire) &&
             !stop_.load(std::memory_order_acquire)) {
        ready = true;
        // Scan the entire partition on every round.  Stopping at the first
        // sentinel would benchmark one hot cache line instead of CPU traffic.
        for (int64_t index = begin; index < end; ++index) {
          const int32_t value =
              __atomic_load_n(data + index, __ATOMIC_ACQUIRE);
          ready = ready && value != kInvalidTopk;
        }
        ++rounds;
        if (!ready) {
          CpuRelax();
        }
      }
      if (cancel_.load(std::memory_order_acquire) ||
          stop_.load(std::memory_order_acquire)) {
        break;
      }
    }
    scan_rounds_[static_cast<size_t>(worker)] = rounds;
  }

  const int64_t thread_count_;
  const int64_t first_cpu_;
  std::vector<std::thread> workers_;
  std::atomic<bool> stop_{false};
  std::atomic<bool> cancel_{false};
  std::atomic<uint64_t> task_sequence_{0};
  std::atomic<int64_t> ready_workers_{0};
  std::atomic<int64_t> completed_workers_{0};
  std::mutex run_mutex_;
  std::mutex error_mutex_;
  std::exception_ptr initialization_error_;

  at::Tensor tensor_;
  int32_t* base_{nullptr};
  int64_t elements_{0};
  const int32_t* pointer_{nullptr};
  int64_t slice_count_{0};
  int64_t slice_elements_{0};
  bool replicated_scan_{false};
  bool armed_{false};
  std::vector<uint64_t> scan_rounds_;
};

}  // namespace

void RegisterSwappedSlicePoller(pybind11::module& module) {
  py::class_<SwappedSlicePollerRuntime>(
      module, "SwappedSlicePollerRuntime")
      .def(py::init<int64_t, int64_t>(),
           py::arg("thread_count"), py::arg("first_cpu") = -1)
      .def("register_tensor", &SwappedSlicePollerRuntime::RegisterTensor,
           py::arg("tensor"))
      .def("arm", &SwappedSlicePollerRuntime::Arm,
           py::arg("element_offset"), py::arg("slice_count"),
           py::arg("slice_elements"), py::arg("replicated_scan") = false)
      .def("wait", &SwappedSlicePollerRuntime::Wait,
           py::arg("timeout_ms") = 30000)
      .def_property_readonly(
          "thread_count", &SwappedSlicePollerRuntime::thread_count);
}

}  // namespace custom
