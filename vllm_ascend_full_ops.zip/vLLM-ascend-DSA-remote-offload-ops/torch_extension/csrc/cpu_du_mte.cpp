// SPDX-License-Identifier: Apache-2.0

#include <cstdlib>
#include <dlfcn.h>
#include <mutex>
#include <string>

#include <torch/extension.h>

namespace custom {
namespace {

constexpr uint32_t kAsyncCopyFlag = 1U << 0;
constexpr int64_t kSmemCopyG2H = 2;
constexpr int64_t kSmemCopyH2G = 3;

struct SmemBatchCopyParams {
    void** sources;
    void** destinations;
    const uint64_t* dataSizes;
    uint32_t batchSize;
    void* stream;
};

using SmemCopyBatch = int32_t (*)(
    void*, SmemBatchCopyParams*, int32_t, uint32_t);
using SmemWait = int32_t (*)(void*);

struct SmemSymbols {
    void* library{nullptr};
    SmemCopyBatch copyBatch{nullptr};
    SmemWait wait{nullptr};
    std::string error;
};

SmemSymbols& GetSmemSymbols()
{
    static SmemSymbols symbols;
    static std::once_flag once;
    std::call_once(once, [&]() {
        const char* configured = std::getenv("MEMFABRIC_SMEM_LIB");
        const char* path = configured != nullptr ? configured : "libmf_smem.so";
        symbols.library = dlopen(path, RTLD_NOW | RTLD_LOCAL);
        if (symbols.library == nullptr) {
            const char* error = dlerror();
            symbols.error = error != nullptr ? error : "dlopen failed";
            return;
        }
        symbols.copyBatch = reinterpret_cast<SmemCopyBatch>(
            dlsym(symbols.library, "smem_bm_copy_batch"));
        symbols.wait = reinterpret_cast<SmemWait>(
            dlsym(symbols.library, "smem_bm_wait"));
        if (symbols.copyBatch == nullptr || symbols.wait == nullptr) {
            const char* error = dlerror();
            symbols.error = error != nullptr ? error : "missing SMEM symbols";
        }
    });
    return symbols;
}

void CheckAddressVector(const at::Tensor& tensor, const char* name)
{
    TORCH_CHECK(tensor.device().is_cpu() && tensor.is_contiguous(),
        name, " must be a contiguous CPU tensor.");
    TORCH_CHECK(tensor.scalar_type() == at::kUInt64,
        name, " must have dtype uint64.");
    TORCH_CHECK(tensor.dim() == 1, name, " must be rank 1.");
}

}  // namespace

int32_t cpu_du_mte_copy_batch(uint64_t handle,
    const at::Tensor& sources, const at::Tensor& destinations,
    const at::Tensor& dataSizes, int64_t direction, uint64_t stream,
    bool asyncCopy)
{
    CheckAddressVector(sources, "sources");
    CheckAddressVector(destinations, "destinations");
    CheckAddressVector(dataSizes, "data_sizes");
    TORCH_CHECK(sources.numel() == destinations.numel() &&
        sources.numel() == dataSizes.numel() && sources.numel() > 0 &&
        sources.numel() <= UINT32_MAX,
        "MTE batch vectors must have one shared size in [1, UINT32_MAX].");
    TORCH_CHECK(direction == kSmemCopyG2H || direction == kSmemCopyH2G,
        "MTE direction must be 2 (G2H) or 3 (H2G).");
    TORCH_CHECK(handle != 0, "MTE Big Memory handle must not be zero.");

    SmemSymbols& symbols = GetSmemSymbols();
    TORCH_CHECK(symbols.copyBatch != nullptr,
        "cannot load MemFabric SMEM batch-copy API: ", symbols.error,
        "; set MEMFABRIC_SMEM_LIB to libmf_smem.so");
    SmemBatchCopyParams params{
        reinterpret_cast<void**>(sources.data_ptr<uint64_t>()),
        reinterpret_cast<void**>(destinations.data_ptr<uint64_t>()),
        dataSizes.data_ptr<uint64_t>(),
        static_cast<uint32_t>(sources.numel()),
        reinterpret_cast<void*>(stream),
    };
    return symbols.copyBatch(reinterpret_cast<void*>(handle), &params,
        static_cast<int32_t>(direction), asyncCopy ? kAsyncCopyFlag : 0);
}

int32_t cpu_du_mte_wait(uint64_t handle)
{
    TORCH_CHECK(handle != 0, "MTE Big Memory handle must not be zero.");
    SmemSymbols& symbols = GetSmemSymbols();
    TORCH_CHECK(symbols.wait != nullptr,
        "cannot load MemFabric SMEM wait API: ", symbols.error,
        "; set MEMFABRIC_SMEM_LIB to libmf_smem.so");
    return symbols.wait(reinterpret_cast<void*>(handle));
}

}  // namespace custom
