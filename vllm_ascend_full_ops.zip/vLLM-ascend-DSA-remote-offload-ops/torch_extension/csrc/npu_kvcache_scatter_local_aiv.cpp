#include <torch/library.h>

#include <tuple>

#include "ops_common.h"

namespace custom {
namespace {
constexpr int64_t BLOCK_SIZE = 128;
constexpr int64_t KPE_DIM = 64;
constexpr int64_t CKV_DIM = 512;
constexpr int64_t COPY_CAP = 16384;
constexpr int64_t TOKEN_BYTES = (KPE_DIM + CKV_DIM) * 2;
constexpr int64_t FLAT_FP8_TOKEN_BYTES = 576;
constexpr int64_t FLAT_C8_TOKEN_BYTES = 656;

void CheckInputs(const at::Tensor& hbmKpe, const at::Tensor& hbmCkv,
    const at::Tensor& staging, const at::Tensor& hbmBlockTable,
    const at::Tensor& srcTokenIds, const at::Tensor& dstSlots,
    const at::Tensor& copyCounts)
{
    TORCH_CHECK(hbmKpe.dim() == 3 && hbmKpe.size(1) == BLOCK_SIZE &&
        hbmKpe.size(2) == KPE_DIM, "hbm_kpe must have shape [blocks, 128, 64].");
    TORCH_CHECK(hbmCkv.dim() == 3 && hbmCkv.size(1) == BLOCK_SIZE &&
        hbmCkv.size(2) == CKV_DIM, "hbm_ckv must have shape [blocks, 128, 512].");
    TORCH_CHECK(
        (staging.dim() == 1 ||
         (staging.dim() == 2 &&
          (staging.size(1) == TOKEN_BYTES ||
           staging.size(1) == FLAT_FP8_TOKEN_BYTES ||
           staging.size(1) == FLAT_C8_TOKEN_BYTES))) &&
        staging.scalar_type() == at::kByte,
        "hbm_staging must be a uint8 block vector or a [tokens, 576/656/1152] matrix.");
    TORCH_CHECK(hbmBlockTable.dim() == 2 && hbmBlockTable.scalar_type() == at::kInt,
        "hbm_block_table must be a two-dimensional int32 tensor.");
    TORCH_CHECK(srcTokenIds.dim() == 3 && srcTokenIds.size(1) == 1 &&
        srcTokenIds.size(2) == COPY_CAP && srcTokenIds.scalar_type() == at::kInt,
        "src_token_ids must have shape [B, 1, 16384] and dtype int32.");
    TORCH_CHECK(dstSlots.sizes() == srcTokenIds.sizes() &&
        dstSlots.scalar_type() == at::kInt,
        "dst_slots must match src_token_ids and use int32.");
    TORCH_CHECK(copyCounts.dim() == 1 && copyCounts.scalar_type() == at::kInt,
        "copy_counts must have shape [B] and dtype int32.");
    TORCH_CHECK(copyCounts.size(0) == hbmBlockTable.size(0) &&
        copyCounts.size(0) == srcTokenIds.size(0), "batch dimensions must match.");
    TORCH_CHECK(hbmKpe.scalar_type() == hbmCkv.scalar_type() &&
        (hbmKpe.scalar_type() == at::kBFloat16 || hbmKpe.scalar_type() == at::kHalf),
        "hbm_kpe and hbm_ckv must use bf16 or fp16.");
    TORCH_CHECK(hbmKpe.is_contiguous() && hbmCkv.is_contiguous() &&
        staging.is_contiguous() && hbmBlockTable.is_contiguous() &&
        srcTokenIds.is_contiguous() && dstSlots.is_contiguous() &&
        copyCounts.is_contiguous(), "all inputs must be contiguous.");
}
}  // namespace

std::tuple<at::Tensor, at::Tensor> npu_kvcache_scatter_local_aiv_npu(
    at::Tensor hbmKpe, at::Tensor hbmCkv, const at::Tensor& staging,
    const at::Tensor& hbmBlockTable, const at::Tensor& srcTokenIds,
    const at::Tensor& dstSlots, const at::Tensor& copyCounts)
{
    CheckInputs(hbmKpe, hbmCkv, staging, hbmBlockTable,
        srcTokenIds, dstSlots, copyCounts);
    // The AIV kernel is instantiated with uint16_t and only copies raw bits.
    // Present BF16 storage as a zero-copy FP16 view because this CANN path
    // reports a zero element size for BF16 custom-op descriptors.
    at::Tensor launchKpe = hbmKpe.scalar_type() == at::kBFloat16 ?
        hbmKpe.view(at::kHalf) : hbmKpe;
    at::Tensor launchCkv = hbmCkv.scalar_type() == at::kBFloat16 ?
        hbmCkv.view(at::kHalf) : hbmCkv;
    // Use the generated ACLNN API: the legacy ACL-op path may be disabled
    // by PTA on A5. Keep all tensor storage alive until queued submission.
    auto keepalive = std::make_tuple(launchKpe, launchCkv, staging,
        hbmBlockTable, srcTokenIds, dstSlots, copyCounts);
    EXEC_NPU_CMD_ORDERED(
        aclnnKvcacheScatterLocalAiv,
        keepalive,
        launchKpe,
        launchCkv,
        staging,
        hbmBlockTable,
        srcTokenIds,
        dstSlots,
        copyCounts,
        launchKpe,
        launchCkv);
    return {hbmKpe, hbmCkv};
}

std::tuple<at::Tensor, at::Tensor> npu_kvcache_scatter_local_aiv_meta(
    at::Tensor hbmKpe, at::Tensor hbmCkv, const at::Tensor& staging,
    const at::Tensor& hbmBlockTable, const at::Tensor& srcTokenIds,
    const at::Tensor& dstSlots, const at::Tensor& copyCounts)
{
    CheckInputs(hbmKpe, hbmCkv, staging, hbmBlockTable,
        srcTokenIds, dstSlots, copyCounts);
    return {hbmKpe, hbmCkv};
}
}  // namespace custom

TORCH_LIBRARY_IMPL(custom, PrivateUse1, m)
{
    m.impl("npu_kvcache_scatter_local_aiv",
        &custom::npu_kvcache_scatter_local_aiv_npu);
}

TORCH_LIBRARY_IMPL(custom, Meta, m)
{
    m.impl("npu_kvcache_scatter_local_aiv",
        &custom::npu_kvcache_scatter_local_aiv_meta);
}
