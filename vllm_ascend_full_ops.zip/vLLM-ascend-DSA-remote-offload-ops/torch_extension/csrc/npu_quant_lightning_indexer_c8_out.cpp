#include <limits>
#include <string>
#include <tuple>

#include "ops_common.h"

namespace nanovllm_dsa_a5_impl {
namespace {

constexpr int64_t kIndexerDim = 128;
constexpr int64_t kBlockSize = 128;
constexpr int64_t kSparseCount = 2048;

void CheckQuantLightningIndexerC8Out(
    const at::Tensor& query,
    const at::Tensor& key,
    const at::Tensor& weights,
    const at::Tensor& query_dequant_scale,
    const at::Tensor& key_dequant_scale,
    const at::Tensor& actual_seq_lengths_query,
    const at::Tensor& actual_seq_lengths_key,
    const at::Tensor& block_table,
    const at::Tensor& sparse_indices_out) {
  TORCH_CHECK(
      query.dim() == 3 && query.size(0) > 0 &&
          (query.size(1) == 32 || query.size(1) == 64) &&
          query.size(2) == kIndexerDim &&
          query.scalar_type() == at::ScalarType::Float8_e4m3fn,
      "C8 LI query must be FP8 E4M3 TND [T,32|64,128].");
  TORCH_CHECK(
      key.dim() == 4 && key.size(0) > 0 &&
          key.size(1) == kBlockSize && key.size(2) == 1 &&
          key.size(3) == kIndexerDim &&
          key.scalar_type() == at::ScalarType::Float8_e4m3fn,
      "C8 LI key must be FP8 E4M3 PA_BSND [blocks,128,1,128].");
  TORCH_CHECK(
      weights.dim() == 2 && weights.size(0) == query.size(0) &&
          weights.size(1) == query.size(1) &&
          weights.scalar_type() == at::kBFloat16,
      "C8 LI weights must be BF16 [T,32|64].");
  TORCH_CHECK(
      query_dequant_scale.dim() == 2 &&
          query_dequant_scale.sizes() == weights.sizes() &&
          query_dequant_scale.scalar_type() == at::kFloat,
      "C8 LI query_dequant_scale must be FP32 [T,32|64].");
  TORCH_CHECK(
      key_dequant_scale.dim() == 3 &&
          key_dequant_scale.size(0) == key.size(0) &&
          key_dequant_scale.size(1) == kBlockSize &&
          key_dequant_scale.size(2) == 1 &&
          key_dequant_scale.scalar_type() == at::kFloat,
      "C8 LI key_dequant_scale must be FP32 [blocks,128,1].");
  const int64_t batch = actual_seq_lengths_query.numel();
  TORCH_CHECK(
      batch > 0 && actual_seq_lengths_query.dim() == 1 &&
          actual_seq_lengths_key.dim() == 1 &&
          actual_seq_lengths_key.numel() == batch &&
          block_table.dim() == 2 && block_table.size(0) == batch,
      "C8 LI packed-query metadata shapes are inconsistent.");
  TORCH_CHECK(
      sparse_indices_out.dim() == 3 &&
          sparse_indices_out.size(0) == query.size(0) &&
          sparse_indices_out.size(1) == key.size(2) &&
          sparse_indices_out.size(2) == kSparseCount &&
          sparse_indices_out.scalar_type() == at::kInt,
      "C8 LI output must be INT32 [T,1,2048].");
  for (const at::Tensor* tensor : {
           &actual_seq_lengths_query, &actual_seq_lengths_key,
           &block_table}) {
    TORCH_CHECK(
        tensor->scalar_type() == at::kInt,
        "C8 LI metadata must use INT32.");
  }
  const c10::Device device = query.device();
  for (const at::Tensor* tensor : {
           &query, &key, &weights, &query_dequant_scale,
           &key_dequant_scale, &actual_seq_lengths_query,
           &actual_seq_lengths_key, &block_table, &sparse_indices_out}) {
    TORCH_CHECK(
        tensor->device() == device && tensor->is_contiguous(),
        "C8 LI inputs and output must be contiguous on one NPU.");
  }
}

}  // namespace

at::Tensor QuantLightningIndexerC8OutNpu(
    const at::Tensor& query,
    const at::Tensor& key,
    const at::Tensor& weights,
    const at::Tensor& query_dequant_scale,
    const at::Tensor& key_dequant_scale,
    const at::Tensor& actual_seq_lengths_query,
    const at::Tensor& actual_seq_lengths_key,
    const at::Tensor& block_table,
    at::Tensor sparse_indices_out) {
  CheckQuantLightningIndexerC8Out(
      query, key, weights, query_dequant_scale, key_dequant_scale,
      actual_seq_lengths_query, actual_seq_lengths_key, block_table,
      sparse_indices_out);

  constexpr int64_t query_quant_mode = 0;
  constexpr int64_t key_quant_mode = 0;
  constexpr int64_t sparse_mode = 3;
  constexpr int64_t all_tokens = std::numeric_limits<int64_t>::max();
  std::string layout_query = "TND";
  std::string layout_key = "PA_BSND";
  char* layout_query_ptr = layout_query.data();
  char* layout_key_ptr = layout_key.data();

  auto keepalive = std::make_tuple(
      query, key, weights, query_dequant_scale, key_dequant_scale,
      actual_seq_lengths_query, actual_seq_lengths_key, block_table,
      sparse_indices_out);
  // This is the exact ACLNN used by torch_npu.npu_quant_lightning_indexer.
  // Only the allocator-owned output is replaced by a caller-owned tensor.
  EXEC_NPU_CMD_ORDERED(
      aclnnQuantLightningIndexer,
      keepalive,
      query,
      key,
      weights,
      query_dequant_scale,
      key_dequant_scale,
      actual_seq_lengths_query,
      actual_seq_lengths_key,
      block_table,
      query_quant_mode,
      key_quant_mode,
      layout_query_ptr,
      layout_key_ptr,
      kSparseCount,
      sparse_mode,
      all_tokens,
      all_tokens,
      sparse_indices_out);
  return sparse_indices_out;
}

at::Tensor QuantLightningIndexerC8OutMeta(
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    const at::Tensor&,
    at::Tensor sparse_indices_out) {
  return sparse_indices_out;
}

}  // namespace nanovllm_dsa_a5_impl

TORCH_LIBRARY_IMPL(nanovllm_dsa, PrivateUse1, m) {
  m.impl(
      "quant_lightning_indexer_c8_out",
      &nanovllm_dsa_a5_impl::QuantLightningIndexerC8OutNpu);
}

TORCH_LIBRARY_IMPL(nanovllm_dsa, Meta, m) {
  m.impl(
      "quant_lightning_indexer_c8_out",
      &nanovllm_dsa_a5_impl::QuantLightningIndexerC8OutMeta);
}
