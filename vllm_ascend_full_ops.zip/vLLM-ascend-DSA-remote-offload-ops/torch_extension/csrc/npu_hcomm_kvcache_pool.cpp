#include <hcomm/hcomm_res.h>

#include <cstdint>
#include <array>
#include <cstring>
#include <memory>
#include <mutex>
#include <string>
#include <utility>
#include <vector>

#include <charconv>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <torch/extension.h>
#include <unistd.h>

#include "../../hcomm_kernel/kvcache_scatter_copy_hcomm_args.h"
#include "../../hcomm_kernel/raw_ub_hybrid_protocol.h"

namespace custom {
namespace {

constexpr uint64_t kStagingBlockBytes = kRawUbBlockBytes;

struct HcommPoolConnection {
    EndpointHandle endpoint = nullptr;
    ChannelHandle channel = 0;
    ThreadHandle aicpuThread = 0;
    std::array<ChannelHandle, kHcommScatterMaxLanes> channels{};
    std::array<ThreadHandle, kHcommScatterMaxLanes> aicpuThreads{};
    uint64_t laneCount = 0;
    uint64_t poolGva = 0;
    uint64_t poolBytes = 0;
    at::Tensor hbmStaging;
    at::Tensor profileRing;
    uint64_t hbmStagingBlocks = 0;
    HcommMemHandle hbmStagingHandle = nullptr;
    std::array<HcommMemHandle, 3> registeredMems{};
    uint32_t registeredMemCount = 0;
    uint64_t stagingGva = 0;
    uint64_t commandGva = 0;
    void* deviceControl = nullptr;
    uint64_t commandSlots = 0;
    uint64_t hostPushPercent = 50;
    uint64_t hostTokenGather = 0;
    uint64_t scatterAfterGather = 1;
    uint64_t deferCompletionToAttention = 0;
    uint64_t ioBytes = kRawUbTokenBytes;
    uint64_t nextGeneration = 1;
    uint64_t lastScatterGeneration = 0;
};

std::mutex& PoolConnectionMutex()
{
    static std::mutex mutex;
    return mutex;
}

std::vector<std::unique_ptr<HcommPoolConnection>>& PoolConnections()
{
    static std::vector<std::unique_ptr<HcommPoolConnection>> connections;
    return connections;
}

bool SetEid(CommAddr* address, const std::string& eid)
{
    const bool compact = eid.size() == 32;
    if (!compact && (eid.size() != 33 || eid[16] != ':')) return false;
    for (size_t index = 0; index < 16; ++index) {
        const auto begin = eid.data() + index * 2 + (!compact && index >= 8 ? 1 : 0);
        unsigned int byte = 0;
        const auto parsed = std::from_chars(begin, begin + 2, byte, 16);
        if (parsed.ec != std::errc{} || parsed.ptr != begin + 2) return false;
        address->eid[index] = static_cast<uint8_t>(byte);
    }
    address->type = COMM_ADDR_TYPE_EID;
    return true;
}

void ReceiveAll(int fd, void* data, size_t bytes)
{
    auto* cursor = static_cast<uint8_t*>(data);
    while (bytes != 0) {
        const ssize_t received = recv(fd, cursor, bytes, 0);
        TORCH_CHECK(received > 0, "raw URMA pool closed its control connection.");
        cursor += received;
        bytes -= static_cast<size_t>(received);
    }
}

void SendAll(int fd, const void* data, size_t bytes)
{
    const auto* cursor = static_cast<const uint8_t*>(data);
    while (bytes != 0) {
        const ssize_t sent = send(fd, cursor, bytes, MSG_NOSIGNAL);
        TORCH_CHECK(sent > 0, "raw URMA pool closed its control connection.");
        cursor += sent;
        bytes -= static_cast<size_t>(sent);
    }
}

HcommMemHandle RegisterHbm(EndpointHandle endpoint, const char* tag, const at::Tensor& tensor)
{
    CommMem memory{COMM_MEM_TYPE_DEVICE, tensor.data_ptr(), static_cast<uint64_t>(tensor.nbytes())};
    HcommMemHandle handle = nullptr;
    TORCH_CHECK(HcommMemReg(endpoint, tag, &memory, &handle) == 0, "HcommMemReg failed.");
    return handle;
}

} // namespace

uint64_t npu_hcomm_kvcache_pool_connect(const std::string& deviceEid, const std::string& hostEid,
    int64_t devicePhyId, int64_t port, const std::string& channelName)
{
    TORCH_CHECK(devicePhyId >= 0 && devicePhyId <= UINT32_MAX, "device_phy_id must be a uint32.");
    TORCH_CHECK(port > 0 && port <= UINT16_MAX, "port must be in [1, 65535].");

    EndpointDesc local{};
    EndpointDesc remote{};
    TORCH_CHECK(EndpointDescInit(&local, 1) == 0 && EndpointDescInit(&remote, 1) == 0,
        "failed to initialize Hcomm endpoint descriptions.");
    local.protocol = COMM_PROTOCOL_UBC_TP;
    local.loc.locType = ENDPOINT_LOC_TYPE_DEVICE;
    local.loc.device.devPhyId = static_cast<uint32_t>(devicePhyId);
    remote.protocol = COMM_PROTOCOL_UBC_TP;
    remote.loc.locType = ENDPOINT_LOC_TYPE_HOST;
    remote.loc.host.id = 0;
    TORCH_CHECK(SetEid(&local.commAddr, deviceEid), "device_eid must contain 32 hexadecimal digits.");
    TORCH_CHECK(SetEid(&remote.commAddr, hostEid), "host_eid must contain 32 hexadecimal digits.");

    HcommChannelDesc channelDesc{};
    TORCH_CHECK(HcommChannelDescInit(&channelDesc, 1) == 0,
        "failed to initialize the Hcomm channel description.");
    channelDesc.remoteEndpoint = remote;
    channelDesc.exchangeAllMems = true;
    channelDesc.role = HCOMM_SOCKET_ROLE_CLIENT;
    channelDesc.port = static_cast<uint16_t>(port);
    channelDesc.channelName = channelName.c_str();
    channelDesc.ubAttr.sqDepth = 64;

    auto connection = std::make_unique<HcommPoolConnection>();
    HcommResult result = HcommEndpointCreate(&local, &connection->endpoint);
    TORCH_CHECK(result == 0, "HcommEndpointCreate failed: ", result);
    result = HcommChannelCreate(connection->endpoint, COMM_ENGINE_AICPU, &channelDesc, 1,
        &connection->channel);
    TORCH_CHECK(result == 0, "HcommChannelCreate failed: ", result);

    const uint64_t channel = connection->channel;
    std::lock_guard<std::mutex> lock(PoolConnectionMutex());
    PoolConnections().emplace_back(std::move(connection));
    return channel;
}

uint64_t npu_hcomm_kvcache_pool_connect_raw(const std::string& deviceEid, int64_t devicePhyId,
    const std::string& poolIp, int64_t controlPort, const at::Tensor& hbmKpe, const at::Tensor& hbmCkv,
    int64_t laneCount, int64_t hostPushPercent, bool hostTokenGather,
    bool scatterAfterGather, bool deferCompletionToAttention, int64_t ioBytes,
    int64_t maxSubIosPerWqe, int64_t fixedWqeBytes)
{
    TORCH_CHECK(devicePhyId >= 0 && devicePhyId <= UINT32_MAX, "device_phy_id must be a uint32.");
    TORCH_CHECK(controlPort > 0 && controlPort <= UINT16_MAX, "control_port must be in [1, 65535].");
    TORCH_CHECK(laneCount > 0 && laneCount <= static_cast<int64_t>(kHcommScatterMaxLanes),
        "lane_count must be in [1, ", kHcommScatterMaxLanes, "].");
    TORCH_CHECK(hostPushPercent >= 0 && hostPushPercent <= 100,
        "host_push_percent must be in [0, 100].");
    TORCH_CHECK(!hostTokenGather || hostPushPercent == 100,
        "host_token_gather currently requires host_push_percent=100.");
    TORCH_CHECK(ioBytes == kRawUbTokenBytes ||
        ioBytes == kRawUbFlatFp8TokenBytes || ioBytes == kRawUbFlatC8TokenBytes,
        "io_bytes must be 576, 656, or 1152.");
    TORCH_CHECK(hostTokenGather || ioBytes == kRawUbTokenBytes,
        "576/656-byte IO currently requires host_token_gather=true.");
    TORCH_CHECK(
        !deferCompletionToAttention ||
            (hostTokenGather && !scatterAfterGather),
        "defer_completion_to_attention requires token gather without "
        "AICPU scatter.");
    TORCH_CHECK(
        !deferCompletionToAttention ||
            ioBytes == kRawUbTokenBytes ||
            ioBytes == kRawUbFlatC8TokenBytes,
        "deferred completion currently supports io_bytes=656 or 1152.");
    TORCH_CHECK(maxSubIosPerWqe >= 0 &&
        maxSubIosPerWqe <= kRawUbAggregationFieldMask,
        "max_subios_per_wqe must be in [0, ",
        kRawUbAggregationFieldMask, "].");
    TORCH_CHECK(fixedWqeBytes >= 0 &&
        fixedWqeBytes / kRawUbFixedWqeUnitBytes <= kRawUbAggregationFieldMask,
        "fixed_wqe_bytes is too large for the raw control protocol.");
    TORCH_CHECK(fixedWqeBytes == 0 || maxSubIosPerWqe != 0,
        "fixed_wqe_bytes requires max_subios_per_wqe > 0.");
    TORCH_CHECK(fixedWqeBytes == 0 || fixedWqeBytes % 64 == 0,
        "fixed_wqe_bytes must be zero or a multiple of 64.");
    if (fixedWqeBytes != 0) {
        const uint64_t maxSubIos = static_cast<uint64_t>(maxSubIosPerWqe);
        const uint64_t maxPayloadBytes = ioBytes == kRawUbTokenBytes ?
            ((maxSubIos + 1) / 2) * kRawUbCkvTokenBytes +
                (maxSubIos / 2) * kRawUbKpeTokenBytes :
            maxSubIos * static_cast<uint64_t>(ioBytes);
        TORCH_CHECK(maxPayloadBytes <= static_cast<uint64_t>(fixedWqeBytes),
            "fixed_wqe_bytes is smaller than the largest capped WQE payload (",
            maxPayloadBytes, " bytes).");
    }

    int fd = socket(AF_INET, SOCK_STREAM, 0);
    sockaddr_in address{};
    address.sin_family = AF_INET;
    address.sin_port = htons(static_cast<uint16_t>(controlPort));
    TORCH_CHECK(inet_pton(AF_INET, poolIp.c_str(), &address.sin_addr) == 1, "pool_ip must be IPv4.");
    TORCH_CHECK(connect(fd, reinterpret_cast<const sockaddr*>(&address), sizeof(address)) == 0,
        "cannot connect to raw URMA pool control port.");

    const RawUbControlRequest request{kRawUbControlMagic, kRawUbControlVersion,
        static_cast<uint32_t>(laneCount),
        PackRawUbAggregationConfig(static_cast<uint32_t>(maxSubIosPerWqe),
            static_cast<uint32_t>(fixedWqeBytes))};
    SendAll(fd, &request, sizeof(request));
    RawUbControlResponse response{};
    ReceiveAll(fd, &response, sizeof(response));
    TORCH_CHECK(response.magic == kRawUbControlMagic && response.version == kRawUbControlVersion &&
        response.laneCount == static_cast<uint32_t>(laneCount), "raw URMA pool returned invalid lane descriptors.");
    TORCH_CHECK(response.commandSlots != 0 && response.commandSlots <= kRawUbCommandSlots &&
        response.commandStride == kRawUbCommandSlotBytes,
        "raw URMA pool returned an invalid command-ring layout.");
    std::array<RawUbPeerDescriptor, kHcommScatterMaxLanes> wireDescriptors{};
    std::array<HcommRawUbPeerDesc, kHcommScatterMaxLanes> descriptors{};
    static_assert(sizeof(wireDescriptors[0]) == sizeof(descriptors[0]));
    ReceiveAll(fd, wireDescriptors.data(), static_cast<size_t>(laneCount) * sizeof(wireDescriptors[0]));
    std::memcpy(descriptors.data(), wireDescriptors.data(),
        static_cast<size_t>(laneCount) * sizeof(descriptors[0]));

    EndpointDesc local{};
    TORCH_CHECK(EndpointDescInit(&local, 1) == 0, "failed to initialize Hcomm endpoint description.");
    local.protocol = COMM_PROTOCOL_UBC_CTP;
    local.loc.locType = ENDPOINT_LOC_TYPE_DEVICE;
    local.loc.device.devPhyId = static_cast<uint32_t>(devicePhyId);
    TORCH_CHECK(SetEid(&local.commAddr, deviceEid), "device_eid must contain 32 hexadecimal digits.");

    auto connection = std::make_unique<HcommPoolConnection>();
    HcommResult result = HcommEndpointCreate(&local, &connection->endpoint);
    TORCH_CHECK(result == 0, "HcommEndpointCreate failed: ", result);
    connection->hbmStagingBlocks = static_cast<uint64_t>(hbmKpe.size(0));
    const uint64_t stagingBytes = connection->hbmStagingBlocks * kStagingBlockBytes;
    connection->hbmStaging = at::empty(
        {static_cast<int64_t>(stagingBytes + kRawUbDeviceControlBytes)},
        hbmKpe.options().dtype(at::kByte));
    connection->profileRing = at::zeros(
        {static_cast<int64_t>(kHcommProfileSlots * sizeof(HcommKvcacheProfileRecord))},
        hbmKpe.options().dtype(at::kByte));
    connection->registeredMems[connection->registeredMemCount++] =
        RegisterHbm(connection->endpoint, "kvcache_kpe", hbmKpe);
    // Packed C8 uses one tensor for both legacy arguments.  Register that
    // storage once; with scatter_after_gather=false AICPU never writes it.
    if (hbmCkv.data_ptr() != hbmKpe.data_ptr()) {
        connection->registeredMems[connection->registeredMemCount++] =
            RegisterHbm(connection->endpoint, "kvcache_ckv", hbmCkv);
    }
    connection->hbmStagingHandle =
        RegisterHbm(connection->endpoint, "kvcache_staging", connection->hbmStaging);
    connection->registeredMems[connection->registeredMemCount++] =
        connection->hbmStagingHandle;
    const uint32_t notifyNum = 0;
    connection->laneCount = static_cast<uint64_t>(laneCount);
    for (uint64_t lane = 0; lane < connection->laneCount; ++lane) {
        result = HcommRawUbChannelCreate(connection->endpoint, &descriptors[lane], &connection->channels[lane]);
        TORCH_CHECK(result == 0, "HcommRawUbChannelCreate failed: ", result);
        result = HcommThreadAlloc(COMM_ENGINE_AICPU, 1, &notifyNum, &connection->aicpuThreads[lane]);
        TORCH_CHECK(result == 0, "HcommThreadAlloc(AICPU) failed: ", result);
    }
    connection->channel = connection->channels[0];
    connection->aicpuThread = connection->aicpuThreads[0];
    connection->poolGva = response.dataGva;
    connection->poolBytes = response.dataBytes;
    connection->commandGva = response.commandGva;
    connection->commandSlots = response.commandSlots;
    connection->hostPushPercent = static_cast<uint64_t>(hostPushPercent);
    connection->hostTokenGather = hostTokenGather ? 1 : 0;
    connection->scatterAfterGather = scatterAfterGather ? 1 : 0;
    connection->deferCompletionToAttention =
        deferCompletionToAttention ? 1 : 0;
    connection->ioBytes = static_cast<uint64_t>(ioBytes);

    HcommRawUbLocalMemDesc stagingDesc{};
    result = HcommRawUbLocalMemExport(connection->hbmStagingHandle, &stagingDesc);
    TORCH_CHECK(result == 0, "HcommRawUbLocalMemExport(staging) failed: ", result);
    connection->stagingGva = stagingDesc.gva;
    connection->deviceControl = static_cast<uint8_t*>(connection->hbmStaging.data_ptr()) + stagingBytes;

    RawUbClientResources clientResources{};
    clientResources.magic = kRawUbControlMagic;
    clientResources.version = kRawUbControlVersion;
    clientResources.laneCount = static_cast<uint32_t>(laneCount);
    clientResources.stagingGva = stagingDesc.gva;
    clientResources.stagingBytes = stagingBytes;
    clientResources.deviceControlGva = stagingDesc.gva + stagingBytes;
    clientResources.deviceControlBytes = kRawUbDeviceControlBytes;
    static_assert(sizeof(clientResources.stagingSegment) == sizeof(stagingDesc));
    std::memcpy(&clientResources.stagingSegment, &stagingDesc, sizeof(stagingDesc));
    for (uint64_t lane = 0; lane < connection->laneCount; ++lane) {
        HcommRawUbLocalPeerDesc peer{};
        result = HcommRawUbLocalPeerExport(connection->channels[lane], &peer);
        TORCH_CHECK(result == 0, "HcommRawUbLocalPeerExport failed: ", result);
        static_assert(sizeof(clientResources.peers[lane]) == sizeof(peer));
        std::memcpy(&clientResources.peers[lane], &peer, sizeof(peer));
    }
    SendAll(fd, &clientResources, sizeof(clientResources));
    RawUbControlAck ack{};
    ReceiveAll(fd, &ack, sizeof(ack));
    TORCH_CHECK(ack.magic == kRawUbControlMagic && ack.version == kRawUbControlVersion &&
        ack.status == 0, "raw URMA pool failed to import NPU resources.");
    close(fd);

    const uint64_t peer = connection->channel;
    std::lock_guard<std::mutex> lock(PoolConnectionMutex());
    PoolConnections().emplace_back(std::move(connection));
    return peer;
}

uint64_t npu_hcomm_kvcache_pool_connect_raw_packed(
    const std::string& deviceEid, int64_t devicePhyId,
    const std::string& poolIp, int64_t controlPort,
    const at::Tensor& packedHbmKv, int64_t laneCount,
    int64_t hostPushPercent, bool deferCompletionToAiv,
    int64_t maxSubIosPerWqe, int64_t fixedWqeBytes)
{
    TORCH_CHECK(
        packedHbmKv.defined() && packedHbmKv.dim() == 4 &&
            packedHbmKv.size(0) > 0 && packedHbmKv.size(1) == 128 &&
            packedHbmKv.size(2) == 1 &&
            packedHbmKv.size(3) == kRawUbFlatC8TokenBytes &&
            packedHbmKv.element_size() == 1 &&
            packedHbmKv.is_contiguous(),
        "packed_hbm_kv must be a contiguous one-byte tensor "
        "[blocks,128,1,656].");
    return npu_hcomm_kvcache_pool_connect_raw(
        deviceEid, devicePhyId, poolIp, controlPort,
        packedHbmKv, packedHbmKv, laneCount, hostPushPercent,
        true, false, deferCompletionToAiv, kRawUbFlatC8TokenBytes,
        maxSubIosPerWqe, fixedWqeBytes);
}

bool npu_hcomm_kvcache_pool_disconnect_raw(uint64_t channel)
{
    std::unique_ptr<HcommPoolConnection> connection;
    {
        std::lock_guard<std::mutex> lock(PoolConnectionMutex());
        auto& connections = PoolConnections();
        for (auto it = connections.begin(); it != connections.end(); ++it) {
            if ((*it)->channel == channel && (*it)->laneCount != 0) {
                connection = std::move(*it);
                connections.erase(it);
                break;
            }
        }
    }
    if (connection == nullptr) return false;

    HcommResult firstError = 0;
    auto recordError = [&firstError](HcommResult result) {
        if (firstError == 0 && result != 0) firstError = result;
    };

    const uint32_t laneCount = static_cast<uint32_t>(connection->laneCount);
    recordError(HcommThreadFree(connection->aicpuThreads.data(), laneCount));
    recordError(HcommChannelDestroy(connection->channels.data(), laneCount));
    for (uint32_t index = connection->registeredMemCount; index > 0; --index) {
        recordError(HcommMemUnreg(
            connection->endpoint, connection->registeredMems[index - 1]));
    }
    recordError(HcommEndpointDestroy(connection->endpoint));

    TORCH_CHECK(firstError == 0,
        "failed to disconnect raw Hcomm pool: ", firstError);
    return true;
}

bool npu_hcomm_kvcache_pool_get_default_hybrid_context(HcommRawScatterRuntimeContext& context)
{
    std::lock_guard<std::mutex> lock(PoolConnectionMutex());
    for (auto it = PoolConnections().rbegin(); it != PoolConnections().rend(); ++it) {
        auto& connection = **it;
        if (connection.laneCount == 0 || connection.deviceControl == nullptr ||
            connection.stagingGva == 0 || connection.commandGva == 0) {
            continue;
        }
        context = {};
        context.hbmStaging = connection.hbmStaging.data_ptr();
        context.hbmStagingBlocks = connection.hbmStagingBlocks;
        context.stagingGva = connection.stagingGva;
        context.commandGva = connection.commandGva;
        context.deviceControl = connection.deviceControl;
        context.generation = connection.nextGeneration++;
        context.hostPushPercent = connection.hostPushPercent;
        context.hostTokenGather = connection.hostTokenGather;
        context.scatterAfterGather = connection.scatterAfterGather;
        context.deferCompletionToAttention =
            connection.deferCompletionToAttention;
        context.ioBytes = connection.ioBytes;
        context.commandSlots = connection.commandSlots;
        context.laneCount = connection.laneCount;
        context.profileRing = reinterpret_cast<HcommKvcacheProfileRecord*>(
            connection.profileRing.data_ptr());
        context.profileSlots = kHcommProfileSlots;
        for (uint64_t lane = 0; lane < connection.laneCount; ++lane) {
            context.laneThreads[lane] = connection.aicpuThreads[lane];
            context.laneChannels[lane] = connection.channels[lane];
        }
        return true;
    }
    return false;
}

void npu_hcomm_kvcache_pool_mark_remote_attention_submission(
    uint64_t generation)
{
    std::lock_guard<std::mutex> lock(PoolConnectionMutex());
    for (auto it = PoolConnections().rbegin();
         it != PoolConnections().rend(); ++it) {
        auto& connection = **it;
        if (connection.hostTokenGather != 0 &&
            connection.scatterAfterGather == 0 &&
            connection.deferCompletionToAttention != 0 &&
            connection.nextGeneration == generation + 1) {
            connection.lastScatterGeneration = generation;
            return;
        }
    }
    TORCH_CHECK(false, "raw Hcomm generation does not belong to the active token-gather connection.");
}

bool npu_hcomm_kvcache_pool_get_default_remote_attention_context(
    at::Tensor& staging, at::Tensor& completion,
    uint64_t& generation)
{
    std::lock_guard<std::mutex> lock(PoolConnectionMutex());
    for (auto it = PoolConnections().rbegin();
         it != PoolConnections().rend(); ++it) {
        auto& connection = **it;
        if (connection.lastScatterGeneration == 0 ||
            connection.hostTokenGather == 0 ||
            connection.scatterAfterGather != 0 ||
            connection.deferCompletionToAttention == 0) {
            continue;
        }
        const int64_t stagingBytes = static_cast<int64_t>(
            connection.hbmStagingBlocks * kStagingBlockBytes);
        const uint64_t slot =
            (connection.lastScatterGeneration - 1) %
            connection.commandSlots;
        const int64_t completionOffset =
            stagingBytes + kRawUbCommandSlotBytes +
            static_cast<int64_t>(
                slot * kRawUbCompletionStride);
        staging = connection.hbmStaging.narrow(
            0, 0, stagingBytes);
        completion = connection.hbmStaging.narrow(
            0, completionOffset, kRawUbCompletionStride);
        generation = connection.lastScatterGeneration;
        connection.lastScatterGeneration = 0;
        return true;
    }
    return false;
}

std::vector<uint64_t> npu_hcomm_kvcache_pool_get_raw_context(uint64_t channel)
{
    std::lock_guard<std::mutex> lock(PoolConnectionMutex());
    for (const auto& connection : PoolConnections()) {
        if (connection->channel == channel) {
            return {
                connection->channel,
                connection->aicpuThread,
                connection->poolGva,
                connection->poolBytes,
            };
        }
    }
    TORCH_CHECK(false, "unknown raw Hcomm channel.");
    return {};
}

at::Tensor npu_hcomm_kvcache_pool_get_profile(uint64_t channel)
{
    std::lock_guard<std::mutex> lock(PoolConnectionMutex());
    for (const auto& connection : PoolConnections()) {
        if (connection->channel == channel) return connection->profileRing;
    }
    TORCH_CHECK(false, "unknown raw Hcomm channel.");
    return {};
}

at::Tensor npu_hcomm_kvcache_pool_get_staging(uint64_t channel)
{
    std::lock_guard<std::mutex> lock(PoolConnectionMutex());
    for (const auto& connection : PoolConnections()) {
        if (connection->channel == channel) {
            const int64_t bytes = static_cast<int64_t>(
                connection->hbmStagingBlocks * kStagingBlockBytes);
            return connection->hbmStaging.narrow(0, 0, bytes);
        }
    }
    TORCH_CHECK(false, "unknown raw Hcomm channel.");
    return {};
}

at::Tensor npu_hcomm_kvcache_pool_get_next_completion(uint64_t channel)
{
    std::lock_guard<std::mutex> lock(PoolConnectionMutex());
    for (const auto& connection : PoolConnections()) {
        if (connection->channel == channel) {
            const int64_t stagingBytes = static_cast<int64_t>(
                connection->hbmStagingBlocks * kStagingBlockBytes);
            const uint64_t slot =
                (connection->nextGeneration - 1) %
                connection->commandSlots;
            const int64_t completionOffset =
                stagingBytes + kRawUbCommandSlotBytes +
                static_cast<int64_t>(
                    slot * kRawUbCompletionStride);
            return connection->hbmStaging.narrow(
                0, completionOffset, kRawUbCompletionStride);
        }
    }
    TORCH_CHECK(false, "unknown raw Hcomm channel.");
    return {};
}

bool npu_hcomm_kvcache_pool_get_default_raw_context(uint64_t& channel, uint64_t& aicpuThread,
    void*& hbmStaging, uint64_t& hbmStagingBlocks)
{
    std::lock_guard<std::mutex> lock(PoolConnectionMutex());
    // The PoC uses the most recently created raw connection.  Multi-pool
    // selection belongs above this operator and can replace this policy later.
    for (auto it = PoolConnections().rbegin(); it != PoolConnections().rend(); ++it) {
        if ((*it)->channel != 0 && (*it)->aicpuThread != 0 && (*it)->hbmStaging.defined()) {
            channel = (*it)->channel;
            aicpuThread = (*it)->aicpuThread;
            hbmStaging = (*it)->hbmStaging.data_ptr();
            hbmStagingBlocks = (*it)->hbmStagingBlocks;
            return true;
        }
    }
    return false;
}

bool npu_hcomm_kvcache_pool_get_default_raw_lanes(
    std::array<uint64_t, kHcommScatterMaxLanes>& channels,
    std::array<uint64_t, kHcommScatterMaxLanes>& threads, uint64_t& laneCount)
{
    std::lock_guard<std::mutex> lock(PoolConnectionMutex());
    for (auto it = PoolConnections().rbegin(); it != PoolConnections().rend(); ++it) {
        if ((*it)->laneCount != 0) {
            channels = (*it)->channels;
            threads = (*it)->aicpuThreads;
            laneCount = (*it)->laneCount;
            return true;
        }
    }
    return false;
}

bool npu_hcomm_kvcache_pool_get_default_raw_context(uint64_t& channel, uint64_t& aicpuThread)
{
    void* hbmStaging = nullptr;
    uint64_t hbmStagingBlocks = 0;
    return npu_hcomm_kvcache_pool_get_default_raw_context(
        channel, aicpuThread, hbmStaging, hbmStagingBlocks);
}

} // namespace custom
