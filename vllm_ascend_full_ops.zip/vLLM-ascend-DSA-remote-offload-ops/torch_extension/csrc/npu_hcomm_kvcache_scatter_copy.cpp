#include <acl/acl.h>

#include <cstdlib>
#include <array>
#include <torch/extension.h>

#include "ops_common.h"
#include "../../hcomm_kernel/kvcache_scatter_copy_hcomm_args.h"
#include "../../hcomm_kernel/raw_ub_hybrid_protocol.h"

namespace custom {
bool npu_hcomm_kvcache_pool_get_default_hybrid_context(HcommRawScatterRuntimeContext& context);
void npu_hcomm_kvcache_pool_mark_remote_attention_submission(
    uint64_t generation);

namespace {

aclrtFuncHandle GetScatterCopyKernel()
{
    static aclrtBinHandle binary = nullptr;
    static aclrtFuncHandle function = nullptr;
    if (function == nullptr) {
        const char* json = std::getenv("HCOMM_KVCACHE_SCATTER_COPY_JSON");
        if (json == nullptr) {
            json = "/usr/local/Ascend/cann/opp/built-in/op_impl/aicpu/config/ccl_kernel.json";
        }
        aclrtBinaryLoadOption option{};
        option.type = ACL_RT_BINARY_LOAD_OPT_CPU_KERNEL_MODE;
        option.value.cpuKernelMode = 0;
        aclrtBinaryLoadOptions options{};
        options.numOpt = 1;
        options.options = &option;
        aclError result = aclrtBinaryLoadFromFile(json, &options, &binary);
        TORCH_CHECK(result == ACL_SUCCESS, "aclrtBinaryLoadFromFile failed for ", json, ": ", result);
        result = aclrtBinaryGetFunction(binary, "HcommKvcacheScatterCopy", &function);
        TORCH_CHECK(result == ACL_SUCCESS, "aclrtBinaryGetFunction(HcommKvcacheScatterCopy) failed: ", result);
    }
    return function;
}

void Append(aclrtArgsHandle args, HcommKvcacheScatterCopyArgs& value)
{
    aclrtParamHandle parameter;
    const aclError result = aclrtKernelArgsAppend(args, &value, sizeof(value), &parameter);
    TORCH_CHECK(result == ACL_SUCCESS, "aclrtKernelArgsAppend(HcommKvcacheScatterCopy) failed: ", result);
}

} // namespace

static void LaunchScatterCopy(
    const at::Tensor& hbmKpe, const at::Tensor& hbmCkv,
    const at::Tensor& hbmBlockTable, const at::Tensor& dramBlockTable,
    const at::Tensor& srcTokenIds, const at::Tensor& dstSlots, const at::Tensor& copyCounts,
    const at::Tensor& readyFlag, int64_t layerId, bool localOnly,
    bool requireIoOnly)
{
    // The current raw-Hcomm path receives a layer-local dram block-table view.
    // Keep this public argument for the future full [B, L, max_blocks] table.
    (void)layerId;

    HcommRawScatterRuntimeContext context{};
    TORCH_CHECK(npu_hcomm_kvcache_pool_get_default_hybrid_context(context),
        "no raw Hcomm connection in this Python process");
    if (requireIoOnly) {
        TORCH_CHECK(
            context.hostTokenGather != 0 &&
                context.scatterAfterGather == 0 &&
                context.ioBytes == kRawUbFlatC8TokenBytes,
            "npu_hcomm_kvcache_io requires host token gather with "
            "scatter_after_gather=false and io_bytes=656; "
            "AICPU scatter is forbidden.");
    }

    HcommKvcacheScatterCopyArgs params{
        hbmKpe.data_ptr(), hbmCkv.data_ptr(), context.hbmStaging,
        hbmBlockTable.data_ptr<int32_t>(), dramBlockTable.data_ptr<uint64_t>(),
        srcTokenIds.data_ptr<int32_t>(), dstSlots.data_ptr<int32_t>(), copyCounts.data_ptr<int32_t>(),
        readyFlag.data_ptr<int32_t>(), context.laneThreads[0], context.laneChannels[0],
        static_cast<uint64_t>(hbmKpe.size(0)), context.hbmStagingBlocks,
        static_cast<uint64_t>(hbmBlockTable.size(1)),
        static_cast<uint64_t>(dramBlockTable.size(1)), static_cast<uint64_t>(copyCounts.size(0)),
        context.laneCount, {}, {}, context.stagingGva, context.commandGva, context.deviceControl,
        context.generation, context.hostPushPercent, context.commandSlots,
        localOnly ? 1ULL : 0ULL, context.profileRing, context.profileSlots,
        context.hostTokenGather, context.scatterAfterGather,
        context.deferCompletionToAttention, context.ioBytes};
    for (uint64_t lane = 0; lane < context.laneCount; ++lane) {
        params.laneThreads[lane] = context.laneThreads[lane];
        params.laneChannels[lane] = context.laneChannels[lane];
    }

    aclrtArgsHandle args = nullptr;
    aclrtFuncHandle function = GetScatterCopyKernel();
    aclError result = aclrtKernelArgsInit(function, &args);
    TORCH_CHECK(result == ACL_SUCCESS, "aclrtKernelArgsInit(HcommKvcacheScatterCopy) failed: ", result);
    Append(args, params);
    result = aclrtKernelArgsFinalize(args);
    TORCH_CHECK(result == ACL_SUCCESS, "aclrtKernelArgsFinalize(HcommKvcacheScatterCopy) failed: ", result);
    aclrtLaunchKernelAttr attribute{};
    attribute.id = ACL_RT_LAUNCH_KERNEL_ATTR_TIMEOUT;
    attribute.value.timeout = 30;
    aclrtLaunchKernelCfg config{};
    config.numAttrs = 1;
    config.attrs = &attribute;
    result = aclrtLaunchKernelWithConfig(function, 1, c10_npu::getCurrentNPUStream().stream(true),
        &config, args, nullptr);
    TORCH_CHECK(result == ACL_SUCCESS, "aclrtLaunchKernelWithConfig(HcommKvcacheScatterCopy) failed: ", result);
    if (!localOnly && context.hostTokenGather != 0 &&
        context.scatterAfterGather == 0 &&
        context.deferCompletionToAttention != 0) {
        npu_hcomm_kvcache_pool_mark_remote_attention_submission(
            context.generation);
    }
}

void npu_hcomm_kvcache_scatter_copy(
    const at::Tensor& hbmKpe, const at::Tensor& hbmCkv,
    const at::Tensor& hbmBlockTable, const at::Tensor& dramBlockTable,
    const at::Tensor& srcTokenIds, const at::Tensor& dstSlots, const at::Tensor& copyCounts,
    const at::Tensor& readyFlag, int64_t layerId)
{
    LaunchScatterCopy(hbmKpe, hbmCkv, hbmBlockTable, dramBlockTable,
        srcTokenIds, dstSlots, copyCounts, readyFlag, layerId, false, false);
}

void npu_hcomm_kvcache_io(
    const at::Tensor& packedHbmKv,
    const at::Tensor& hbmBlockTable,
    const at::Tensor& dramBlockTable,
    const at::Tensor& srcTokenIds,
    const at::Tensor& dstSlots,
    const at::Tensor& copyCounts,
    const at::Tensor& readyFlag,
    int64_t layerId)
{
    TORCH_CHECK(
        packedHbmKv.defined() && packedHbmKv.dim() == 4 &&
            packedHbmKv.size(0) > 0 && packedHbmKv.size(1) == 128 &&
            packedHbmKv.size(2) == 1 &&
            packedHbmKv.size(3) == kRawUbFlatC8TokenBytes &&
            packedHbmKv.element_size() == 1 &&
            packedHbmKv.is_contiguous(),
        "packed_hbm_kv must be a contiguous one-byte tensor "
        "[blocks,128,1,656].");
    LaunchScatterCopy(
        packedHbmKv, packedHbmKv, hbmBlockTable, dramBlockTable,
        srcTokenIds, dstSlots, copyCounts, readyFlag, layerId,
        false, true);
}

void npu_hcomm_kvcache_local_scatter(
    const at::Tensor& hbmKpe, const at::Tensor& hbmCkv,
    const at::Tensor& hbmBlockTable, const at::Tensor& dramBlockTable,
    const at::Tensor& srcTokenIds, const at::Tensor& dstSlots, const at::Tensor& copyCounts,
    const at::Tensor& readyFlag, int64_t layerId)
{
    LaunchScatterCopy(hbmKpe, hbmCkv, hbmBlockTable, dramBlockTable,
        srcTokenIds, dstSlots, copyCounts, readyFlag, layerId, true, false);
}

} // namespace custom
